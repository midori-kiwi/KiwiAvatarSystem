# KiwiAvatarSystem Chat Permanent Report

ChatTopic: Native Provenance / PowerShell 5.1 Foundation / Workflow Consolidation
ChatTitle: v44.55.12 Native Original Package Provenance Closure + PowerShell Foundation
ArchiveName: KiwiChat_NativeProvenanceAndPowerShellFoundation_Updated_20260902-0026-JST.zip
LastWorkUpdate: 2026-09-02 00:26:43 JST
LastWorkUpdatePrecision: DATE_TIME
ArchiveCreated: 2026-09-02 23:22 JST
ArchiveTimestampBasis: LAST_RELEVANT_WORK_BEFORE_ARCHIVE_REQUEST
Project: D:\KiwiAvatarSystem
Unity: 6000.0.80f1 / Windows / DX12
CurrentInvestigationVersion: v44.55.12 Original Package Provenance Audit
Status: DONE
LocalProductionVerification: LOCAL_PRODUCTION_NOT_DIRECTLY_VERIFIED_IN_NORMAL_CHAT
LocalProductionEvidence: Verified through Codex consolidated reports, user-executed validators/audits, and exact SHA records included below.

---

## EXECUTIVE SUMMARY

This chat completed the Native provenance recovery work that began after v44.55.17 rejected `PRESENTATION_PLUS_FINAL_UNORM8 mode2` as semantically equivalent to `CURRENT_FLOAT`.

The work first corrected v44.55.16/v44.55.17 observer/validator issues, then moved to Native provenance because any future Native/CPU preprocessing change required a trusted source → build → artifact chain.

A first provenance auditor found:

- current critical Production SHA values matched the expected authority set;
- current Interop and Production Native DLL had ABI parity;
- no current `.vcxproj` existed for the v44.55.12 Native DLL;
- one historical DLL copy exactly matched the current Production DLL;
- current Native source was marked as a reconstructed candidate.

A PowerShell 5.1 `Generic.List` binder failure was then reproduced in the audit tooling. The immediate script was fixed with `::new()` + `.ToArray()`, and Codex subsequently implemented a common Windows PowerShell 5.1 compatibility/safety foundation across the repository.

Historical-context recovery located the exact Production DLL in the v44.55.12 standalone build. Codex then audited local files and recovered the original v44.55.12 package, including the Native source, Interop, build/install scripts, DLL, OBJ, EXP, LIB and build logs.

Final provenance decision for this chat:

**Provenance Class B — Strongly Supported**

The package Native source is byte-identical to current Production Native source; package Interop is byte-identical to current Production Interop; package DLL is byte-identical to the current Production DLL and the historical v44.55.12 standalone DLL. OBJ/EXP/toolchain/timeline evidence strongly correlates the source change with the binary.

Class A was not assigned because the complete historical SDK/header/environment inputs were not cryptographically sealed, the build was not deterministic `/Brepro`, and no trusted external build attestation/signature exists.

No Production, Native, Tracking or Runtime behavior was modified by the final provenance audit.

This chat also established a lasting workflow split:
- Codex: repository-wide/local-file/static/provenance/PowerShell/compile work;
- normal chat: external research, design decisions, Codex re-audit, Runtime CSV/Log/MP4 judgement and Production acceptance.

---

## OBJECTIVE

Primary objectives completed in this chat:

1. Determine whether the v44.55.12 Native source/DLL provenance could be recovered without guessing a build definition.
2. Prevent any Native DLL rebuild or replacement before provenance was sufficiently supported.
3. Eliminate recurring Windows PowerShell 5.1 compatibility failures at the tooling foundation rather than patching each script independently.
4. Minimize normal-chat ↔ Codex round trips and file uploads.
5. Consolidate project-wide custom instructions, authority rules and handoff workflow.

---

## CONFIRMED FACTS

### Production critical authority used during this chat

`Assets\Script\KiwiInferenceFaceTracker.cs`
SHA256:
`52C046EE44B41A4FF50B85AEF503BC29DD31B57EAF58C0D160CCC33C5D4B7695`

`Assets\Script\FaceLandmarkerRunner.cs`
SHA256:
`6C65C075270F10C791F6B044E3BC04C6024AADF916D65283F0EEFFA3448BBB93`

`Assets\KiwiAvatarSystem\Runtime\Camera\KiwiNativeCameraInterop.cs`
SHA256:
`AC473ADBADE5EDC89726211ECAF03D040B5CC00FCA39BEA4A0D16195FA53E8B5`

`Assets\Plugins\x86_64\KiwiNativeCamera.dll`
SHA256:
`82D1FC2910468056C02E8BAE1C72996D8492173A84BEBBCAE322EBEF435678A5`

`Native\KiwiNativeCamera\Source\KiwiNativeCameraPlugin.cpp`
SHA256:
`636D76251F9CB3BB785F4497D3D0722033FC0CE36CB4A574B65EDA58B5ABE32A`

### v44.55.17 semantic result

`CURRENT_FLOAT`
vs
`PRESENTATION_PLUS_FINAL_UNORM8 mode2`

Result:
- status = COMPLETE
- decision = FAIL
- completed = 69
- canonicalComparable = 47
- observerFault = 0
- sourceIdentityMismatch = 0
- hardInvariantViolation = 0

Aggregate failures:
- Presence P95 0.021542 > 0.010
- Presence max 0.037391 > 0.030
- Canonical point P95 1.5199 px > 1.0 px
- Canonical point max 3.048 px > 2.0 px
- Rotation P95 0.5488° > 0.10°
- Rotation max 0.8327° > 0.25°

Pass:
- Scale
- Geometry Quality
- Expression

Decision:
`PRESENTATION_PLUS_FINAL_UNORM8 mode2` is rejected as a semantically equivalent CPU Production input representation.

### v44.55.16 / v44.55.17 observer corrections

v44.55.16 had a decision-precedence defect where sample sufficiency could mask hard mismatches.

Correct precedence retained after correction:

`INVALID_OBSERVER > HARD_FAIL > INSUFFICIENT_DATA > AGGREGATE_GATE > PASS`

v44.55.17 also contained a provenance/output naming defect where v44.55.16 output prefixes remained in artifact filenames. This did not invalidate the semantic result but established the requirement to validate class/contract/version/output-name consistency.

### Initial Native provenance audit

User-executed v44.55.18.1 static validation:
- Windows PowerShell 5.1: PASS
- Production SHA guards: PASS
- Audit script SHA: PASS
- Build script SHA: PASS
- Generic.List PS5.1 hotfix guards: PASS
- no project copy/move/delete in audit/build scripts: PASS

User-executed v44.55.18.1 provenance audit:
- closureStatus = `NOT_CLOSED_RECONSTRUCTED_SOURCE`
- abiParity = 1
- vcxprojCandidateCount = 0
- isolatedRebuildReady = 0
- historicalExactProductionDllCopyCount = 1

This correctly prevented an isolated rebuild.

### Historical exact DLL

Recovered path:

`Builds\v44_55_12D3DFixedPointSubtexelAudit\KiwiAvatarSystem_v44_55_12_SUBTEXEL_Data\Plugins\x86_64\KiwiNativeCamera.dll`

Its SHA256 is exactly:

`82D1FC2910468056C02E8BAE1C72996D8492173A84BEBBCAE322EBEF435678A5`

matching current Production.

### v44.55.12 original package recovery

Recovered local ZIP:

`D:\Users\main\Downloads\KiwiAvatarSystem_v44_55_12_D3DFixedPointSubtexelSamplingParityAudit.zip`

ZIP SHA256:
`06666AF4E0FDA1013EC4E9E865C2FC97BE4CC8730F9F1CEACE47EB8F973D0DF2`

Original unzipped Downloads directory also remained present.

The ZIP and original directory matched for all 18 files by path, size and SHA256.

Key recovered files included:

- `Installer\Build-KiwiNativeCamera-v44.55.12.ps1`
- `Installer\Apply-v44.55.12.ps1`
- `Installer\Validate-v44.55.12.ps1`
- `Installer\Rollback-v44.55.12.ps1`
- `Launch-v44.55.12-BuildAndAudit.ps1`
- `Build\build_native_v44_55_12.cmd`
- `Native\KiwiNativeCameraPlugin.cpp`
- `Runtime\KiwiNativeCameraInterop.cs`
- `Build\KiwiNativeCamera.dll`
- `Build\KiwiNativeCameraPlugin.obj`
- `Build\KiwiNativeCamera.exp`
- `Build\KiwiNativeCamera.lib`
- build stdout/stderr and build record
- observer source

### Exact package ↔ Production identity

Package Native source SHA:
`636D76251F9CB3BB785F4497D3D0722033FC0CE36CB4A574B65EDA58B5ABE32A`

Current Production Native source:
same SHA, byte-identical.

Package Interop SHA:
`AC473ADBADE5EDC89726211ECAF03D040B5CC00FCA39BEA4A0D16195FA53E8B5`

Current Production Interop:
same SHA, byte-identical.

Package DLL:
80896 bytes,
SHA:
`82D1FC2910468056C02E8BAE1C72996D8492173A84BEBBCAE322EBEF435678A5`

Current Production DLL:
same size/SHA, byte-identical.

Historical v44.55.12 standalone DLL:
same size/SHA, byte-identical.

### Source/build correlation

Recovered OBJ:
SHA256:
`51D6BFD52B63E020E93DF8CB55FFCD951C0B8166A0CA87A4AC71EEB74924A7A0`

Its COFF symbols include the v44.55.12 fixed-point subtexel functions and the exported subtexel entry point.

Recovered EXP:
SHA256:
`DF98463511B69F117E714DBBF5855751C8F1B9625B1E8D7C905F81C9831E707C`

It embeds the original MSVC 14.44.35207 linker path and original Build working-directory information.

Recovered LIB:
SHA256:
`3DED4E41B7E88674FA31763C75ED24677669E7C2AD1709ED510A2ACD6D64F423`

### Toolchain evidence

Historical:
- Visual Studio 2022 Developer Command Prompt v17.14.37
- MSVC 14.44.35207 family
- compiler build consistent with 19.44.35228
- linker 14.44
- x64 PE32+

Current matching local tools discovered by Codex:
- `cl.exe` file version 19.44.35228.0
- `link.exe` file version 14.44.35228.0
- Windows SDK currently available: 10.0.26100.0

The exact historical Windows SDK selection was not recorded.

### Provenance result

`Class=B`
`Label=Strongly Supported`

Operational conclusion:
The local original package provenance for the v44.55.12 Native source and `KiwiNativeCamera.dll` is strongly supported and internally coherent.

### PowerShell foundation

Codex implemented:

`Tools\KiwiPowerShell\KiwiPsCompat.psm1`

`Installer\Validate-KiwiCommon.ps1`

`Installer\Test-KiwiPsCompat.ps1`

Codex audit results:
- Windows PowerShell 5.1 parse errors = 0
- forbidden PS7 operators = 0
- Generic.List danger findings = 0 after fixes
- 20 existing Generic.List + `@($list)` hazards corrected
- common compatibility smoke test = PASS
- Unity batchmode compile = PASS
- Production files modified = 0
- Native files modified = 0

Legacy warning count remained 32, all non-blocking review warnings.

---

## PUBLIC DESIGN PRINCIPLES

### PowerShell / validator safety

The project established these permanent operational principles:

- Windows PowerShell 5.1 is a fixed compatibility target.
- Generic Lists should use `::new()` and explicit `.ToArray()`.
- Do not depend on `&&`, `||`, `??` or other PS7-only syntax.
- Common SHA, safe I/O, process execution, tool discovery, transactional replacement, rollback and write-target guards belong in a shared compatibility layer.
- Validators are not automatically trusted; validator/observer defects must be investigated as seriously as Production defects.
- Production write targets should be protected by canonical root/allowlist checks.

### Native provenance

ABI parity alone does not prove source-to-binary provenance.

A robust provenance chain should track:

source
→ build definition
→ compiler/linker/SDK/flags
→ build inputs
→ artifact
→ install/copy
→ Production DLL

Exact SHA equality is strong evidence, but ordinary non-deterministic PE builds can differ in timestamp and other metadata. A controlled reproduction test should therefore record/harden all inputs and compare semantic/structural binary evidence as well as raw SHA.

### Correctness vs Performance

Observer-heavy correctness runs must not be used as Production performance authority.

Correct sequence:

Semantic Correctness PASS
→ Performance A/B
→ Visual Runtime

---

## INFERENCES / HYPOTHESES

1. The recovered v44.55.12 package build DLL was built from the adjacent package Native source using the recorded build command and MSVC 14.44 family. This is strongly supported by source identity, exact DLL identity, OBJ symbols, EXP linker path and timeline, but not cryptographically proven to Class A.

2. `Apply-v44.55.12.ps1` or an equivalent install sequence was used around 2026-08-31 18:00:20 JST. The matching backup content/timing and Production artifact timing strongly support this.

3. Exact historical byte reproduction is feasible to attempt but not guaranteed because the complete historical SDK/header/environment state was not sealed and `/Brepro` was not used.

These remain inferences and were not promoted to Class A facts.

---

## PRODUCTION AUTHORITY

Authority order applied in this chat:

1. Local Production actual files + SHA, as reported/verified by Codex and user-executed validators
2. Same-Production Runtime/standalone evidence
3. Original v44.55.12 recovered package/build artifacts
4. Latest KiwiValidation / Codex consolidated reports
5. Actual package/tool source
6. Official documentation/source
7. Git/local history
8. older diagnostics

Normal-chat caveat:

`LOCAL_PRODUCTION_NOT_DIRECTLY_VERIFIED_IN_NORMAL_CHAT`

Normal chat did not directly read `D:\KiwiAvatarSystem`; local-file claims came from user-executed scripts and Codex local audits.

---

## WORK PERFORMED

### 1. v44.55.17 semantic gate review
Purpose:
Correct the decision precedence bug and obtain a valid semantic result.

Result:
Valid COMPLETE/FAIL.
Mode2 rejected as equivalent CPU input representation.

Impact:
Do not relax thresholds or repeat mode2 trying to obtain a PASS.

### 2. Duplicate backend-equivalence work avoided
A proposed new CURRENT_FLOAT CPU-vs-GPU backend gate was stopped after prior v44.54 evidence showed that equivalent testing had already been completed.

Impact:
Avoided reimplementing a redundant diagnostic.

### 3. Native provenance phase selected
Reason:
Future Native/preprocess changes required a trusted Native source/build chain.

### 4. v44.55.18 provenance tooling created
Read-only audit + isolated-build tooling created with Production SHA guards.

### 5. PowerShell 5.1 failure discovered
The audit failed with `Argument types do not match`.

Root cause:
Windows PowerShell 5.1 binder issue involving Generic.List and array-subexpression conversion.

### 6. v44.55.18.1 PS5.1 hotfix
Changed tooling to:
`[System.Collections.Generic.List[object]]::new()`
+
`.ToArray()`

Added stage markers.

Result:
Static validation PASS and provenance audit COMPLETE.

### 7. v44.55.18.2 historical context recovery
Found exact historical Production DLL in the v44.55.12 standalone build.

Result:
Historical build-context candidates found, but original build definition initially still missing.

### 8. Codex full local provenance audit
Codex inspected repository history, Native source/build material, backups, validation outputs, exact historical DLL and PowerShell ecosystem.

Result:
- Production unchanged
- provenance still not closed at that point
- common PowerShell 5.1 foundation implemented
- Unity batchmode compile PASS

### 9. Original v44.55.12 package supplied and audited locally
The original package/build directory was recovered from Downloads and inspected.

Result:
Provenance upgraded to:
`Class B — Strongly Supported`

This is the last substantive technical update in this chat and is the Archive timestamp basis.

### 10. Custom instruction / workflow consolidation
The project-wide development process was reviewed and condensed into persistent custom-instruction guidance.

This was organizational work, not the Archive timestamp basis.

---

## VALIDATED DECISIONS

### Decision: Reject mode2 as semantically equivalent CPU input
Reason:
Canonical semantic aggregate gates failed repeatedly.
Evidence:
v44.55.17 completed 69 / canonical 47 with presence, canonical-point and rotation failures.
Regression constraints:
Do not loosen thresholds post hoc.
Still current:
YES for this chat's decision scope.

### Decision: Do not guess/reconstruct a Native build definition when evidence is missing
Reason:
Native DLL changes are high risk and ABI parity alone is insufficient.
Evidence:
v44.55.18 initial audit.
Regression constraints:
Require source/build/toolchain evidence before Native reproduction.
Still current:
YES.

### Decision: v44.55.12 Native provenance = Class B, Strongly Supported
Reason:
Original package recovered with exact source/Interop/DLL identity and build artifact/toolchain/timeline correlation.
Evidence:
`KiwiCodexConsolidatedReport_v44_55_12_OriginalPackageAudit.txt`
Regression constraints:
Do not call it cryptographically Class A without sealed historical inputs or controlled reproduction evidence.
Still current:
YES for provenance classification.

### Decision: Use common Windows PowerShell 5.1 compatibility foundation
Reason:
Repeated per-version PowerShell failures are a tooling-system defect, not isolated script mistakes.
Evidence:
Codex audit + smoke tests.
Regression constraints:
New scripts should reuse common helpers rather than clone fragile logic.
Still current:
YES.

### Decision: Minimize Codex ↔ normal-chat round trips
Reason:
Repository-wide work is best completed in one Codex pass and returned as one consolidated report.
Still current:
YES.

---

## REJECTED APPROACHES

### Rejected: Repeat CURRENT_FLOAT CPU/GPU backend equivalence test
Why considered:
Initially proposed as v44.55.18.
Why rejected:
Equivalent work had already been completed in v44.54.
Revisit condition:
Only if new backend/runtime evidence invalidates the earlier test.

### Rejected: Continue tuning/retesting mode2 for a PASS
Why considered:
Mode2 had favorable pixel-level behavior.
Why rejected:
Canonical semantic equivalence failed on meaningful output metrics.
Revisit condition:
Only a fundamentally new preprocessing definition with pre-registered gates.

### Rejected: Run isolated rebuild before build definition was recovered
Why considered:
Potential route to provenance closure.
Why rejected:
`vcxprojCandidateCount=0`, reconstructed-source warning, incomplete build chain.
Revisit condition:
A controlled reproduction test may be authorized later using the recovered original package and fully hashed inputs.

### Rejected: Patch PowerShell errors version by version
Why rejected:
Repeated Generic.List/PS5.1/tool/path problems showed need for a common foundation.
Revisit condition:
None; shared foundation is the preferred model.

---

## SUPERSEDED CONCLUSIONS

OLD:
`Native provenance = NOT_CLOSED / Production DLL frozen due missing original build definition`

NEW:
`Native provenance = Class B / Strongly Supported`

WHY:
The original v44.55.12 package and build artifacts were recovered locally.

EVIDENCE:
Exact source/Interop/DLL identities, OBJ symbols, EXP tool path, backup/install timeline and historical standalone exact DLL.

---

OLD:
`Current canonical Native source may be only a reconstructed candidate with uncertain relation to Production DLL`

NEW:
The source remains historically labelled/reconstructed in provenance wording, but the recovered original v44.55.12 package contains a Native source byte-identical to current Production source and paired with the exact Production DLL plus matching build artifacts.

WHY:
Original package recovered.

---

OLD:
`PowerShell 5.1 Generic.List binder problem is a one-script issue`

NEW:
It is treated as a project tooling-foundation concern; 20 repository hazards were corrected and common compatibility helpers were introduced.

---

## OBSERVER / VALIDATOR FINDINGS

1. v44.55.16 decision-precedence bug:
   hard mismatch could be masked by insufficient-data evaluation.

2. v44.55.17 artifact naming bug:
   v44.55.16 filename prefix remained in v44.55.17 output.

3. v44.55.18 PowerShell 5.1 binder failure:
   Generic.List + array-subexpression caused `Argument types do not match`.

4. Validator/tooling lesson:
   parse/static validation must include:
   - PS5.1 compatibility
   - collection coercion
   - version/class/contract/output filename alignment
   - SHA/write-target safety
   - transactional behavior
   - root containment
   - subprocess lifecycle

Production defects and observer/validator defects must remain separate.

---

## FILES / SHA256

### Current Production authority

Path:
`Assets\Script\KiwiInferenceFaceTracker.cs`
Role:
Production inference/tracking
SHA256:
`52C046EE44B41A4FF50B85AEF503BC29DD31B57EAF58C0D160CCC33C5D4B7695`
Before/After:
UNCHANGED IN THIS CHAT
Current/Obsolete:
CURRENT

Path:
`Assets\Script\FaceLandmarkerRunner.cs`
Role:
Production Face Landmarker runner
SHA256:
`6C65C075270F10C791F6B044E3BC04C6024AADF916D65283F0EEFFA3448BBB93`
Before/After:
UNCHANGED IN THIS CHAT
Current/Obsolete:
CURRENT

Path:
`Assets\KiwiAvatarSystem\Runtime\Camera\KiwiNativeCameraInterop.cs`
Role:
Production Native interop
SHA256:
`AC473ADBADE5EDC89726211ECAF03D040B5CC00FCA39BEA4A0D16195FA53E8B5`
Before/After:
UNCHANGED IN FINAL PROVENANCE AUDIT
Current/Obsolete:
CURRENT

Path:
`Assets\Plugins\x86_64\KiwiNativeCamera.dll`
Role:
Production Native DLL
SHA256:
`82D1FC2910468056C02E8BAE1C72996D8492173A84BEBBCAE322EBEF435678A5`
Before/After:
UNCHANGED IN THIS CHAT
Current/Obsolete:
CURRENT

Path:
`Native\KiwiNativeCamera\Source\KiwiNativeCameraPlugin.cpp`
Role:
Current Native source
SHA256:
`636D76251F9CB3BB785F4497D3D0722033FC0CE36CB4A574B65EDA58B5ABE32A`
Before/After:
UNCHANGED IN FINAL PROVENANCE AUDIT
Current/Obsolete:
CURRENT

### Important audit/report files

`KiwiCodexConsolidatedReport_v44_55_18_2.txt`
Role:
Codex Native provenance + PowerShell foundation consolidated report.

`KiwiCodexConsolidatedReport_v44_55_12_OriginalPackageAudit.txt`
Role:
Final original-package provenance audit.
Status:
CURRENT AUTHORITY FOR THIS CHAT'S NATIVE PROVENANCE DECISION.

`KiwiAvatarSystem_v44_55_12_D3DFixedPointSubtexelSamplingParityAudit.zip`
Role:
Recovered original v44.55.12 package.
SHA256:
`06666AF4E0FDA1013EC4E9E865C2FC97BE4CC8730F9F1CEACE47EB8F973D0DF2`

### PowerShell foundation

`Tools\KiwiPowerShell\KiwiPsCompat.psm1`
Role:
Common PS5.1 compatibility/safety foundation.

`Installer\Validate-KiwiCommon.ps1`
Role:
Common repository PowerShell validator.

`Installer\Test-KiwiPsCompat.ps1`
Role:
Executable PS5.1 smoke test.

Exact SHA values for these files are preserved in the Codex consolidated report. They were not recomputed directly by normal chat.

---

## RUNTIME EVIDENCE

### Correctness evidence
- v44.55.17 canonical semantic report
Authority:
CORRECTNESS
Result:
mode2 semantic FAIL.

### Static/provenance evidence
- v44.55.18 / v44.55.18.1 provenance validation/audit output
Authority:
PROVENANCE / STATIC_ONLY

- v44.55.18.2 historical Native context report
Authority:
PROVENANCE / STATIC_ONLY

- `KiwiCodexConsolidatedReport_v44_55_18_2.txt`
Authority:
PROVENANCE / STATIC_ONLY

- `KiwiCodexConsolidatedReport_v44_55_12_OriginalPackageAudit.txt`
Authority:
PROVENANCE / STATIC_ONLY
Result:
Class B Strongly Supported.

### Unity compile
Codex batchmode compile:
PASS
Authority:
STATIC_ONLY

### Performance
No observer-heavy timing from this chat is accepted as Production Performance Authority.

### Visual
No MP4 was required for the final provenance/PowerShell work.
Visual evidence was not part of the final provenance decision.

---

## CURRENT RESULT

### Chat-local result

Native provenance recovery:
**DONE — Class B / Strongly Supported**

PowerShell 5.1 foundation:
**DONE**

Production Native DLL:
**UNCHANGED**

Production Tracking Core:
**UNCHANGED**

Native rebuild:
**NOT RUN**

Production DLL replacement:
**NOT RUN**

Mode2 CPU input:
**REJECTED for semantic equivalence**

### Project-wide later context

After the work archived here, newer project-wide reference material supplied to this chat records later CPU/inference work through v44.55.23 with v44.55.24 planned.

Therefore this archive must not be used to overwrite later project state.

The current project-wide next action from the newer project reference is:

**v44.55.24 Pair-Bound Shadow Output Snapshot**

This is later than this chat's Native provenance work and supersedes any older “choose next unfinished task” wording.

---

## OPEN ISSUES

For this chat's provenance scope:

1. Class A cryptographic provenance is not established.
2. Historical Windows SDK/header/environment input hashes were not sealed.
3. No `/Brepro` deterministic build was used.
4. No trusted external build attestation/signature exists.
5. Existing original package PowerShell scripts have legacy transactional/containment/hash gaps and should not be treated as the modern scripting standard.

These are not blockers for preserving current stable Production.

Project-wide open issue from later authority:

- v44.55.23 `MIXED_TRANSACTION` remains provisional until v44.55.24 removes the Worker-output lifecycle observer race.

---

## NEXT ACTION

### Project-wide current next action

Implement/validate:

**v44.55.24 Pair-Bound Shadow Output Snapshot**

Purpose:
Eliminate the remaining Worker allocator output lifecycle race from v44.55.23 before treating `MIXED_TRANSACTION` as a final domain result.

Do not start:
- Production CPU conversion,
- Native modifications,
- Tracking modifications,
- pixel-center/FMA deep investigation,

before the v44.55.24 transaction-authority result is closed.

### If Native changes become necessary later

Use the recovered v44.55.12 original package as provenance basis and perform a controlled isolated reproduction only after:

- hashing all source/header/library/tool inputs;
- recording `cl /Bv`;
- recording linker version;
- recording VsDevCmd environment;
- fixing/recording SDK selection;
- using a KiwiValidation/TEMP-only workspace;
- comparing OBJ symbols, exports, imports, normalized PE/sections and raw SHA where meaningful.

Production installation must remain a separate explicitly authorized step.

---

## DO NOT CHANGE

Without new independent evidence:

- Face Landmarker Primary / Source of Truth
- working Tracking Core
- `KiwiFaceMotion.cs` as a camera workaround
- `KiwiInferenceFaceTracker.cs` as a camera workaround
- Native Camera stable Production path
- FIFO / stale queue prohibition
- fixed Unity-visible texture identity
- session epoch vs frame sequence separation
- `UpdateExternalTexture` prohibition
- `g_unityD3D12Queue->Wait(...)` prohibition
- callback/worker `IMFSample` retention prohibition
- D3D11On12 1080p Camera Production rejection
- strong smoothing/Kalman prohibition as problem masking
- fixed semantic thresholds without pre-registered evidence
- Production lane.input direct oracle rejection
- semantic-PASS-before-Production-CPU rule
- Correctness / Performance / Visual separation

Do not rebuild Native from a guessed build definition.

Do not commit/push unless explicitly requested.

---

## HANDOFF

A next chat can resume safely with the following assumptions:

1. This chat's Native provenance problem is no longer “missing build package”.
   The original v44.55.12 package was recovered and audited.

2. Native provenance classification is:
   `Class B — Strongly Supported`.

3. Current Production source/Interop/DLL exact hashes used in this chat are listed above.

4. Current stable Native DLL was not rebuilt or replaced.

5. Common PowerShell 5.1 foundation has been implemented and should be reused instead of cloning fragile standalone scripts.

6. Mode2 preprocessing was rejected at canonical semantic level; do not re-test simply to obtain a PASS.

7. The project has since progressed beyond this chat's CPU/preprocess state.
   Newer project authority supplied later in the conversation places the current project at v44.55.23 with v44.55.24 as the next investigation.

8. For all future work:
   - normal chat handles external research, design/review, Runtime evidence and Production decisions;
   - Codex handles local repo-wide static/provenance/compile/PowerShell work;
   - minimize back-and-forth;
   - prefer one consolidated Codex report and one Runtime evidence ZIP.

---

## MASTER REPORT UPDATE CANDIDATES

Archive:
`KiwiChat_NativeProvenanceAndPowerShellFoundation_Updated_20260902-0026-JST.zip`

Topic:
Native provenance recovery + PS5.1 foundation

LastWorkUpdate:
2026-09-02 00:26:43 JST

Validated Decision:
- v44.55.12 Native provenance = Class B / Strongly Supported
- common PowerShell 5.1 foundation adopted

Rejected Approach:
- guessed Native rebuild definition
- per-version PowerShell hotfixing
- mode2 semantic-equivalence promotion

Superseded Conclusion:
- “Original v44.55.12 build package missing / provenance not closed enough to identify package chain”
  → superseded by recovered original package and Class B decision.

Open Issue:
- Class A cryptographic provenance remains unproven but is not a blocker for current stable Production.

Next Action:
Project-wide current authority says v44.55.24 Pair-Bound Shadow Output Snapshot.

---

## CHAT ARCHIVE INDEX

Archive:
KiwiChat_NativeProvenanceAndPowerShellFoundation_Updated_20260902-0026-JST.zip

Topic:
NativeProvenanceAndPowerShellFoundation

LastWorkUpdate:
2026-09-02 00:26:43 JST

Status:
DONE

Supersedes:
Earlier `NOT_CLOSED_ORIGINAL_BUILD_DEFINITION_MISSING` conclusion for v44.55.12 package recovery.

SupersededBy:
None for this chat's Native provenance decision.
Later project CPU/inference investigation state is tracked separately by newer project reports.

NextArchiveCandidate:
v44.55.24 Production Output Transaction Authority closure.

---

## SOURCE INDEX USED FOR ARCHIVE

Normal-chat conversation:
- v44.55.17 semantic decision review
- v44.55.18 / .1 / .2 provenance workflow
- PowerShell 5.1 failure and root-fix direction
- Codex workflow split
- custom-instruction consolidation
- v44.55.12 original package provenance result

Uploaded/available project references:
- `KiwiCodexConsolidatedReport_v44_55_18_2.txt`
- `KiwiCodexConsolidatedReport_v44_55_12_OriginalPackageAudit.txt`
- `Github-リポジトリ.txt`
- `KiwiAvatarSystem-情報源・Authority一覧.txt`
- `KiwiAvatarSystem-統合最新版カスタム指示-情報源-作業履歴-今後計画-更新基準-2026-09-02.txt`
- `通常チャット用-恒久REPORT・ZIP直接作成指示.txt`

GitHub repository reference:
`https://github.com/midori-kiwi/KiwiAvatarSystem/tree/main`

Authority note:
Newer project-wide reference material was used only to avoid emitting a stale project-wide NEXT ACTION. It does not change the Archive timestamp basis for this chat.

---

## FINAL ARCHIVE RESULT

ChatScopeStatus:
DONE

NativeProvenance:
CLASS_B_STRONGLY_SUPPORTED

PowerShellFoundation:
IMPLEMENTED_AND_PS51_VALIDATED

ProductionChanged:
0

NativeChanged:
0

NativeBuildLaunchedDuringFinalAudit:
0

RuntimeRequiredForFinalProvenanceWork:
NO

ArchiveTimestampBasis:
LAST_RELEVANT_WORK_BEFORE_ARCHIVE_REQUEST

LastWorkUpdate:
2026-09-02 00:26:43 JST
