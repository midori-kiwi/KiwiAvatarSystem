# KiwiAvatarSystem Chat Permanent Report

ChatTopic: Workflow Role Split / Japanese QA Labels / Commit Notification / Source Docs Revision
ChatTitle: 通常チャット・GitHub・Codexの役割分担と情報源v4改訂
ArchiveName: KiwiChat_WorkflowRoleSplitAndDocsRevision_Updated_20260913-JST.zip
LastWorkUpdate: 2026-09-13
LastWorkUpdatePrecision: DATE_ONLY
ArchiveCreated: 2026-09-13 00:51:38 JST
ArchiveTimestampBasis: LAST_RELEVANT_WORK_BEFORE_ARCHIVE_REQUEST
Project: D:\KiwiAvatarSystem
Unity: 6000.0.80f1
CurrentInvestigationVersion: GoalAligned v4 policy/source-document revision
Status: DONE

## EXECUTIVE SUMMARY

このチャットでは、KiwiAvatarSystemの開発運用を主目的へ寄せるため、既存の
`CustomInstructions / CurrentRoadmap / CoreRules`
を見直し、3ファイルをv4へ改訂した。

確定した運用変更は次の3点。

1. 通常チャット + GitHubを、公開情報調査、設計、GitHub source解析、最小修正、Static review、commitまでの主担当とする。
2. Codexは特に問題がない限り、local環境でしか実行・確認できない作業へ限定する。
3. ユーザー向けの確認項目・判定は可能な限り日本語化し、commitが適切なboundaryに到達した時は通常チャットから明示的に知らせる。

CurrentRoadmapは、添付時点の2026-09-10 P3D状態をそのままCurrentに残さず、このプロジェクトで直近に保持されていた2026-09-13 H1同一ビルド人間確認の状態へ更新した。
ただしこのチャット自身では新しいRuntime、Unity compile、Native build、benchmarkは実施していない。
したがって、製品側の新規Runtime PASSをこのチャットの成果として主張しない。

製品側のCurrent Nextは、
「同一ビルドでLandmarker飛びを再現し、authority / identity / timestamp / provider / presentationの最初の失敗boundaryだけを特定する」
として保持した。

## OBJECTIVE

ユーザー要求:

- Codexは原則local-only作業のみ担当する。
- GitHub上のsource解析→修正→commitは通常チャットを主担当とする。
- `ROTATION_MATCH=PASS/FAIL` 等のユーザー向けチェック項目を日本語化する。
- commitが必要なタイミングで通常チャットから知らせる。
- 上記を添付のCustomInstructions / CurrentRoadmap / CoreRulesへ矛盾なく反映する。
- できるだけ日本語で記述する。

## CONFIRMED FACTS

### このチャットで直接確認・実施した内容

- 既存CustomInstructions、CurrentRoadmap、CoreRulesを読み、役割分担・Authority・検証・Human Visual契約との整合性を確認した。
- 3文書をv4として実ファイル生成した。
- CustomInstructionsは5000文字未満に収めた。
- 3文書すべてで以下を反映した。
  - 通常チャット + GitHubを通常のsource開発主担当とする。
  - Codexをlocal-only execution/evidence中心へ限定する。
  - 日本語チェック項目を主表記にする。
  - commit適切時点を通常チャットが通知する。
  - pushはユーザー明示指示時のみとする。
- CurrentRoadmapでは、旧「H1未実行 / NEXT=H1 minimal integration」をCurrentとして残さず、直近のH1 Human Visual不合格とLandmarker飛び再発をCurrentへ反映した。
- 原因未特定の補償修正をcommitしない方針を明記した。

### このチャットで新規に確認していない内容

- D:\KiwiAvatarSystem のcurrent live HEAD/status/SHA
- local worktree dirty state
- Unity compile
- Native build / ABI
- Runtime
- clean performance
- Human Visualの再実行
- local ProductionへのGitHub変更反映

これらは `NORMAL_CHAT_LIVE_LOCAL_PRODUCTION_NOT_DIRECTLY_VERIFIED` の範囲を越えていない。

## PUBLIC DESIGN PRINCIPLES

このチャットでは新規のWeb/公式Source調査は実施していない。

採用した原則は、既存CoreRules / CurrentRoadmapに保持されているKiwiAvatarSystem内部契約を再整理したもの。

- Face Landmarker = Primary / Source of Truth
- latest-frame
- FIFO / stale queue禁止
- Root / Head / Eye / Mouth authority分離
- Head single rigid authority
- Human Visualはvalidator/logで上書きしない
- GitHub上の変更はlocal Production Runtime PASSへ自動昇格しない
- 正常なProductionを理由なく再設計しない
- first proven boundaryだけを最小修正する

## INFERENCES / HYPOTHESES

- Landmarker飛びの原因boundaryは未特定。
- tracking math、provider、identity、timestamp、FaceGeometry、FacePart、Camera、Native、backendのいずれかへ原因帰属できるEvidenceはこのチャットでは得ていない。
- 英語ラベルから日本語ラベルへの表示変更は運用上の可読性改善であり、Runtime correctnessを変えるものではない。
- 通常チャット主体のGitHub開発へ移すことでCodex往復を減らせると期待されるが、latencyや開発時間の定量改善は未測定。

## PRODUCTION AUTHORITY

### Implementation
current local Productionは通常チャットから直接未確認。

### Runtime
このチャットでは新規Runtimeなし。

### Static / Document
このチャットで生成したv4文書が本チャットの直接Authority。

### GitHub
このチャットではGitHub source変更・commitは実施していない。

### Performance
Authorityなし。

### Visual
このチャットでHuman Visual再実行なし。
製品CurrentのVisual状態は既存プロジェクト文脈に保持されていた直近H1 Human Visual不合格をRoadmapへ反映したものであり、このチャットで再測定したものではない。

## WORK PERFORMED

### 1. 既存3文書の役割分担監査

目的:
通常チャット / GitHub / Codexの既存責務が新方針と衝突しないか確認する。

結果:
旧CoreRulesには通常チャットをGitHub開発主担当とする記述が既にあったが、Codexにもlocal candidate適用やsource modificationの広い責務が残っていたため、local-only原則を明確化する必要があった。

判定:
合格。改訂boundaryを特定。

影響:
Codexを一般source開発の既定経路にしない方針を3文書へ統一。

### 2. 日本語チェック項目方針の追加

目的:
`ROTATION_MATCH=PASS/FAIL` 等の人間確認をユーザーが直接判断しやすい表記へ変更する。

結果:
主表記を日本語へ変更。
例:
- 回転一致=合格/不合格
- 目のねじれ=合格/不合格
- 口のねじれ=合格/不合格
- 回転時Root非移動=合格/不合格
- まばたき=合格/不合格
- 口表情=合格/不合格
- LIVE CAMERA=合格/不合格

内部validator/reportの英語キーを正確に照合する必要がある時だけ日本語の後へ併記する。

判定:
合格。

### 3. commit通知契約の追加

目的:
commit boundaryを見失わず、早すぎるWIP commitと遅すぎる複数boundary混在commitを防ぐ。

結果:
意味のある最小変更がStatic reviewを通り、次のlocal検証の再現可能な基準点を固定すべき時点で、
通常チャットが「今がコミット適切時点」と明示する契約を追加。

pushはユーザー明示指示時のみ。

判定:
合格。

### 4. CurrentRoadmapの時系列補正

目的:
添付Roadmapの2026-09-10 P3D状態を、既に後続Evidenceが存在するのにCurrentとして残さない。

結果:
直近プロジェクト文脈の2026-09-13 H1 Human Visual不合格、
Landmarker飛び再発、
原因boundary未特定、
Performance未評価
をCurrentへ反映。

旧NEXT:
H1_MINIMAL_SAME_SAMPLE_HUMAN_HEAD_FACEPART_PRODUCT_INTEGRATION

新NEXT:
同一ビルド Landmarker飛び first-boundary localization

判定:
合格。ただしcurrent live localは未確認。

### 5. 3ファイル生成と自己検証

生成:
- KiwiAvatarSystem_CustomInstructions_20260913_GoalAligned_v4.txt
- KiwiAvatarSystem_CurrentRoadmap_20260913_GoalAligned_v4.txt
- KiwiAvatarSystem_CoreRules_20260913_GoalAligned_v4.txt

確認:
- Codex local-only原則あり
- commit通知契約あり
- 日本語チェック項目あり
- CurrentRoadmapに2026-09-13状態あり
- CustomInstructions 5000文字未満

判定:
合格。

## VALIDATED DECISIONS

### Decision 1
通常チャット + GitHubを通常のsource開発主担当にする。

Reason:
通常チャットで完結できる公開source解析、設計、Static review、GitHub修正をCodexへ往復させる必要がないため。

Evidence:
ユーザー明示方針 + v4文書反映。

Regression constraints:
GitHub変更をlocal Production Runtime PASSへ昇格しない。
local-only検証はCodex/current local側で閉じる。

Still current:
YES

### Decision 2
Codexは原則local-only作業に限定する。

Reason:
Codexの価値をlocal repo、dirty state、exact Unity、Native、Runtime、hardware/GUI Evidenceへ集中させるため。

Evidence:
ユーザー明示方針 + v4文書反映。

Regression constraints:
通常チャットでできるsource reviewや一般修正を理由なくCodexへ送らない。
local-only作業まで通常チャットだけで確認したふりをしない。

Still current:
YES

### Decision 3
ユーザー向けQA判定は日本語を主表記にする。

Reason:
Human Visual確認の可読性と判断の直接性を上げるため。

Evidence:
ユーザー明示方針 + v4文書反映。

Regression constraints:
machine-readable/internal keyを破壊しない。
必要時は日本語 + 英語内部キー併記。

Still current:
YES

### Decision 4
commit適切時点を通常チャットが通知する。

Reason:
再現可能なlocal検証基準点を適切な粒度で固定するため。

Evidence:
ユーザー明示方針 + v4文書反映。

Regression constraints:
原因未特定/WIPで無理にcommitしない。
複数独立boundaryを1 commitへ混ぜない。
pushは明示指示時のみ。

Still current:
YES

## REJECTED APPROACHES

### Rejected
Codexを通常のGitHub source解析・修正の既定担当として使い続ける。

Why considered:
旧運用ではCodexにrepo横断監査、source modification、compile、Runtimeまで広く担当させていた。

Why rejected:
通常チャット + GitHubで完結できる作業までlocal agent往復させる必要がなく、役割境界が曖昧になるため。

Evidence:
ユーザー明示方針。

Revisit condition:
通常チャット/GitHub側で対象操作が不可能、またはlocal-only evidenceが不可欠な場合。

### Rejected
人間確認項目を英語machine keyだけで表示する。

Why rejected:
ユーザー向けHuman Visual確認として不要に読みにくいため。

Revisit condition:
内部validatorとの厳密照合が必要な箇所では日本語の後に英語keyを併記。

### Rejected
commit時期を通知せず、後からまとめて判断する。

Why rejected:
first-boundary最小修正の履歴とlocal検証基準点が曖昧になり得るため。

Revisit condition:
なし。通知契約を維持。

## SUPERSEDED CONCLUSIONS

### 1. Codexの通常開発責務

OLD:
Codex/localをProduction Evidence Execution Agent兼local candidate適用担当として広く使い、
source modificationも通常経路に含める運用。

NEW:
通常チャット + GitHubをsource解析→修正→Static review→commitの主担当とし、
Codexは原則local-only実行/証拠取得へ限定。

WHY:
ユーザーが開発往復を減らし、local専用作業へCodexを集中させる方針を追加。

EVIDENCE:
このチャットのユーザー明示指示およびv4文書。

### 2. commit / pushの扱い

OLD:
旧恒久REPORT指示等には「commit / pushは明示指示時のみ」という包括的表現が残っていた。

NEW:
commitは、意味のある最小変更がStatic reviewを通りlocal検証基準点を固定すべき時点で通常チャットが必要性を通知し、通常チャットがGitHub上で担当する。
pushは引き続きユーザー明示指示時のみ。

WHY:
ユーザーが「コミットが必要なタイミングで知らせること」を追加し、
GitHub上の通常開発を通常チャット主担当に変更したため。

EVIDENCE:
このチャットのユーザー明示指示およびv4文書。

### 3. CurrentRoadmapのNext

OLD:
2026-09-10版:
NEXT=H1_MINIMAL_SAME_SAMPLE_HUMAN_HEAD_FACEPART_PRODUCT_INTEGRATION
H1=未実行。

NEW:
H1 frame identity repair後のHuman Visual=不合格。
Landmarker飛びが再発。
NEXT=同一ビルド Landmarker飛び first-boundary localization。

WHY:
後続の2026-09-13プロジェクトEvidenceが旧Roadmapを時系列上Supersedeしているため。

EVIDENCE:
プロジェクト文脈で保持された直近H1同一ビルド人間確認情報。
このチャットでは再Runtimeしていない。

## OBSERVER / VALIDATOR FINDINGS

このチャットではObserver / Validator / Runtime collectorを新規実行していない。

確認した運用上の原則:
- Human Visual不合格をvalidator PASSで上書きしない。
- 英語内部keyの日本語化は表示契約であり、validator schema自体を勝手に変更しない。
- CurrentRoadmap更新に際し、P3D observer runをclean Performance Authorityへ昇格しない。

新規Observer defect:
NONE CONFIRMED IN THIS CHAT

新規Validator defect:
NONE CONFIRMED IN THIS CHAT

## FILES / SHA256

### Current v4 outputs

Path:
KiwiAvatarSystem_CustomInstructions_20260913_GoalAligned_v4.txt

Role:
通常チャット用カスタム指示。役割分担、日本語判定、commit通知、current state要約。

SHA256:
3CF3A05149BB6936151BEE5FC6509D71C9AB167C10B41059039ED37F1254063C

Size:
7811 bytes / 4997 chars

Before/After:
v3添付版 → v4改訂版

Current/Obsolete:
CURRENT FOR THIS CHAT REVISION

---

Path:
KiwiAvatarSystem_CurrentRoadmap_20260913_GoalAligned_v4.txt

Role:
現行技術状態、first blocker、Next Action、Critical Path、役割分担。

SHA256:
C50C4D3FCDB755EDEA84F9B9ED460FE655FD2ABD6F507BEB4F4CEAEA04725587

Size:
8326 bytes / 5576 chars

Before/After:
2026-09-10 P3D Current → 2026-09-13 H1 Human Visual不合格 / Landmarker飛びfirst-boundary未特定

Current/Obsolete:
CURRENT FOR THIS CHAT REVISION

---

Path:
KiwiAvatarSystem_CoreRules_20260913_GoalAligned_v4.txt

Role:
恒久Project-level契約。Current SHA/Phaseを含めず、通常チャット/GitHub/Codex責務とcommit通知を固定。

SHA256:
33EE4EC32BDA8632EEAE231B36E7C7D34C598389C8AB8AF64218270C94AEDF83

Size:
10801 bytes / 7123 chars

Before/After:
v3添付版 → v4改訂版

Current/Obsolete:
CURRENT FOR THIS CHAT REVISION

## RUNTIME EVIDENCE

このチャットで新規Runtime Evidenceは生成していない。

Authority:
STATIC_ONLY / DOCUMENT_POLICY

参照した製品Current状態は既存プロジェクト文脈からの引継ぎであり、
このチャットの新規same-build Runtime Authorityではない。

Performance Authority:
NONE

Human Visual rerun:
NONE

## CURRENT RESULT

このチャットの文書改訂作業:
完了。

確定:
- 通常チャット + GitHub = 通常source開発の主担当
- Codex = 原則local-only execution/evidence担当
- ユーザー向け確認項目 = 日本語主表記
- commit適切時点 = 通常チャットが通知
- push = ユーザー明示指示時のみ
- 3文書v4生成済み
- CurrentRoadmapは旧P3D/H1未実行状態から後続H1状態へ更新

製品側:
- H1 Human Visual不合格を保持
- Landmarker飛びの原因boundaryは未特定
- Performance / Final Product / Windows Acceptanceは未合格
- local current live Productionは通常チャット未確認

## OPEN ISSUES

1. D:\KiwiAvatarSystem current live HEAD/status/SHAは通常チャット未確認。
2. v4文書がlocal projectの正式情報源へ反映済みかは未確認。
3. Landmarker飛びの最初の因果boundaryは未特定。
4. H1 Human Visualの各症状が同一原因か独立原因か未確定。
5. clean Performance Authorityなし。
6. GitHub上の今後の修正をlocalへ反映する具体的手順は、最初の実修正時にcurrent branch/dirty stateを見て確定する。

## NEXT ACTION

製品開発の次の単一作業:

**同一ビルド Landmarker飛び first-boundary localization**

実施場所の分担:
- 通常チャット:
  GitHub source解析、設計、必要な最小source修正案、Static review、適切ならcommit。
- Codex/local:
  current local identity、local-only files/dirty、exact Unity build、same-build Runtime、hardware/GUI Evidence。
- 人間:
  最終Human Visual判定。

commit:
現時点では原因未特定の補償修正をcommitする段階ではない。
first proven boundaryに対する意味のある最小修正がStatic reviewを通り、
local検証基準点を固定すべき時点で通常チャットが「今がコミット適切時点」と通知する。

## DO NOT CHANGE

新Evidenceが得られるまで理由なく変更しない:

- Face Landmarker Primary / Source of Truth
- latest-frame原則
- FIFO / stale queue禁止
- persistent ROI
- Root / Head / Eye / Mouth authority分離
- Head single rigid authority
- Native Path B baseline
- strong smoothing / Kalman禁止
- stale prediction禁止
- 根拠なきthreshold緩和禁止
- speculative Fence / Wait / flush / async disable禁止
- KiwiFaceMotion / KiwiInferenceFaceTrackerをcamera workaroundにしない
- Big-Bang rewrite禁止
- external tracker Primary置換禁止
- Human Visualをvalidatorで上書きしない

## HANDOFF

次チャットでは以下だけで再開可能。

### 開発運用
通常チャット + GitHubを通常のsource開発主担当とする。
GitHub sourceを通常チャットで解析→最小修正→Static review→commitまで進める。
GitHub上のcommitをlocal Production PASS扱いしない。

Codexは原則local-only:
- live local files/dirty/SHA/provenance
- exact Unity compile/build
- Native build/ABI
- installed artifact
- Runtime/stress/benchmark
- local hardware/GUI Evidence
- rollback/distribution

### 表示
Human Visualチェックは日本語主表記。
必要な時だけ内部英語keyを併記。

### commit
最小変更がStatic reviewを通りlocal検証基準点を固定すべき時点で、
通常チャットがユーザーへ明示的にcommit時期を知らせる。
pushはユーザー明示指示時のみ。

### Product Current
H1 frame identity correctness/restart範囲は直近引継ぎ上合格。
H1 Human Visualは不合格。
Landmarker飛び再発。
原因boundary未特定。
clean Performance未評価。
通常チャットからcurrent local Productionは未確認。

### Product Next
同一ビルドでLandmarker飛びを再現し、
authority / identity / timestamp / provider / presentationの
最初の失敗boundaryだけを特定する。
原因特定前に複数症状の補償修正を入れない。

## PROJECT MASTER REPORTへ反映すべき内容

Archive Name:
KiwiChat_WorkflowRoleSplitAndDocsRevision_Updated_20260913-JST.zip

LastWorkUpdate:
2026-09-13 / DATE_ONLY

Validated Decision:
- 通常チャット + GitHubをsource開発主担当へ
- Codexを原則local-onlyへ
- Human Visual判定を日本語主表記へ
- commit適切時点の通知契約を追加

Rejected Approach:
- Codexを通常GitHub開発の既定担当として使う
- 英語machine keyだけでHuman Visual確認
- commit boundaryを通知しない

Superseded Conclusion:
- commit/push両方を一律「明示指示時のみ」とする旧表現
  → commitは適切なboundaryで通常チャットが通知・担当、pushのみ明示指示。
- 2026-09-10 RoadmapのH1未実行Current
  → 後続H1 Human Visual不合格 / Landmarker飛びCurrent。

Open Issue:
Landmarker飛び first causal boundary未特定。

Next Action:
同一ビルド Landmarker飛び first-boundary localization。

## CHAT ARCHIVE INDEX

Archive:
KiwiChat_WorkflowRoleSplitAndDocsRevision_Updated_20260913-JST.zip

Topic:
WorkflowRoleSplitAndDocsRevision

LastWorkUpdate:
2026-09-13

Status:
DONE

Supersedes:
- 旧Codex広範source-development分担
- 旧英語中心Human Visual checklist運用
- 旧commit/push包括的明示指示運用
- 2026-09-10 Roadmap上のH1未実行Current

SupersededBy:
NONE AT ARCHIVE TIME

NextArchiveCandidate:
Landmarker first-boundary localization / minimal proven fix / next same-build Human Visual closure

## ARCHIVE VALIDATION NOTES

- LastWorkUpdateはREPORT依頼日時ではなく、直前の実質的なv4文書改訂日を使用。
- 正確な改訂時刻を確定できる記録を本チャットから直接取得できないためDATE_ONLYとした。
- SHAはこのチャットで実生成されたv4ファイルから再計算。
- ZIP SHA256は自己参照回避のためREPORT外、最終回答で提示する。
- 本ZIPはREPORT 1ファイルのみを格納し、既存Evidence/成果物を重複梱包していない。
