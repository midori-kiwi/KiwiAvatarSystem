# KiwiAvatarSystem Chat Permanent Report

ChatTopic: CommercialTrackingLandmarkPresentation  
ChatTitle: 商用VTuber / SNSフィルター品質化 — Landmark / Tracking / Model Follow / Mask / Provider Authority / Presentation  
ArchiveName: KiwiChat_CommercialTrackingLandmarkPresentation_Updated_20260823-JST.zip  
LastWorkUpdate: 2026-08-23  
LastWorkUpdatePrecision: DATE_ONLY  
ArchiveCreated: 2026-09-02 23:20 JST  
ArchiveTimestampBasis: LAST_RELEVANT_WORK_BEFORE_ARCHIVE_REQUEST  
Project: D:\KiwiAvatarSystem  
Unity: 6000.0.80f1  
CurrentInvestigationVersion: KiwiAvatarSystem v5.1.0 Phase 16.8 — Commercial Authority / QoS / Writer Audit  
Status: SUPERSEDED  
ChatCloseStatus: VALIDATION_PENDING  
ProductionAuthorityAtArchive: LOCAL_PRODUCTION_NOT_DIRECTLY_VERIFIED  
GitHubBaselineUsedInChat: 0b890a317cc3de64a4eadc955ce87bf21479786b  
RuntimeGraphicsAPIInThisChat: DX11  
ArchiveScope: このチャットで行ったPhase16.x商用品質化作業の恒久保存。2026-09-02時点のプロジェクト全体Current Authorityは、このチャットより後の作業で更新されているため、本REPORTを最新Production Authorityとして扱わない。

---

## EXECUTIVE SUMMARY

このチャットでは、KiwiAvatarSystemのLandmark・Tracking・モデル追従・Eye/Mouth・Mask処理を、商用VTuberソフトおよびTikTok / Snapchat / SNOW等のSNS Face Filterに近い「低遅延・高精度・低ジッター・高速追従・静止安定」品質へ近づけるため、Phase 16.1からPhase 16.8まで段階的に調査・実装・Runtime解析を行った。

最初の重大発見は、Phase16 continuity logicが存在していてもRuntimeで実際には有効化されておらず、CSV全行で `continuityEnabled=0` 等になっていたことである。これはthreshold不足ではなくmigration/application問題だった。そのためPhase16.3系でmigration coordinatorを監査・修正し、旧96回retry loopを廃止、Phase16.2 migrationを同期的・idempotent・検証可能な方式へ変更した。

その後、Phase16.4でHolding中にもPrediction=0を維持したまま既存display resamplerを進めることで、「静止→accepted sample到着時にまとめて動く」階段挙動を改善した。Phase16.5ではProvider handoff補正の解除をsample単位でslew-limitし、短いProvider transitionで位置・回転・Scale差が一度に放出される問題を抑える方向へ進んだ。

Phase16.6ではLandmark/Tracking/Model Follow/Maskを同じframe/generation/timestamp contractへ寄せ、Rigid Coherence GuardとMask transaction generationを強化した。Phase16.7では478 Landmarkをface-local座標へ変換し、平行移動/Roll/Scaleを除去したうえでsub-pixel jitterと孤立点outlierを抑えるcommercial landmark precision layerを追加した。

しかし最新Runtime解析では、Phase16.7のisolated landmark rejectが最大77点、最大補正1.693 eye-spanまで増えており、Yaw/Perspective/Expression等のcoherent deformationをoutlierとして誤認する危険が確認された。またTracking cadence中央値は約6.37Hz、effective accepted interval P95約381msで、Renderは約40FPSあるにもかかわらずTrackingが不規則な5–8Hz域に留まった。ProviderGenerationも3→33と約30回変化し、短いNONE gapの大半が0.6秒以下だったため、短いcadence missをProvider Switchとして扱いすぎていることが商用品質との差として浮上した。

さらに、最新の正しい23:58 MP4+CSV同期解析ではRoot→映像上Avatar中心のrobust fitがR²≈0.99916まで取れた一方、Rootが±150ms内でほぼ動いていないのに見た目だけ0.36–0.80 body-height級で飛ぶeventが複数残った。これはLandmark/Rootだけでは説明できず、Rootより下流のmodel child / renderer / animation / late presentation writerを疑う必要がある。そのためPhase16.8ではSticky Rigid Authority、40FPS環境でも働くCommercial QoS、Landmark mass-reject guard、Attachment recalibration抑制、Presentation profile再調整、およびUpdate→LateUpdate→onBeforeRender→beginCameraRenderingを観測するTransform Writer Auditを追加した。

Phase16.8は累積Overlayとして静的検証・ZIP integrity PASSまで完了したが、このチャット内ではUnity 6000.0.80f1上の実Compile/Preflight/Runtime再計測までは完了していない。よってチャット終端時点のPhase16.8 statusはVALIDATION_PENDINGである。

2026-09-02時点ではプロジェクト全体の作業はさらに進行しており、本チャットのPhase16.8は歴史的アーカイブとして保存する。現在Productionへ無条件に再適用してはならない。

---

## OBJECTIVE

1. Landmark精度を商用VTuber / SNS Face Filter級へ近づける。
2. Trackingを低遅延・低ジッター・高速追従・静止安定へ改善する。
3. Provider switch / dropout / resume時の瞬間ワープを抑える。
4. モデルRoot/HeadとEye/Mouth/Maskを同一semantic transactionへ寄せる。
5. Camera cadenceやInference問題をTracking mathで隠さない。
6. 正常sampleへの遅延を増やさず、異常sample・authority transition・presentation破綻だけを局所的に抑制する。
7. 商用ソフト公開設計を比較し、Kiwiへ適用可能な原則だけ採用する。
8. Runtime MP4+CSVを全フレーム解析し、仮説ではなく実測で次の修正対象を決める。

---

## CONFIRMED FACTS

### Project / Environment used in this chat

- Unity: 6000.0.80f1。
- Runtime evidence in this chat: DX11。
- MediaPipeUnityPlugin: v0.16.3。
- Face LandmarkerをPrimary / Source of Truthとして維持する方針。
- GitHub main baselineとして `0b890a317cc3de64a4eadc955ce87bf21479786b` を確認していた。
- 通常チャットから `D:\KiwiAvatarSystem` のlocal Production実体およびactual Production SHAを直接確認していない。
- よってProductionについては `LOCAL_PRODUCTION_NOT_DIRECTLY_VERIFIED`。

### Phase16 continuity application defect

Phase16.2適用前のRuntimeではactive CSV rowすべてで以下が0だった:

- `continuityEnabled=0`
- `directBypassSuppressed=0`
- `discontinuityGuard=0`
- `trackingRateHz=0`
- `effectiveIntervalMs=0`
- `responseCap=0`

UI変更はRuntimeで反映されていたため、Overlay全体が未ロードなのではなく、continuity source patch/migrationがKiwiFaceMotionへ実適用されていないことが主因と判断された。

### 96-attempt retry loop defect

Phase16.3 coordinatorはPhase16.2 markerを待ちながら96回migration application attemptを繰り返したが、旧Phase16.2 migrationがexact-string anchor依存であり、失敗時にsourceを変えずgeneric warningを出すだけだった。よって96回繰り返しても状態は進まず、retry loop自体が有害だった。

Phase16.3bで:
- 96回retry loopを削除。
- Phase16.2 migrationをdirect call。
- source即再読込。
- markerとrequired tokenを同期検証。
- stage別failure reasonを出す方式へ変更。

### Unity 6 API compatibility defect

Phase16.3aで `Time.unscaledTimeSinceLevelLoad` がUnity 6000.0.80f1で存在しないことを修正。

### Phase16.4 continuity behavior

Phase16.3b後のretestでは:
- `continuityEnabled=1` が有効区間全行で成立。
- guardも実際に作動。
- tracking rate / response capが実値を持つようになった。

一方、Rootがrender frameの多くで完全停止し、accepted sample到着時だけ大きく進む階段状挙動が残った。

Phase16.4ではHolding中:
- `ResetPredictionHistory()` を先に行う。
- Prediction=0を維持。
- `UpdateAndRenderDisplayPose(dt)` で最後にaccept済みposeへ既存display resamplerだけを進める。
という方式へ変更。

### Phase16.5 Provider handoff finding

あるretestでは:
- Provider switch: 約16回 / 約25秒。
- Large Root event: 15件。
- そのうち14件、約93%がProvider switch後3 accepted sample以内。

Phase16.5ではhandoff releaseをaccepted sample単位でslew-limitし、release step最大0.42/sampleとした。

### Commercial cadence mismatch

Phase16.5当初のcommercial cadence boostはRender>=45FPSを条件にしていたが、最新実測ではRender中央値約40FPSのため、boostは2548行中172行、約6.75%しか有効でなかった。

Phase16.8で:
- ON threshold: 34FPS
- OFF threshold: 30FPS
- hysteresis
- normal QoS target: 12Hz
- source age悪化時: 15Hz
へ変更。

### Phase16.7 Landmark refiner over-rejection

最新Runtimeで:
- `landmarkIsolatedRejectCount` 最大77。
- 最大補正量 1.693 eye-span。

Phase16.8で:
- isolated hold最大4点/sample。
- 5点以上がreject候補ならcoherent geometry changeとしてmass rejectをキャンセル。
へ変更。

### Latest matched MP4 + CSV

正しい対応pair:

Video:
`KiwiAvatarSystem - Face Landmark Detection - Windows, Mac, Linux - Unity 6.0 (6000.0.80f1) _DX11_ 2026-08-22 23-58-34(1).mp4`

CSV:
`KiwiFrameComparison_20260822_235836.csv`

解析:
- Video: 1697 / 1697 encoded frames。
- CSV: 2548 / 2548 rows。
- Root→video Avatar center robust fit: R²≈0.99916。
- tracking rate median≈6.37Hz。
- effective accepted interval median≈157ms。
- P95≈381ms。
- Render median≈40FPS。
- ProviderGeneration 3→33、約30回generation変化。
- NONE gap 52区間、そのうち51/52が0.6秒以下。
- max visible jump≈189.4px≈0.842 body-height。
- Rootが±150ms内でほぼ動いていないのにvisible modelだけ0.36–0.80BH級で動くeventも複数確認。

### Mismatched CSV discovery

`KiwiFrameComparison_20260822_230122(1).csv` は以前のCSVとSHA256完全一致で、23:58 video用CSVではなかった。
これはProduction defectではなくEvidence identity / pairing問題。

---

## PUBLIC DESIGN PRINCIPLES

このチャットではVTube Studio、Warudo、Animaze、TikTok Effect House等の公開仕様・公開挙動を比較対象にした。

採用した公開設計原則:

1. Tracking cadenceとdisplay cadenceを分離する。
2. Tracking sampleをdisplay FPSへ補間する。
3. Headは安定したsingle rigid authorityを持つ。
4. Position / Rotation / Expressionを別channelとして扱う。
5. 通常動作と高速動作でresponse policyを分ける。
6. Short dropoutを即authority switchへ変換しない。
7. Lost / Recoveryを明示状態として扱う。
8. Face Binding / Mask / Occlusionは共通顔座標系へ結びつける。
9. 商用品質は「全部を強くLow Passすること」ではなく、normal motion latencyとexception handlingを分離する。
10. 非公開商用ソフトの内部実装は断定しない。公開情報から得られる原則のみKiwiへ適用する。

商用比較からの主要判断:
Kiwiの商用品質との差はLandmarkモデル単体だけでなく、irregular tracking cadence、provider authority churn、distributed presentation transactions、Rootより下流のtransform writer可能性が大きい。

---

## INFERENCES / HYPOTHESES

### H1. Rootより下流のTransform writer

候補:
- Model child Transform
- Animator / Animation
- Renderer transform / matrix
- LateUpdate後のscript
- `onBeforeRender`
- `beginCameraRendering`
- Camera projection/presentation timing

Phase16.8 Transform Writer Auditで確定予定。

### H2. Provider churnがTracking品質を大きく劣化

短いNONE gapの大半が0.6秒未満であるため、短いcadence missをprovider loss/switchに変換しすぎている可能性が高い。

### H3. Texture + Crop + Mask full atomicity未完了

FacePartCropperはCrop/Mask geometryをsemantic timestampでholdできる一方、表示Textureは現在の`sourceImage.texture`へ進む構造がある。最終的には `Texture + Crop + Mask + canonical semantic geometry` をmatched camera sample単位のimmutable transactionとして扱う必要がある可能性が高い。

### H4. Presentation target timeの分散

Root / Crop / Contour / Mask / GPU local residualが独立presentation timingを持つため、最終commercial architectureでは単一Presentation Target Timeへ揃える必要がある可能性がある。ただしPhase16.8 writer audit結果前に大規模再設計しない。

---

## PRODUCTION AUTHORITY

このREPORTでのAuthority:

1. このチャットで得られたlatest matched Runtime MP4+CSV。
2. このチャットで生成・静的検証したPhase16.x Overlay。
3. GitHub main baseline `0b890a317cc3de64a4eadc955ce87bf21479786b`。
4. MediaPipe / Unity / commercial software公開設計情報。
5. 過去Phase16.x diagnostics。

重要:
- `D:\KiwiAvatarSystem` local Production actual placement/SHAは通常チャットから直接確認していない。
- `LOCAL_PRODUCTION_NOT_DIRECTLY_VERIFIED`。
- GitHub mainがlocal Productionより古い可能性があるため、GitHubをProduction authorityとして扱わない。
- 2026-09-02時点のProject-wide authorityは本チャットより新しい。したがって本REPORTはhistorical chat archiveであり、Phase16.8を現在Productionへ直接再適用する根拠にはしない。

---

## WORK PERFORMED

### Phase16.1 — Diagnostic Play Gate Fix
- 目的: continuity diagnostic / play gate周辺の修正。
- Status: SUPERSEDED。

### Phase16.2 — Measured Continuity / UI Layout
- accepted realtime cadence fallback。
- Position error 0.20 body-height。
- Rotation error 24°。
- Scale error 0.10。
- 後のRuntimeでmigration application自体の失敗が判明。
- Status: SUPERSEDED。

### Phase16.3 / 16.3a / 16.3b
- migration application guarantee。
- Unity6 compile API fix。
- 96回retry loop廃止。
- Phase16.2 migrationをidempotent / stage-verified化。
- continuity logicが実Runtimeでactiveになった。

### Phase16.4 — Presentation Hold Resampling
- Holding中Prediction=0維持。
- last accepted poseへdisplay resampler継続。
- あるretestで最大visible jumpが約514.6px→約82.8px / 0.426BH、約84%改善。

### Phase16.5 — Commercial Handoff + Cadence
- handoff release monotonic。
- max release 0.42/sample。
- commercial cadence boost追加。
- 後に45FPS gateが実環境で不足と判明。

### Phase16.6 — Commercial Landmark / Tracking / Follow / Mask
- landmark topology guard。
- Rigid Coherence Guard。
- commercial presentation tuner。
- Mask transaction generation consistency。
- global smoothingを増やさず異常frameだけ抑える方向を維持。

### Phase16.7 — Commercial Landmark Precision
- 478点face-local化。
- translation / roll / scale除去。
- eye / mouth / brow / iris region handling。
- isolated outlier hold。
- eye-span normalization。
- 2nd sample reacquisition。
- Runtimeでmass rejection過多を発見。

### Phase16.8 — Commercial Authority / QoS / Writer Audit
- Sticky Rigid Authority。
- short cadence miss中provider identity最大0.60秒維持。
- minimum ownership 1.0秒。
- MediaPipe→Inference Engine復帰は4 independent coherent frames確認。
- QoS ON 34FPS / OFF 30FPS。
- normal 12Hz / high source age 15Hz。
- isolated hold max 4 points/sample。
- >=5 points候補ならmass-reject bypass。
- short internal provider switchでattachment recalibrationしない。
- lost>=0.60秒のみreacquisition calibration候補。
- fast presentation threshold 32FPS。
- Transform Writer Audit: Update / LateUpdate / onBeforeRender / beginCameraRendering。
- Static validation / ZIP integrity PASS。
- Unity Runtime validationは未完了。

---

## VALIDATED DECISIONS

1. Continuityが実Runtimeでactiveであることを確認する前にthreshold tuningしない。
2. 96-attempt marker wait retry loopを使用しない。
3. Holding中はPrediction=0を維持し、last accepted poseへ既存display resamplerだけを進める。
4. Provider switch transitionだけ局所slew-limitし、same-provider normal motionへglobal smoothingを追加しない。
5. Commercial tracking QoSはactual Render FPSに合わせる。
6. Landmark isolated outlier guardで大量点を同時holdしない。
7. Rootでは説明できないvisible jumpをLandmark smoothingで隠さない。
8. Transform Writer AuditでRoot後段writerを特定してから修正する。

---

## REJECTED APPROACHES

- Continuity inactiveのままthresholdをさらに厳しくする。
- Global Kalman / strong Low Passで商用品質を作る。
- Provider switchだけを厳しくすれば全jumpが解決すると仮定する。
- Landmark precisionだけをさらに強くする。
- 23:01 CSVを23:58 videoのEvidenceとして扱う。
- 45FPS固定gateをcommercial cadence policyとして維持する。

---

## SUPERSEDED CONCLUSIONS

OLD: 主因はcontinuity threshold不足。  
NEW: まずcontinuity migration/application failureだった。

OLD: Continuityがactiveになればvisible jump問題はほぼ終了。  
NEW: Provider transition、low cadence、Root-independent visual jumpが残る。

OLD: Landmark precision不足がモデルjumpの主要因。  
NEW: Landmark/Rootがほぼ動かないのにmodel visible stateだけ飛ぶeventが存在。

OLD: Phase16.7 isolated landmark guardをそのまま強化可能。  
NEW: mass reject防止が必要。

OLD: Commercial cadence boost threshold 45FPS。  
NEW: Phase16.8では34FPS ON / 30FPS OFF hysteresis。

OLD: `KiwiFrameComparison_20260822_230122(1).csv` を最新23:58 videoと組み合わせる。  
NEW: 23:58 videoは `KiwiFrameComparison_20260822_235836.csv` が正しいpair。

---

## OBSERVER / VALIDATOR FINDINGS

1. 旧Phase16.3 coordinatorの96回attemptはprogress指標ではなく、migration design defectだった。
2. `Time.unscaledTimeSinceLevelLoad` compile errorはtracking defectではなくUnity API compatibility defectだった。
3. 旧CSVと23:58 videoのpair mismatchはEvidence identity defectだった。
4. Root comparator aloneではvisible jumpを完全に説明できず、observer coverage gapがあった。
5. Phase16.8 static PASSをUnity Runtime PASSとして扱わない。

---

## FILES / SHA256

### Cumulative overlays created in this chat

- Phase16.1: `KiwiAvatarSystem_v5_1_0_Phase16_1_DiagnosticPlayGateFix_Overlay(1).zip`  
  SHA256 `f7cc3ebc8d058264c3db32b52d1367d3b67f110f1bf1e6efcdbf3700fa48162c` — OBSOLETE。

- Phase16.2: `KiwiAvatarSystem_v5_1_0_Phase16_2_MeasuredContinuity_UILayout_Overlay.zip`  
  SHA256 `ca98ffd957864aae8fa501b8c6599927ea0f70561d23dc41fc3b3e03edd6d38e` — OBSOLETE。

- Phase16.3: `KiwiAvatarSystem_v5_1_0_Phase16_3_ContinuityMigrationApplicationGuarantee_Overlay.zip`  
  SHA256 `e375306776a6572022aff80cdaa6247713e21a726e8ec9a49f6a89e0023195b7` — OBSOLETE。

- Phase16.3a: `KiwiAvatarSystem_v5_1_0_Phase16_3a_Unity6CompileFix_Overlay.zip`  
  SHA256 `77897ec1ad22881dd051684ff68de46de81b77eff98671dd84c7b499219ea062` — OBSOLETE as delivery; fix retained。

- Phase16.3b: `KiwiAvatarSystem_v5_1_0_Phase16_3b_ContinuityMigrationRepair_Overlay.zip`  
  SHA256 `d5a014e93f4953de254f235f94cd893ae03e81ab8fbf1905ecd758e74f028eb6` — OBSOLETE as delivery。

- Phase16.4: `KiwiAvatarSystem_v5_1_0_Phase16_4_PresentationHoldResampling_Overlay.zip`  
  SHA256 `7bdda2dfe231127eff38942664f04de15a2f89eecbacc79ec705230c986bb421` — OBSOLETE as delivery。

- Phase16.5: `KiwiAvatarSystem_v5_1_0_Phase16_5_CommercialHandoffCadence_Overlay.zip`  
  SHA256 `51810d7b7157b3bf81c3bd617717931872f2baed7a7c9b92f2b164f4ed4cacde` — OBSOLETE。

- Phase16.6: `KiwiAvatarSystem_v5_1_0_Phase16_6_CommercialLandmarkTrackingFollowMask_Overlay.zip`  
  SHA256 `7ee9f0f33ff0a8e26f5de57b4c1874e48688d289a7c20e2ce2aac11d518d4e4a` — OBSOLETE。

- Phase16.7: `KiwiAvatarSystem_v5_1_0_Phase16_7_CommercialLandmarkPrecision_Overlay.zip`  
  SHA256 `cb67d42a75ab1ccb1b13536e9437c9336f20215a1c3f36a834fd3fd8634cc99d` — OBSOLETE; partly superseded。

- Phase16.8: `KiwiAvatarSystem_v5_1_0_Phase16_8_CommercialAuthorityQoSWriterAudit_Overlay.zip`  
  SHA256 `e1c2b143ba2c38ae80c3487db75123b72d0f31b94614c95829f31ed7afb38a6d` — LATEST_IN_THIS_CHAT / VALIDATION_PENDING / HISTORICAL_ONLY_AS_OF_ARCHIVE。

### Important source files discussed

- `Assets/Script/KiwiFaceMotion.cs` — local Production SHA: `NOT_AVAILABLE_IN_NORMAL_CHAT`。
- `Assets/Script/FaceLandmarkerRunner.cs` — GitHub baseline blob SHA `07642817b5d929888cf86ec9d0b55756800d32db`; local Production SHA unavailable。
- `Assets/Script/FacePartCropper.cs` — GitHub baseline blob SHA `8cf3d9571d0b8093e58ea27b8d81ee51b209761d`; local Production SHA unavailable。
- `Assets/Script/FacePartShapeMask.cs` — GitHub baseline blob SHA `2ae12d712a41dc78e4246c36e0502fe49539f510`; local Production SHA unavailable。

---

## RUNTIME EVIDENCE

### Evidence A — Continuity inactive run

Files:
- `KiwiAvatarSystem - Face Landmark Detection - Windows, Mac, Linux - Unity 6.0 (6000.0.80f1) _DX11_ 2026-08-22 21-47-08.mp4`
- `KiwiFrameComparison_20260822_214702.csv`

Authority: CORRECTNESS + VISUAL。

Key result:
- continuity telemetry all 0。
- max visible jump≈514.6px。
- mapped CSV Unity Frame 1025。
- `rootPositionDelta=4.670797` ≈2.359 body-height。
- rotation delta≈28.74°。
- Provider NONE→Runner/MediaPipe。

### Evidence B — Phase16.4 retest

Authority: CORRECTNESS + VISUAL。

Known metrics:
- Video 665 encoded frames。
- CSV 913 rows。
- `continuityEnabled=1` active 913/913。
- guard active 225 rows。
- max video jump≈82.8px≈0.426BH。
- prior≈514.6px/frameから約84%改善。
- Root positionの約82% render framesが完全停止する階段問題を確認。

Exact filenameはcurrent archive contextに残っていないため推測しない。

### Evidence C — Phase16.5 retest

Authority: CORRECTNESS + VISUAL。

Known metrics:
- Video 827 encoded frames。
- CSV 1260 rows。
- tracking median≈8.03Hz。
- accepted interval≈124.5ms。
- observation age median≈163ms。
- provider switch≈16。
- large Root events 15。
- switch後3 accepted sample以内14/15≈93.3%。

Exact filenameは推測しない。

### Evidence D — Latest correct matched pair

Video:
`KiwiAvatarSystem - Face Landmark Detection - Windows, Mac, Linux - Unity 6.0 (6000.0.80f1) _DX11_ 2026-08-22 23-58-34(1).mp4`

CSV:
`KiwiFrameComparison_20260822_235836.csv`

Authority: CORRECTNESS + VISUAL。

- video 1697 / 1697 encoded frames。
- CSV 2548 / 2548 rows。
- Root→video Avatar center robust fit R²≈0.99916。
- tracking median≈6.37Hz。
- accepted interval median≈157ms、P95≈381ms。
- Render median≈40FPS。
- ProviderGeneration 3→33、約30 transitions。
- NONE gaps 52、うち51/52<=0.6s。
- Landmark isolated reject max=77。
- max adjustment=1.693 eye-span。
- max visible jump≈189.4px≈0.842BH。
- Root-independent visible events 0.36–0.80BH級も複数。

### Evidence E — Wrong pair CSV

`KiwiFrameComparison_20260822_230122(1).csv`

Authority: INVALID_FOR_23_58_VIDEO。
Reason: 旧CSVとSHA256完全一致。
Classification: OBSERVER / EVIDENCE IDENTITY ISSUE。

---

## CURRENT RESULT

Chat-end technical result:
`KiwiAvatarSystem v5.1.0 Phase 16.8 — Commercial Authority / QoS / Writer Audit`
まで実装・静的検証・ZIP生成済み。

Phase16.8 static validation:
- C# 69 files。
- delimiter issues 0。
- duplicate meta GUID 0。
- required markers確認。
- old 96 retry 0。
- `Time.unscaledTimeSinceLevelLoad` 0。
- ZIP integrity PASS。

Not completed in this chat:
- Unity 6000.0.80f1 actual compile after Phase16.8。
- Full Preflight after Phase16.8。
- Phase16.8 runtime MP4+CSV。
- Writer Audit runtime verdict。
- Root後段writerの直接修正。
- full Texture/Crop/Mask immutable transaction。
- unified Presentation Target Time。

Archive-time interpretation:
本チャットは2026-09-02時点では後続project workによりSUPERSEDEDされたhistorical archive。Phase16.8をcurrent Productionとして再適用しない。

---

## OPEN ISSUES

1. Phase16.8 Unity compile / preflight / runtime未検証。
2. `rootMovedAfterLate` の実Runtime結果未取得。
3. `visualMovedWithoutRoot` の実Runtime結果未取得。
4. Root-independent visual jumpのwriter未特定。
5. Tracking cadenceがcommercial targetへ届くか未確認。
6. Sticky authorityでProviderGeneration churnがどこまで減るか未確認。
7. Landmark mass reject bypassがreal Yaw/Perspectiveを正しく通すか未確認。
8. Texture + Crop + Mask + camera sample full atomic transaction未完成。
9. Root / Crop / Contour / Mask / GPU residualのpresentation target time統合未完成。
10. Absolute anatomical Landmark accuracyはground-truth計測未実施。
11. GitHub baselineとactual local Productionの差はこのチャットでは直接確認していない。

---

## NEXT ACTION

### Chat-close next action

当時のPhase16.8状態を検証する場合:

1. Unity compile red errors=0確認。
2. Full Preflight `5.1.0-phase16.8`。
3. 同一Play sessionで新Frame Comparison CSV開始。
4. MP4録画。
5. static / slow X/Y / diagonal / fast motion / abrupt stop / reversal / Yaw/Pitch/Roll / Blink / gaze / Mouth / Brow / deep profile / short Lost / longer Lost / Reacquireを実施。
6. CSV stop後にvideo stop。
7. MP4+同一run CSVを全frame解析。

最重要判定:
- `rootMovedAfterLate=1` → LateUpdate後Root writer。
- `visualMovedWithoutRoot=1` → model child / renderer / animator writer。
- 両方0でvisible jump → Camera projection / renderer matrix / capture timing。

### Archive-time current-project caveat

2026-09-02現在、Project-wide workはこのchat後に進んでいる。現在作業を再開する場合は、まず最新Project Master / KiwiValidation / local Production authorityを確認し、このPhase16.8 handoffをそのままCurrent Planとして使わない。

---

## DO NOT CHANGE

新しい独立Evidenceなしに以下を変更しない:

- Face Landmarker Primary / Source of Truth。
- Head single rigid authority。
- Eye/Mouth→Root feedback禁止。
- Same Provider ResumeとProvider Switchの区別。
- Source AgeとLivenessの分離。
- GPU callback→Presentation direct write禁止。
- Holding/Lost Prediction=0。
- latest-frame priority。
- FIFO / stale queue禁止。
- Root writer追加禁止。
- strong global smoothing / Kalmanで問題を隠さない。
- thresholdを実測なしに変更しない。
- camera/inference cadence問題をKiwiFaceMotion / KiwiInferenceFaceTrackerのtracking mathで隠さない。
- Texture/Crop/Mask transaction contractを弱めない。
- old generation / duplicate / out-of-order publishを許可しない。
- actual local Production SHA確認なしにcritical filesを上書きしない。
- historical Phase16.8 Overlayを2026-09-02 current Productionへ無条件再適用しない。
- commit / pushは明示指示なしに行わない。

---

## HANDOFF

このチャットはPhase16.xのcommercial-quality tracking改善履歴である。

最重要の歴史的流れ:

1. Continuity logicは存在していたがRuntimeでinactiveだった。
2. Phase16.3bでmigration applicationを確実化し、96 retryを廃止。
3. Phase16.4でHolding中display resamplingを導入。
4. Phase16.5でprovider handoff releaseをslew-limit。
5. Phase16.6でLandmark/Tracking/Model/Mask transactionを強化。
6. Phase16.7でface-local Landmark refinementを追加。
7. RuntimeでLandmark mass reject過多、Tracking 6.37Hz、Provider churn約30回、Root-independent visible jumpを発見。
8. Phase16.8でSticky Authority / 12–15Hz QoS / mass-reject bypass / attachment recalibration guard / Writer Auditを実装。
9. Phase16.8はstatic PASSだがRuntime未検証でチャット終了。
10. 2026-09-02時点ではProject全体Authorityはこのchat後へ進んでいるため、本REPORTはhistorical archive。

現在Project作業を続けるなら、最新local Production、latest Runtime、latest KiwiValidation、current Package SourceをAuthorityとして、このREPORTは背景履歴として参照する。

---

## PROJECT MASTER REPORT UPDATE CANDIDATES

LOCAL MASTER REPORT: NOT_UPDATED_FROM_NORMAL_CHAT

反映候補:
- Archive: `KiwiChat_CommercialTrackingLandmarkPresentation_Updated_20260823-JST.zip`
- LastWorkUpdate: 2026-08-23 DATE_ONLY
- Validated: continuity application先行確認 / 96 retry廃止 / Holding resampling / Provider局所slew / mass Landmark reject禁止 / Writer Audit方針
- Rejected: global smoothing / continuity inactiveでthreshold tuning / Landmark単独原因説 / mismatched CSV authority化
- Open Issue at chat close: Phase16.8 Writer Audit runtime validation
- Current archive note: 2026-09-02時点ではlater project workによりSUPERSEDED

---

## CHAT ARCHIVE INDEX

Archive: KiwiChat_CommercialTrackingLandmarkPresentation_Updated_20260823-JST.zip  
Topic: CommercialTrackingLandmarkPresentation  
LastWorkUpdate: 2026-08-23  
LastWorkUpdatePrecision: DATE_ONLY  
Status: SUPERSEDED  
ChatCloseStatus: VALIDATION_PENDING  
Supersedes: Phase16.1–Phase16.7 cumulative chat delivery state  
SupersededBy: LATER_PROJECT_WORK_AFTER_2026-08-23; exact archive/version not established by this chat report  
NextArchiveCandidate: Current project investigation archive as of 2026-09-02, not this historical Phase16 branch

---

## ARCHIVE VALIDATION NOTES

- Archive timestamp uses last relevant technical work date, not report creation date。
- Exact technical-work clock time was not available; time was not guessed。
- LastWorkUpdatePrecision=DATE_ONLY。
- ArchiveCreated is separate: 2026-09-02 23:20 JST。
- local Production not directly verified。
- unknown SHA values were not invented。
- Correctness / Visual / Static evidence are separated。
- Phase16.8 static PASS is not represented as Runtime PASS。
- obsolete / superseded conclusions are retained with replacement reasons。
- Evidence files are indexed rather than duplicated into this archive to keep artifact count minimal。
