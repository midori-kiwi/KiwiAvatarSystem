# KiwiAvatarSystem Chat Permanent Report

ChatTopic: CPU Inference Semantic / Output Transaction Authority
ChatTitle: Native Exact-HostTicks Preflight → v44.55.15 Semantic Gate → Project-Wide Reassessment
ArchiveName: KiwiChat_CPUInferenceSemanticAuthority_Updated_20260902-JST.zip
LastWorkUpdate: 2026-09-02
LastWorkUpdatePrecision: DATE_ONLY
ArchiveCreated: 2026-09-03T00:29:00+09:00
ArchiveTimestampBasis: LAST_RELEVANT_WORK_BEFORE_ARCHIVE_REQUEST
Project: D:\KiwiAvatarSystem
Unity: 6000.0.80f1 / Windows / DX12
CurrentInvestigationVersion: v44.55.24 Pair-Bound Shadow Output Snapshot (NEXT / NOT YET VALIDATED)
Status: IN_PROGRESS

Archive: KiwiChat_CPUInferenceSemanticAuthority_Updated_20260902-JST.zip
Topic: CPU inference semantic equivalence, preprocessing authority, observer validity, output transaction authority
Supersedes: this chat's earlier v44.55.16 immediate-next plan; immediate Native/mode2 Production directions
SupersededBy: NONE
NextArchiveCandidate: v44.55.24 completion / Production Output Transaction Authority decision

## EXECUTIVE SUMMARY

This chat re-audited the CPU Production path before allowing any Production change. The main result was not a Production defect but repeated discovery of Observer/Validator defects: PowerShell 5.1 assumptions, launcher dependencies, false BAT launch failure, report persistence weakness, and an irrelevant mesh-triangle readiness gate. These were corrected without changing Tracker, Runner, Interop, Native DLL, tracking math, or Production GPU authority.

v44.55.15 FIX5 produced a valid same-frame CPU-vs-CPU preprocessing comparison. Plain exact-hostTicks CURRENT_FLOAT was very close at raw landmark/presence level but failed the predeclared proxy gate on centroid and bbox-center; thresholds were not relaxed after the result.

A whole-project review then changed the validation emphasis from pixel/raw-landmark proxy agreement to Source Identity → Input/Timestamp coherence → Model Semantic → Canonical Output → Authority/Transaction Safety → Latency/Cadence → Lifecycle/Recovery → Resource/Memory → Visual MP4.

IMPORTANT CURRENT-AUTHORITY UPDATE: the supplied 2026-09-02 integrated project state contains later work beyond the early end of this chat. v44.55.17 canonical semantic failed; v44.55.19 rejected CURRENT_FLOAT and mode2 as Production CPU authority; v44.55.20 excluded backend difference and confirmed preprocessing as the discrepancy domain; v44.55.21 rejected border/footprint; v44.55.22 rejected Production lane.input direct readback as an authority oracle; v44.55.23 completed 115/115 with Observer Validity PASS but MIXED_TRANSACTION remains tentative because Worker output lifecycle reuse has not been excluded. Therefore the next action is v44.55.24 Pair-Bound Shadow Output Snapshot, not v44.55.16 and not CPU Production conversion.

## OBJECTIVE

1. Determine whether CPU inference can replace GPU Production without semantic, latency, cadence, lifecycle, or transaction regressions.
2. Avoid Native C++/DLL changes while source provenance is not fully closed.
3. Separate backend cost from preprocessing/input semantic differences.
4. Audit the Validator/Observer itself before trusting results.
5. Establish trustworthy pair-bound Production/reference output authority.

## CONFIRMED FACTS

### Environment
- Project: D:\KiwiAvatarSystem
- Unity: 6000.0.80f1
- Windows / DX12
- Ryzen 9 5950X / RTX 4090
- UGREEN Camera 4K, 1920x1080@60 Native NV12
- MediaPipeUnityPlugin v0.16.3
- Unity Inference Engine 2.4.1
- Face Landmarker Primary / Source of Truth
- Native Production camera: Path B SystemMemoryNV12
- Production inference baseline: 3-lane GPUCompute

### Production SHAs used by v44.55.15 static guards
- KiwiInferenceFaceTracker.cs: 52C046EE44B41A4FF50B85AEF503BC29DD31B57EAF58C0D160CCC33C5D4B7695
- FaceLandmarkerRunner.cs: 6C65C075270F10C791F6B044E3BC04C6024AADF916D65283F0EEFFA3448BBB93
- KiwiNativeCameraInterop.cs: AC473ADBADE5EDC89726211ECAF03D040B5CC00FCA39BEA4A0D16195FA53E8B5
- active KiwiNativeCamera.dll: 82D1FC2910468056C02E8BAE1C72996D8492173A84BEBBCAE322EBEF435678A5

These hashes were explicitly guarded in this chat. They are not claimed to be the final 2026-09-03 local hashes without a fresh local audit. LOCAL_PRODUCTION_NOT_DIRECTLY_VERIFIED.

### Native provenance
The available Native source was marked RECONSTRUCTED_CANDIDATE: not recovered original, not bit-identical to active DLL, and not sufficient to justify Production replacement. Therefore ABI/export parity alone is insufficient and guessed Native rebuild is prohibited.

### v44.55.15 FIX5 semantic result
Comparison:
A = same exact-hostTicks CURRENT_FLOAT snapshot → CPU Worker
B = same snapshot/hostTicks/crop matrix PRESENTATION_PLUS_FINAL_UNORM8 mode2 → CPU Worker

Production GPU remained sole authority; no tracker/ROI/authority write; no Native DLL change; identity-neighbor correction was excluded from the decision.

Measured:
- completed pairs: 16
- pair errors: 0
- nonfinite: 0
- presence decision mismatch: 0
- semantic presence mismatch: 0
- landmark 2D p95: ~0.726 px
- landmark within 2 px: 100%
- bbox width p95: ~0.455 px
- bbox height p95: ~0.242 px
- centroid p95: ~0.587 px
- bbox center p95: ~0.527 px
- semantic PASS: 4
- semantic FAIL: 12

Predeclared proxy failures: centroid p95 >0.25 px and bbox center p95 >0.25 px. No post-hoc threshold relaxation.

### Later 2026-09-02 project authority
- v44.55.17: Canonical Semantic FAIL.
- v44.55.19: CURRENT_FLOAT HARD_FAIL; mode2 AGGREGATE_FAIL; both rejected as Production CPU authority.
- v44.55.20: Common Tensor Backend Isolation PASS across REF/A/B GPU/CPU; PREPROCESSING_CONFIRMED; backend itself not primary discrepancy.
- v44.55.21: MODE2_CLAMP == MODE2_ORIGINAL bitwise; 110 pairs; ge4AnyTapOobRatio=0; originalClampExactRatio=1; BORDER_REJECTED. >=4 LSB anomalies concentrated in 8/110 pairs.
- v44.55.22: Production lane.input direct oracle REJECT because queue-external readback can create false differences.
- v44.55.23: packed logical output 1405 floats; backing capacity may be larger; 115/115 completed; observerFault=0; snapshot/identity/shape/nonfinite failures=0; anomalous=8; Production=REF exact 5; Production=MODE2 exact 0; Neither exact 3; Observer Validity PASS; MIXED_TRANSACTION tentative.
- Remaining risk: shadow Worker output can be re-read after later schedules reuse Worker/allocator-owned output memory.

## PUBLIC DESIGN PRINCIPLES

- Real-time tracking must bound in-flight work and prefer latest data over stale backlog.
- Tracking/input cadence and presentation/display cadence are separate concerns.
- Unity Inference Engine Worker outputs are Worker/allocator-owned and must not be treated as indefinitely immutable snapshots.
- Tensor logical count/shape differs from backing storage capacity; backing ComputeBuffer capacity may exceed logical length.
- Readback/snapshot correctness depends on lifecycle and pair identity, not only values.
- Commercial VTuber internals are not asserted when non-public; only public design principles are used.

## INFERENCES / HYPOTHESES

Leading hypothesis: the remaining intermittent anomalies are more likely transaction/lifecycle-related than constant border or backend arithmetic errors, because backend isolation passed, border clamp matched bitwise, large anomalies are sparse, lane.input direct oracle was invalidated, and v44.55.23 still has an unclosed Worker-output lifecycle observation window.

Not proven until v44.55.24:
- whether the 3 NEITHER_EXACT pairs are real Production differences,
- whether pair-bound snapshots remove them,
- whether pixel-center/subtexel/transform/FMA investigation is still needed afterward.

## PRODUCTION AUTHORITY

Priority:
1. local Production actual placement + SHA
2. same-Production latest Runtime
3. actually used package source
4. latest KiwiValidation / consolidated report
5. official documentation/source
6. local git history
7. GitHub main
8. older diagnostics
9. issues/articles/social evidence

GitHub: https://github.com/midori-kiwi/KiwiAvatarSystem/tree/main
GitHub main may lag local Production and must not override it.

## WORK PERFORMED

1. Native Exact Quantized Preflight reassessment → immediate Native rebuild path rejected because source provenance was not closed.
2. v44.55.15 observer built to compare same-frame CURRENT_FLOAT and mode2 on CPU while preserving Production GPU authority.
3. Validator bug: PowerShell StrictMode + LASTEXITCODE assumption → fixed via Start-Process -Wait -PassThru / Process.ExitCode.
4. Launcher bug: historical fixed launcher filename dependency → replaced by direct Path-B Unity launch.
5. Launcher bug: stale ERRORLEVEL caused false Failed-to-launch message → fixed via post-launch process verification.
6. Observer persistence bug: stopping Editor Play did not guarantee report → ARMED proof, fixed Editor log, partial report on stop, explicit runtime duration.
7. Observer gate bug: exact mesh triangle count blocked semantic measurement although unrelated to inference input → triangle count demoted to observation-only.
8. v44.55.15 FIX5 valid semantic run → CURRENT_FLOAT not promoted; thresholds unchanged.
9. Whole-project review → validation order moved from proxy pixel/raw-output emphasis to source/canonical/transaction authority.
10. 2026-09-02 later authority integrated → v44.55.24 is now the next action.

## VALIDATED DECISIONS

Decision: Face Landmarker remains Primary / Source of Truth.
Reason: CPU investigation does not justify tracker replacement.
Still current: YES.

Decision: Native Path B SystemMemoryNV12 remains Production.
Reason: stable validated camera path.
Still current: YES.

Decision: GPU inference remains Production authority until semantic and transaction correctness are closed.
Still current: YES.

Decision: CPU backend itself is not the primary discrepancy source.
Evidence: v44.55.20 common-tensor backend isolation.
Still current: YES.

Decision: Production lane.input direct readback is not an authority oracle.
Still current: YES.

Decision: Correctness Observer runs are not Performance Authority.
Still current: YES.

Decision: v44.55.23 MIXED_TRANSACTION is provisional.
Reason: pair-bound Worker output lifecycle not yet proven.
Still current: YES.

## REJECTED APPROACHES

- Rebuild Production from reconstructed Native source merely because it compiles/exports correctly. Revisit only after provenance closure and necessity proof.
- Plain CURRENT_FLOAT → immediate CPU Production. Rejected by v44.55.15 proxy gate and later canonical/triangulation authority.
- mode2 → immediate CPU Production because of pixel parity. Rejected by later semantic authority.
- Relax 0.25 px thresholds after failure. Rejected as post-hoc fitting.
- Mesh triangle count as inference-semantic readiness gate. Rejected; observation-only.
- Production lane.input direct oracle. Rejected.
- Subtexel/chroma/half-texel tuning as immediate next step. Rejected until transaction authority is closed.

## SUPERSEDED CONCLUSIONS

OLD: Next step is v44.55.16 Canonical Semantic Equivalence Gate.
NEW: Next step is v44.55.24 Pair-Bound Shadow Output Snapshot.
WHY: later 2026-09-02 project authority includes v44.55.17–23.

OLD: v44.55.15 CURRENT_FLOAT proxy failure should select mode2 Native path.
NEW: neither CURRENT_FLOAT nor mode2 may become Production based on pixel/proxy parity alone.

OLD: v44.55.23 MIXED_TRANSACTION is final.
NEW: tentative until pair-bound output snapshot removes Worker lifecycle ambiguity.

OLD: Native source must be rebuilt next.
NEW: avoid Native changes until independently necessary and provenance-closed.

## OBSERVER / VALIDATOR FINDINGS

Observer/Validator defects found or incorporated:
1. PS5.1 empty/return binding behavior.
2. LASTEXITCODE assumption for Unity GUI process.
3. historical launcher filename dependency.
4. stale BAT ERRORLEVEL false launch failure.
5. report not guaranteed on Editor Play stop.
6. insufficient runtime-duration instruction.
7. irrelevant mesh-triangle start gate.
8. raw proxy metrics initially over-weighted.
9. v44.55.23 logical tensor length incorrectly confused with backing capacity in first implementation.
10. Production lane.input direct oracle invalid.
11. post-record PeekOutput may observe Worker allocator reuse; current v44.55.24 target.

Permanent rule: Validator PASS is not sufficient by itself. Audit source identity, ownership, timestamps, logical/backing shape, lifecycle, write target, blocking behavior, and observation timing.

## FILES / SHA256

Key Production hashes used in this chat are listed above. No missing SHA is invented.

Historical observer packages created in this chat:
- v44.55.15 base → OBSOLETE
- FIX2 → OBSOLETE
- FIX3 → OBSOLETE
- FIX4 → OBSOLETE
- FIX5 → latest v44.55.15 observer package in this chat, but project investigation has advanced beyond v44.55.15.

## RUNTIME EVIDENCE

v44.55.15 FIX5 semantic TXT:
Authority: CORRECTNESS
Result: valid measurement; CURRENT_FLOAT failed predeclared proxy gate.
Performance Authority: NO.

v44.55.15 Editor log:
Authority: CORRECTNESS / OBSERVER_VALIDITY
Purpose: prove observer lifecycle and diagnose gate/launcher/report issues.

KiwiFrameComparison CSV from correctness observer:
Authority: SUPPORTING_ONLY for regression context.
Performance Authority: NO.

MP4 from correctness observer:
Authority: VISUAL SUPPORTING_ONLY.

v44.55.23 Runtime:
Authority: CORRECTNESS / OBSERVER_VALIDITY
Result: 115/115, observer validity PASS, MIXED_TRANSACTION tentative.

## CURRENT RESULT

Tracking Core: stable / do not redesign.
Native Camera: Path B stable / do not change without independent evidence.
LIVE CAMERA: CLOSED / PRODUCTION ACCEPTED per current project state.
Inference backend: GPU Production remains authority.
CPU backend: backend capability viable, but preprocessing/output transaction correctness unresolved.
Primary unresolved domain: Preprocessing / Output Transaction Authority.
Latest confirmed: v44.55.23 Observer Validity PASS, 115/115 completed.
Latest tentative: MIXED_TRANSACTION.

## OPEN ISSUES

1. Pair-bound shadow output lifecycle.
2. Whether the 3 v44.55.23 NEITHER_EXACT cases survive valid pair-bound ownership.
3. Production Output Transaction Authority.
4. Reference Transaction Authority.
5. Pixel-center/transform arithmetic only if still needed after authority closure.
6. Native provenance closure if a Native change becomes necessary.
7. Preprocessing semantic PASS.
8. Canonical semantic PASS.
9. CPU/GPU Production Performance A/B only after correctness.
10. Lifecycle/recovery/backend-switch validation.
11. Long-run memory/resource stability.
12. Final MP4 frame-by-frame visual validation.

## NEXT ACTION

v44.55.24 Pair-Bound Shadow Output Snapshot.

Goal: determine whether v44.55.23 ANOMALOUS_NEITHER_EXACT is real Production output difference or Observer Worker-output lifecycle artifact.

Required design:
- snapshot REF_FROZEN_GPU and MODE2 B_GPU while the same pair is alive: `_pairPending == true`, `_commonScheduled == true`.
- bind snapshot identity to pair token, record index, sequence, NativeHostTicks, ManagedHostTicks, LaneStartedHostTicks.
- copy logical packed 1405-float output into observer-owned storage before another Worker schedule can reuse output memory.
- compare against Production completed pendingOutput from the same authoritative pair.
- do not first reacquire PeekOutput after record completion.
- Production writes = 0.
- decision rules fixed before runtime.

Decision branch A: NEITHER_EXACT disappears and Production becomes REF → v44.55.23 mixed result was Observer lifecycle artifact.
Decision branch B: pair-bound NEITHER_EXACT reproduces → only then treat as real Production-vs-shadow discrepancy and continue into lower-level transform/arithmetic investigation.

## DO NOT CHANGE

Until new independent evidence:
- Face Landmarker Primary / Source of Truth
- KiwiFaceMotion tracking math
- KiwiInferenceFaceTracker tracking math as camera workaround
- Native Path B camera / Native DLL
- fixed Presentation texture identity
- latest-frame architecture / FIFO prohibition
- stale/generation/cross-system gates
- FaceTexture same-sample transaction
- thresholds post-hoc
- strong smoothing / Kalman masking
- Unity D3D12 queue waits / blocking GPU waits
- UpdateExternalTexture
- rotating Unity-visible texture identity
- Production lane.input direct oracle
- Production CPU authority
- working Spout / LIVE CAMERA baseline
- commit/push without explicit instruction

## PROJECT MASTER REPORT INTEGRATION NOTES

When local MASTER is next updated, add:
- Archive: KiwiChat_CPUInferenceSemanticAuthority_Updated_20260902-JST.zip
- LastWorkUpdate: 2026-09-02
- Validated: backend not primary discrepancy; border rejected; lane.input oracle rejected; v44.55.23 observer validity PASS; MIXED_TRANSACTION tentative
- Rejected: immediate CURRENT_FLOAT/mode2 CPU Production; Native rebuild without provenance; post-hoc threshold relaxation; triangle topology as semantic gate
- Open Issue: Worker output lifecycle / pair-bound snapshot authority
- Next Action: v44.55.24 Pair-Bound Shadow Output Snapshot

MASTER_REPORT_NOT_DIRECTLY_UPDATED

## HANDOFF

1. Do not resume from v44.55.16.
2. Current next action is v44.55.24 Pair-Bound Shadow Output Snapshot.
3. Goal is correctness/authority, not performance and not CPU Production conversion.
4. Keep GPU Production authority unchanged.
5. Keep Native DLL/source unchanged.
6. Snapshot shadow outputs while the same pair is alive into observer-owned storage.
7. Never use post-record PeekOutput as immutable authority.
8. Compare logical 1405 floats; larger backing capacity is valid.
9. Maintain exact pair/source identity.
10. If v24 removes NEITHER_EXACT, classify v23 mixed result as Observer artifact.
11. If v24 reproduces it pair-bound, only then continue into pixel-center/transform/FMA-level work.
12. Semantic correctness must pass before CPU Production A/B.
13. Correctness observer performance metrics are not Production Performance Authority.
14. Observer/Validator remains part of the audit target.

## CHAT ARCHIVE INDEX

Archive: KiwiChat_CPUInferenceSemanticAuthority_Updated_20260902-JST.zip
Topic: CPU Inference Semantic / Output Transaction Authority
LastWorkUpdate: 2026-09-02
Status: IN_PROGRESS
Supersedes: early v44.55.16 next-action plan and immediate Native/mode2 Production directions
SupersededBy: NONE
NextArchiveCandidate: v44.55.24 completion

## FINAL ARCHIVE ASSESSMENT

The core KiwiAvatarSystem architecture remains sound: Face Landmarker primary, latest-frame, Path B camera, fixed presentation identity, bounded asynchronous inference, strict source/timestamp/generation authority, and same-sample transactions.

The primary lesson from this chat is that the remaining problem should not be attacked by stacking more preprocessing fixes. First establish trustworthy pair-bound output authority and keep treating Observer/Validator lifecycle as first-class correctness work.

Current decision: PROCEED WITH v44.55.24 ONLY. DO NOT START CPU PRODUCTION CONVERSION YET.
