# KiwiAvatarSystem 恒久REPORT
Topic: CPU Backend Parity / Presentation Frame Identity / Static-First Validation
Archive basis: 2026-08-31 19:06 JST
Project: `D:\KiwiAvatarSystem`
Unity: `6000.0.80f1`
Platform: Windows / DX12
Hardware: Ryzen 9 5950X / RTX 4090
Camera: UGREEN Camera 4K / 1920x1080@60 / Native NV12
MediaPipeUnityPlugin: v0.16.3
Status: v44.55.13 FIX2 STATIC_ALL_PASS
Authority note: LOCAL_PRODUCTION_NOT_DIRECTLY_VERIFIED
SHA rule: hashes below are only those explicitly observed/generated in this chat. Unknown Production SHA values are not invented.

---

## 1. Executive Summary

このチャットでは、GPU Production inference と CPU direct/shadow path の差を追跡し、「backend差」ではなく「入力frame identity / preprocessing parity」が主因であることを段階的に切り分けた。

確定した主要事項:

1. v44.54: 同一host float入力なら CPU / GPUCompute backend のraw model出力は実質同一。backendそのものはcorrectness上の主因ではない。
2. v44.55.10: Production cropTextureに付与されたsequence/timestampと実画素が稀にずれる `FRAME_CONTENT_RACE_CONFIRMED`。外れ値はtarget SではなくS+1 / S+2と一致した。
3. v44.55.11: frame identity補正後input parityは全件0.5 LSB未満。ただしraw output STRONG gateは未達。CPU Production切替は保留。
4. v44.55.12: D3D fixed-point subtexel仮説を検証。FULL_FLOATが全体最良で、16.8 / 16.9 / 16.10 / 16.12は改善せず `NOT_SUPPORTED`。
5. v44.55.13 FIX2: Static-First validation pipelineを完成。Source guard 29/29 PASS、Unity batchmode compile PASS、Editor static audit PASS、Production critical hash再照合PASS、`V44_55_13_FIX2_STATIC_ALL_PASS`。

現在の方針: **静的検証を最大限優先し、Runtimeは必要事項を1回の十分長い統合A/Bでまとめて測る。計測時間は最小化しなくてよいが、実測回数を最小限にする。**

---

## 2. Objective

最終目的は、現在の安定したProduction GPU 3-lane inferenceのcorrectnessを維持しつつ、CPU backend/direct preprocessing pathが実運用上同等かつ低遅延であることを証明し、必要ならProduction CPU化またはCPU/GPU hybrid化へ安全に移行すること。

CPU化自体を目的化しない。correctness / latency / cadence / FaceTexture transaction / tracking authorityを維持できない場合は現Production GPUを維持する。

---

## 3. Frozen Production Constraints / Do Not Change

- Face Landmarkerをprimary/source of truthとする。
- `KiwiFaceMotion.cs` / `KiwiInferenceFaceTracker.cs` のtracking mathをcamera/performance workaroundとして変更しない。
- ROI / tracking thresholds / smoothingを性能対策として緩和しない。
- strong smoothing / global Kalman / permanent frame bufferを導入しない。
- Latest-frame only。FIFO禁止。
- FaceTextureはstrict same-sample transaction。
- stale / generation gateを維持。
- `cameraGeneration`はcamera session / texture identity epoch。
- Unity-visible texture identityは固定 `KiwiNativeCameraPresentation`。
- `g_unityD3D12Queue->Wait(...)` を復活させない。
- `UpdateExternalTexture`禁止。
- callback/workerをまたぐ `IMFSample`保持禁止。
- rotating Unity-visible texture identity禁止。
- D3D11On12 1080p Production禁止。
- CPU-blocking GPU waits禁止。
- Mesh v44.11、Inference lifecycle v44.14、Surface Fit v44.17、Spout v44.20.1、Async Compute v44.22はfrozen。
- Windows Production Camera Path B: MF Source Reader without D3D manager → system-memory NV12 → latest CPU buffer → immediate sample release → GPU upload → stable Presentation Texture。
- Camera color final v44.43 metadata-driven。
- v44.44 MediaPipe observer removed。
- Production remains v44.48 O25 default + 3-lane GPU inference until all CPU gates pass。

---

## 4. Production Mesh Authority

O25 Production:
- originalTriangles: 1,017,188
- resultTriangles: 254,296
- vertexCount: 508,601
- blendShapeCount: 5
- boneCount: 17
- resultError: 0.000386
- in-place index commit
- shared mesh identity preserved
- vertex data not compacted
- blendshape order preserved
- bone weights preserved bit-exact by vertex

---

## 5. Confirmed Facts

### 5.1 v44.54 Backend Equivalence

同一host float入力:
- CPU median: 約11.81 ms
- GPU median: 約40.53 ms
- landmark2d p95: 約0.000038 px
- presence sigmoid p95: 約4.35e-7

結論: **CPU/GPU backendそのものは数値差の主因ではない。**

### 5.2 v44.55.10 Presentation Frame Identity

5件の外れ値すべてでtarget Sより近傍frameが一致。
- S=1690 → S+2=1692: 約3.456 → 0.0426 LSB
- S=1787 → S+1=1788: 約3.375 → 0.0408
- S=1944 → S+2=1946: 約3.432 → 0.0441
- S=2507 → S+1=2508: 約3.414 → 0.0402
- S=2728 → S+2=2730: 約3.405 → 0.0421

Counters:
- identityNeighborWinsCount=5
- identityTargetWinsOutlierCount=0
- identityNeighborUnder0_5LsbCount=5
- API failure=0
- snapshotTensorMismatch=0

結論: **FRAME_CONTENT_RACE_CONFIRMED**。metadata S確定後、GPU sampling前にfixed Presentation内容が次frameへ進む窓がある。

### 5.3 v44.55.11 Identity-Corrected CPU/GPU Output Equivalence

- 93/93 measured pair
- pairError/nonfinite=0
- Presentation race 13件、13/13 neighbor correction成功
- corrected input MAE: mean 0.04593 / p95 0.05104 / max 0.05375 LSB、全件 <0.5 LSB
- CPU service median 約9.37 ms / p95 約12.89 ms
- GPU service median 約39.38 ms / p95 約54.43 ms
- CPU completion 約1 frame / GPU completion 約3 frames

Raw semantic:
- landmark 2D p95: 約0.776 px
- within 1px: 約98.77%
- presence sigmoid diff p95: 約0.02973
- presence decision mismatch: 0
- far-threshold mismatch: 0

設定したSTRONG gate未達。結論: **NEAR PASSだがSTRONGではREJECT**。CPU Production switchには進めない。

### 5.4 v44.55.12 D3D Fixed-Point Subtexel Audit

55/55 pair、error/nonfinite/API failure=0、snapshot→observer FLIP_Y exact。

Global MAE:
- FULL_FLOAT: 0.056946582 LSB
- 16.8: 0.057583978
- 16.9: 0.057425328
- 16.10: 0.057168364
- 16.12: 0.056995739

Best count:
- FULL_FLOAT: 44
- 16.8: 0
- 16.9: 0
- 16.10: 1
- 16.12: 10

Identity race: expanded=2 / neighbor wins=2 / target wins=0 / neighbor under0.5=2。

結論: **SUBTEXEL_NOT_SUPPORTED / FULL_FLOAT remains best**。16.8～16.12 fixed-pointをProductionへ採用しない。color/chroma/half-texelをこの結果から変更しない。

注意: report内の `bestCandidate=FINAL_UNORM8 / bestMeanAbsLsb=0` はpairCount=0候補をbest扱いした集計表示バグであり、判定根拠にしない。

---

## 6. Public Design Principles Applied

- 非同期GPU inferenceではinput resourceのownership/lifetimeを明確にする。
- metadataとpixel content identityを同一transactionとして扱う。
- CPU/GPU backend比較は同一model・同一raw input・tracking前raw outputで行う。
- backend間のbit-perfect一致だけでなくtask-level semantic parityも評価する。
- Async readback中のworker/resource再利用競合を避ける。
- Production authorityを変更する前にshadow/observerで検証する。

商用VTuberソフト内部の詳細sampler/queue実装は非公開であり、Kiwi固有のqueue/resource lifetimeへの直接適用は推測と区別する。

---

## 7. Rejected / Superseded Directions

Rejected:
- CPU/GPU backend自体が主原因
- UNORM8量子化だけで差が説明できる
- D3D fixed-point subtexelが主原因
- tracking threshold変更
- stronger smoothing / Kalman
- camera cadence workaroundとしてtracking core変更
- fixed Presentation identityを捨てる方式
- Production lane.inputへの外部readbackをcorrectness authorityにする

Superseded:
- v44.55.13 initial: Apply scriptがfilename uniquenessを誤前提として `KiwiInferenceFaceTracker.cs found 2` で停止。Production変更前に停止。
- v44.55.13 FIX1: canonical path resolverへ改善しsource guard 29/29 PASS。ただしobserver生成時にliteral `\n`を164個混入しUnity compile失敗。
- v44.55.13 FIX2: 164個のliteral `\n`を修復し、validation順序を source guard → Unity actual compile → Editor static audit → critical hash再照合 → final PASS に変更。現在のauthority。

---

## 8. v44.55.13 FIX2 Validation Result

User-executed Windows result:
- `V44_55_13_FIX2_APPLY_PASS`
- Production critical files unchanged: 5
- Source guard: 29/29 PASS
- `V44_55_13_FIX2_SOURCE_GUARD_PASS`
- `V44_55_13_FIX2_UNITY_COMPILE_PASS`
- `[Kiwi v44.55.13 Static] PASS`
- `V44_55_13_FIX2_STATIC_ALL_PASS`
- Production critical hash recheck: PASS

CSV / MP4はこの段階では不要と判断。

---

## 9. Files / SHA256

v44.55.10 ZIP:
`EB4E275DB26D308666B41C5437A96B9D2FF6E7B66DADA13C76B262B26F849CC4`

v44.55.11 ZIP:
`B976206BEAD21083BF6905A09F80EB78FBAF676636FB79642AA5B6EAA349CFD5`

v44.55.12 ZIP:
`7D1AD278F1F9C53A19E02550AEA1BE0DF202A74832F8EC4AA981F04E6F253B8A`

v44.55.13 FIX2 ZIP:
`1A2C24F4E28ED4EC307DAD5849CADDC9DAA7765F8AAD79A62ADBEB571EA16CCA`

FIX2 Observer:
`299C192FE609F59515345D9395B5FE413A551D9CD58E90EBEB4FF7251D46FBDF`

FIX2 Editor static audit:
`5C56006675B765B10EFA444DE85C57C405883FAF05C9D16813630D0B02E5540E`

Native unchanged:
`636D76251F9CB3BB785F4497D3D0722033FC0CE36CB4A574B65EDA58B5ABE32A`

Interop unchanged:
`AC473ADBADE5EDC89726211ECAF03D040B5CC00FCA39BEA4A0D16195FA53E8B5`

Production critical 5 file individual SHA:
`SHA256=NOT_AVAILABLE_IN_NORMAL_CHAT`
ただしFIX2 user-side hash manifest再照合はPASS。

---

## 10. Correctness / Performance / Visual / Provenance

Correctness:
- v44.54 same-float backend equivalence
- v44.55.10 frame identity neighbor proof
- v44.55.11 identity correction all <0.5 LSB
- v44.55.12 fixed-point negative result
- v44.55.13 FIX2 actual Unity compilation + editor static audit + SHA guards

Performance:
- v44.55.12 v44.47 steady: renderHz 83.3294
- CPU Main median 10.6111 ms / p95 16.3093
- CPU Total median 11.2360 / p95 16.5218
- GPU median 5.0921 / p95 8.2811
- Camera.Render median 7.1946 / p95 9.8376
- Graphics.Blit median 0.2705
- WaitForGPU 0
- observer-heavy runtimeはProduction performance authorityにしない。

Visual:
- v44.55.10 / v44.55.11では全フレーム順次decodeでblack/exact duplicate/明確なfreeze/mesh崩壊/LIVE CAMERA破綻なしのrunあり。
- LIVE CAMERA画質改善課題は将来課題として維持。tracking変更で回避しない。

Provenance:
Authority priority:
1. local Production + exact SHA
2. same-Production latest Runtime
3. actual Package Source
4. latest validation/consolidated report
5. official docs/source
6. local git
7. GitHub main
8. older diagnostics

Current caveat: `LOCAL_PRODUCTION_NOT_DIRECTLY_VERIFIED`。

---

## 11. Open Issues

1. v44.55.11でidentity補正後もraw semantic STRONG gate未達。
2. 0.05 LSB級input差をbit-perfect方向へさらに追う価値は低い。
3. 実運用上、CPU semantic結果がGPU authorityと十分一致するかはProduction-input semantic A/Bで最終確認が必要。
4. CPU化した場合の実cadence / end-to-end latency / FaceTexture strict transaction / stale-discard / accepted-sample ageをRuntimeで測る必要がある。
5. LIVE CAMERA表示品質の別監査は未完。

---

## 12. Next Action — v44.55.14

次版:
**v44.55.14 Static-Gated Integrated Production CPU Semantic/Latency A/B**

方針:
- まず静的検証を最大化。
- Production GPU authorityを維持。
- CPU shadow結果はtrackingへpublishしない。
- semantic / presence / geometry / timestamp / identity / FaceTexture transaction契約を静的に検証。
- source hash / forbidden API / lifecycle / worker ownership / output shape / model names / ROI source / sequence mappingを静的に確定。
- 実測は時間最小ではなく**回数最小**。
- 必要なRuntime項目を**1回の十分長い統合A/B run**へ集約。
- 1 runでsemantic report + steady report + CSV + MP4 + Player.logを取得し、correctness / latency / cadence / safety / visualを同時判定。

Runtimeへ進む条件:
- static source guard PASS
- Unity actual compile PASS
- Editor static audit PASS
- Production critical SHA unchanged
- no authority write from CPU shadow
- no blocking GPU waits
- no forbidden camera/tracking changes

---

## 13. Handoff Summary

次チャットではv44.55.13 FIX2をcurrent validation authorityとする。

確定:
- Backend差は主因ではない。
- Frame content raceは確定。
- Identity correctionは有効。
- Fixed-point subtexel仮説は棄却。
- Static-first validation pipelineはFIX2で完成。
- FIX2 `STATIC_ALL_PASS`。
- Production backendはまだGPU 3-lane。
- CPU Production switchはまだ行わない。

次の作業:
v44.55.14を設計・静的検証し、静的で証明できない項目のみを1回の統合Runtime A/Bへまとめる。

User preference:
- 回答は短く的確。
- 外部調査→比較→Kiwi比較→risk→最善1案→完全版→静的検証→Runtimeの順。
- 実測時間は最小でなくてよい。
- **実測回数を最小限にする。**
