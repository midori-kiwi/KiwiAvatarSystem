# KiwiAvatarSystem Chat Permanent Report

ChatTopic: Natural Motion Tracking / Provider Continuity / FacePart Mask / v5.0.1 Rigid Unpin + Head-Local Face Parts  
ChatTitle: v4.5 → v5.0.1 Tracking・Natural Motion・FacePart Mask改善チャット  
ArchiveName: KiwiChat_NaturalMotionTrackingFacePartMask_v5_0_1_Updated_20260821-2341-JST.zip  
LastWorkUpdate: 2026-08-21 23:41 JST  
LastWorkUpdatePrecision: DATE_TIME  
ArchiveCreated: 2026-09-02 23:19 JST  
ArchiveTimestampBasis: LAST_RELEVANT_WORK_BEFORE_ARCHIVE_REQUEST  
Project: D:\KiwiAvatarSystem  
Unity: 6000.0.80f1  
CurrentInvestigationVersion: Historical chat endpoint = v5.0.1 / Current project authority at archive time = v44.55.23 investigation line  
Status: SUPERSEDED  

---

## EXECUTIVE SUMMARY

このチャットでは、KiwiAvatarSystemの旧v4.5系Tracking/FacePart構造を基点に、商用VTuber・Face Mocap・SNS AR Filterの公開設計原則を比較しながら、Tracking Authority、Provider continuity、stale handling、Prediction、Eye/Mouth semantic transaction、Mask座標系、Head-local face-part presentationを段階的に見直した。

チャット内の最終技術成果物は **KiwiAvatarSystem v5.0.1 Rigid Unpin + Head-Local Face Parts**。v5.0で発生した「Avatar Rootが実質固定される」「Eye/Mouth Maskが不自然に斜めになる」という回帰に対し、

- Same Provider Resume != Provider Switch
- stale sampleは公開しないが短いsame-provider gapではProvider identityを保持
- 真のProvider switch時だけzero-discontinuity handoff
- 3D HeadがRigid Roll authority
- Camera Eye/Mouth patchはHead-local sample frameへ変換
- Texture UVとSemantic Mask UVを同一rotation / sample frameで処理

という修正を採用した。

v5.0.1 reviewのRuntime映像解析では、194 encoded frames / 14.451 s / 2560×1352を全encoded-frame走査し、Root presentationが実質固定されていたことを数値で確認した。v5.0.1 ZIP integrityはPASSで、ZIP SHA256は `8943d3e44f74c8c3d0982478bf3a95fecb84c6b34a316ebc31920e3bd529b52e` と記録されている。

ただし、このチャットのv5.0.1系統は**現在のProduction Authorityではない**。2026-09-02時点のプロジェクト統合情報では、Production/Inference調査はv44.55.23 Production Output Transaction Authorityまで進み、次作業はv44.55.24 Pair-Bound Shadow Output Snapshotとされている。このため、本REPORTは**歴史的なTracking/FacePart設計・回帰知見の恒久保存**として扱い、現在のProduction採用判断には最新local Production + Runtime + KiwiValidation REPORTを優先する。

---

## OBJECTIVE

このチャットの主要目的は以下。

1. KiwiAvatarSystemのTracking / Follow / Prediction / Mask処理を商用品質へ近づける。
2. 正面静止時のRoot jitter・勝手な移動・上下ブレを減らす。
3. Eye/Mouthが消える、別領域を拾う、Maskが不自然に傾く等のsemantic/presentation破綻を修正する。
4. Provider switch / Resume / stale result / livenessを整理し、正常sampleを最速で通しながら異常時だけ局所抑制する。
5. 商用VTuber / Face Mocap / SNS AR Filterの公開設計を比較し、Kiwiへ適用可能な原則だけ採用する。
6. 動画解析を粗い0.5 s / 1 sサンプリングではなく、可能な限り全encoded frame単位で行う。
7. Unity正式基準を6000.0.80f1へ更新する。
8. 「既存正常動作維持」自体を最優先にせず、実測・比較で明確に優れた案がある場合は既存実装の変更・置換・再設計を許可する方針へ更新する。

---

## CONFIRMED FACTS

### Environment

- Unity正式基準: **6000.0.80f1**
- OS: Windows
- このチャットでの実測動画タイトルはDX11。
- MediaPipeUnityPlugin: v0.16.3
- UniVRM: 0.130.1
- VRM target: VRM 0.x
- Blender: 5.2

### v5.0.1 Runtime visual evidence

対象動画:

`KiwiAvatarSystem - Face Landmark Detection - Windows, Mac, Linux - Unity 6.0 (6000.0.80f1) _DX11_ 2026-08-21 23-12-08.mp4`

v5.0.1 reviewに記録された確認値:

- encoded frames: 194
- duration: 14.451 s
- resolution: 2560×1352
- 全encoded frame走査
- Avatar本体重心標準偏差:
  - X ≈ 0.027 px
  - Y ≈ 0.052 px
- 全変動範囲:
  - X ≈ 0.226 px
  - Y ≈ 0.313 px

これにより、v5.0適用後は「追従が弱い」のではなく、Root presentationが実質固定状態だったと判断された。

TelemetryではProviderがRunner/InferenceEngineのまま稼働している一方、handoff/resume countが増加していた。

### v5.0.1 Root cause / fix

確認された原因:

- no-candidate時にactive Provider identityが失われ、
- 同じProvider復帰でもproviderChanged扱いとなり、
- zero-discontinuity handoffが直前表示poseへ繰り返し再整合し、
- same-provider short gapがRoot pinningを生んでいた。

v5.0.1方針:

- stale sampleは公開しない
- same-provider short gapでもProvider identityを維持
- same-provider復帰は通常fresh measurementとして再開
- 真の異Provider切替のみzero-discontinuity handoff

### v5.0.1 FacePart cause / fix

確認された構造問題:

- 3D Avatar RootはHead Rigid Rollを表現する。
- Camera Eye/Mouth patchおよびsemantic contourにもActor Rollが残る。
- patch内部のRollをそのままsurfaceへ貼るとRigid Rollが局所FacePart側で二重表現され得る。

v5.0.1では:

- `KiwiFacePartRigidSampleFrame`
- `SurfaceFittedRawImage`のHead-local sample-frame rotation API

を用い、Texture UVとMask evaluation UVを同じ角度・crop pixel aspectで変換する構造とした。

### v5.0.1 archiveable artifact facts

- Artifact:
  `KiwiAvatarSystem_v5_0_1_RigidUnpin_HeadLocalFaceParts_Overlay.zip`
- ZIP SHA256:
  `8943d3e44f74c8c3d0982478bf3a95fecb84c6b34a316ebc31920e3bd529b52e`
- Manifest hashed files: 74
- ZIP regular files: 75
- Missing: 0
- Extra: 0
- SHA mismatch: 0
- CRC error: 0
- Deletion target: 0

### Current authority at archive time

2026-09-02の統合最新版情報では、プロジェクトはこのチャットのv5.0.1系統より大幅に先へ進んでいる。

Current project investigation state:

- v44.55.23 Production Output Transaction Authority
- Runtime 115/115 completed
- Observer validity PASS
- Production=REF exact: 5 anomalous pairs
- Production=MODE2 exact: 0
- Neither exact: 3
- Decision: MIXED_TRANSACTION（暫定）
- Worker output lifecycle race未排除
- Next: v44.55.24 Pair-Bound Shadow Output Snapshot

よって、本チャットのv5.0.1は**現Production Authorityではない**。

---

## PUBLIC DESIGN PRINCIPLES

このチャットで比較対象とした主な公開系:

- VTube Studio
- VSeeFace / OpenSeeFace
- FaceRig / Animaze
- Luppet / LuppetX
- Warudo
- Faceware Studio
- AccuFACE
- MetaHuman Animator
- DeepAR
- Snap Lens Studio
- TikTok Effect House
- MediaPipe Face Landmarker
- その他Realtime VTuber / Face Mocap / AR systems

採用した公開設計原則:

1. **Rigid head authorityとlocal facial appearanceを分離**
   - Head translation / rotationとEye/Mouth expressionを分離する。
   - Blink/MouthがRootを動かさない。

2. **Tracking cadenceとPresentation cadenceを分離**
   - Tracking結果をRender cadenceへ適切に提示する。
   - FIFOで古い結果を積まない。

3. **LivenessとLatencyを分離**
   - source ageが大きいこととProviderが停止したことは別。
   - arrival age / last result arrivalをlivenessへ使う。

4. **Predictionは短時間・条件付き**
   - motion consistencyがあるときのみ。
   - stop/reversal/Holding/Lostでは縮小または0。

5. **Neutral calibration**
   - actor-specific neutralを使う。
   - bad sampleで全履歴を消さない。

6. **Semantic partはatomic**
   - Crop / Mask / texture / geometryが同じsample transactionに属する。

7. **Side-viewはFar Eyeを無理に追わない**
   - confidence / occlusion / continuityを利用する。

8. **異常局所sampleだけを抑制**
   - 正常sampleをGlobal smoothingで遅らせない。

---

## INFERENCES / HYPOTHESES

以下は当時の推測または設計仮説であり、現Productionで再検証せずCurrent Factとして扱わない。

- v5.0前後の100 ms級GPU readbackがtracking naturalness悪化の主要因の一つだった可能性。
- Inference lanesを1/2/3 adaptive化するとend-to-end latencyが改善する可能性。
- Eye topology outlier guardにより片Eyeの誤cropを抑えつつYaw/Rollを維持できる可能性。
- Head-local FacePart sample frameが二重Rollを視覚的に解消する可能性。
- Immutable Tracking Frame / Generation Architectureが今後のasync/model switch競合を減らす可能性。

これらは当時の設計検討として価値があるが、現在のv44.55.x Production Authorityとは別に再評価すること。

---

## PRODUCTION AUTHORITY

本REPORT作成時のAuthority:

1. Current local Production + SHA
   - **LOCAL_PRODUCTION_NOT_DIRECTLY_VERIFIED**
2. Current latest Runtime Evidence
   - この通常チャットでは2026-09-02 current Production runtimeを直接再実測していない。
3. Current Package Source
   - 直接local PackageCacheを確認していない。
4. 2026-09-02統合最新版 / Authority一覧
   - current project stateを判断する補助Authority。
5. v5.0.1 review / ZIP integrity
   - このチャットのhistorical endpointを確認するAuthority。
6. GitHub
   - historical/supporting only。

### GitHub hash inconsistency note

このチャット初期ではGitHub main baselineとして
`6b4d2448e3446a3b026165fb87617cdd0253e532`
を使用した。

後続のFile Library handoffでは、then-current mainとして
`0b890a317cc3de64a4eadc955ce87bf21479786b`
が記録され、そのparentとして`6b4d244...`が記録されている。

このREPORTではlocal Productionを直接確認していないため、どちらも現Production hashとして採用しない。
GitHub main < local Productionの場合はlocal Productionを優先する。

---

## WORK PERFORMED

### v4.5.1 Static Audit Hardening

目的:
- duplicate処理 / lifecycle / Range/default矛盾確認。

主な修正:
- `KiwiFacePartLiveMotionBridge` Disable/Enable mailbox lifecycle。
- `KiwiInferenceRecoveryBootstrap` Presence Inspector Range/default矛盾。
- Runner再探索頻度制限。

結果:
- Static-only hardening。
- Runtime Tracking quality authorityではない。

### v4.5.2 Adaptive Containment Compile Fix

発見:
- `KiwiFacePartAdaptiveContainment.cs`でfield `_continuity`に対し裸の`continuity`参照。

修正:
- 参照名のみ修正。

結果:
- CS0103系compile error解消目的。

### v4.5.3 Tracking Authority & Stale Result Hardening

目的:
- 旧Tracking Owner競合とstale result adoption抑制。

導入:
- Provider freshness見直し。
- Live2D stale result抑制。
- GPU workload調整。
- 旧RuntimePanel tracking owner縮小。

結果:
- 後続v4.5.4でFacePart visibility regressionが判明。

### v4.5.4 FacePart Visibility & Tracking Compatibility Recovery

発見:
- v4.5.3で旧PlayerPrefs Tracking load停止が広すぎ、FacePart表示/Crop/Mask等の互換設定まで復元されなくなった可能性。

修正:
- compatibility setting load復旧。
- Commercial Profileをfinal authorityとして再適用。
- FacePart visibility fail-open/recovery。
- stale Live2D circuit breaker。

### v4.5.5 Static Rigid Pose Authority Recovery

発見:
- legacy PurePose/Ultra設定復帰でIdle/Talk等Secondary Body MotionがRootへ加算可能。
- Provider HubのarbitrationがRoot pathへ完全には使われていない経路。

修正方針:
- Root input authorityをHubへ寄せる。
- `ultraDisableSecondaryBodyMotion=true`等Pure Tracking contract。

### v4.6 Commercial Canonical Solve Space

目的:
- expression geometryとRigid translation分離。

主な設計:
- Jaw-neutral upper-face Root anchor。
- Canonical Rigid Pose境界。
- Provider handoff alignment。

### v4.7 Commercial Rigid Continuity & Latency Hardening

発見:
- LateUpdateはHub、onBeforeRenderはRunner directというauthority split。
- source ageとarrival ageの扱いが不適切。
- stale observationでNeutral/Tracking pose間jumpの可能性。

修正方針:
- LateUpdate / onBeforeRender authority統一。
- continuity freshness見直し。
- Holding時Root hold。
- Prediction縮小。

### v4.7.1 Continuity Compile Fix

発見:
- `nowTicks` local name shadowingによるCS0136。

修正:
- child scope local rename。

### v4.8 Video-Measured Semantic Coherence

全encoded-frame解析を強化。

確認/修正対象:
- stale semantic rejection
- Crop/Mask座標系
- atomic contour reject
- Mask readiness
- calibration progress persistence
- VisibilityRecovery single-writer

重要:
- Prediction source ageとextrapolation capを分離。

### v4.9 Dense Encoded Frame Continuity / Atomic Semantic Transactions

動画を最小encoded-frame単位で検証。

確認:
- same-provider resume時のRoot discontinuity。
- isolated Eye source crop outlier。
- Crop/Mask timestamp混在リスク。

設計:
- Same-provider continuity resume handoff
- per-part semantic transaction
- isolated eye guard

後続v5.0でsame-provider resume設計が過剰になりRoot固定回帰へ繋がった。

### v5.0 Natural Motion / Commercial Continuity / Semantic Topology

目的:
- 「揺れを消す」ではなくhuman-like response。
- static quiet / fast start / continuous motion / stop without overshoot。

設計:
- Source Age / Arrival Age完全分離。
- adaptive 1/2/3 inference lane policy。
- eye topology outlier guard。
- Hub authority強化。

Regression:
- same-provider short gapがhandoff相当として扱われ、Rootが実質固定。
- FacePart Rigid Rollの二重表現でMaskが斜めに見える問題。

### v5.0.1 Rigid Unpin + Head-Local Face Parts

最終技術作業。

Root fix:
- same-provider gapでidentity保持。
- stale sampleは非公開。
- same-provider復帰は通常fresh measurement。
- real provider switchのみhandoff。

FacePart fix:
- Head-local sample frame。
- Texture UV + Mask UVの同一rotation。
- actor-neutral eye-lineからshared local rotation。
- large single eye-line jump guard。
- Root / RectTransform / Surface fitへの書込みなし。

Static/ZIP:
- 36 C# files
- delimiter mismatch 0
- Range/default mismatch 0
- duplicate top-level type 0
- duplicate .meta GUID 0
- Provider identity simulation PASS
- same-provider resume simulation PASS
- real cross-provider handoff simulation PASS
- Head-local sampling rotation math PASS
- migration validation PASS
- `AsyncGPUReadback.WaitAllRequests()` 0
- manual deletion 0
- ZIP integrity PASS

---

## VALIDATED DECISIONS

### Decision: Same Provider Resume != Provider Switch

Reason:
同一Providerの短いcadence gapをbackend switchとして扱うとhandoff alignmentが累積し、Root pinningを起こした。

Evidence:
v5.0 regression video / v5.0.1 review。

Regression constraints:
- stale poseを再公開しない。
- Provider identityとsample validityを分離する。
- real provider change時のzero-discontinuity handoffは維持。

Still current:
設計原則としてCurrent。

### Decision: Source Age != Liveness

Reason:
古いobservationでも新しいresultが継続到着しているstreamと、Providerが停止したstreamは別failure mode。

Evidence:
v4.9/v5.0動画・Telemetry解析。

Regression constraints:
- source age = latency quality
- arrival age = provider liveness
- source ageだけで即Holding/Lostへ落とさない

Still current:
Current design principle。

### Decision: Head is single rigid authority

Reason:
Eye/Mouth/Blink/semantic noiseがRootへ逆流すると商用品質を損なう。

Evidence:
このチャット全体のRoot/FacePart regressions。

Regression constraints:
Eye/Mouth → Root feedback禁止。

Still current:
Current。

### Decision: Texture/Crop/Mask semantic transaction must remain coherent

Reason:
CropとMaskの異なるtimestamp/generation混在はEye/Mouth誤表示を引き起こす。

Evidence:
v4.8/v4.9 video/code review。

Regression constraints:
同一partのreject時はCrop + Maskを同じprevious valid transactionへHold。

Still current:
Current。

### Decision: Head-local face-part sampling

Reason:
RootとCamera patchのRigid Roll二重表現を避ける。

Evidence:
v5.0 Mask roll regression / v5.0.1 review。

Regression constraints:
Texture UVとMask UVを同一transformにする。
Root/RectTransform/Surface fitをFacePart local samplerが所有しない。

Still current:
Historical validated design principle; current Productionへの実配置はlocal current sourceで再確認が必要。

### Decision: Video analysis uses all encoded frames when practical

Reason:
0.5 s / 1 s contact sheetでは瞬間jump / mask corruption / continuity transitionを見逃す。

Evidence:
v4.8以降の解析でframe-level異常を特定。

Still current:
Current QA practice。

### Decision: Unity 6000.0.80f1 is the formal baseline

Reason:
ユーザー明示。

Still current:
Current。

### Decision: Best overall design may replace working implementation

Reason:
既存正常動作維持自体を最優先にせず、Tracking accuracy / latency / natural motion / semantic quality / lifecycle / architecture等で明確に優れた案を採用する。

Constraint:
理由のない全面再構築・style-only rewrite・実測なしthreshold tuningは禁止。

Still current:
Current user policy。

---

## REJECTED APPROACHES

### Rejected: Same-provider short resumeをprovider switch扱い
Why rejected: Root固定・alignment累積を生んだ。  
Evidence: v5.0 regression。  
Revisit condition: なし。ResumeとSwitchは別stateとして扱う。

### Rejected: Source ageだけでTracking Lost/Holding判断
Why rejected: live but latency-heavy providerをfalse dropout扱いし、hold/jumpを生む。  
Evidence: v4.9/v5.0 analysis。  
Revisit condition: livenessを別clockで取れない特殊backendのみ別途検討。

### Rejected: Strong smoothing / new Global Kalmanで問題を隠す
Why rejected: normal sample latency増加、stop/reversal遅延、root cause隠蔽。  
Revisit condition: 独立Runtime A/Bで総合優位が証明された場合のみ。

### Rejected: CropとMaskを独立timestampで進める
Why rejected: semantic atomicity破壊。  
Revisit condition: なし。

### Rejected: Hub installed中のconsumer direct Runner bypass
Why rejected: Authority split、Holding/Provider arbitration破壊。  
Revisit condition: Hub自体が正式に未installのfallback modeのみ。

### Rejected: Camera Rigid RollをRootとlocal patchで二重適用
Why rejected: Eye/Mouth Mask/textureの不自然な傾き。  
Revisit condition: 3D HeadがRollを所有しない別avatar architectureの場合のみ。

---

## SUPERSEDED CONCLUSIONS

### OLD
GitHub main `6b4d244...`を最新基準として扱う。

### NEW
後続handoff artifactでは`0b890a...`がthen-current mainとして記録。さらに2026-09-02 current project authorityはlocal Production / v44.55.x investigationで、GitHub mainは低位Authority。

### WHY
Projectがこのチャット後も継続して進展。

### OLD
v5.0.1が「最新累積版」。

### NEW
このREPORT作成時にはv5.0.1はhistorical/superseded archive endpoint。Current project investigationはv44.55.23 → v44.55.24。

### WHY
後続のProduction/Inference/Native/Validation作業が進んだため。

### OLD
「正常動作を壊さないことが最優先」。

### NEW
既存実装が正常でも、実測・比較で明確により良い総合案がある場合は変更・置換・再設計可。

### WHY
ユーザーが正式方針を更新。

---

## OBSERVER / VALIDATOR FINDINGS

このチャットでは、Validator/Static Audit自体の見落としが複数回発生した。

例:

- v4.5.2前に`continuity` / `_continuity` typoをStatic Auditで見落とし。
- v4.7で`nowTicks` local shadowing CS0136を見落とし。
- migration途中版でC#に存在しない`string.Replace(old,new,count)`相当の問題を最終化前に検出。
- duplicate replacement targetによる複数箇所書換えリスクを検出し、ReplaceFirst型へ修正。

結論:

- Static PASSを絶対視しない。
- Unity C# compile ruleを別Validatorで確認する。
- migration simulationをidempotentに行う。
- Observer/ValidatorのbugとProduction defectを混同しない。

---

## FILES / SHA256

### KiwiAvatarSystem_v5_0_1_RigidUnpin_HeadLocalFaceParts_Overlay.zip

Role: このチャットのhistorical final cumulative Overlay。  
SHA256: `8943d3e44f74c8c3d0982478bf3a95fecb84c6b34a316ebc31920e3bd529b52e`  
Current/Obsolete: SUPERSEDED_AS_PROJECT_PRODUCTION_AUTHORITY / Historical evidenceとして保存価値あり。

### KiwiAvatarSystem_v5_0_1_RigidUnpinHeadLocalFacePartsReview.md

Role: v5.0.1動画解析・設計理由。  
SHA256: NOT_AVAILABLE_IN_NORMAL_CHAT  
Current/Obsolete: Historical supporting evidence。

### KiwiAvatarSystem_v5_0_1_ZIP_INTEGRITY.json

Role: v5.0.1 ZIP integrity。  
SHA256: NOT_AVAILABLE_IN_NORMAL_CHAT  
Current/Obsolete: Historical validation evidence。

### Current local Production files

Path: D:\KiwiAvatarSystem\...  
SHA256: LOCAL_PRODUCTION_NOT_DIRECTLY_VERIFIED

この通常チャットでは現在local Productionを直接監査していないため、推測SHAは禁止。

---

## RUNTIME EVIDENCE

### v5.0 Natural Motion test video

Filename: `KiwiAvatarSystem - Face Landmark Detection - Windows, Mac, Linux - Unity 6.0 (6000.0.80f1) _DX11_ 2026-08-21 22-20-16.mp4`  
Authority: VISUAL + SUPPORTING_CORRECTNESS  
Known review: approx 40.70 s / 1010 encoded frames / 2560×1352 / all encoded frames reviewed。  
Not Performance Authority: video/overlay telemetry run was not isolated clean benchmark。

### v5.0 regression / v5.0.1 root-cause video

Filename: `KiwiAvatarSystem - Face Landmark Detection - Windows, Mac, Linux - Unity 6.0 (6000.0.80f1) _DX11_ 2026-08-21 23-12-08.mp4`  
Authority: VISUAL + CORRECTNESS_SUPPORT  
Known: 194 encoded frames / 14.451 s / 2560×1352 / full-frame review / Root effectively pinned / Eye-Mouth local mask roll unnatural。

### v5.0.1 ZIP integrity

Filename: `KiwiAvatarSystem_v5_0_1_ZIP_INTEGRITY.json`  
Authority: STATIC_ONLY / ARTIFACT_INTEGRITY  
Result: PASS

### Current project runtime at archive time

Authority: NOT DIRECTLY LOADED IN THIS CHAT ARCHIVE CREATION。  
Current integrated project information states v44.55.23 runtime 115/115 / Observer Validity PASS / MIXED_TRANSACTION provisional。  
Do not treat this chat's v5.0.1 video as current Production Runtime。

---

## CURRENT RESULT

### Historical result of this chat

The chat reached v5.0.1 with:

- same-provider Root pinning cause identified and structurally corrected
- real Provider switch handoff preserved
- Head-local FacePart sampling introduced
- Texture/Mask rotation contract aligned
- all-encoded-frame QA policy adopted
- Unity baseline fixed to6000.0.80f1
- user policy updated to allow replacing working code when a clearly better overall design exists

At that moment, the remaining required step was Unity runtime validation of v5.0.1。

### Current project result at archive creation

This chat is no longer current Production authority。

As of 2026-09-02 integrated project state:

- Current major unresolved topic: Preprocessing / Output Transaction Semantic
- v44.55.23 Observer validity: PASS
- v44.55.23 decision: MIXED_TRANSACTION provisional
- v44.55.24 Pair-Bound Shadow Output Snapshot: next priority

---

## OPEN ISSUES

### Historical open issues at v5.0.1 endpoint

1. v5.0.1 Unity compile/runtime revalidation。
2. Root translation responsiveness確認。
3. Roll後のEye/Mouth Head-local mask確認。
4. Same-provider gap / real provider switch回帰確認。
5. Eye topology false reject / false accept確認。
6. Model switch + async semantic generation safety。
7. Global Tracking RecoveryとSemantic Recoveryの分離。
8. Immutable Tracking Frame / Generation architecture検討。
9. Runtime Policy Resolver / Single Writer強化。
10. FacePart Presentation arbitration整理。

### Current project open issue at archive time

Higher-authority current task: **v44.55.24 Pair-Bound Shadow Output Snapshot**。

目的: v44.55.23の3件NEITHER_EXACTがreal Production差かWorker output lifecycle observer raceか確定する。

---

## NEXT ACTION

### Historical next action for this chat

v5.0.1適用後のTelemetry付き動画を撮影し、正面静止、translation、fast motion、stop/reversal、Roll、Roll+Blink、Yaw/Pitch、Mouth-only、Face Lost/Reacquire、Model switchを全encoded-frame解析する。

### Current next action at archive creation

**Do not resume from v5.0.1 as if it were current Production.**

First use current Production authority:

1. local Production actual placement + SHA
2. latest same-Production Runtime
3. current KiwiValidation / Consolidated REPORT
4. v44.55.24 Pair-Bound Shadow Output Snapshot

v5.0.1 design lessons should be reused only where they remain compatible with the current Production architecture。

---

## DO NOT CHANGE

次の独立Evidenceがない限り、current projectでは以下を理由なく変更しない。

- Face Landmarker Primary / Source of Truth
- Head single rigid authority
- Eye/Mouth → Root feedback禁止
- latest-frame priority
- FIFO / stale accumulation禁止
- Source Age / Liveness分離
- Same Provider Resume / Provider Switch分離
- Texture/Crop/Mask same-sample transaction
- strong smoothing / Global Kalmanで問題隠蔽
- AsyncGPUReadback global blocking wait
- Native stable Production path
- Production lane.input direct oracle再採用
- Semantic PASS前のProduction CPU化
- commit / push without explicit instruction

ただし、ユーザー方針により、**より優れた総合設計が実測・比較で明確な場合は、working implementation自体の置換・再設計は可能**。

---

## HANDOFF

次チャットでこのREPORTだけを読む場合:

1. このREPORTは**2026-08-21 v5.0.1 Tracking/FacePart chatのhistorical archive**であり、current Production source snapshotではない。
2. Unity baselineは6000.0.80f1。
3. このチャットの重要な恒久知見:
   - Same Provider Resume != Provider Switch
   - Source Age != Liveness
   - Head = single rigid authority
   - Eye/Mouth → Root feedback禁止
   - Crop/Mask/Texture atomic transaction
   - Head-local FacePart presentation
   - all encoded framesを使うVisual QA
4. v5.0 regression:
   - same-provider gapがhandoff化されRoot pinning
   - Eye/Mouth patch Rigid Roll二重表現
5. v5.0.1 fix:
   - provider identity保持
   - stale sample非公開
   - same-provider resumeを通常fresh measurement
   - real provider switchのみhandoff
   - shared Head-local sample frame
   - Texture/Mask同一rotation
6. v5.0.1 ZIP SHA:
   `8943d3e44f74c8c3d0982478bf3a95fecb84c6b34a316ebc31920e3bd529b52e`
7. ただしcurrent Productionへ復帰するときはv5.0.1から再開せず、2026-09-02 current Authorityへ接続する。
8. Current integrated project next step: v44.55.24 Pair-Bound Shadow Output Snapshot。
9. local Productionを通常チャットから直接確認できない場合: `LOCAL_PRODUCTION_NOT_DIRECTLY_VERIFIED` と明記し、SHAを想像しない。
10. Working codeが正常でも、明確により良い総合案があれば変更可能。ただしEvidenceなしの全面再構築は禁止。

---

## PROJECT MASTER REPORT UPDATE CANDIDATES

Archive Name: `KiwiChat_NaturalMotionTrackingFacePartMask_v5_0_1_Updated_20260821-2341-JST.zip`  
LastWorkUpdate: 2026-08-21 23:41 JST

Validated Decisions:
- Same Provider Resume != Provider Switch
- Source Age != Liveness
- Head single rigid authority
- Eye/Mouth → Root feedback禁止
- Semantic part atomic transaction
- Head-local FacePart sampling
- Unity 6000.0.80f1 baseline
- best overall design may replace working implementation if evidence is clear

Rejected:
- source age only → Lost/Holding
- same-provider resume as switch
- strong global smoothing/Kalman masking
- independent Crop/Mask timestamps
- local patch Rigid Roll double application

Superseded:
- v5.0.1 as current latest Production
- GitHub 6b4d baseline as current authority
- “working behavior preservation is always highest priority”

Current Open Issue:
Historical v5.0.1 runtime acceptance is superseded by later project line。

Current Next Action:
v44.55.24 Pair-Bound Shadow Output Snapshot。

---

## CHAT ARCHIVE INDEX

Archive: KiwiChat_NaturalMotionTrackingFacePartMask_v5_0_1_Updated_20260821-2341-JST.zip  
Topic: Natural Motion Tracking / Provider Continuity / FacePart Mask / v5.0.1  
LastWorkUpdate: 2026-08-21 23:41 JST  
Status: SUPERSEDED  
Supersedes: Earlier v4.5-v5.0 tracking/mask conclusions within this chat。  
SupersededBy: Later KiwiAvatarSystem Production investigation line through v44.55.23+。  
NextArchiveCandidate: v44.55.24 Pair-Bound Shadow Output Snapshot completion archive。

---

## SOURCE / PROVENANCE NOTES

This permanent report was assembled from:

- current conversation content
- v5.0.1 review from File Library
- v5.0.1 ZIP integrity record
- later next-chat handoff artifact
- 2026-09-02 integrated KiwiAvatarSystem instructions / authority state
- permanent archive instruction document

No current local `D:\KiwiAvatarSystem` filesystem inspection was performed during archive creation。

Therefore:

`LOCAL_PRODUCTION_NOT_DIRECTLY_VERIFIED`

No unverified SHA was invented。
