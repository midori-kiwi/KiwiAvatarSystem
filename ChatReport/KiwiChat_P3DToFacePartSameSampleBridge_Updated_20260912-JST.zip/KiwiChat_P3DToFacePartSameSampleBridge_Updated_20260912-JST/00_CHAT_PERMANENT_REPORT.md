# KiwiAvatarSystem Chat Permanent Report

ChatTopic: P3D_TO_FACEPART_SAME_SAMPLE_BRIDGE
ChatTitle: P3D → FacePart Same-Sample Bridge Boundary Closure
ArchiveName: KiwiChat_P3DToFacePartSameSampleBridge_Updated_20260912-JST.zip
LastWorkUpdate: 2026-09-12
LastWorkUpdatePrecision: DATE_ONLY
ArchiveCreated: 2026-09-12 18:04:07 JST
ArchiveTimestampBasis: LAST_RELEVANT_WORK_BEFORE_ARCHIVE_REQUEST
Project: D:\KiwiAvatarSystem
Unity: 6000.0.80f1
CurrentInvestigationVersion: H1_MINIMAL_SAME_SAMPLE_HUMAN_HEAD_FACEPART_PRODUCT_INTEGRATION / P3D_TO_FACEPART_SAME_SAMPLE_BRIDGE
Status: IN_PROGRESS

## EXECUTIVE SUMMARY

このチャットでは、H1 Human Head / FacePart統合の次境界として
`P3D_TO_FACEPART_SAME_SAMPLE_BRIDGE` を設計レベルで前進させた。

今回の主結論は以下。

1. 新しいFaceGeometry pose sourceやsolverを作るのではなく、既存P3D側の
   `KiwiFaceGeometryTransactionService` を再利用する方針が最小責務である。
2. FacePart側のsource rigid removal writerは
   `KiwiFacePartRigidSampleFrame` 1個に維持する。
3. P3D accepted Pose16は、Pose単体ではなく完全なsame-sample identityと不可分な
   immutable snapshotとしてFacePartへ渡す。
4. FacePart appearance transactionとFaceGeometry transactionはexact identity match時のみ結合する。
   “latest geometry” の時刻近似結合は禁止する。
5. Pose16からrollを抽出する数式は推測実装しない。
   実使用MediaPipeUnityPlugin 0.16.3 Sourceまたは既存の正しいconsumerから、
   matrix convention / handedness / axis / mirror / signを閉じてから実装する。
6. Camera / Native / backend / Root / visible Head / tracking mathは今回のboundary外。
7. compile / local Runtime / Human Visual / Performanceはこのチャットでは未実行・未PASS。
8. Codex/local実行用として、Static audit → matrix semantic closure → minimal bridge →
   lifecycle → exact Unity compile → FULL_AUDIT_1+2 → targeted Runtime、の実行指示を作成した。

重要:
通常チャットからlive local Productionは直接確認していない。
このREPORTは設計・static source review・次作業定義の恒久記録であり、
local Production PASSやsame-build Runtime PASSへ昇格させない。

## OBJECTIVE

Face LandmarkerをPrimary / Source of Truthとして維持したまま、
P3Dで成立しているsame-sample FaceGeometry poseを
対応するFacePart Eye/Mouth appearance transactionへ安全に結合する。

目標データフロー:

`first468 / FacePart appearance`
→ `same-sample FaceGeometry Pose16`
→ `source rigid pose removal exactly once`
→ `head-local Eye/Mouth non-rigid appearance`
→ `existing fixed fitted surface`
→ `visible Head rigid pose exactly once`

目的は別人化ではなく、ユーザーのEye / Blink / Mouth / Mouth Shape / Open / Expressionを
Kiwi modelへ低遅延・高精度・低jitterで表示すること。

## CONFIRMED FACTS

### Static / repository-snapshot facts confirmed in this chat

- P3D側に `KiwiFaceGeometryTransactionService` が存在し、
  same-sample FaceGeometry transactionを扱う既存境界として利用可能であることを、
  このチャットで参照したsource snapshotから確認した。
- P3D transactionは少なくともframe/sample identityとgeneration類を保持し、
  stale / duplicate / mixed generationを拒否する設計であることをsource reviewで確認した。
- `KiwiFacePartRigidSampleFrame` をFacePart de-rigidizationの単一writerとして維持する方針を採用した。
- `SurfaceFittedRawImage` のexisting sample-frame rotation pathを維持し、
  texture sampleとsemantic maskの同一rotation transactionを壊さない方針を採用した。
- H1 bridgeの実装前にFaceGeometry Pose16 matrix semanticsを閉じる必要がある。
- このチャットではcompile / build / Runtime / performance benchmark / human visual reviewは実行していない。

### Inherited project state used but NOT re-verified as live local in this chat

- Face Landmarker = Primary / Source of Truth。
- Head = single rigid authority。
- Root / Head / Eye / Mouth responsibility separation。
- latest-frame / bounded / nonblockingを維持。
- FIFO / stale queue / previous-frame fallback / strong smoothing / Kalmanで問題を隠さない。
- H1 SourceRigidSingleOwner static closureは既存stateとして扱ったが、
  このチャットでlive-local再検証はしていない。
- SharedTiltLockはretired、FacePartAngleLock x3はdisabledを維持する前提で次工程を設計した。

### Authority discrepancy that must NOT be hidden

このチャットで作成したlocal/Codex実行指示には、
preflight expectationとして以下を記載した。

- branch=`work/raw-direct-motion`
- expected base HEAD=`7969a47342c712aa2a5bdfa13a5967a73db5e0e0`

一方、プロジェクト側の既存current contextには、
report-time Authorityとして別HEAD
`cd37cbe815ca13343869d11a4b353c057f9ec0e7`
が記録されている。

通常チャットではlive local HEADを直接確認していないため、
どちらもcurrent local Production Authorityへ自動昇格しない。

次のlocal preflightで必ず
branch / HEAD / status / dirty state / before SHA
を実測し、この差異を解消すること。

SHAを推測して継続してはいけない。

## PUBLIC DESIGN PRINCIPLES

このチャットでは新規の外部Web調査は行っていないため、
新しい公開設計原則を追加採用していない。

ただし実装判断として、実使用MediaPipeUnityPlugin 0.16.3の
FaceGeometry transformation matrix semanticsをpackage Sourceから確認することを必須とした。

公開/Package Source確認前に、
`atan2(...)` 等のEuler/roll式を推測でProductionへ入れることは認めない。

## INFERENCES / HYPOTHESES

以下はまだRuntime/compileで確定していない設計推論。

1. 最小bridgeは、
   `KiwiFaceGeometryTransactionService` がaccepted Pose16 + complete identityを
   immutable snapshotとして公開し、
   `KiwiFacePartRigidSampleFrame` がappearance transaction identityとの完全一致時だけconsumeする形。
2. “latest accepted pose” をLateUpdate等で読む方式は、
   appearance N + pose N+1 のmixed-sampleを作る可能性があるため不適切。
3. 現在のbilateral-eye crop roll estimatorは、
   P3D Pose16 pathのcorrectnessが成立した後に同一channelのduplicate authorityになるならretire候補。
   Pose16 path証明前に無条件削除しない。
4. Identity mismatch時はprevious pose fallbackを使わず、
   existing lifecycle/transaction contractに従ってnon-publish / neutral扱いとするのが安全。

これらはlocal implementation / compile / Runtimeで最終確認する。

## PRODUCTION AUTHORITY

Claim-Scoped Authorityを使用。

Current normal-chat authority:
`NORMAL_CHAT_LIVE_LOCAL_PRODUCTION_NOT_DIRECTLY_VERIFIED`

今回使用したもの:
- このチャット内のrepository/static source review
- 既存Project context / prior validated state
- 添付された恒久REPORT運用規則

今回使用していないもの:
- live local `D:\KiwiAvatarSystem` direct inspection
- same-build Product Runtime
- clean Production performance benchmark
- same-build Human Visual review

したがって以下へは昇格しない:
- LOCAL_PRODUCTION_PASS
- RUNTIME_PASS
- PERFORMANCE_PASS
- HUMAN_VISUAL_PASS
- FINAL_PRODUCT_ACCEPTANCE

GitHub/repository snapshotはlocal Productionそのものではない。

## WORK PERFORMED

### 1. 次境界のGoal Alignment

目的:
H1を最終ユーザー可視要件へつなぐfirst missing boundaryを特定する。

結果:
P3D FaceGeometry poseとFacePart appearanceのsame-sample bridgeを次作業に設定。

Status:
PASS as design-direction selection.

影響:
Camera / Native / backend等の無関係な最適化へ逸れず、
FacePart Human Head correctnessへ直接進む。

### 2. P3D producer側source trace

目的:
新しいPose producerが本当に必要か確認する。

結果:
既存 `KiwiFaceGeometryTransactionService` を再利用するのが最小責務と判断。

Status:
STATIC REVIEW COMPLETE for design placement.
LOCAL PRODUCTION NOT DIRECTLY VERIFIED.

影響:
second FaceGeometry solver / second inference / second pose authorityを追加しない。

### 3. FacePart writer側authority整理

目的:
source rigid removal ownerを増やさずbridge可能か確認する。

結果:
`KiwiFacePartRigidSampleFrame` を唯一のFacePart source-rigid writerとして維持する設計を採用。

Status:
DESIGN RETAIN.

影響:
新しいMonoBehaviour roll writer、
SharedTiltLock再有効化、
FacePartAngleLock再有効化を行わない。

### 4. Transaction join rule定義

目的:
same-sample guaranteeを壊さないPose/appearance joinを定義する。

結果:
Pose16 + identityを不可分snapshot化し、
appearance identityとexact matchした場合のみapplyする。

Status:
DESIGN ACCEPTED.

影響:
latest-pose近似、frameIdのみ一致、generation無視、
previous-frame fallbackを禁止。

### 5. Matrix semantic gate定義

目的:
誤ったroll sign / axis / handednessをProductionへ入れない。

結果:
実Package Sourceまたは既存correct consumerから
matrix convention / row-column / handedness / axis / mirror / sign
を閉じるまではroll抽出式を実装しない。

Status:
REQUIRED BEFORE IMPLEMENTATION.
CURRENTLY UNRESOLVED.

### 6. local/Codex実行指示作成

内容:
- exact Unity / branch / HEAD / dirty preflight
- current dataflow audit
- matrix semantic closure
- minimal immutable snapshot bridge
- exact identity gate
- single-owner preservation
- lifecycle reset
- forbidden changes
- static exit criteria
- FULL_AUDIT_1
- FULL_AUDIT_2
- targeted same-build Runtime authorization
- REPORT requirements
- COMMIT=NO
- PUSH=NO

Status:
READY FOR LOCAL EXECUTION.

## VALIDATED DECISIONS

### Decision 1
Decision:
P3D Pose producerを新設せず、既存 `KiwiFaceGeometryTransactionService` をbridge sourceに使う。

Reason:
既存same-sample transactionを再利用でき、
owner / inference / state / lifecycle surfaceを増やさないため。

Evidence:
このチャットでのrepository/static source review。

Regression constraints:
second solver / second inference / second pose owner禁止。

Still current:
YES, pending local verification.

### Decision 2
Decision:
FacePart source rigid removal writerは
`KiwiFacePartRigidSampleFrame` 1個に維持する。

Reason:
Head/FacePart rigid authority重複を避けるため。

Evidence:
H1 single-owner state + current bridge design review。

Regression constraints:
SharedTiltLock / FacePartAngleLock等を同時activeにしない。

Still current:
YES.

### Decision 3
Decision:
Pose16と完全identityをatomic/immutable snapshotとして扱い、
FacePart appearance transactionとexact identity match時のみapplyする。

Reason:
mixed sample / mixed epoch / stale pose適用を防止するため。

Evidence:
current transaction architecture and lifecycle requirements。

Regression constraints:
latest-only近似join、frameId-only join、previous fallback禁止。

Still current:
YES.

### Decision 4
Decision:
Pose16→roll抽出式はpackage semantics確認前に実装しない。

Reason:
axis/sign/handedness/mirrorの誤解はHuman Head visual correctnessを直接破壊するため。

Evidence:
P3D Pose16が4x4 transformation matrixであり、
FacePartへ使うroll conventionのclosureが別途必要。

Regression constraints:
推測atan2 / Euler式禁止。

Still current:
YES.

### Decision 5
Decision:
今回のboundaryでCamera / Native / backend / Root / visible Headを変更しない。

Reason:
first missing boundaryはFaceGeometry→FacePart bridgeであり、
他責務を同時変更すると原因分離・rollback・authorityが悪化するため。

Still current:
YES.

## REJECTED APPROACHES

### Rejected: Latest-geometry approximate join
Why considered:
実装が簡単に見えるため。

Why rejected:
appearance sampleとpose sampleがズレ、
same-sample transactionを破壊し得る。

Evidence:
transaction identity architecture。

Revisit condition:
NONE unless exact same-sample guaranteeを別方式で形式的に証明できる場合。

### Rejected: Pose-only shared mutable state
Why considered:
bridgeコード量を減らせるため。

Why rejected:
identityとPoseを別読みにするとmixed snapshotが起こり得る。

Revisit condition:
NONE for Production bridge.

### Rejected: New FaceGeometry solver / second inference
Why considered:
FacePart専用poseを独立生成する案。

Why rejected:
既存P3D transactionがあり、責務・latency・resource・lifecycleを増やすだけ。

Revisit condition:
既存P3D producerが要求semanticを満たさないことがsource/runtimeで証明された場合のみ。

### Rejected: Guessed matrix-to-roll formula
Why considered:
一般的4x4 matrixからrollを直接算出できるため。

Why rejected:
MediaPipe/package-specific coordinate conventionを未確認のまま式を決めると符号/軸を誤る可能性がある。

Revisit condition:
実Package Source / correct consumerでsemantic closure後。

### Rejected: Previous-frame pose fallback / queue / history
Why considered:
一時的なmissing poseを隠せるため。

Why rejected:
stale presentationを導入し、latest-frame / same-sample contractを壊す。

Revisit condition:
原則なし。必要なら別claimとして明確なevidenceが必要。

### Rejected: Multiple active roll owners
Why considered:
legacy eye-line estimatorをfallbackとして同時活用する案。

Why rejected:
source rigid authorityが重複し、double correction / state ambiguityを作る。

Revisit condition:
fallbackを明確にmutually-exclusive ownerとして設計し、
必要性をRuntimeで証明した場合のみ。

## SUPERSEDED CONCLUSIONS

このチャットで新たに正式SUPERSEDEしたProduction conclusionはない。

注意:
current eye-line estimatorのretirementはまだ未確定。
P3D Pose16 bridge correctness確認前にobsolete扱いしない。

## OBSERVER / VALIDATOR FINDINGS

このチャットでは新しいObserver / Validator / Runtime benchmarkを実行していない。

したがって:
- Observer PASSなし
- Validator PASSなし
- Compile PASSなし
- Runtime PASSなし
- Performance authorityなし

今後のvalidatorは、
regex / cardinality / source path / source identity / stale file参照を自身についても監査する。

## FILES / SHA256

### KiwiFaceGeometryTransactionService.cs
Role:
P3D same-sample FaceGeometry transaction / accepted Pose16 source候補。

SHA256:
NOT_AVAILABLE_IN_NORMAL_CHAT

Authority:
repository/static review only; live local not directly verified.

Current/Obsolete:
CURRENT CANDIDATE SOURCE.

### KiwiFacePartRigidSampleFrame.cs
Role:
FacePart source rigid removal single writer / bridge consumer候補。

SHA256:
NOT_AVAILABLE_IN_NORMAL_CHAT

Authority:
repository/static review / inherited H1 state.

Current/Obsolete:
CURRENT.

### KiwiFacePartTextureTransaction.cs
Role:
FacePart appearance transaction identity / commit boundaryとして監査対象。

SHA256:
NOT_AVAILABLE_IN_NORMAL_CHAT

Authority:
exact local implementation must be re-opened in local audit.

Current/Obsolete:
TO_VERIFY LIVE LOCAL.

### FacePartCropper.cs
Role:
Eye/Mouth crop transaction producer / current appearance source audit対象。

SHA256:
NOT_AVAILABLE_IN_NORMAL_CHAT

Current/Obsolete:
CURRENT AUDIT TARGET.

### SurfaceFittedRawImage.cs
Role:
sample-frame rotation / mask presentation path。

SHA256:
NOT_AVAILABLE_IN_NORMAL_CHAT

Current/Obsolete:
CURRENT AUDIT TARGET.

### FaceLandmarkerRunner.cs
Role:
P3D service creation/submission boundary確認対象。

SHA256:
NOT_AVAILABLE_IN_NORMAL_CHAT

Current/Obsolete:
CURRENT AUDIT TARGET; protected core principle applies.

## RUNTIME EVIDENCE

New Runtime evidence in this chat:
NONE.

No same-build H1 transaction Runtime was executed.

Prior P3D/H1 evidence was inherited as project context only and was not re-run here.

Therefore:
Correctness Runtime: NOT RUN
Performance Benchmark: NOT RUN
Human Visual: NOT RUN

## CORRECTNESS / PERFORMANCE / VISUAL / PROVENANCE SEPARATION

### Provenance
Normal chat does not directly verify current local Production.
Branch/HEAD discrepancy remains to be resolved by local preflight.

### Static Correctness
Bridge design direction: READY.
Matrix semantic closure: PENDING.
Exact local implementation audit: PENDING.
Compile: PENDING.

### Runtime Correctness
PENDING.

Required targeted checks include:
- appearance identity == Pose identity only
- mismatch application count = 0
- duplicate accepted application = 0
- out-of-order application = 0
- stale generation application = 0
- mixed epoch application = 0
- restart old-pose reuse = 0
- active source rigid writer count = 1
- Root translation unchanged

### Performance
NOT MEASURED.
Correctness runをPerformance Authorityにしない。

### Human Visual
NOT PASS / NOT EXECUTED in this chat.

Do not auto-pass:
- ROTATION_MATCH
- EYE_TWIST
- MOUTH_TWIST
- MOUTH_SIZE
- SURFACE_CLIP
- Final Human Visual

## OPEN ISSUES

1. live local branch / HEAD / status / dirty stateをpreflightで確定する。
2. `7969a...` と `cd37c...` のAuthority差異をlocal実測で解消する。
3. exact current FacePart appearance transaction identity surfaceをmethod単位で確認する。
4. Pose16 matrix semantics:
   - matrix layout
   - row/column convention
   - handedness
   - axis meaning
   - image/camera mirror relation
   - roll sign
   をPackage Source / correct consumerから閉じる。
5. immutable Pose16 + identity snapshot APIの最小実装位置を確定する。
6. lifecycle reset:
   service dispose / graph destruction / callback-root release /
   camera generation / tracking session generation /
   provider generation / model generation / scene reload /
   disable/destroy / lost-reacquire
   でold poseが残らないことを確認する。
7. exact Unity 6000.0.80f1 compile。
8. FULL_AUDIT_1 + FULL_AUDIT_2。
9. targeted same-build correctness Runtime。
10. その後にHuman Visual gate。

## NEXT ACTION

最優先:

`P3D_TO_FACEPART_SAME_SAMPLE_BRIDGE`

local/Codexで、今回作成した実行指示をそのままpreflightから開始する。

順序:

1. live local ProjectVersion / exact Unity / branch / HEAD / status / dirty保護
2. current source dataflow audit
3. Package Source matrix semantic closure
4. minimal immutable Pose16+identity bridge
5. exact FacePart identity match gate
6. lifecycle closure
7. exact Unity compile
8. FULL_AUDIT_1
9. FULL_AUDIT_2
10. targeted same-build Runtime authorization

成功時のみ:
`P3D_TO_FACEPART_SAME_SAMPLE_BRIDGE_STATIC=PASS`

その後:
`TARGETED_SAME_BUILD_H1_TRANSACTION_RUNTIME`

## DO NOT CHANGE

Evidenceなしに変更しない:

- Face Landmarker Primary / Source of Truth
- Camera / Native baseline
- inference backend selection
- KiwiFaceMotion tracking/root math
- KiwiInferenceFaceTracker camera workaround化
- Root translation authority
- visible Head rigid authority
- provider normalization ownership
- temporal presentation owner
- prediction owner
- tracking thresholds
- strong smoothing / Kalman
- FIFO / stale queue / history
- second Face Landmarker
- custom FaceGeometry solver
- neural face replacement
- Texture/Crop/Mask/FacePart same-sample transaction
- SharedTiltLock retirement
- FacePartAngleLock x3 disabled state
- source rigid writer count = 1 principle

COMMIT:
NO

PUSH:
NO

## MASTER REPORT UPDATE CANDIDATES

今後Project Masterへ反映すべき内容:

Archive Name:
`KiwiChat_P3DToFacePartSameSampleBridge_Updated_20260912-JST.zip`

Validated Decision:
- reuse existing P3D transaction service
- atomic Pose16 + full identity
- exact identity join only
- single FacePart source-rigid writer
- matrix semantics before formula
- unrelated Camera/Native/backend/Root/Head changes deferred

Rejected Approach:
- latest-pose approximate join
- mutable pose-only bridge
- guessed matrix formula
- previous-frame fallback / queue / history
- second FaceGeometry solver
- multiple active roll owners

Superseded Conclusion:
NONE newly finalized.

Open Issue:
- local Authority SHA discrepancy
- matrix semantic closure
- exact implementation/compile/runtime pending

Next Action:
`P3D_TO_FACEPART_SAME_SAMPLE_BRIDGE` local execution.

## CHAT ARCHIVE INDEX

Archive:
KiwiChat_P3DToFacePartSameSampleBridge_Updated_20260912-JST.zip

Topic:
P3D_TO_FACEPART_SAME_SAMPLE_BRIDGE

LastWorkUpdate:
2026-09-12

LastWorkUpdatePrecision:
DATE_ONLY

Status:
IN_PROGRESS

Supersedes:
NONE explicitly finalized in this chat.

SupersededBy:
NONE

NextArchiveCandidate:
Targeted same-build H1 transaction Runtime / Human Visual gate completion archive.

## HANDOFF

新チャットまたはlocal/Codexへ引き継ぐ際は、
このREPORTの `NEXT ACTION` から再開する。

最重要の未解決点は実装コード量ではなく、
1. live local Authority確定
2. FaceGeometry matrix semantic closure
3. exact same-sample identity join
の3点。

これらを閉じる前にVisual tweak、Camera/Native最適化、
threshold調整、smoothing追加へ進まない。

正常なWorking Coreを理由なく再設計しない。
問題をfilterで隠さず、first proven boundaryだけ修正する。
