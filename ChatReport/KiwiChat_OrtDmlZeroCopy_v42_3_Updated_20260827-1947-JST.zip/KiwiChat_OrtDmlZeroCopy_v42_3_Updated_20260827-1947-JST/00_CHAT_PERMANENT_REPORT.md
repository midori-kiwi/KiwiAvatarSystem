# KiwiAvatarSystem Chat Permanent Report

ChatTopic: ORT DirectML Native D3D12 Zero-Copy v42.3 / Native Plugin Lifecycle Root Fix / Validation Automation Handoff  
ChatTitle: v42.3 ORT DirectML D3D12 Zero-Copy Shadow 成立とNative Plugin Lifecycle根本修正  
ArchiveName: KiwiChat_OrtDmlZeroCopy_v42_3_Updated_20260827-1947-JST.zip  
LastWorkUpdate: 2026-08-27 19:47 JST  
LastWorkUpdatePrecision: DATE_TIME  
ArchiveCreated: 2026-09-02 23:30:06 JST  
ArchiveTimestampBasis: LAST_RELEVANT_WORK_BEFORE_ARCHIVE_REQUEST  
Project: D:\KiwiAvatarSystem  
Unity: 6000.0.80f1 / Windows / DX12  
CurrentInvestigationVersion: v42.3  
Status: DONE (HISTORICAL_CHAT_ARCHIVE; current project work has advanced beyond v42.3)  
ProductionVerification: LOCAL_PRODUCTION_NOT_DIRECTLY_VERIFIED  

## EXECUTIVE SUMMARY

このチャットでは、ORT DirectMLをUnity DX12上でGPU Zero-Copy shadowとして成立させるため、v42～v42.3の起動・PluginImporter・transaction・native graphics-device lifecycle問題を順に切り分けた。v42.2ではStandalone build自体は成功していたが、Player起動時に `KiwiOrtDmlZeroCopyBridge.dll` 内でnative crashした。原因クラスをUnity native rendering plugin lifecycleへ戻して見直し、v42.3で `IUnityGraphics` device-event callbackを基準にしたlifecycleへ修正した。

v42.3はApply PASS、Validator 34/34 PASS、DX12 Development Standalone Build PASS。その後の720p ZEROCOPY Runtimeで `enabled=1 backend=ORT_DIRECTML_NATIVE_D3D12 gpuInputReadback=0` を確認し、旧native crashは消失した。1130 pairのORT/Sentis比較ではlandmark/presence parityがほぼ完全一致し、全1130 pairでORT observed completionがSentis arrivalより先行した。したがって、このチャットの技術的結論は **「ORT DirectML Native D3D12 Zero-Copy feasibility = VALIDATED / GO」** である。

ただし、このrunはSentis authorityとORT shadowを同時稼働させるCorrectness Observer runであり、GPU使用率も高い。よってRender FPSやORT inference latencyをProduction Performance Authorityとして採用してはいけない。チャット終了時の次段は自動Validation Harness、同条件BASELINE A/B、ORT Authority A/Bであった。

重要: 2026-09-02時点のプロジェクト全体Authorityでは、その後v44.55.xまで進んでおり、現在の最優先はv44.55.24 Pair-Bound Shadow Output Snapshotである。本REPORTはv42.3の恒久履歴・成立証拠であり、現在のProduction再開点としてv42.3へ戻してはならない。

## OBJECTIVE

1. v42 ORT DirectML Zero-Copy shadowがUnity DX12 Playerで起動しない原因を特定する。  
2. PluginImporter/preload/transaction/native lifecycleを場当たりHOTFIXではなく根本修正する。  
3. exact 192x192 authority cropをGPU上でORT DirectMLへ渡し、CPU image readbackを除去する。  
4. Sentis authorityを維持したままORT shadow parityとtimingを測定する。  
5. 後続検証をCodex + PowerShell + Unity Runnerで自動化できるhandoffを整える。

## CONFIRMED FACTS

### v42.2までの起動問題

- v42.2 Standalone EXEは存在し、Build自体は成功していた。
- v42.2のPlayer起動失敗はlauncher filenameだけの問題ではなく、実際にはnative crashまで到達していた。
- crash stack先頭は `KiwiOrtDmlZeroCopyBridge.dll + 0x25AD` で、ORT/DirectML DLLではなくbridge側だった。
- v42.2では `KiwiOrtDmlZeroCopyBridge.dll`、`DirectML.dll 1.15.4.0`、`onnxruntime.dll 1.22.x` がロードされていた。

### v42.3 static/build

ユーザー実行結果:

- Apply: PASS
- Native bridge build: PASS
- PluginImporter policy: `preloaded=1`, `win64=1`, `cpu=x86_64`, `unity=6000.0.80f1`
- Validator: **34/34 PASS**
- Development Standalone Build: **PASS**
- Standalone bridge identity: exactly one Data/Plugins module
- Native PDB deployed beside bridge
- MAP retained at build root
- Validatorで以下を確認:
  - real device callback
  - preload null-renderer gate
  - unconditional manual initializeなし
  - lifecycle state/message export
  - D3D12 interface atomic
  - event config idempotent
  - no SyncWorkerThreads
  - no Unity graphics queue Wait
  - DML queue GPU Wait retained
  - Unity queue Signal retained
  - observer authority unchanged

### v42.3 Runtime startup

Player logで以下を確認:

`[KiwiInferenceV42.3] contract=KIWI_V5_1_PHASE16_20_32_V42_3_ORT_DML_NATIVE_LIFECYCLE_ROOTFIX enabled=1 backend=ORT_DIRECTML_NATIVE_D3D12 input=192x192 gpuInputReadback=0 authority=UNITY_INFERENCE_ENGINE slots=3 latestOnly=1 bridgeReadyAttempts=1 graphicsApi=Direct3D12`

さらに:

- Unity 6000.0.80f1
- Direct3D 12 / RTX 4090
- Native Camera Path B active
- UGREEN Camera 4K 1920x1080@60
- `captureTransport=B:SystemMemoryNV12`
- Native timestamp calibration active
- v39 cadence probe OFF
- v38 async-compute probe OFF
- row calibration = `FLIP_Y`
- FrameComparison rows = 1481
- Zero-Copy telemetry rows = 1130
- native bridge crashなし

### v42.3 Runtime measured values

同一FrameComparison runのcounter delta / elapsed timeから算出:

| Metric | Result |
|---|---:|
| Render FPS median | 40.262867 fps |
| Native capture/source rate | 60.213864 Hz |
| Native presented rate | 38.557524 Hz |
| Sentis scheduled rate | 38.312973 Hz |
| Sentis completed rate | 33.476300 Hz |
| Canonical adoption rate | 33.476300 Hz |
| FaceTexture commit rate | 33.340438 Hz |
| Sentis request→done median | 72.6911 ms |
| Sentis request→done P95 | 82.2326 ms |
| Accepted source age median | 85.7427 ms |
| Accepted source age P95 | 91.5599 ms |
| Native source interval median | 16.109 ms |
| Native capture GPU Wait count | 0 |
| Native processing GPU Wait count | 0 |
| Native dropped count | 0 |
| Native processing failures | 0 |
| Cross-system discard count | 0 |
| FaceTexture miss / hold | 0 / 0 |
| FacePart presentation epoch violations | 0 |

Zero-Copy telemetry 1130 paired rows:

| Metric | Result |
|---|---:|
| ORT inference p50 | 21.8234 ms |
| ORT inference p95 | 28.1739 ms |
| Bridge→done p50 | 22.3056 ms |
| Bridge→done p95 | 28.6178 ms |
| Source→ORT observed p50 | 36.1797 ms |
| Source→Sentis arrival p50 | 84.7426 ms |
| ORT effective completion rate | 38.2918 Hz |
| worker queue p50 | 0.0159 ms |
| nativeFailures | 0 |
| nativeSkipped | 0 |
| nativeReadyReplacements | 0 |
| Landmark MAE normalized p50 | 7.231809e-8 |
| Landmark max abs raw p50 | 1.06811523e-4 |
| Presence absolute diff p50 | 5.96046448e-8 |

`ortMinusSentisObservedMs` CSV列は全行0であり、diagnostic bug。host tickから直接計算すると:

- ORT observed - Sentis arrival median = **-49.19335 ms**
- range = -125.0079 ～ -6.5901 ms
- **1130 / 1130 pairでORTがSentisより先行**

GPU telemetry:

- utilization.gpu median = 98%
- P95 = 100%
- memory utilization median = 2%
- power median = 124.03 W
- GPU temperature median = 61°C

### Known non-zero-copy issues observed

- startupに `d3d12: upload buffer was too small for the requested resource!` warningあり。
- Sentis startup recoveryが1回発生: `Restarted Inference Engine (no GPU readback completion).`
- shutdownで `ComputeTensorData` / `ComputeBuffer` undisposed warningsが大量発生。
- Persistent native allocation leak warningあり。

これらはZero-Copy parity成立とは分離したOpen Issue。

## PUBLIC DESIGN PRINCIPLES

このチャットで確認・採用した公開設計原則:

1. Unity native rendering pluginは `UnityPluginLoad` で `IUnityGraphics` を取得し、`RegisterDeviceEventCallback` によりgraphics device lifecycleを追跡する。plugin load時にgraphics device initialize eventを取り逃す可能性があるため、lifecycleを明示的に扱う必要がある。
2. D3D12 interface/resourceを使う処理はgraphics deviceの実状態と結び付け、preloadだけをdevice-ready証拠にしない。
3. ORT DirectMLは外部D3D12 resourceをGPU allocationとして扱うAPIを提供し、GPU resourceを入力tensorへ結び付けられる。
4. Unity graphics queueと別DML compute queue間の同期はGPU-side fence signal/waitで行い、CPU blocking waitを避ける。
5. Diagnostic shadowはProduction authorityと分離し、observerが性能を汚染する場合はCorrectnessとPerformanceを別runで評価する。

## INFERENCES / HYPOTHESES

以下は確定事実ではない:

- ORT standalone benchmark約0.4msに対しUnity shadowでORT inference p50約21.8msとなった主因は、Sentis + ORTの同時実行でGPUが98～100%近く飽和しているためである可能性が高い。
- Sentisを停止しORTだけをbackend authorityにするとlatency/FPSが改善する可能性がある。

これらはAuthority A/Bで実測するまで採用しない。

## PRODUCTION AUTHORITY

このREPORT作成時、通常チャットから `D:\KiwiAvatarSystem` の現在の実配置を直接読み取っていないため:

**LOCAL_PRODUCTION_NOT_DIRECTLY_VERIFIED**

このチャット内のv42.3判断Authority:

1. 同一v42.3 Development Standalone Runtime evidence
2. user-provided Apply / Validator / Build output
3. uploaded Player.log / FrameComparison / ZeroCopy / GPU telemetry
4. Unity NativeRenderingPlugin公式sourceで確認したdevice-event lifecycle
5. ORT DirectML公式source/APIで確認したD3D12 external allocation path

GitHub repository:
`https://github.com/midori-kiwi/KiwiAvatarSystem/tree/main`

GitHub mainはlocal Productionより古い可能性があるためProduction authorityにはしない。

### Archive-time project-wide override

2026-09-02に提供された最新統合Authorityでは、プロジェクトはv44.55.xまで進んでいる。最新確定はv44.55.23 Observer Validity PASS / 115/115 Runtime PASS、最新暫定はMIXED_TRANSACTION、次作業はv44.55.24 Pair-Bound Shadow Output Snapshot。

したがって、本REPORT内の「ORT Authority A/Bを次に行う」という記述は**このチャット終了時点のhistorical next action**であり、2026-09-02のcurrent project next actionではない。

## WORK PERFORMED

### 1. v42 Validator / PluginImporter failure review

目的: Zero-Copy bridgeがUnity DX12 interface readyにならない原因を切り分ける。  
結果: `.meta` text parsing前提がPowerShell/Unity importer構造に対して脆弱と判明。  
Decision impact: `.meta` direct edit方式を廃止し、Unity Editor `PluginImporter` APIへ移行。

### 2. v42.1 Plugin lifecycle/preload root-fix

目的: `isPreloaded`設定をUnity Editor APIで決定的に適用。  
結果: importer policy自体は改善したが、transaction stale backup問題が別途発生。  
Decision impact: backup lifecycleも根本修正対象へ。

### 3. v42.2 transaction lifecycle root-fix

目的: stale backup、Apply再実行、Rollback lifecycleをfail-closed化。  
結果: v42.2 validation 14/14 PASS。Build EXEも存在。  
追加発見: packageのlauncher namingがv42/v42_2で不整合。またrunnerがPlayer即時終了をrun complete扱いできる欠陥。  
Decision impact: naming/preflight/exit-code監査を後続Harness必須要件へ。

### 4. v42.2 native crash capture

目的: Playerが起動しない真因の取得。  
結果: bridge/ORT/DirectMLはロードされるが `KiwiOrtDmlZeroCopyBridge + 0x25AD` を先頭にnative crash。  
Decision impact: preload不足仮説だけでは不十分。Unity graphics-device lifecycle設計へ戻る。

### 5. v42.3 Native Plugin Device Lifecycle Root Fix

目的: Unity公式device-event lifecycleに合わせ、preload/device-ready混同を除去。  
結果: Apply PASS / Validator 34/34 PASS / Standalone Build PASS。  
Decision impact: Runtime実測へGO。

### 6. v42.3 ZEROCOPY 720P Runtime

目的: native crash消失、Zero-Copy enable、parity、timing、camera regression確認。  
結果: `enabled=1`, `gpuInputReadback=0`, Camera ~60.21Hz, failure/drop/wait=0, parity極小差、1130/1130 ORT先行。  
Decision impact: ORT DML Zero-Copy feasibilityをVALIDATED / GO。

### 7. Codex automated validation handoff design

目的: 今後のApply→Validate→Build→Runtime→artifact回収→解析→判定を自動化。  
決定事項:

- Codex = repo横断監査/判断/解析
- PowerShell/Unity = deterministic local execution
- FrameComparison原本:
  `C:\Users\main\AppData\LocalLow\MidoriKiwi\KiwiAvatarSystem\KiwiFrameComparison\`
- ZeroCopy / Player log / GPU telemetryのrunner copy:
  `D:\KiwiAvatarSystem\`
- 最終集約先:
  `D:\KiwiAvatarSystem\ValidationRuns\<RunID>\`
- 原本は移動/削除せずcopyする。
- 「最新ファイル」を雑に拾わずtimestamp/version/mode/resolution/caseで同一runをbindingする。

## VALIDATED DECISIONS

### Decision: Unity `.meta` direct parsing/editを廃止
Reason: field/block存在を仮定したPowerShell処理が再現性なく失敗した。  
Evidence: v42 HOTFIX2/HOTFIX3 installer failures。  
Regression constraints: PluginImporter変更はUnity Editor API経由。  
Still current: YES。

### Decision: Native bridge lifecycleはUnity graphics device eventを基準にする
Reason: v42.2 crashをpreloadだけでは解消できず、v42.3 lifecycle root-fix後に正常起動。  
Evidence: v42.3 `enabled=1` Runtime。  
Regression constraints: preload != device-ready。renderer/device nullを安全に扱う。  
Still current: validated historical design principle。

### Decision: ORT DirectML Native D3D12 Zero-Copy feasibility = GO
Reason: GPU input readback=0で1130 paired rows、fail/skip/replacement=0、parity極小差。  
Evidence: v42.3 Runtime evidence。  
Regression constraints: Sentis/Face Landmarker authorityをshadow test中に変更しない。  
Still current: historical feasibility evidence。Current Production backend採用を意味しない。

### Decision: Correctness ObserverとPerformance Benchmarkを分離
Reason: v42.3 shadowはSentis + ORT同時稼働でGPU utilization 98～100%。  
Evidence: GPU telemetry。  
Regression constraints: このrunのFPS/ORT latencyをProduction performance authorityにしない。  
Still current: YES。

### Decision: Runtime evidenceをValidationRunsへrun単位で集約
Reason: CSV/log不足、launcher naming、latest-file取り違えの再発防止。  
Evidence: このチャットでの検証運用設計。  
Regression constraints: 原本を削除しない。同一RunIDでbinding。  
Still current: automation designとして有効。ただしlocal current implementationは本REPORTから直接未確認。

## REJECTED APPROACHES

### Rejected: CPU image readback shadowをProduction候補にする
Why considered: ORT DML parity確認の最初の手段。  
Why rejected: v41 AsyncGPUReadbackが大きなlatency/FPS悪化を生んだ。  
Evidence: v41 historical evidence（このArchiveには本体未梱包）。  
Revisit condition: なし。Zero-Copy経路が成立したため戻さない。

### Rejected: `.meta` YAML文字列置換によるPluginImporter設定
Why considered: preloadをinstallerから直接設定するため。  
Why rejected: Unity version/meta schema依存でHOTFIX2/3が失敗。  
Evidence: installer failures。  
Revisit condition: 原則なし。

### Rejected: preload成功だけでnative device readyと判定
Why considered: v42 bridge not-ready原因仮説。  
Why rejected: v42.2ではpreload/bridge deployment改善後もnative crash。  
Evidence: v42.2 crash stack + v42.3 lifecycle成功。  
Revisit condition: なし。

### Rejected: Launcherの`run complete`を成功証拠にする
Why considered: 初期runner実装。  
Why rejected: Player即時終了/クラッシュでもrunnerが完了表示可能だった。  
Evidence: v42.2 launch debugging。  
Revisit condition: なし。ExitCode/startup-survival/artifact completenessを必須化。

## SUPERSEDED CONCLUSIONS

### OLD
「v42 ZEROCOPY runが動かない主因はNative bridgeがpreloadされていないこと」

### NEW
preloadは必要条件の一部だったが、根本原因クラスはnative graphics-device lifecycle。v42.3 device-event root-fix後に正常起動。

### WHY
v42.2でもbridge/ORT/DirectMLはロードされ、bridge内native crashまで進んだため。

### EVIDENCE
v42.2 crash stack / v42.3 Runtime startup marker。

---

### OLD
「v42.3の次はBASELINE→ORT Authority A/B」

### NEW
これは2026-08-27時点のhistorical next action。2026-09-02のproject-wide current stateではv44.55.24 Pair-Bound Shadow Output Snapshotが最優先。

### WHY
その後のプロジェクト作業でv44.55.x CPU/GPU semantic/transaction investigationまで進んだため。

### EVIDENCE
2026-09-02統合最新版カスタム指示 / Authority一覧。

## OBSERVER / VALIDATOR FINDINGS

1. Windows PowerShell 5.1ではString.Splitのoverload挙動差により、validatorがfalse failureを出した履歴がある。Validator自身をProduction同等に監査する必要がある。
2. `.meta` field/blockを固定文字列として読むvalidator/installerは不適切。
3. v42.2 runnerはPlayerの早期終了を成功相当の`run complete`として表示できた。ExitCode/startup survivalが必須。
4. v42.3 `ortMinusSentisObservedMs`列は全行0で、実host ticksと不一致。diagnostic column bugでありtracking/runtime本体の差ではない。
5. v42.3 shadow runはCorrectness Observerであり、Sentis + ORT + telemetry負荷を含む。Performance Authorityにしない。
6. Evidence collectionは「最新ファイル」ではなくRun identityでbindingする必要がある。

## FILES / SHA256

### Archive source package

Path/Artifact: `KiwiAvatarSystem_v5_1_0_Phase16_20_32_v42_3_NATIVE_PLUGIN_DEVICE_LIFECYCLE_ROOTFIX_TRANSACTIONAL.zip`  
Role: v42.3 installer/build/runtime source package  
SHA256: `b2913a8b992fbc9b49b146d15f0b614c5e6d1c15088b2d82a397b072985d9dc0`  
Verification: archive作成時に `/mnt/data` copyを再計算  
Current/Obsolete: historical validated diagnostic package; not asserted as 2026-09-02 Production

### Production-protected tracker

Path: `D:\KiwiAvatarSystem\Assets\Script\KiwiInferenceFaceTracker.cs`  
Role: inference/tracking core  
Validator-reported SHA256: `52c046ee44b41a4ff50b85aef503bc29dd31b57eaf58c0d160ccc33c5d4b7695`  
DirectlyVerifiedSHA256: `NOT_AVAILABLE_IN_NORMAL_CHAT`  
Note: v42.3 validator outputで「tracker unchanged」と報告された値。現在local Production実体は直接確認していない。

その他の現在Production critical file SHAは本チャットから直接確認していないため推測しない。

## RUNTIME EVIDENCE

このArchiveには、再取得価値の高い最終v42.3 Runtime evidenceのみ `Evidence/` へ複製した。原本のlocal保存先を変更したことを意味しない。

### 1. Player log
File: `KiwiStandalonePlayer_v42_3_DX12_DEV_ZEROCOPY_720P_20260827_194615.log`  
SHA256: `ffe018f5e740cfea3d0c69fc832de5dc910b8d87dcb6d962c91ea6093d317a02`  
Authority: CORRECTNESS / LIFECYCLE / SUPPORTING_ONLY  
Purpose: backend enable、camera identity、row calibration、startup/shutdown確認

### 2. FrameComparison
File: `KiwiFrameComparison_20260827_194643.csv`  
SHA256: `81b0821d23cb54b216a3b86f2b9df58164e1201a01d9e16f61676b0c73c54d57`  
Rows: 1481  
Authority: CORRECTNESS / LATENCY-CADENCE SUPPORTING_ONLY  
Production Performance Authority: NO (shadow observer run)

Original source folder:
`C:\Users\main\AppData\LocalLow\MidoriKiwi\KiwiAvatarSystem\KiwiFrameComparison\`

### 3. ORT DML Zero-Copy telemetry
File: `KiwiOrtDmlZeroCopyTelemetry_v42_3_ZEROCOPY_720P_20260827_194615.csv`  
SHA256: `3446d2f738452f418a0f434d2953c2ed9b351bd6d9b874ecd1fe7cc5bd5796ed`  
Rows: 1130  
Authority: CORRECTNESS / PARITY / SUPPORTING TIMING  
Production Performance Authority: NO

Runner copy location:
`D:\KiwiAvatarSystem\`

### 4. GPU telemetry
File: `KiwiGpuTelemetry_v42_3_DX12_DEV_STANDALONE_ZEROCOPY_720P_20260827_194615.csv`  
SHA256: `b4bb972e67ed941831b16358d64cd0a848f0076039c90a9257d0d80078954022`  
Authority: SUPPORTING_ONLY / OBSERVER LOAD CONTEXT

### 5. GPU telemetry metadata
File: `KiwiGpuTelemetry_v42_3_DX12_DEV_STANDALONE_ZEROCOPY_720P_20260827_194615.meta.txt`  
SHA256: `866caa184feda07a02ebba8320b80a2fb089cc2b537aebc399d76e467be052fc`  
Run generated: 2026-08-27 19:46:15 +09:00  
Run finished: **2026-08-27 19:47:20 +09:00**  
Authority: PROVENANCE / RUN IDENTITY

このfinished timestampをArchive `LastWorkUpdate` の根拠とした。

### Visual
MP4: このv42.3初回Zero-Copy bridge/parity runでは「No OBS/MP4」で実施したため、Visual Performance/Tracking acceptanceはこのrunでは未実施。  
Authority: VISUAL = NOT_AVAILABLE_FOR_THIS_RUN

## CORRECTNESS / PERFORMANCE / VISUAL / PROVENANCE SEPARATION

### Correctness
PASS for Zero-Copy feasibility/parity:
- backend enabled
- GPU input readback 0
- 1130 paired samples
- parity extremely close
- no native failure/skip/replacement
- camera identity/cadence intact

### Performance
NOT FINAL AUTHORITY:
- Render FPS、ORT latency、GPU utilizationは記録したが、Sentis + ORT shadow + telemetry同時実行のためProduction A/B判定には使わない。

### Visual
NOT PERFORMED for this specific v42.3 first bridge/parity run。

### Provenance
v42.3 package SHAとRuntime evidence SHAを本Archiveで固定。local Production current placementは直接未検証。

## CURRENT RESULT

### このチャットの最終技術結果

**v42.3 ORT DirectML Native D3D12 Zero-Copy Shadow = VALIDATED / GO**

成立した内容:
- Native plugin lifecycle root-fix
- Unity DX12 bridge startup
- GPU input readback removal
- ORT DML execution
- Sentis parity
- Camera Path B non-regression
- no native drops/waits/failures in measured run

成立していない内容:
- ORTをProduction authority backendとして正式採用
- Production performance superiority確定
- shutdown resource leak解消
- visual acceptance

### 2026-09-02 Project-wide current result

このArchiveはhistorical。Project-wide current investigationはv44.55.23→v44.55.24であり、v42.3を現在の作業開始点として扱わない。

## OPEN ISSUES

### Historical open issues from this chat

1. BASELINE 720PとZEROCOPY 720Pのstrict A/B。
2. ORT Authority backend A/B。
3. `ortMinusSentisObservedMs` telemetry bug修正。
4. Sentis shutdown `ComputeTensorData/ComputeBuffer` resource cleanup。
5. Persistent native leak warning調査。
6. startup `d3d12 upload buffer too small` warningの責務分離調査。
7. automated validation harness実装。

### Archive-time current project issue

2026-09-02 Authorityではv44.55.23のMIXED_TRANSACTIONは暫定で、Worker output lifecycle race未排除。v44.55.24 Pair-Bound Shadow Output Snapshotが先。

## NEXT ACTION

### CURRENT project action at archive creation

**v44.55.24 Pair-Bound Shadow Output Snapshotを実施し、Worker allocator output lifecycle raceを排除する。**

本Archiveのv42.3 historical next action（Validation Harness / BASELINE / ORT Authority A/B）へ先に戻らない。

### Historical next action from end of this chat

当時の予定は:
1. Automated Runtime Validation Harness
2. v42.3 BASELINE 720P
3. strict BASELINE vs ZEROCOPY A/B
4. ORT Authority A/B

## DO NOT CHANGE

新しい独立Evidenceなしに:

- Face Landmarker Primary / Source of Truth
- Native Camera Path B SystemMemoryNV12
- latest-frame policy
- camera session epoch / texture identity semantics
- strict FaceTexture transaction
- KiwiFaceMotion.csをcamera/inference workaroundとして変更
- KiwiInferenceFaceTracker.cs tracking mathをcamera/inference workaroundとして変更
- ROI / threshold / model / decodeを性能回避策として変更
- strong smoothing / Kalman
- FIFO / stale queue
- blocking GPU wait
- Unity D3D12 graphics queue Wait
- UpdateExternalTexture
- rotating Unity-visible texture identity

を変更しない。

また、2026-09-02 current project ruleとして:
- Production lane.input direct oracleを再採用しない。
- Semantic PASS前にProduction CPU化しない。
- Correctness Observer runをPerformance Authorityにしない。

## VALIDATION AUTOMATION HANDOFF

このチャットで設計した自動検証の基本方針:

```text
Codex
  -> source/SHA/dependency audit
  -> design/regression review
PowerShell + Unity local runner
  -> Apply
  -> Static Validate
  -> Build
  -> Player start/survival/ExitCode
  -> auto recording
  -> fixed-duration Runtime
  -> graceful quit
  -> artifact completeness
  -> metric analysis
  -> report.json/report.md
```

推奨run集約:

```text
D:\KiwiAvatarSystem\ValidationRuns\<RunID>\
  FrameComparison\
  ZeroCopy\
  GPU\
  Logs\
  Video\
  report.json
  report.md
```

RunID:
`YYYYMMDD_HHMMSS_<VERSION>_<MODE>_<RESOLUTION>`

重要:
- 原本をdelete/moveしない。
- copyで集約。
- latest filenameだけでbindingしない。
- timestamp/version/mode/resolution/caseを一致させる。
- artifact不足はfail-closed。
- early crash/ExitCode未確認でPASSを出さない。
- PowerShell 5.1 compatibilityを固定要件とする。

## HANDOFF

このREPORTを読む次担当者は、以下を区別すること。

### v42.3から得られた恒久的価値

- ORT DirectML Native D3D12 Zero-CopyはUnity 6 DX12上で実際に成立した。
- native pluginはpreloadだけでなくgraphics device-event lifecycleを正しく扱う必要がある。
- GPU input readbackなしでSentisと極めて高いoutput parityが得られた。
- observer/runner/validator自体にもfalse failure・telemetry bug・false PASSの可能性がある。
- ValidationRuns run identity方式は再発防止に有効。

### このREPORTから再開してはいけないもの

2026-09-02時点ではプロジェクト全体がv44.55.xへ進んでいるため、v42.3 ORT Authority A/Bを「現在の次作業」として実施してはいけない。

Current project authority:
- v44.55.23 Observer Validity PASS
- 115/115 Runtime PASS
- MIXED_TRANSACTION = 暫定
- next = v44.55.24 Pair-Bound Shadow Output Snapshot

### Authority order

1. local Production actual placement + SHA
2. same-Production latest Runtime
3. actual Package Source
4. latest KiwiValidation / Consolidated Report
5. official docs/source
6. local git
7. GitHub main
8. older diagnostics/chat archives

本REPORTは8に相当するhistorical chat archiveだが、v42.3 Zero-Copy feasibilityに関する一次Runtime evidenceを内包するため、その限定論点では重要な証拠として残す。

## PROJECT MASTER REPORT UPDATE CANDIDATES

Masterへ反映すべきhistorical items:

- Archive: `KiwiChat_OrtDmlZeroCopy_v42_3_Updated_20260827-1947-JST.zip`
- Topic: ORT DirectML Native D3D12 Zero-Copy v42.3
- LastWorkUpdate: 2026-08-27 19:47 JST
- Validated: native device-event lifecycle root-fix
- Validated: ORT DML Zero-Copy feasibility/parity
- Rejected: `.meta` direct parser/editor
- Rejected: preload-only device readiness assumption
- Observer finding: `ortMinusSentisObservedMs` invalid zero column
- Open historical issue: shutdown resource cleanup
- Current override: v44.55.24 is project-wide next action

通常チャットからlocal MASTER REPORTは直接更新していない。

## CHAT ARCHIVE INDEX

Archive: `KiwiChat_OrtDmlZeroCopy_v42_3_Updated_20260827-1947-JST.zip`  
Topic: `OrtDmlZeroCopy_v42_3`  
LastWorkUpdate: `2026-08-27 19:47 JST`  
Status: `DONE / HISTORICAL`  
Supersedes: `v42 / v42.1 / v42.2 bridge-startup and lifecycle conclusions`  
SupersededBy: `later v44.x project state for current Production direction; v42.3 feasibility evidence remains valid historically`  
NextArchiveCandidate: `v44.55.24 Pair-Bound Shadow Output Snapshot completion`  

---

Archive note: ZIP SHA256はZIP生成後の自己参照を避けるためREPORT本文には埋め込まず、作成時の最終応答で提示する。
