# KiwiAvatarSystem Chat Permanent Report

## METADATA

ChatTopic: Face Landmarker以上のTracking方式比較 / Kiwi適用判断  
ChatTitle: Landmarker以上のトラッキング処理はある？  
ArchiveName: KiwiChat_FaceLandmarkerTrackingComparison_Updated_20260902-JST.zip  
LastWorkUpdate: 2026-09-02  
LastWorkUpdatePrecision: DATE_ONLY  
ArchiveCreated: 2026-09-02 23:12 JST  
ArchiveTimestampBasis: LAST_RELEVANT_WORK_BEFORE_ARCHIVE_REQUEST  
Project: D:\KiwiAvatarSystem  
Unity: 6000.0.80f1 / Windows / DX12  
CurrentInvestigationVersion: Tracking comparison only; no Production code/version change in this chat  
Status: DONE  

Archive: KiwiChat_FaceLandmarkerTrackingComparison_Updated_20260902-JST.zip  
Topic: FaceLandmarkerTrackingComparison  
Supersedes: NONE  
SupersededBy: NONE  
NextArchiveCandidate: v44.55.24 Pair-Bound Shadow Output Snapshot completion, or a future dedicated Tracking benchmark/audit

## EXECUTIVE SUMMARY

このチャットでは、「Face Landmarker以上のトラッキング処理があるか」を検討した。

結論は、KiwiAvatarSystemに対して Face Landmarker を別トラッカーへ即置換する根拠はない。
Face LandmarkerをPrimary / Source of Truthとして維持し、その後段で geometry / rigid head pose / channel authority / prediction policy / adaptive stabilization 等を必要に応じて改善する方が、現在のKiwi設計との整合性が高い。

ただし、このチャットでは比較候補の実測・Production A/B・新規コード実装は行っていない。
したがって「Landmarker + 独自後段処理が必ず他方式より高性能」というProductionレベルの確定結論にはしない。

現行プロジェクトの既定方針である Face Landmarker Primary / Source of Truth は変更しない。

## OBJECTIVE

- Face Landmarkerより上位の追跡方式または処理構成が存在するか確認する。
- KiwiAvatarSystemでFace Landmarkerを置換すべきか、後段処理を改善すべきか整理する。
- 現行Tracking Coreを理由なく作り直さない方針との整合性を確認する。

## CONFIRMED FACTS

### Current Kiwi project context

SOURCE=UPLOADED_PROJECT_CONTEXT / PROJECT_CHAT_CONTEXT

- Face LandmarkerはKiwiAvatarSystemのTracking Primary / Source of Truthとして固定されている。
- Tracking Coreでは latest-frame、FIFO/stale queue禁止、persistent ROI、near-raw responsiveness、Head single rigid authority、Root / Head / Eye / Mouth authority分離を維持する。
- strong smoothing / Kalmanで上流問題を隠す方式は禁止。
- KiwiFaceMotion.cs / KiwiInferenceFaceTracker.cs をcamera/display cadence workaroundとして変更しない。
- Native Camera Path B SystemMemoryNV12は安定済みで、新しい独立EvidenceなしにNative C++/DLLを変更しない。
- 現在のプロジェクト最優先は v44.55.24 Pair-Bound Shadow Output Snapshot。
- Semantic Correctness確定前にProduction CPU化へ進まない。

### This chat

- Production code変更: NONE
- local Production direct inspection: NOT PERFORMED
- Runtime CSV / TXT / Player.log / MP4 validation: NONE
- Compile / build / static validation: NONE
- SHA256 recalculation of Production files: NONE
- Tracking replacement decision: NOT ADOPTED

LOCAL_PRODUCTION_NOT_DIRECTLY_VERIFIED

## PUBLIC DESIGN PRINCIPLES

### Face tracking architecture

このチャットで採用可能と整理した一般原則:

- Landmark detector / estimator と Avatar presentation/filtering を別責務として扱う。
- Head rotationとRoot translationを同一の単純ランドマーク変位から直接混ぜない。
- 観測・姿勢推定・presentation stabilizationを分離する。
- 遅延を増やす常時強平滑化より、正常sampleを速く通し、異常時だけ局所抑制する。
- Predictionを使う場合も、stale sampleを無期限に予測し続けず、source liveness/source ageと分離する。
- 商用/非公開システムの内部実装は公開事実と推測を分離する。

### Alternative classes discussed

比較候補として以下のクラスを挙げた:

- NVIDIA Maxine AR系
- Apple ARKit / TrueDepth系
- MediaPipe Face Landmarker + Kiwi独自後段処理

ただし、このチャット内ではこれらの同一条件Runtime A/Bは実施していない。

## INFERENCES / HYPOTHESES

以下はProduction実測未確認:

- KiwiではFace Landmarkerの観測自体より、後段のgeometry / authority分離 / temporal policyの方が改善余地が大きい可能性がある。
- Windows + NVIDIA限定ではMaxineが比較ベンチマーク候補になり得る。
- TrueDepth利用可能環境ではARKit系が高品質な比較候補になり得る。
- Face Landmarker + 適切な後段tracking処理が、Kiwiのクロスプラットフォーム性と既存設計を維持しつつ最も実用的な方向になる可能性が高い。

これらをProduction採用判断に使うには、同一input / timestamp / canonical outputでの実測比較が必要。

## PRODUCTION AUTHORITY

このチャットでのAuthority優先順位:

1. 現在のlocal Production実体 + SHA
   - 通常チャットから直接未確認
2. 同一Production最新Runtime
   - このチャットでは新規Runtimeなし
3. 実使用Package Source
   - MediaPipeUnityPlugin v0.16.3 / Unity Inference Engine 2.4.1 がプロジェクト文脈上の基準
4. 最新KiwiValidation / Consolidated REPORT
5. 公式Documentation / 公式Source
6. local Git history
7. GitHub main
8. 過去version / diagnostic
9. Issue / Discussion
10. 技術記事 / SNS等

GitHub mainはlocal Productionより古い可能性があるためProduction Authorityにはしない。

## WORK PERFORMED

1. Face Landmarker以上の単一トラッカー候補の有無を整理。
   - 目的: 置換すべき明確な上位互換があるか判断。
   - 結果: 環境依存で強い候補はあるが、Kiwi向けの無条件上位互換は確定できない。
   - Result: PASS as architectural comparison.

2. Kiwiの既存Tracking Core方針と比較。
   - 目的: 置換が現行設計を壊さないか確認。
   - 結果: Face Landmarker Primaryを維持し、必要なら後段を局所改善する方が現行制約と整合。
   - Result: PASS as design consistency review.

3. Geometry / prediction / adaptive stabilization等の後段処理を候補化。
   - 目的: Landmarkerそのものを捨てずに追従品質を高める方向を整理。
   - 結果: 将来検証候補として妥当。ただしRuntime Evidenceなしのため未採用。
   - Result: HYPOTHESIS / VALIDATION_REQUIRED.

4. 恒久REPORT / ZIP運用指示をこのチャットの保存ルールとして登録。
   - 技術成果ではなくarchive運用ルール。
   - LastWorkUpdateには使用していない。

## VALIDATED DECISIONS

Decision: Face Landmarker Primary / Source of Truthを維持する。  
Reason: 現行Kiwi Tracking Coreの成立済み設計と一致し、このチャットでは置換を正当化するProduction Evidenceがない。  
Evidence: Project context / uploaded authority instructions; no contradictory runtime evidence in this chat.  
Regression constraints: Working Tracking Coreを理由なく再設計しない。  
Still current: YES

Decision: 「Landmarkerより上」という理由だけで単一trackerへ置換しない。  
Reason: Maxine/ARKit等は環境・ハード依存があり、Kiwiの既存authority/cross-platform設計を無条件に上回るProduction証拠がない。  
Evidence: Architectural comparison only; no same-condition Kiwi A/B.  
Regression constraints: 置換検討時はSource Identity→Semantic→Canonical→Latency→Lifecycle→Visualの順で比較する。  
Still current: YES

Decision: 後段改善を行う場合も、Head rigid authority / Root separation / latest-frame / near-raw原則を維持する。  
Reason: Kiwiの既定品質思想と一致。  
Evidence: Uploaded integrated project instructions / authority list.  
Regression constraints: strong smoothing、FIFO、stale prediction常態化は禁止。  
Still current: YES

## REJECTED APPROACHES

Rejected: Face Landmarkerを即Maxine等へ置換。  
Why considered: 高性能な代替face tracking stackが存在する可能性。  
Why rejected: Kiwi Productionでのsame-input Runtime A/Bなし。Windows/NVIDIA等の依存も増える。  
Evidence: This chat contains no Production equivalence/performance validation.  
Revisit condition: Face Landmarkerの明確な限界がRuntimeで確認され、同一input/authority条件で代替が優越した場合。

Rejected: 強い平滑化/KalmanでLandmarker jitterを隠す。  
Why considered: 静止安定化の一般的手段。  
Why rejected: Kiwi固定方針に反し、正常時latencyを増やし根本原因を隠す可能性。  
Evidence: Project design constraints.  
Revisit condition: 原則再採用しない。新しい独立Evidenceと明確なlatency予算がある場合のみ再評価。

## SUPERSEDED CONCLUSIONS

OLD: 「Landmarker + 独自Prediction/Geometry/Adaptive Tracking = 必ず★★★★★で最適」と断定可能。  
NEW: アーキテクチャ候補として有力だが、このチャットではProduction実測未実施のため最終性能優位は未確定。  
WHY: Same-input / same-timestamp / canonical / latency / visual A/B evidenceがないため。  
EVIDENCE: This chat's actual evidence scope.

## OBSERVER / VALIDATOR FINDINGS

- このチャットでは新規Observer/Validator runなし。
- Observer-heavy runのPerformance値を正式採用しない既存原則を継続。
- 新しいTracking方式を比較する場合、observerそのものがtimestamp/source identity/latencyを汚染しないことを別途監査する。

## FILES / SHA256

### Project critical files

Path: D:\KiwiAvatarSystem\... Production Tracking files  
Role: Current tracking authority  
SHA256: NOT_AVAILABLE_IN_NORMAL_CHAT  
Before/After: UNCHANGED_IN_THIS_CHAT  
Current/Obsolete: CURRENT (project context; local placement not directly verified)

### Uploaded reference files used for archive/context

File: KiwiAvatarSystem-情報源・Authority一覧.txt  
Role: Project authority rules and current investigation context  
SHA256: NOT_AVAILABLE_IN_NORMAL_CHAT  
Current/Obsolete: CURRENT_REFERENCE

File: KiwiAvatarSystem-統合最新版カスタム指示-情報源-作業履歴-今後計画-更新基準-2026-09-02.txt  
Role: Current project state / completed work / open work / fixed constraints  
SHA256: NOT_AVAILABLE_IN_NORMAL_CHAT  
Current/Obsolete: CURRENT_REFERENCE

File: 通常チャット用-恒久REPORT・ZIP直接作成指示.txt  
Role: Archive generation contract  
SHA256: NOT_AVAILABLE_IN_NORMAL_CHAT  
Current/Obsolete: CURRENT_REFERENCE

File: Github-リポジトリ.txt  
Role: Repository pointer only  
SHA256: NOT_AVAILABLE_IN_NORMAL_CHAT  
Current/Obsolete: SUPPORTING_ONLY

## RUNTIME EVIDENCE

No new Runtime Evidence generated or analyzed in this chat.

Correctness: NONE  
Performance: NONE  
Visual: NONE  
Provenance: NONE  
Static-only: Architectural/project-context review only  
Supporting-only: Uploaded authority/instruction files

Important:
このチャットのTracking比較結果をPerformance Authorityとして扱わない。

## CURRENT RESULT

- Face Landmarker Primary / Source of Truthは維持。
- 代替trackerへの置換は不採用。
- 後段のgeometry / rigid head pose / prediction / adaptive stabilizationは「将来の検証候補」であり、Production採用済みではない。
- 現行Tracking Core / Native Camera / Presentationの成立済み経路は変更しない。
- このチャットではProduction file変更・Runtime検証なし。

## OPEN ISSUES

1. Face Landmarker後段に本当に追加tracking改善が必要かは、現在のCPU/GPU preprocessing/transaction semantic問題が閉じた後に再評価する。
2. 追加する場合、Head/Root分離・latency・static jitter・fast motion・dropoutを同一Runtimeで測定する必要がある。
3. Maxine / ARKit等との比較は、必要性が生じた時のみ環境依存を含めて正式benchmarkする。

## NEXT ACTION

Project-wide current priority:
1. v44.55.24 Pair-Bound Shadow Output Snapshotを先に完了する。
2. Production Output Transaction Authority / Reference Transaction Authorityを確定する。
3. Semantic Correctnessが閉じるまでTracking Core変更へ進まない。

Tracking-specific future action:
- 明確なRuntime不足が確認された場合だけ、Face Landmarkerを維持した後段改善を局所A/Bする。

## DO NOT CHANGE

次Evidenceまで変更しない:

- Face Landmarker Primary / Source of Truth
- existing latest-frame policy
- FIFO / stale queue禁止
- persistent ROI
- Head single rigid authority
- Root / Head / Eye / Mouth authority分離
- KiwiFaceMotion.cs / KiwiInferenceFaceTracker.cs をcamera workaroundにしない
- strong smoothing / Kalmanで問題を隠さない
- Native stable Path Bを理由なく変更しない
- Production lane.input direct oracleを再採用しない
- Semantic PASS前にProduction CPU化しない
- working Production Coreを整理目的だけで再設計しない
- commit / pushは明示指示なしに行わない

## MASTER REPORT UPDATE CANDIDATES

Archive Name:
KiwiChat_FaceLandmarkerTrackingComparison_Updated_20260902-JST.zip

LastWorkUpdate:
2026-09-02 (DATE_ONLY)

Validated Decision:
Face Landmarker Primaryを維持。代替trackerへ即置換しない。

Rejected Approach:
Production EvidenceなしのMaxine/他tracker即置換。

Superseded Conclusion:
「Landmarker + 独自後段が必ず最上位」とする断定を、未実測仮説へ格下げ。

Open Issue:
後段tracking改善の必要性は現行semantic/transaction調査完了後に再評価。

Next Action:
v44.55.24 Pair-Bound Shadow Output Snapshot。

MASTER local update status:
NOT_PERFORMED_IN_NORMAL_CHAT

## HANDOFF

次チャットではこのREPORT単体から以下を引き継ぐ:

- Face LandmarkerはKiwi Tracking Primary / Source of Truthのまま。
- このチャットは「代替tracking方式の設計比較」であり、Production実装やRuntime A/Bではない。
- Maxine / ARKit等は比較候補だが、Kiwiでの優位性は未証明。
- Kiwiに適用するなら、既存Tracking Coreを壊さず後段のgeometry/authority/temporal policyを局所改善する方向を優先する。
- ただし現プロジェクト最優先はTracking改善ではなく v44.55.24。
- v44.55.24完了前にTracking/Native/Production CPU化へ横道に進まない。
- local Production / critical SHAはこの通常チャットでは直接確認していない。
