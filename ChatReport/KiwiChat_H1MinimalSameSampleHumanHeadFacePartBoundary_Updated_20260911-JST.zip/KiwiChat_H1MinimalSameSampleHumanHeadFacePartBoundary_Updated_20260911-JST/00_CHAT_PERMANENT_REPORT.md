# KiwiAvatarSystem Chat Permanent Report

ChatTopic: H1MinimalSameSampleHumanHeadFacePartBoundary
ChatTitle: 前回から再開 / H1 Minimal Same-Sample Human-Head FacePart Product Integration 着手
ArchiveName: KiwiChat_H1MinimalSameSampleHumanHeadFacePartBoundary_Updated_20260911-JST.zip
LastWorkUpdate: 2026-09-11
LastWorkUpdatePrecision: DATE_ONLY
ArchiveCreated: 2026-09-11 00:37:07 JST
ArchiveTimestampBasis: LAST_RELEVANT_WORK_BEFORE_ARCHIVE_REQUEST
Project: D:\KiwiAvatarSystem
Unity: 6000.0.80f1
CurrentInvestigationVersion: H1_MINIMAL_SAME_SAMPLE_HUMAN_HEAD_FACEPART_PRODUCT_INTEGRATION
Status: IN_PROGRESS

## EXECUTIVE SUMMARY

このチャットでは、P3D完了後の次作業として
`H1_MINIMAL_SAME_SAMPLE_HUMAN_HEAD_FACEPART_PRODUCT_INTEGRATION`
へ進む方針を再確認し、H1の実装境界を現行Core Rules / Current Roadmap / GitHub実コードと突き合わせる監査に着手した。

今回のチャット内で新しいRuntime PASS、Human Visual PASS、Clean Performance Authority、
local Production SHA確定、コード変更完了、compile/build完了は得られていない。
したがってH1は引き続き未完了であり、Production採用判定は行わない。

P3Dで既に閉じたsame-sample FaceGeometry transaction/lifecycleは再OPENしない。
次に確認すべきfirst goal-relevant boundaryはFacePart consumer側であり、
same-sample first468 + FaceGeometry poseを使ってsource rigid poseのみを除去し、
Eye/Mouthのnon-rigid appearanceをhead-localのexisting fixed fitted surfaceへ提示し、
visible Head poseを1回だけ適用する最小経路である。

## OBJECTIVE

Windows/DX12上でFace LandmarkerをPrimary / Source of Truthとして維持しつつ、
Eye/Blink/Mouth/Expressionの最新same-sample情報を最小latencyでKiwi Avatarへ反映する。

H1の目的は診断Phaseを増やすことではなく、
ROTATION_MATCH / EYE_TWIST / MOUTH_TWISTを最小のProduct統合で閉じ、
Root/Head/Eye/Mouthのauthorityを崩さずHuman Visual Gateへ到達すること。

## CURRENT AUTHORITY

### Confirmed from current project source documents

- Project: `D:\KiwiAvatarSystem`
- Unity: `6000.0.80f1`
- Primary platform: Windows / DX12
- MediaPipeUnityPlugin: `0.16.3`
- Inference Engine: `2.4.1`
- Face Landmarker: Primary / Source of Truth
- Native baseline: Path B SystemMemoryNV12
- LIVE CAMERA presentation baseline: 560x315 / 16:9 / Bilinear
- Latest authoritative P3D report-time snapshot:
  - branch=`work/raw-direct-motion`
  - HEAD=`cd37cbe815ca13343869d11a4b353c057f9ec0e7`
  - report-time=2026-09-10 19:07:22 JST
- P3C_1 callback/destruction lifecycle: RETAIN_PASS
- P3D FaceGeometry correctness/lifecycle Runtime: PASS_WITH_SCOPE_LIMITS
- P3D observer run is not Clean Performance Authority
- H1: NOT_RUN / PASS_NOT_CLAIMED
- Human Visual: NOT_RUN
- Final Production Acceptance: NOT_CLAIMED

### Normal-chat live authority

`NORMAL_CHAT_LIVE_LOCAL_PRODUCTION_NOT_DIRECTLY_VERIFIED`

このチャットではcurrent local HEAD/status/worktree/Production sourceを直接確認していない。
GitHub/report-time SHAをcurrent live Production Authorityへ昇格しない。

## CONFIRMED FACTS

1. Current RoadmapのNEXT_SINGLE_ACTIONは
   `H1_MINIMAL_SAME_SAMPLE_HUMAN_HEAD_FACEPART_PRODUCT_INTEGRATION`。

2. P3Dではsame-sample FaceGeometry transaction/lifecycleが対象scope内で成立済み。
   P3C_1/P3Dは新Evidenceで破れない限り再OPENしない。

3. H1 targetは次の最小経路:
   `same-sample first468`
   → `FaceGeometry metric pose`
   → `source rigid appearance de-rigidization`
   → `head-local Eye/Mouth non-rigid appearance`
   → `existing fitted fixed surface`
   → `visible Kiwi Head pose exactly once`

4. H1へCamera/Native/backend最適化、Root math変更、
   second inference、custom FaceGeometry solver、FIFO/history、
   strong smoothing/Kalman、stale predictionを混ぜない。

5. このチャットではH1のコード変更、Unity compile、Runtime、
   same-build Human Visualは未完了。

## STATIC / SOURCE STATUS

- 現行Core Rules / Current Roadmapに基づくH1 entry条件と責務分離を確認。
- GitHub実コードとの突合監査へ着手したが、このチャット内で
  method/resource/consumer boundaryの完全なsource closureまでは到達していない。
- local Production sourceは通常チャットから直接確認していないため、
  implementation currentnessはUNKNOWN。

## RUNTIME STATUS

新規Runtime実行なし。

P3D以前のscope付きPASSを保持するが、
H1 Product behavior、Eye/Blink/Mouth/Expression提示、
Root non-movement、Human Visualはこのチャットでは未検証。

## PERFORMANCE STATUS

新規Clean Performance benchmarkなし。

`PERFORMANCE_AUTHORITY=NONE_FOR_THIS_CHAT`

P3D observer-heavy evidenceをH1 latency/performance authorityとして使用しない。

## VISUAL STATUS

新規same-build Human Visualなし。

未閉鎖:
- ROTATION_MATCH
- EYE_TWIST
- MOUTH_TWIST
- Eye/Blink/Mouth/Expressionの自然な提示
- Root non-movement確認

MOUTH_SIZE / SURFACE_CLIPはCONDITIONAL_UNPROVEN。
H1 same-build Product Gateで再現した場合のみOPENする。

## PUBLIC / DURABLE DESIGN PRINCIPLES

- Face LandmarkerはPrimary / Source of Truth。
- Headはsingle rigid authority。
- Root / Head / Eye / Mouthを分離する。
- Yaw/Pitch/Roll/Blink/Mouth/EyeをRoot translationへ混入させない。
- source appearance referenceとvisible Head authorityを分ける。
- Eye/Mouthのnon-rigid appearanceを残し、source rigid poseだけ除去する。
- visible Head poseは1回だけ適用する。
- latest-frame / bounded / nonblockingを維持する。
- FIFO、stale queue、permanent buffer、stale prediction、strong smoothing/Kalmanを導入しない。
- Working CoreをEvidenceなしに再設計しない。
- Camera/Inference問題をtracking mathで隠さない。

## INFERENCES

- P3Dによって旧H1 NO_GOの主要前提不足
  「high-rate IE sampleにsame-sample FaceGeometry poseがない」
  は解消したため、H1は再試行可能なauthorization candidateである。
- ただしH1 consumer側のsource path/owner/presentation実装が
  current localでどう構成されているかは、このチャットでは未閉鎖。
- よって最小source auditなしに実装へ飛ぶのは不適切。

## UNKNOWN

- current local branch / HEAD / dirty status
- current local Production source exact contents
- GitHub snapshotとlocal Productionの一致
- H1 consumer側のexact method/dataflow/lifetime
- H1実装後のcompile correctness
- H1 same-build Runtime correctness
- H1 Human Visual結果
- H1 clean latency/resource cost
- MOUTH_SIZE / SURFACE_CLIPの再現有無

## REJECTED / SUPERSEDED

再昇格しない:
- 旧H1 candidateのNO_GO状態を、そのまま現在のH1不可判定として扱うこと
  （P3Dにより前提条件が変化）
- MediaPipe-only H1
- stale MediaPipe poseをnewer IE sampleへ適用
- custom FaceGeometry solver
- duplicate Face Landmarker inference
- geometry FIFO / Queue<T>
- second admission owner
- main-thread blocking poller
- strong smoothing / Kalman / stale prediction
- speculative Fence / Wait / queue flush / async disable
- Big-Bang rewrite
- external tracker Primary
- neural face replacement Primary

## OBSERVER / VALIDATOR / BENCHMARK FINDINGS

- P3D observer instrumentationはCorrectness/Lifecycle scope用であり、
  Clean Performance Authorityではない。
- Validator/observer PASSでHuman Visualを上書きしない。
- このチャットでは新しいvalidator/benchmarkを実行していない。

## FILES / SHA / PROVENANCE

Authoritative report-time snapshot carried forward:
- branch: `work/raw-direct-motion`
- HEAD: `cd37cbe815ca13343869d11a4b353c057f9ec0e7`
- timestamp: `2026-09-10 19:07:22 JST`
- scope: P3D report-time only

Current live local SHA:
`NOT_DIRECTLY_VERIFIED_IN_NORMAL_CHAT`

SHA推測なし。

## WORK PERFORMED IN THIS CHAT

1. 前回作業からH1へ継続する方針を採用。
2. H1の実装境界をCore Rules / Current Roadmap基準で再確認。
3. P3D transaction/lifecycleを再OPENせず、
   FacePart consumer側だけをfirst goal-relevant boundaryとして扱う方針を固定。
4. GitHub実コードとのsource comparisonへ着手。
5. Archive依頼時点ではsource closure / implementation / validationには未到達。

## CURRENT RESULT

`IN_PROGRESS`

H1へ進む方向自体はGoal-Aligned。
ただし、このチャットでH1 PASSやProduction変更完了を主張できるEvidenceはない。

## OPEN ISSUES

最優先は1つだけ:

H1 FacePart consumer pathのcurrent sourceを、
P3D same-sample geometry producerと接続するmethod/dataflow/owner単位で閉じる。

この時点で別のCamera/Native/backend/Performance Phaseを開始しない。

## NEXT ACTION

`H1_MINIMAL_SAME_SAMPLE_HUMAN_HEAD_FACEPART_PRODUCT_INTEGRATION`

実行順:
1. Codex/local preflightでcurrent live identityを確定。
2. P3D same-sample geometry producerとFacePart consumerのexact source pathを監査。
3. first proven boundaryだけ最小変更。
4. exact Unity compile。
5. targeted same-build Runtime identity/transaction/lifecycle。
6. same-build Human Visual:
   neutral / yaw / pitch / roll / combined +
   Eye / Blink / Mouth / Expression + Root non-movement。
7. FULL_AUDIT_1 + independent FULL_AUDIT_2。

## DO NOT CHANGE

新Evidenceなしに以下を変更しない:
- Face Landmarker Primary authority
- P3Dで閉じたsame-sample transaction/lifecycle
- Native Path B SystemMemoryNV12 baseline
- LIVE CAMERA 560x315 / 16:9 / Bilinear accepted baseline
- Camera cadence workaroundとしてのKiwiFaceMotion.cs / KiwiInferenceFaceTracker.cs
- Root/Head/Eye/Mouth authority separation
- visible Head single rigid authority

## HANDOFF

次チャットは本REPORTを基準に、
H1 FacePart consumer source boundaryの監査から再開する。

重要:
- P3C_1/P3Dを再実行しない。
- local ProductionはまずPreflightで確認する。
- report-time/GitHub SHAをlocal liveへ自動昇格しない。
- Human Visualをvalidator PASSで代替しない。
- MOUTH_SIZE/SURFACE_CLIPは再現前にOPENしない。
- H1以外の無関係な最適化を混ぜない。

## ARCHIVE SELF-AUDIT

- REPORT依頼日時をArchive名へ使用していない: PASS
- LastWorkUpdate時刻を推測していない: PASS (`DATE_ONLY`)
- current local Productionを直接確認済みと誤記していない: PASS
- report-time SHAをcurrent live SHAへ昇格していない: PASS
- Correctness / Performance / Visualを分離: PASS
- P3D observer runをPerformance Authorityにしていない: PASS
- H1未実行をPASS扱いしていない: PASS
- Superseded旧H1 NO_GOを無条件でcurrent扱いしていない: PASS
- SHA推測なし: PASS
