# KiwiAvatarSystem Chat Permanent Report

## METADATA

ChatTopic: Unity Project Intake and Permanent Archive Workflow  
ChatTitle: Unityプロジェクト一式からの構築可否確認 / 恒久REPORT・Archive運用確定  
ArchiveName: KiwiChat_UnityProjectIntakeAndArchiveWorkflow_Updated_20260902-JST.zip  
LastWorkUpdate: 2026-09-02  
LastWorkUpdatePrecision: DATE_ONLY  
ArchiveCreated: 2026-09-02  
ArchiveTimestampBasis: LAST_RELEVANT_WORK_BEFORE_ARCHIVE_REQUEST  
Project: D:\KiwiAvatarSystem  
Unity: 6000.0.80f1 / Windows / DX12  
CurrentInvestigationVersion: v44.55.23 authority result provisional; next planned v44.55.24  
Status: DONE  

ArchiveIndex:
- Archive: KiwiChat_UnityProjectIntakeAndArchiveWorkflow_Updated_20260902-JST.zip
- Topic: Unity Project Intake and Permanent Archive Workflow
- LastWorkUpdate: 2026-09-02
- Status: DONE
- Supersedes: NONE
- SupersededBy: NONE
- NextArchiveCandidate: v44.55.24 Pair-Bound Shadow Output Snapshot or the next substantial Unity project implementation/audit chat

Source status:
- LOCAL_PRODUCTION_NOT_DIRECTLY_VERIFIED
- SOURCE=PROJECT_CHAT_CONTEXT
- SOURCE=UPLOADED_REPORT
- SOURCE=FILE_LIBRARY_REFERENCE
- SOURCE=GITHUB_REFERENCE

## EXECUTIVE SUMMARY

This chat established two things.

1. A complete Unity project can be used as the basis for future KiwiAvatarSystem reconstruction, repair, audit, or completion work. The practical project intake baseline is `Assets/`, `Packages/`, and `ProjectSettings/`; large generated directories such as `Library/`, `Temp/`, `Logs/`, and `obj/` are not required for normal source-level reconstruction unless a later investigation specifically needs them.

2. The KiwiAvatarSystem permanent chat archive workflow was adopted as a standard operating rule. Important chats are archived as one topic → one permanent archive, with one ZIP as the primary deliverable. Archive timestamps must represent the last relevant work before the archive request, not the report-creation time. When exact time is not known, `DATE_ONLY` is required rather than guessing.

No Unity project files were modified in this chat. No compile, build, Runtime, ABI, SHA, Native DLL, Tracking, Inference, or Production validation was performed here.

The project-wide current technical state recorded in the uploaded authority documents remains:
- Tracking Core: stable baseline
- Native Camera: Path B SystemMemoryNV12 baseline
- LIVE CAMERA: CLOSED / Production Accepted
- CPU/GPU backend: backend itself not the primary semantic cause on identical tensor input
- Main unresolved area: preprocessing / transaction semantic authority
- Latest confirmed investigation state: v44.55.23 Observer Validity PASS, 115/115 completed
- `MIXED_TRANSACTION`: provisional only
- Next priority: v44.55.24 Pair-Bound Shadow Output Snapshot

## CHAT OBJECTIVE

Primary objectives:
- Confirm whether a usable KiwiAvatarSystem Unity project can be reconstructed/worked on from a complete Unity project package.
- Define how future Unity project files should be supplied without unnecessary generated directories.
- Adopt a permanent-report/archive workflow that preserves important chat decisions, authority, evidence classification, superseded conclusions, open issues, and next actions.
- Create the actual permanent archive for this chat.

## CONFIRMED FACTS

### Confirmed in this chat

- The user requested confirmation that work can proceed from a Unity project set.
- The accepted project intake baseline is `Assets/`, `Packages/`, and `ProjectSettings/`.
- Generated directories such as `Library/`, `Temp/`, `Logs/`, and `obj/` are not part of the minimum project intake baseline for ordinary source reconstruction.
- The user supplied and adopted a detailed KiwiAvatarSystem permanent-report/archive workflow.
- The workflow requires actual ZIP generation when the user requests a permanent archive.
- The workflow requires one primary ZIP deliverable.
- Archive naming must use the last relevant work timestamp before the archive request, not the archive-creation timestamp.
- Exact time is not reliably established for the last relevant technical/workflow decision in this chat, therefore this archive uses `20260902` DATE_ONLY.
- Local Production `D:\KiwiAvatarSystem` was not directly inspected in this normal chat.
- No SHA256 for local Production files was calculated in this chat.
- No project code, Scene, Prefab, Native DLL, package, validator, or installer was changed in this chat.
- No Runtime evidence was generated or analyzed in this chat.

### Confirmed project-state snapshot from uploaded authority material

The uploaded current project summary records:
- Project: `D:\KiwiAvatarSystem`
- Unity: `6000.0.80f1`
- Windows / DX12
- MediaPipeUnityPlugin: `v0.16.3`
- Unity Inference Engine: `2.4.1`
- Face Landmarker remains Primary / Source of Truth.
- Native Camera Production baseline is Path B SystemMemoryNV12.
- LIVE CAMERA is recorded as CLOSED / PRODUCTION ACCEPTED with 560x315 presentation sizing.
- v44.55.23 completed 115/115 with Observer Validity PASS.
- v44.55.23 `MIXED_TRANSACTION` is explicitly provisional because Worker output lifecycle reuse/race is not yet fully excluded.
- v44.55.24 Pair-Bound Shadow Output Snapshot is the next required investigation step.
- Semantic correctness must be established before any Production CPU-backend adoption.
- Production lane.input direct oracle is rejected and must not be reintroduced as authority.

## PUBLIC DESIGN PRINCIPLES

No new external web research was performed in this chat.

The currently adopted public/source-derived design principles carried into this archive are:

- Prefer the actual local Production + SHA over GitHub main when they differ.
- Prefer actual package source for the exact package version in use over generic documentation when implementation details matter.
- Treat generated Unity directories as reconstructable artifacts unless a specific provenance/build investigation requires them.
- Keep source-of-truth identity, timestamps, generations, lifecycle, and transaction boundaries explicit.
- Separate Correctness, Performance, Visual, and Provenance evidence.
- Do not interpret a correctness-observer run containing readbacks/dumps/heavy diagnostics as Production performance authority.
- Do not infer private internals of commercial tracking applications from their external behavior.
- Preserve working Production code unless independent evidence justifies modification.

## INFERENCES / HYPOTHESES

- A future full Unity-project ZIP containing the minimum source directories should be sufficient for broad managed-code, scene, package, Prefab, and project-settings audit, but some local-only provenance questions may still require Codex/local-repo verification.
- If Native DLL provenance, exact Production hashes, build definitions, or local Git state become relevant, normal-chat reconstruction alone may be insufficient; those items should be treated as local-verification tasks.
- No claim is made in this archive that the current GitHub main equals current local Production.

## PRODUCTION AUTHORITY

Authority order adopted for KiwiAvatarSystem:

1. Current local Production actual files + SHA
2. Latest Runtime evidence from the same Production
3. Actual package source in use
4. Latest KiwiValidation / Consolidated REPORT
5. Official documentation / official source
6. Local Git history
7. GitHub main
8. Older versions / diagnostics
9. Issues / discussions
10. Technical articles
11. Reddit / X / YouTube and other user reports

Authority used in this chat:
- Uploaded `KiwiAvatarSystem-情報源・Authority一覧.txt`
- Uploaded `KiwiAvatarSystem-統合最新版カスタム指示-情報源-作業履歴-今後計画-更新基準-2026-09-02.txt`
- Uploaded permanent-report/archive instructions
- GitHub repository reference file

Local Production status:
`LOCAL_PRODUCTION_NOT_DIRECTLY_VERIFIED`

## WORK PERFORMED

### 1. Unity project intake feasibility decision
Purpose:
Determine whether future KiwiAvatarSystem work can proceed from the Unity project as a whole.

Result:
PASS as a workflow decision.

Decision impact:
Use the Unity project source set as the primary input rather than requesting many individual scripts by default.

### 2. Minimum project intake definition
Purpose:
Reduce upload size and unnecessary generated data.

Result:
Minimum baseline set to:
- `Assets/`
- `Packages/`
- `ProjectSettings/`

Generated folders are not required by default:
- `Library/`
- `Temp/`
- `Logs/`
- `obj/`

Decision impact:
Future project transfer can remain smaller and easier to audit.

### 3. Permanent archive workflow adoption
Purpose:
Ensure important decisions and evidence remain reconstructable even when full chat history is unavailable.

Result:
PASS.

Adopted:
- one important chat / one major work theme → one permanent archive
- one ZIP as primary deliverable
- DATE_TIME only when exact last-work time is verifiable
- otherwise DATE_ONLY
- Confirmed Facts / Public Design Principles / Inferences separated
- Validated / Rejected / Superseded retained
- Observer/Validator defects recorded
- Correctness / Performance / Visual / Provenance separated
- local-unverified state explicitly marked
- SHA never guessed

### 4. Project current-state reconciliation from uploaded authority summary
Purpose:
Avoid accidentally treating obsolete Native/LIVE CAMERA/CPU conclusions as current.

Result:
PASS at document-review level only.

Current documented successor state:
- old Native 13–20 Hz conclusion: obsolete
- D3D11On12 1080p camera Production: rejected
- LIVE CAMERA Runtime Pending: obsolete; now accepted
- immediate CPU Production adoption: rejected
- Production lane.input direct oracle: rejected
- v44.55.23 MIXED_TRANSACTION: provisional, not final

### 5. Permanent ZIP generation for this chat
Purpose:
Satisfy the adopted archive rule with an actual downloadable archive.

Result:
PASS, subject to ZIP integrity validation performed during generation.

## VALIDATED DECISIONS

### Decision 1
Decision:
Use complete Unity project source directories as the normal basis for future KiwiAvatarSystem reconstruction/audit work.

Reason:
Project-wide work involves Scene, Prefab, packages, project settings, scripts, plugins, and inter-file dependencies; isolated script upload is insufficient for many cross-cutting audits.

Evidence:
Current chat workflow decision.

Regression constraints:
Do not assume generated caches are authoritative. Request or inspect them only when a specific provenance/build/runtime issue requires them.

Still current: YES

### Decision 2
Decision:
Minimum normal project-transfer baseline is `Assets/ + Packages/ + ProjectSettings/`.

Reason:
These carry the source assets, dependencies, and project configuration required for ordinary Unity reconstruction.

Evidence:
Current chat workflow decision.

Regression constraints:
Native source, installers, validation tools, or extra project-root files must also be included when the requested task depends on them.

Still current: YES

### Decision 3
Decision:
Adopt the permanent chat archive workflow as standard KiwiAvatarSystem process.

Reason:
It preserves authority, decisions, evidence, superseded conclusions, and next actions across chat boundaries.

Evidence:
User-supplied permanent-report/archive instructions.

Regression constraints:
Never use archive-creation time as LastWorkUpdate unless it is actually also the last relevant work. Never guess SHA or timestamp precision.

Still current: YES

### Decision 4
Decision:
This archive uses DATE_ONLY.

Reason:
Exact last relevant work time cannot be verified without guessing.

Evidence:
Archive timestamp rule.

Regression constraints:
Do not retrofit a guessed HHMM later.

Still current: YES

## REJECTED APPROACHES

### Rejected 1
Rejected:
Requiring the full Unity `Library/` directory by default.

Why considered:
It contains imported and generated project state.

Why rejected:
It is large and normally reconstructable; it is unnecessary for ordinary project source reconstruction.

Evidence:
Current chat project-intake decision.

Revisit condition:
Specific package-cache provenance, deterministic import, generated artifact, or local-only build issue requires it.

### Rejected 2
Rejected:
Using the archive creation/request timestamp in the ZIP filename.

Why considered:
It is easy to obtain.

Why rejected:
It misrepresents how current the archived technical content is.

Evidence:
Permanent archive rules.

Revisit condition:
Never, unless the archive-creation event itself is also the last relevant substantive work and that fact is verifiable.

### Rejected 3
Rejected:
Guessing exact local Production SHA or treating GitHub main as current Production.

Why considered:
Would make the report look more complete.

Why rejected:
Violates Production authority and provenance rules.

Evidence:
Authority document.

Revisit condition:
Only after direct local verification.

## SUPERSEDED CONCLUSIONS

### Superseded 1
OLD:
Native Camera currently operates at roughly 13–20 Hz.

NEW:
Current project summary records Path B SystemMemoryNV12 as the stable Native Camera baseline; the old 13–20 Hz diagnostic conclusion is obsolete.

WHY:
Later investigation superseded earlier v13-v18 diagnostic state.

EVIDENCE:
Uploaded current project summary.

### Superseded 2
OLD:
LIVE CAMERA Runtime validation is pending / Native or Tracking may require modification.

NEW:
LIVE CAMERA is CLOSED / PRODUCTION ACCEPTED with presentation-side 560x315 adjustment, Compile/Runtime/Visual PASS, and no Native/Tracking/Inference modification.

WHY:
Later presentation-specific audit resolved the issue.

EVIDENCE:
Uploaded current project summary.

### Superseded 3
OLD:
mode2 pixel parity or CPU speed could justify direct CPU Production adoption.

NEW:
CPU Production adoption remains prohibited until semantic/transaction authority is resolved.

WHY:
Later canonical and Production authority investigations rejected pixel-parity/performance-only adoption.

EVIDENCE:
v44.55.17 through v44.55.23 authority chain in uploaded summary.

### Superseded 4
OLD:
Production lane.input direct readback can act as the reference oracle.

NEW:
Production lane.input direct oracle is rejected.

WHY:
Observer/readback lifecycle itself can create false differences.

EVIDENCE:
v44.55.22 documented conclusion.

## OBSERVER / VALIDATOR FINDINGS

No Observer or Validator was run in this chat.

Project-level findings preserved from uploaded current-state material:

- v44.55.23 initially treated backing buffer capacity `147456` vs logical tensor size `1405` as invalid.
- Inference Engine 2.4.1 source audit established that backing capacity may exceed logical size.
- Observer was corrected to validate capacity and logical shape separately and snapshot only the first 1405 logical values.
- Corrected v44.55.23 Runtime completed 115/115 with:
  - observerFault = 0
  - snapshot failures = 0
  - identity/shape/nonfinite = 0
  - capturesPending = 0
- `MIXED_TRANSACTION` remains provisional because post-record `PeekOutput()` reacquisition may still be exposed to Worker allocator output reuse.
- Therefore v44.55.24 must bind shadow snapshots to the live pair lifetime.

Performance caution:
v44.55.23 is a correctness-observer investigation and its diagnostic overhead must not be treated as formal Production performance authority.

## FILES / SHA256

### Uploaded/reference files used for this archive

Path/File:
`KiwiAvatarSystem-情報源・Authority一覧.txt`

Role:
Project authority hierarchy, source locations, current CPU/inference investigation chain.

SHA256:
SHA256=NOT_AVAILABLE_IN_NORMAL_CHAT

State:
CURRENT SUPPORTING AUTHORITY DOCUMENT

---

Path/File:
`KiwiAvatarSystem-統合最新版カスタム指示-情報源-作業履歴-今後計画-更新基準-2026-09-02.txt`

Role:
Current integrated project design rules, completed work, obsolete conclusions, open work, current next action.

SHA256:
SHA256=NOT_AVAILABLE_IN_NORMAL_CHAT

State:
CURRENT PROJECT SUMMARY / SUPPORTING AUTHORITY

---

Path/File:
`通常チャット用-恒久REPORT-アーカイブ作成指示.txt`
and/or later direct ZIP creation instruction supplied in this chat.

Role:
Permanent archive/report workflow authority.

SHA256:
SHA256=NOT_AVAILABLE_IN_NORMAL_CHAT

State:
CURRENT WORKFLOW AUTHORITY

---

Path/File:
`Github-リポジトリ.txt`

Role:
GitHub repository reference:
`https://github.com/midori-kiwi/KiwiAvatarSystem/tree/main`

SHA256:
SHA256=NOT_AVAILABLE_IN_NORMAL_CHAT

State:
SUPPORTING_ONLY; NOT LOCAL PRODUCTION AUTHORITY

### Local Production files

No local Production file was directly inspected or hashed in this chat.

Status:
`LOCAL_PRODUCTION_NOT_DIRECTLY_VERIFIED`

## RUNTIME EVIDENCE

No Runtime evidence was newly generated, uploaded, or analyzed as part of this chat's substantive work.

Project-state evidence referenced from uploaded summaries only:

- v44.55.23 corrected Runtime
  - Type: CORRECTNESS
  - Result: 115/115 completed; Observer Validity PASS
  - Performance authority: NO
  - Current: YES for observer validity
  - Domain result: MIXED_TRANSACTION remains PROVISIONAL

- LIVE CAMERA accepted Runtime/Visual result
  - Type: CORRECTNESS / VISUAL
  - Current summary status: CLOSED / PRODUCTION ACCEPTED
  - Evidence files themselves were not re-opened in this chat

- Original Package / Native provenance audit
  - Type: PROVENANCE
  - Current summary says provenance strongly supported
  - Actual local Production DLL/source chain was not re-verified in this chat

## CURRENT RESULT

This chat is complete as a workflow/setup archive.

Established:
- Unity project intake can use a project-wide source package rather than isolated files.
- `Assets/`, `Packages/`, and `ProjectSettings/` are the normal minimum intake set.
- Permanent-report/archive workflow is now the standard for KiwiAvatarSystem important chats.
- Actual ZIP generation is required for archive requests.
- Archive time semantics and DATE_ONLY fallback are fixed.
- Project current-state summary is preserved without changing any Production conclusion.

No code or Production state changed.

## OPEN ISSUES

### READY / next technical investigation

1. v44.55.24 Pair-Bound Shadow Output Snapshot
2. Exclude Worker allocator output lifecycle reuse/race
3. Re-evaluate the previous 3 `ANOMALOUS_NEITHER_EXACT` pairs
4. Finalize Production Output Transaction Authority
5. Finalize Reference Transaction Authority

### VALIDATION_PENDING

- Local Production SHA and actual placement were not re-verified in this normal chat.
- Local Git state and dirty worktree were not verified.
- Actual project ZIP contents have not yet been supplied in this chat.

### DEFERRED UNTIL SEMANTIC PASS

- Production CPU backend candidate
- CPU/GPU formal performance A/B
- lifecycle/recovery acceptance
- final visual frame-by-frame acceptance

## NEXT ACTION

Highest priority technical action:
`v44.55.24 Pair-Bound Shadow Output Snapshot`

Required intent:
Snapshot REF_FROZEN_GPU and MODE2 B_GPU outputs while the same pair is still alive (`_pairPending == true`, `_commonScheduled == true`) into observer-owned GPU buffers, with fixed pair identity, before Worker output storage can be reused.

Do not proceed to CPU Production conversion, Native changes, Tracking changes, or lower-level pixel-center/FMA investigation before this authority question is closed.

For the separate Unity-project intake path:
When project-wide implementation/audit is requested, provide a project archive centered on `Assets/`, `Packages/`, and `ProjectSettings/`, plus project-root Native/Tools/Installer/KiwiValidation content when relevant to the requested task.

## DO NOT CHANGE

Without new independent evidence, do not:

- Replace Face Landmarker as Primary / Source of Truth
- Modify `KiwiFaceMotion.cs` as a camera/display cadence workaround
- Modify `KiwiInferenceFaceTracker.cs` as a camera/display cadence workaround
- Relax tracking thresholds without Runtime evidence
- Introduce strong smoothing or Kalman filtering to hide upstream defects
- Reintroduce FIFO or stale queues
- Reintroduce blocking GPU waits
- Reintroduce `UpdateExternalTexture`
- Reintroduce Unity D3D12 queue waits
- Reintroduce rotating Unity-visible texture identity
- Reintroduce Production lane.input direct oracle
- Rebuild Native DLL from guessed provenance/build definitions
- Move to Production CPU backend before semantic PASS
- Treat correctness-observer performance as formal Production performance
- Redesign working Production Core without evidence
- Commit or push unless explicitly instructed

## HANDOFF

A future chat can continue from this archive as follows:

1. Treat `D:\KiwiAvatarSystem` local Production + exact SHA as highest authority when directly available.
2. Treat GitHub main only as history/reference unless parity with local Production is proven.
3. Preserve the stable Tracking and Native baselines.
4. Preserve LIVE CAMERA as CLOSED / PRODUCTION ACCEPTED unless new evidence shows regression.
5. Keep v44.55.23 result split:
   - Observer validity: CONFIRMED PASS
   - 115/115 completion: CONFIRMED
   - MIXED_TRANSACTION: PROVISIONAL
6. The reason v44.55.23 is provisional is not backend performance; it is potential Worker output lifecycle reuse around post-record `PeekOutput()` reacquisition.
7. Execute v44.55.24 before lower-priority semantic or performance work.
8. Keep Correctness, Performance, Visual, and Provenance evidence separate.
9. Never guess SHA, timestamp precision, or local Production state.
10. For future project-wide work, prefer one complete Unity project archive instead of repeated isolated-file uploads.

## MASTER REPORT UPDATE CANDIDATES

The local `KIWI_PROJECT_MASTER_REPORT.md` was not directly updated in this chat.

Items to reflect later when local MASTER is available:

- New Validated Decision:
  Unity project intake baseline = `Assets/ + Packages/ + ProjectSettings/`.
- New Validated Decision:
  Permanent chat archive workflow is standard.
- Open Issue:
  v44.55.24 remains next technical authority investigation.
- Current Next Action:
  Pair-Bound Shadow Output Snapshot.
- Chat Archive:
  `KiwiChat_UnityProjectIntakeAndArchiveWorkflow_Updated_20260902-JST.zip`
- LastWorkUpdate:
  `2026-09-02 / DATE_ONLY`
