# KiwiAvatarSystem Chat Permanent Report

ChatTopic: Commercial Face-Part Architecture / Commercial Control Plane / Full Code Audit
ChatTitle: 商用システム比較から3D Model Primary + 2D Face-Part Constraintを詰め、v4.1〜v4.5累積実装と全コード重複・潜在バグ監査を実施したチャット
ArchiveName: KiwiChat_CommercialFacePartArchitectureAndCodeAudit_Updated_20260902-JST.zip
LastWorkUpdate: 2026-09-02
LastWorkUpdatePrecision: DATE_ONLY
ArchiveCreated: 2026-09-02T23:32:00+09:00
ArchiveTimestampBasis: LAST_RELEVANT_WORK_BEFORE_ARCHIVE_REQUEST
Project: D:\KiwiAvatarSystem
Unity: 6000.0.80f1
CurrentInvestigationVersion: v4.6 completion audit (NOT YET PACKAGED / VALIDATION PENDING)
Status: IN_PROGRESS

---

## EXECUTIVE SUMMARY

このチャットでは、KiwiAvatarSystemの「実写Eye/Mouthを3D Avatarへ貼る」方式を、VTuber・SNS Face Filter・商用Facial Mocapの公開設計を比較しながら段階的に強化した。

主な到達点:

1. 最終構成を `3D Model Primary + 2D Semantic Tracking + LIVE Camera Local Tracker + Adaptive Overscan + Tight Mask + Surface Constraint + Anatomical Guard` とした。
2. `v4.1 Live-Frame Coherent Face Parts`で、Semantic Trackingの間を最新Camera frameのGPU local trackerで補う方式を導入。
3. `v4.2 Anatomical Constraint Fusion`で、傾き時の片目だけの大ズレとEye/Mouth overlapに対して、bilateral eye rigid/similarity solve、single-eye fallback、mouth-to-eye-pair topology、final rendered anatomy guardを導入。
4. `v4.3 Commercial Runtime Hardening`でexecution order、AsyncGPUReadback callback phase separation、2-slot bounded mailbox、per-request teardown wait、adaptive GPU search cost、anatomy override ownership、F9 diagnostic GC低減を整理。
5. `v4.4 Commercial Control Plane`でpersistent user profile、Responsive/Balanced/Stable、Auto/Quality/Balanced/Realtime、Faceware-style Pathfinder、Single Writer化を導入。
6. `v4.5 On-Screen Panel Controls`でF8/F9 shortcut dependencyを廃止し、画面上のSetup/Telemetry ON/OFFへ変更。
7. 最後に累積版とGitHub mainを横断監査し、旧世代コードとの二重Owner/潜在バグを発見。
8. v4.6完成版の作成に着手したが、恒久REPORT依頼時点では最終ZIP生成・最終静的Validationまで未完了。

現時点で最重要なのは「新機能追加」ではなく、v4.6で旧世代Ownerとself-modifying Editor installerを整理し、single-writer / deterministic lifecycleを閉じること。

## OBJECTIVE

- 実写Eye/Mouthを3D Modelへ自然に貼り付ける最終方式を決める。
- 傾き・高速移動・Blink/Mouth動作時のFacePartズレを商用品質へ近づける。
- Eye/Mouthの相互干渉、片目だけの大ズレ、Mask overlapを防ぐ。
- 商用ソフトの高評価機能・設計思想を、Kiwiの既存Tracking Coreを壊さず取り込む。
- 累積実装後に全コードを再監査し、重複処理・複数Owner・潜在Lifecycle bugを除去する。

## CONFIRMED FACTS

### GitHub main

Repository: https://github.com/midori-kiwi/KiwiAvatarSystem/tree/main

このチャット終盤で再確認したGitHub main:
- Commit SHA: `6b4d2448e3446a3b026165fb87617cdd0253e532`
- Commit message: `Fixed`
- Commit date: `2026-08-20T13:37:20Z`

注意:
- GitHub mainはlocal Productionより古い可能性がある。
- この通常チャットから `D:\KiwiAvatarSystem` の実配置・最終SHAは直接確認していない。
- Production authority: `LOCAL_PRODUCTION_NOT_DIRECTLY_VERIFIED`。

### Main sourceで確認した重複候補

1. `KiwiFacePartRigidCenterLock.cs`
   - Roll時にmouth側へ独自position correctionを行う旧Owner。
   - v4.2以降のEye-pair rigid + Mouth topologyと役割が重複し得る。
2. `MouthCropGuard.cs`
   - 条件次第で `mouthImage.uvRect` を最終的に書き換える。
   - v4.1以降の `FacePartCropper + LiveMotionBridge` とwrite-target競合し得る。
3. `FacePartAngleLock.cs`
   - 独立して `_SampleRotationRad` / pivotを制御。
   - `KiwiFacePartSharedTiltLock` とrotation ownerが競合し得る。
4. Presentation FPS
   - `FacePartCropper` / `KiwiStandaloneRuntime` / `KiwiTrackingQuality10Controller` / `KiwiPlatformRuntime` に責務が分散していた履歴がある。
   - MobileではPlatformRuntimeの60fps意図をQuality10が120fpsへ戻せる潜在競合を監査対象とした。
5. `KiwiInferenceRecoveryBootstrap` と `KiwiMatureVTuberSupervisor`
   - `sentisMediaPipeRefreshRateHz`
   - Inference presence threshold
   について複数Writerになり得る箇所をv4.4で整理。

### Current face-part rendering behavior from main source

`KiwiFacePartQualityCoordinator` main sourceではsurface-facing guard、depth-ratio far-eye guard、yaw fallback、CanvasRenderer alpha final gate、material `_PoseVisibility`、mouth visible size capを持つ。

### Old Editor migration code

GitHub mainには旧世代のself-modifying installerが存在することを確認:
- `KiwiAsyncInferenceMailboxInstaller.cs`
- `KiwiInferenceAdoptionInstaller.cs`
- `KiwiInferenceBackendHysteresisInstaller.cs`
- `KiwiPrecisionTrackingInstaller.cs`
- その他累積migration

Runner側に既に対応機能が統合済みのものについては、source rewrite継続理由が薄く、v4.6ではvalidation-only化またはobsolete化候補。

## PUBLIC DESIGN PRINCIPLES

### VTube Studio
- tracking cadenceとapplication/render cadenceを分離
- neutral calibration
- user-facing sensitivity/range tuning
- side-view時のEye continuity
- per-channel behavior

### Warudo
- Head / Body / BlendShapeの責務分離
- Input range / Output range / Sensitivityを明示
- configurable tracking-to-avatar mapping
- quality/performance profile

### Faceware Studio
- actor-specific tuning
- neutral calibration
- control単位のAnimation Tuning
- Pathfinder型setup/health feedback
- realtime optimization mode

### AccuFACE
- BlinkがHeadを動かす、Eye movementがMouthを動かす等のTracking Interferenceを部位別に抑制。
- KiwiではEye/Mouth local correctionをRoot/Headへ逆流させず、MouthはEye-pair rigid motionをparentとする。

### MetaHuman Animator
- Head Orientation / Translation / Stabilizationを独立
- neutral reference
- rigid head authorityとFacePart local animationを混ぜない

### TikTok Effect House / Snapchat Lens Studio
- Eyes / Mouth等を独立semantic region/channelとして扱う
- surface attachment
- feature-specific visibility / occlusion
- geometryとexpressionを分離

### DeepAR
- Eye/Lip等の高精度2D featureをgeneric full-face meshとは別channelとして扱う。
- KiwiではEye-pairとMouthを別local solverとしつつ、face-local topologyで拘束。

## INFERENCES / HYPOTHESES

1. v4.2のbilateral eye rigid solveにより、傾き時の「片目だけ大きく飛ぶ」症状は大幅に減る見込み。
2. Mouth topology + final anatomy guardによりEye/Mouth overlapは減る見込み。
3. v4.3のAsync readback phase separationによりGPU callback timing依存のpresentation raceは減る見込み。
4. v4.4のSingle Writer整理によりpresence threshold / auxiliary cadenceの意図しない上書きは減る見込み。
5. v4.6で旧RigidCenter / MouthCropGuard / AngleLock / FPS ownerを整理すれば累積世代間の二重処理はさらに減る見込み。
6. v4.1〜v4.5累積版は、この通常チャット内でUnity実機compile/runtimeを実行していないため、商用品質達成をConfirmedとはしない。

## PRODUCTION AUTHORITY

Authority order:
1. Local Production + SHA — `LOCAL_PRODUCTION_NOT_DIRECTLY_VERIFIED`
2. Same-Production latest Runtime — このチャットでは新規Runtime Evidenceなし
3. Actual package/source
4. KiwiValidation / Consolidated Report
5. Official docs/source
6. GitHub main
7. Past generated overlays
8. Commercial public design information

生成overlayを次版のProduction authorityとは扱わない。次実装時は必ずlocal Production / current GitHub main / latest Runtimeを再確認する。

## WORK PERFORMED

### 1. 商用システム追加調査
対象: VTube Studio / Warudo / Animaze / Faceware / MetaHuman / AccuFACE / TikTok Effect House / Snapchat Lens Studio / DeepAR等。
結果: 3D Model Primary、2D semantic/local feature channels、neutral calibration、per-channel response、interference reduction、final occlusion/anatomy guardをKiwiへ適用可能と判断。
Status: PASS / DESIGN INPUT

### 2. v4.1 Live-Frame Coherent Face Parts
- `KiwiFacePartLiveMotionBridge.cs`
- small-patch GPU block matching
- 2-slot bounded AsyncGPUReadback
- latest result only
- adaptive overscan
- no Root/Head feedback
- per-frame temporary array削除
- in-flight grid/radius pinning
- callback allocation削減
- teardown lifetime整理
Static review: 57/57 PASS と報告。
Runtime: NOT VERIFIED IN THIS CHAT.

### 3. v4.2 Anatomical Constraint Fusion
- bilateral Eye pair similarity solve
- bounded translation/rotation/scale
- single-eye low-confidence fallback
- tilt時local residual tightening
- MouthをEye-pair rigid parentへ従属
- minimum mouth-eye-line separation
- minimum mouth-eye center distance
- final rendered anatomy guard
- fitted-surface one-eye asymmetry guard
Static review: 68/68 PASS と報告。
Runtime: NOT VERIFIED IN THIS CHAT.

### 4. v4.3 Commercial Runtime Hardening
- execution order整理
- AsyncGPUReadback callbackで直接presentation stateを変更しない
- callback result → mailbox → LateUpdate採用
- old completion discard
- global `WaitAllRequests()`廃止
- per-request teardown wait
- adaptive local tracker search cost
- Anatomy Guardをsafety override化
- F9 text build cached StringBuilder化
Static review: 82/82 PASS と報告。
Runtime: NOT VERIFIED IN THIS CHAT.

### 5. v4.4 Commercial Control Plane
新規:
- `KiwiCommercialProfileController`
- `KiwiCommercialQualityGovernor`
- `KiwiCommercialPathfinder`
- `KiwiCommercialSetupPanel`

Profile: Move X/Y、Position X/Y、Pitch/Yaw/Roll gain/max、Eye/Mouth/Contour response、Responsive/Balanced/Stable。
Quality: Auto/Quality/Balanced/Realtime。調整対象はlive 2D resolution、patch stride、resting search radius、auxiliary MediaPipe cadence。Render FPS自体は下げない。
Ownership fix: runtime auxiliary MediaPipe cadence ownerをSupervisorへ、Inference adaptive presence thresholdとfixed threshold競合を整理。
Static validation: 128/128 PASS と報告。
Runtime: NOT VERIFIED IN THIS CHAT.

### 6. v4.5 On-Screen Panel Controls
- F8/F9 runtime shortcut削除
- top-center compact dock: Setup / Telemetry ON/OFF
- visibility persistence
- fresh install: Setup OFF / Telemetry OFF / Dock ON
- public visibility API
Static validation: 57/57 PASS と報告。
Runtime: NOT VERIFIED IN THIS CHAT.

### 7. 全コード重複・潜在バグ監査
発見:
- Legacy RigidCenter vs v4.2 mouth rigid/topology
- MouthCropGuard vs Cropper/LiveMotionBridge
- FacePartAngleLock vs SharedTiltLock
- multiple FPS writers
- Mobile FPS owner conflict
- repeated reflection
- stale async mailbox across disable/re-enable
- model hot-swap stale mask references
- empty-mask repeated scene search
- hidden far-eye still participating in final collision
- Anatomy override state potentially surviving disable
- old self-modifying Editor installers

Status: IN_PROGRESS / v4.6 FINAL PACKAGE NOT YET GENERATED

## VALIDATED DECISIONS

### Decision: 3D Model Primaryを維持
Reason: Head/Avatar rigid transformは3D model authorityであるべきで、Eye/Mouth 2D residualをRootへ逆流させるとauthority汚染になる。
Regression constraints: Eye/Mouth local correction must never write Root/Head pose。Tracking Coreへmodel-specific処理を逆流させない。
Still current: YES

### Decision: Eye pairはindependent translationではなくbounded similarity solve
Reason: 実際のRollでは左右Eyeが反対方向へ動くためhard shared translationでは実 motionを壊す。一方完全独立では片目だけ飛ぶ。
Still current: YES

### Decision: Mouth local trackingはEye-pair rigid face frameをparentにする
Reason: Mouth trackerの誤認でEye領域へ飛ぶことを抑える。
Still current: YES

### Decision: Source CropとSemantic Maskを分離
Reason: Tracking uncertaintyにはoverscanが必要だが表示領域まで広げると見た目が悪化する。
Still current: YES

### Decision: Async callbackはpresentation stateを直接変更しない
Reason: completion phaseによるraceを避けLateUpdateでdeterministic採用する。
Still current: YES

### Decision: Single Writerを優先
対象: presence threshold、auxiliary MediaPipe cadence、FPS、uvRect、sample rotation、surface offset、mouth visible scale。
Still current: YES

### Decision: Shortcutではなくon-screen UI
Reason: ユーザー要求 + commercial app UX。
Still current: YES

## REJECTED APPROACHES

### Rejected: 目を完全に同じtranslationで動かす
Why rejected: 本当のRollで左右Eyeが逆方向へ動くためrigid geometryを破壊する。
Revisit condition: なし。similarity solveを使う。

### Rejected: Mouthを完全独立local trackerにする
Why rejected: Eye領域への誤match、Face topology破綻。
Revisit condition: 高信頼な専用lip trackerが別authorityとして導入される場合のみ。

### Rejected: 全体へstrong smoothing / Kalmanを追加
Why rejected: 正常時latencyと高速追従を犠牲にし上流問題を隠す。

### Rejected: permanent frame buffer / prefetch
Why rejected: near-live webcam face pathではlatency増大。

### Rejected: Quality GovernorがApplication.targetFrameRateを下げる
Why rejected: tracking resource adaptationとpresentation cadence ownershipを混ぜる。

### Rejected: old `Production lane.input direct oracle`
プロジェクト全体で既にREJECT済み。このチャットでも再採用していない。

## SUPERSEDED CONCLUSIONS

OLD: v4.1ではLeft/Right Eye/Mouth local trackerを基本的に独立扱い。
NEW: v4.2ではEye pair rigid solve + Mouth topologyへ変更。
WHY: 完全独立は傾き時のsingle-eye runawayとmouth-eye overlapを許すため。

OLD: F8/F9 keyboard shortcutでSetup/Telemetryを切替。
NEW: v4.5ではon-screen dockで切替。
WHY: ユーザー要求 + commercial app UXとしてkeyboard dependencyを除去。

OLD: 生成累積overlayを次版のsource-of-truthとして積み上げればよい。
NEW: 次版作業前にはcurrent GitHub main / local Production / latest Runtimeを再確認する。
WHY: generated overlayはlocal Production authorityではなく世代間重複を持ち得るため。

## OBSERVER / VALIDATOR FINDINGS

v4.1〜v4.5の「Static review xx/xx PASS」はlexical structure、required token/invariant、duplicate class、banned API、ZIP integrity等を確認する補助Validator。

これは以下を意味しない:
- Unity compile PASS
- Runtime correctness PASS
- Performance PASS
- Visual PASS

Evidence class: STATIC_ONLY

Observer/Validator自体も完全authorityではない。v4.6ではcompile、scene/runtime、write-target ownership、lifecycle、hot-swapを実測で閉じる必要がある。

## FILES / SHA256

### GitHub main authority
Commit: `6b4d2448e3446a3b026165fb87617cdd0253e532`
Role: GitHub source reference
Current/Obsolete: CURRENT_GITHUB_MAIN_AT_CHAT_END
Local Production: NOT DIRECTLY VERIFIED

### Important main files reviewed

Path: `Assets/Script/FaceLandmarkerRunner.cs`
Role: Face Landmarker primary / hybrid inference runner
SHA256: NOT_AVAILABLE_IN_NORMAL_CHAT
Current/Obsolete: CURRENT GITHUB MAIN SOURCE

Path: `Assets/Script/FacePartCropper.cs`
Role: Eye/Mouth crop owner candidate
SHA256: NOT_AVAILABLE_IN_NORMAL_CHAT
Current/Obsolete: CURRENT GITHUB MAIN SOURCE

Path: `Assets/Script/MouthCropGuard.cs`
Role: Legacy mouth uvRect writer
GitHub blob SHA: `0451b9ca943b4744938dad4c2dfde54e82c48945`
SHA256: NOT_AVAILABLE_IN_NORMAL_CHAT
Current/Obsolete: LEGACY / v4.6 ownership cleanup candidate

Path: `Assets/Script/FacePartAngleLock.cs`
Role: Legacy independent sample rotation owner
SHA256: NOT_AVAILABLE_IN_NORMAL_CHAT
Current/Obsolete: LEGACY / v4.6 ownership cleanup candidate

Path: `Assets/KiwiAvatarSystem/Runtime/Optimization/KiwiFacePartRigidCenterLock.cs`
Role: Legacy mouth positional correction during roll
SHA256: NOT_AVAILABLE_IN_NORMAL_CHAT
Current/Obsolete: LEGACY / v4.6 ownership cleanup candidate

Path: `Assets/KiwiAvatarSystem/Runtime/Optimization/KiwiFacePartQualityCoordinator.cs`
Role: crop preset / surface visibility / final renderer gate / mouth size cap
SHA256: NOT_AVAILABLE_IN_NORMAL_CHAT
Current/Obsolete: CURRENT, but ownership interaction must be preserved carefully

Path: `Assets/KiwiAvatarSystem/Editor/KiwiPrecisionTrackingInstaller.cs`
GitHub blob SHA: `d1a8ef600abc9c8aa9a9d8171abe5e24b53821c1`
Role: legacy safe-upgrade/self-modifying migration
SHA256: NOT_AVAILABLE_IN_NORMAL_CHAT
Current/Obsolete: REVIEW REQUIRED

### Generated cumulative overlays in this chat
- `KiwiAvatarSystem_v4_1_LiveFrame_CoherentFaceParts_Overlay.zip`
- `KiwiAvatarSystem_v4_2_AnatomicalConstraintFusion_Overlay.zip`
- `KiwiAvatarSystem_v4_3_CommercialRuntimeHardening_Overlay.zip`
- `KiwiAvatarSystem_v4_4_CommercialControlPlane_Overlay.zip`
- `KiwiAvatarSystem_v4_5_OnScreenPanelControls_Overlay.zip`

These are chat-generated artifacts, not automatically Production-installed evidence.
SHA256: NOT RECORDED IN THIS REPORT
Current: v4.5 is latest packaged cumulative overlay in this chat.
v4.6: NOT YET PACKAGED at archive time.

## RUNTIME EVIDENCE

No new Unity Runtime CSV / Player.log / MP4 was supplied after v4.1〜v4.5 package creation。
Therefore:
- v4.1〜v4.5 Runtime Correctness: NOT VERIFIED
- v4.1〜v4.5 Performance: NOT VERIFIED
- v4.1〜v4.5 Visual: NOT VERIFIED
Evidence classification: STATIC_ONLY

Project-level authority supplied separately says Native Camera Path B is stable、LIVE CAMERA 560x315 is Production Accepted / CLOSED、CPU Production conversion is blocked pending preprocessing/transaction semantic work、v44.55.24 Pair-Bound Shadow Output Snapshot is a separate top-level investigation。これらと本チャットのface-part overlay validationを混同しない。

## CURRENT RESULT

Completed:
- Commercial system design comparison
- 3D Model Primary final face-part architecture
- live-frame local correction concept
- eye-pair rigid solve
- mouth topology
- final anatomy guard
- commercial profile / quality governor / Pathfinder
- on-screen Setup/Telemetry UI
- broad duplicate-owner audit

Not completed:
- v4.6 final cumulative source package
- final cleanup of legacy Editor source rewriters
- Unity compile
- Runtime correctness
- Performance A/B
- Visual validation

Current status: `IN_PROGRESS`

## OPEN ISSUES

1. v4.6 final package未生成。
2. Legacy `KiwiFacePartRigidCenterLock`をcompat no-op化する最終実装/検証。
3. `MouthCropGuard`をstrict Landmarker/compat modeへ固定し、uvRect single-writerを保証。
4. `FacePartAngleLock`をSharedTilt authorityと競合しないよう無効化/compat化。
5. Desktop/MobileのFPS single-writerを完全に閉じる。
6. Model hot-swap後のMask/Surface reference refreshをRuntimeで検証。
7. Live GPU tracker Disable/Enable stale completionをRuntimeで検証。
8. Hidden far-eyeがAnatomy collisionへ参加しないことをRuntimeで検証。
9. Anatomy override解除後のMouth scale復元をRuntimeで検証。
10. Old Editor migration群を `still required / validation-only / obsolete` に分類。
11. Source rewriterをvalidation-only stubへできるものだけ安全に退役。
12. local Production SHA未確認。
13. Unity compile未確認。
14. Runtime CSV/Log/MP4未確認。

## NEXT ACTION

最優先: **v4.6 Commercial Ownership Consolidation / Full Code Audit Final を完成させる。**

手順:
1. `D:\KiwiAvatarSystem` local Production actual files + SHA256確認
2. GitHub mainとの差分確認
3. v4.5 generated overlayとの差分確認
4. write-target matrix作成: uvRect / sample rotation / surface offset / visibility / mouth scale / prediction envelope / FPS / inference threshold / auxiliary cadence
5. legacy ownerをcompat/no-op/disableへ整理
6. Editor source rewriterをstill required / validation-only / obsoleteに分類
7. whole-file final implementation
8. static compile/lint
9. Unity compile
10. Runtime correctness
11. Runtime performance
12. Visual MP4
13. v4.6 Production adoption decision

別系統のプロジェクト最優先調査 `v44.55.24 Pair-Bound Shadow Output Snapshot` とface-part v4.6を混同しない。

## DO NOT CHANGE

新しい独立Evidenceなしに変更しない:
- Face Landmarker Primary / Source of Truth
- Tracking Coreの基本数学
- KiwiFaceMotionをCamera workaroundとして変更
- KiwiInferenceFaceTrackerをCamera workaroundとして変更
- Native stable Path B
- LIVE CAMERA accepted 560x315 path
- strong smoothing
- global Kalman
- threshold relaxation
- FIFO / stale queue
- UpdateExternalTexture
- Unity D3D12 queue wait
- blocking GPU wait
- rotating texture identity
- permanent frame buffer
- Root/HeadへEye/Mouth local correctionをfeedback
- Production lane.input direct oracle
- Semantic PASS前のProduction CPU化
- explicit user instructionなしのcommit/push

## HANDOFF

次チャットではこのREPORTだけでも再開可能。

Current face-part architecture:
`3D Model Primary + Face Landmarker semantic source + Provider/Continuity + Latency budget + LIVE camera local GPU correction + Adaptive overscan + Tight semantic mask + Bilateral Eye rigid/similarity solve + Mouth topology constraint + Model-primary surface constraint + Final rendered anatomy guard + Commercial user/profile/quality/pathfinder UI`

Latest packaged chat artifact:
`KiwiAvatarSystem_v4_5_OnScreenPanelControls_Overlay.zip`
Status: STATIC_ONLY / not Runtime validated in this chat.

Next implementation target:
`v4.6 Commercial Ownership Consolidation`

Key cleanup targets:
- Legacy RigidCenter
- MouthCropGuard
- FacePartAngleLock
- FPS owners
- stale model-switch references
- GPU disable/re-enable mailbox
- Anatomy hidden-eye collision
- Anatomy override reset
- reflection cache
- old Editor source rewriters

Authority reminder:
Local Production + SHA > same Production Runtime > actual Package Source > latest reports > official source > GitHub main > generated old overlays.

Do not treat v4.5 ZIP as Production authority without checking actual installation.

## PROJECT MASTER REPORT — ITEMS TO REFLECT LATER

Archive: KiwiChat_CommercialFacePartArchitectureAndCodeAudit_Updated_20260902-JST.zip
LastWorkUpdate: 2026-09-02
Validated Decision: 3D Model Primary + bounded local 2D face-part constraints with bilateral eye rigid solve and mouth topology.
Rejected Approach: global smoothing / fully independent Eye/Mouth sprites / shared-translation-only eye lock.
Superseded Conclusion: keyboard F8/F9 panel control -> on-screen control dock.
Open Issue: v4.6 ownership consolidation and Runtime validation.
Next Action: complete v4.6 against local Production authority, then compile/runtime validate.

## CHAT ARCHIVE INDEX

Archive: KiwiChat_CommercialFacePartArchitectureAndCodeAudit_Updated_20260902-JST.zip
Topic: CommercialFacePartArchitectureAndCodeAudit
LastWorkUpdate: 2026-09-02
Status: IN_PROGRESS
Supersedes: None explicitly designated in this chat.
SupersededBy: None at archive creation.
NextArchiveCandidate: KiwiChat_CommercialOwnershipConsolidation_v4_6_Updated_<LAST_WORK>-JST.zip
