# KiwiAvatarSystem Chat Permanent Report

## METADATA

ChatTopic: Standalone Build / MediaPipe StreamingAssets / Spout-to-OBS Integration  
ChatTitle: KiwiVTuber Standalone executable and OBS integration completion  
ArchiveName: KiwiChat_StandaloneBuildSpoutOBS_Updated_20260902-JST.zip  
LastWorkUpdate: 2026-09-02  
LastWorkUpdatePrecision: DATE_ONLY  
ArchiveCreated: 2026-09-02 23:12 JST  
ArchiveTimestampBasis: LAST_RELEVANT_WORK_BEFORE_ARCHIVE_REQUEST  
Project: LOCAL_PRODUCTION_NOT_DIRECTLY_VERIFIED  
Unity: CHAT-LOCAL GUIDANCE USED 2022.3.62f2; CURRENT PROJECT AUTHORITY FILE STATES 6000.0.80f1  
CurrentInvestigationVersion: Standalone/OBS integration; no v44.55.x investigation version assigned in this chat  
Status: DONE (CHAT_SCOPE; NOT A GLOBAL PRODUCTION ACCEPTANCE)

Archive:
KiwiChat_StandaloneBuildSpoutOBS_Updated_20260902-JST.zip

Topic:
Standalone executable + MediaPipe StreamingAssets + Spout/OBS integration

Supersedes:
Editor-only operating assumption for this chat scope

SupersededBy:
NONE

NextArchiveCandidate:
KiwiChat_OneClickLaunchAndOBSOperations_* (only if that work is later performed)

---

## EXECUTIVE SUMMARY

This chat completed a standalone operating path for the kiwi VTuber workflow.

The work moved from an Editor-centric setup to a standalone executable, resolved a standalone MediaPipe resource-loading problem by switching the MediaPipe sample asset loader to `StreamingAssets` and placing `face_landmarker_v2_with_blendshapes.bytes` under `Assets/StreamingAssets`, and then verified the resulting executable by direct user observation.

Final chat-level confirmations:

- the standalone application started successfully;
- the webcam / Face Landmarker path responded after the StreamingAssets fix;
- avatar tracking operated normally;
- the standalone application produced the Spout sender;
- OBS received and displayed the Spout output.

No final CSV, Player.log, build log, SHA-guarded local Production inspection, or performance benchmark was supplied for the successful run. Therefore the result is a **chat-scope functional/integration PASS**, not a claim that current `D:\KiwiAvatarSystem` Production is globally accepted.

A major archive-time authority discrepancy was also identified: the chat had been operating from older project context (`D:\Kiwi3D_Maker\Unity\KiwiVRM`, Unity 2022.3.62f2), while the uploaded current project authority material states `D:\KiwiAvatarSystem`, Unity 6000.0.80f1 / DX12. The old path/version must not be promoted to current project authority without local verification.

---

## CHAT OBJECTIVE

Primary objective:

1. make the existing kiwi VTuber setup usable as a standalone Windows application rather than requiring Unity Editor Play mode;
2. preserve existing tracking behavior rather than redesigning the tracking core;
3. keep Face Landmarker functional in the standalone build;
4. preserve Spout output and verify OBS reception;
5. stop once the standalone → tracking → Spout → OBS path was operational.

A later one-click launcher for `KiwiVTuber.exe` + OBS was considered, but intentionally deferred when the user stopped the work.

---

## CONFIRMED FACTS

### Chat-local functional facts

Confirmed by direct user statements in this chat:

- After the MediaPipe standalone resource-loading change, the user reported: `正常に動いた`.
- The user then reported: `OBSにも映った`.
- Therefore, for the build/session tested by the user, the standalone application, tracking path, Spout sender path, and OBS reception path were functional at the end of the chat.

### Standalone configuration performed in this chat

The chat introduced / instructed:

- `KiwiStandaloneRuntime.cs`
- `Application.runInBackground = true`
- VSync disabled when configured
- `Application.targetFrameRate` target of 120
- a `StandaloneRuntime` GameObject carrying the component
- Windows standalone build workflow
- MediaPipe `AppSettings.asset` asset loader change:
  - `Local` → `StreamingAssets`
- Face Landmarker model placement:
  - `Assets/StreamingAssets/face_landmarker_v2_with_blendshapes.bytes`

The successful user report came after the `StreamingAssets` modification.

### Generated chat artifact

A chat-generated `KiwiStandaloneRuntime.cs` exists in the conversation workspace.

SHA256:
`19A0BB7BAE071EB210BE650B161E248E76570B53BC902F2A13F8387B8E89E5C9`

Important limitation:
This hash identifies the generated chat artifact, **not** the user's final installed Production copy. The actual local file after any manual edits is not directly verified.

### Current project authority supplied at archive time

The uploaded project authority material states:

- Project: `D:\KiwiAvatarSystem`
- Unity: `6000.0.80f1`
- Windows / DX12
- MediaPipeUnityPlugin: `v0.16.3`
- Face Landmarker remains Tracking Primary / Source of Truth
- current project-level next investigation is v44.55.24 Pair-Bound Shadow Output Snapshot.

These project-wide facts are archive-time context and are not evidence that this standalone test was executed against that exact Production tree.

### Local Production verification status

`LOCAL_PRODUCTION_NOT_DIRECTLY_VERIFIED`

No direct inspection of the user's local `D:\KiwiAvatarSystem` tree, actual build output, installed `AppSettings.asset`, installed `KiwiStandaloneRuntime.cs`, or final executable SHA occurred in normal chat.

---

## PUBLIC DESIGN PRINCIPLES

The following principles were used in the chat and remain consistent with the supplied KiwiAvatarSystem rules:

1. Standalone builds cannot rely on Editor-only resource availability; runtime assets required by MediaPipe must be packaged in a runtime-accessible location.
2. `StreamingAssets` is an appropriate Unity mechanism for packaging files that must remain directly loadable at runtime.
3. Runtime integration problems should first be fixed at the broken ownership/resource/lifecycle boundary rather than by changing established tracking math.
4. Spout/Presentation is a separate pipeline from Face Landmarker tracking. A failure or fix in standalone asset loading should not justify redesigning tracking.
5. A correctness/functional run with no controlled performance instrumentation is not a Performance Authority run.
6. A working Production path should not be rewritten solely for cleanup.

The project-level fixed design principle remains:
Face Landmarker is the tracking Primary / Source of Truth.

---

## INFERENCES / HYPOTHESES

The following are **not** promoted to confirmed global facts:

- The standalone camera failure was inferred to be caused by MediaPipe model/resource loading. The subsequent success after the `StreamingAssets` change strongly supports this for the tested build, but no final Player.log was archived to prove the exact failing call.
- The earlier `EndLayoutGroup: BeginLayoutGroup must be called first.` message was treated as an Editor IMGUI/layout issue rather than the runtime camera root cause. This is consistent with the later successful standalone run, but the exact originating Editor window was not proven.
- A 120 FPS Unity target was chosen to reduce presentation/update waiting opportunities. No controlled latency A/B was performed in this chat; 120 FPS is therefore not a measured optimum.
- Direct3D11 was suggested during the standalone-build instructions, but this chat did not provide evidence that D3D11 was necessary for the final successful build. Current project authority separately identifies the main KiwiAvatarSystem Production as DX12. Do not turn the D3D11 suggestion into a project-wide requirement.

---

## PRODUCTION AUTHORITY

Authority actually available for this archive:

1. User-reported final functional observations from the tested standalone build.
2. Files generated/uploaded in this chat.
3. Uploaded KiwiAvatarSystem authority / integrated instruction documents.
4. Project conversation context.
5. Public/official information used during troubleshooting.

Not available:

- direct local Production filesystem inspection;
- exact Production SHA comparison;
- final standalone executable SHA;
- final Player.log from the successful run;
- final build log;
- controlled performance telemetry.

Authority warning:

The chat-local environment references and the current uploaded project authority do not match. The current uploaded authority file is higher priority for **project-wide current state**, while the chat-local information remains valid only as historical evidence of the standalone work performed here.

SOURCE labels:

- SOURCE=PROJECT_CHAT_CONTEXT
- SOURCE=UPLOADED_REPORT
- SOURCE=UPLOADED_FILE
- SOURCE=USER_RUNTIME_OBSERVATION
- LOCAL_PRODUCTION_NOT_DIRECTLY_VERIFIED

---

## WORK PERFORMED

### 1. Standalone runtime helper introduced

Purpose:
Allow the avatar application to keep updating while OBS/game windows have focus and set a low-latency-oriented frame-rate policy.

Work:
A `KiwiStandaloneRuntime.cs` helper was generated.

Initial behavior:
- run in background;
- optional VSync disable;
- target frame rate 120.

Result:
Artifact created.

Validation:
No compile log was archived at that moment.

Impact:
Allowed progression toward standalone operation without modifying the Face Landmarker tracking core.

### 2. Inspector property visibility issue investigated

Observed:
The user reported that the `KiwiStandaloneRuntime` properties were not visible.

Response:
A complete replacement form using serialized private fields and `OnEnable()` re-application was provided in chat, and compile-error checks were recommended.

Result:
The conversation later progressed to executable testing, indicating this blockage was no longer active.

Important:
The exact final local source contents were not uploaded back after manual integration.

### 3. Standalone executable launched, but camera did not respond

Observed:
User supplied a screenshot and reported that the camera did not respond.

Initial assessment:
The executable itself was running, but the Face Landmarker input path was not operating.

The tracking core itself was deliberately not rewritten.

### 4. MediaPipe standalone resource path corrected

Investigation direction:
Standalone builds require runtime-accessible task/model assets.

Change instructed:
`AppSettings.asset`:
`Asset Loader Type = StreamingAssets`

Model placement instructed:
`Assets/StreamingAssets/face_landmarker_v2_with_blendshapes.bytes`

The user reported that the expected packaged resource was not present under the originally suggested package path, so the guidance was corrected to use the Face Landmarker task bundle as the runtime model file and place it under `StreamingAssets`.

Result:
User confirmed `AppSettings.asset` was successfully modified.

### 5. Editor GUI layout error observed

Observed error:
`EndLayoutGroup: BeginLayoutGroup must be called first.`

Assessment:
Treated as an Editor GUI/layout issue, not evidence of a Face Landmarker runtime failure.

Decision:
Do not modify tracking code in response to this GUI error.

### 6. Standalone functional validation

User result:
`正常に動いた`

Chat-level interpretation:
PASS for the standalone webcam / Face Landmarker / avatar tracking path in the tested build.

Evidence class:
CORRECTNESS / USER_RUNTIME_OBSERVATION

Performance authority:
NO

### 7. OBS integration validation

User result:
`OBSにも映った`

Chat-level interpretation:
PASS for the tested standalone → Spout → OBS integration path.

Evidence class:
VISUAL + INTEGRATION / USER_RUNTIME_OBSERVATION

Performance authority:
NO

### 8. Work intentionally stopped

The next planned convenience task was one-click launch of `KiwiVTuber.exe` and OBS.

User explicitly stopped:
`いったんここまで`

Therefore no launcher script or automation should be considered implemented.

---

## VALIDATED DECISIONS

### Decision: Keep the existing tracking core unchanged for standalone enablement

Reason:
The failure appeared at standalone runtime/resource initialization rather than tracking semantics.

Evidence:
Tracking became functional after the resource-loading configuration was corrected.

Regression constraints:
- do not modify Face Landmarker tracking math as a workaround for standalone resource loading;
- preserve Face Landmarker as Primary / Source of Truth.

Still current:
YES

### Decision: Package the Face Landmarker runtime asset through StreamingAssets for this standalone path

Reason:
The standalone build needed the model/task file at runtime.

Evidence:
The user reported successful operation after `AppSettings.asset` and runtime asset placement were corrected.

Regression constraints:
- keep filename/path consistent with the runtime configuration;
- verify build output contains the expected StreamingAssets content after future build-system changes.

Still current:
YES for this tested standalone path, subject to actual current Production verification.

### Decision: Treat standalone → Spout → OBS as functionally complete for this chat

Reason:
User directly confirmed both standalone operation and OBS display.

Evidence:
`正常に動いた`
`OBSにも映った`

Regression constraints:
No new tracking/native redesign merely to further “clean up” this completed path.

Still current:
YES at chat scope.

---

## REJECTED APPROACHES

### Rejected: Modify tracking math to make standalone camera start

Why considered:
The visible symptom was “camera not responding”.

Why rejected:
The problem was addressed at MediaPipe runtime asset loading, after which the standalone path worked.

Evidence:
Successful user runtime confirmation after the StreamingAssets change.

Revisit condition:
Only if independent evidence later shows a tracking semantic defect unrelated to runtime asset loading.

### Rejected: Treat the Editor `EndLayoutGroup` error as the camera root cause

Why considered:
The error appeared during the same workflow.

Why rejected:
It is an Editor GUI/layout class of error and the standalone application later worked.

Evidence:
Subsequent user confirmation of normal runtime.

Revisit condition:
Only if it blocks build/editor operation reproducibly and can be tied to a specific Editor extension/window.

### Rejected: Automatically continue into one-click launcher work

Why considered:
It was the next operational convenience step.

Why rejected:
User explicitly stopped the work.

Evidence:
`いったんここまで`

Revisit condition:
User requests continuation.

---

## SUPERSEDED CONCLUSIONS

### OLD
The required Face Landmarker model was expected under a package `Runtime/Resources` location.

### NEW
For this standalone workflow, the required model/task file was placed under:
`Assets/StreamingAssets/face_landmarker_v2_with_blendshapes.bytes`
and the asset loader was changed to `StreamingAssets`.

### WHY
The expected package file was not present, and the standalone build required a runtime-packaged model asset.

### EVIDENCE
User reported the configuration was changed and then reported normal operation.

---

### OLD
Chat-local environment assumptions treated `D:\Kiwi3D_Maker\Unity\KiwiVRM` / Unity 2022.3.62f2 as the active environment.

### NEW
The current uploaded project-wide authority states:
`D:\KiwiAvatarSystem`
Unity `6000.0.80f1`
Windows / DX12.

### WHY
The archive-time authority files are newer project-wide context.

### EVIDENCE
Uploaded `KiwiAvatarSystem-統合最新版カスタム指示-情報源-作業履歴-今後計画-更新基準-2026-09-02.txt` and `KiwiAvatarSystem-情報源・Authority一覧.txt`.

### Consequence
The standalone result is preserved as a valid chat-level historical result, but old environment metadata must not overwrite current project authority.

---

## OBSERVER / VALIDATOR FINDINGS

No dedicated Kiwi Correctness Observer or Validator was run for this standalone task.

No observer-heavy performance run was performed.

No performance numbers are promoted from this chat.

The successful run is based on direct user functional observation only.

The Editor `EndLayoutGroup` message is recorded as an Editor-side issue, not a Production tracking observer failure.

---

## FILES / SHA256

### Chat-generated standalone helper

Path/filename:
`KiwiStandaloneRuntime.cs`

Role:
Standalone runtime focus/frame-policy helper.

SHA256:
`19A0BB7BAE071EB210BE650B161E248E76570B53BC902F2A13F8387B8E89E5C9`

Before/After:
Generated during this chat.

Current/Obsolete:
GENERATED_CHAT_ARTIFACT; actual deployed local copy NOT directly verified.

### Face Landmarker runtime model

Path expected in tested project:
`Assets/StreamingAssets/face_landmarker_v2_with_blendshapes.bytes`

Role:
Face Landmarker runtime task/model bundle.

SHA256:
`NOT_AVAILABLE_IN_NORMAL_CHAT` for the final installed local copy.

Current/Obsolete:
CURRENT for the tested standalone configuration.

### AppSettings.asset

Role:
MediaPipe runtime asset loader configuration.

Required chat-local setting:
`Asset Loader Type = StreamingAssets`

SHA256:
`NOT_AVAILABLE_IN_NORMAL_CHAT`

Current/Obsolete:
CURRENT for the tested standalone configuration.

### Current project authority documents used during archive creation

`KiwiAvatarSystem-情報源・Authority一覧.txt`
SHA256:
`6D8C09AE6E3F19BDD7F4AF91BB304118C21AABA26A1547172A798E31975F33C4`

`KiwiAvatarSystem-統合最新版カスタム指示-情報源-作業履歴-今後計画-更新基準-2026-09-02.txt`
SHA256:
`B7EC5EC1A102D92D729FB5BDDA89CB1222B0F141610FDC92DA547B132E9FD8B4`

`通常チャット用-恒久REPORT・ZIP直接作成指示.txt`
SHA256:
`428F06E91F777F4D151F5507002BA21B363AD9E17F4C3C63E787D545B16F2219`

`Github-リポジトリ.txt`
SHA256:
`E4A48239BC2C13EACD0FEAE40AEBEF3A434EBA9DCA8AB363BB72F97ADC849E26`

These hashes refer to the uploaded archive-time source files in this chat environment, not local Production files.

---

## RUNTIME EVIDENCE

### Successful standalone operation

Evidence:
User statement: `正常に動いた`

Type:
CORRECTNESS

Authority:
USER_RUNTIME_OBSERVATION

Timestamp:
2026-09-02 (exact time unavailable)

Version:
Standalone build from this chat; exact executable hash unavailable.

Result:
PASS

Performance Authority:
NO

---

### OBS Spout reception

Evidence:
User statement: `OBSにも映った`

Type:
VISUAL / INTEGRATION

Authority:
USER_RUNTIME_OBSERVATION

Timestamp:
2026-09-02 (exact time unavailable)

Version:
Same chat standalone operating path; exact executable hash unavailable.

Result:
PASS

Performance Authority:
NO

---

### Pre-fix screenshot

Evidence:
Screenshot supplied when user reported the camera did not respond.

Type:
SUPPORTING_ONLY

Purpose:
Record the pre-fix failure state.

Current/Obsolete:
OBSOLETE AS CURRENT FAILURE STATE after successful post-fix runtime.

---

### Missing evidence

Not archived for the final successful run:

- Player.log
- final build log
- CSV telemetry
- performance benchmark
- final executable SHA256
- final local `AppSettings.asset` SHA256
- final local `KiwiStandaloneRuntime.cs` SHA256

Therefore this archive must not be used as a performance or exact-provenance authority.

---

## CURRENT RESULT

Chat-scope result:

`Standalone executable → Face Landmarker tracking → Spout sender → OBS display` is functionally complete based on direct user observation.

The standalone MediaPipe loading problem was resolved by configuring runtime asset loading through `StreamingAssets`.

No additional tracking modifications are justified by this chat.

Project-wide state:

The current uploaded authority material identifies a newer/different main Production context:
`D:\KiwiAvatarSystem`, Unity 6000.0.80f1 / DX12.

Therefore the standalone result should be carried forward as a validated functional technique/result, but any attempt to merge it into current Production requires direct local verification of paths, build settings, and file SHA.

---

## OPEN ISSUES

### READY

- If desired later, create a one-click operational launcher for the standalone app + OBS.
- If integrating this result into current `D:\KiwiAvatarSystem`, verify actual Production scene/build settings and whether equivalent standalone support already exists before copying any legacy helper/config.

### VALIDATION_PENDING

- Exact final executable SHA.
- Exact final deployed `KiwiStandaloneRuntime.cs` contents/SHA.
- Exact final deployed `AppSettings.asset` contents/SHA.
- Final successful Player.log/build log if provenance-grade standalone acceptance is needed.

### DEFERRED

- OBS profile/scene backup workflow.
- Streaming-service-specific output configuration.
- One-click launcher.

---

## NEXT ACTION

No mandatory next action; the user intentionally stopped here.

When this topic resumes, the safest next step is:

1. decide whether the goal is only convenience (one-click launch) or integration into the current `D:\KiwiAvatarSystem` Production;
2. if current Production integration is requested, inspect the actual local Production files/SHA before making changes;
3. do not copy old Unity 2022.3/D3D11 assumptions into the current Unity 6000.0.80f1/DX12 project without evidence.

The separate project-level authority file identifies v44.55.24 Pair-Bound Shadow Output Snapshot as the current main KiwiAvatarSystem investigation. That work is not part of this standalone/OBS chat and must remain separate.

---

## DO NOT CHANGE

Without new independent evidence:

- do not replace Face Landmarker;
- do not change `KiwiFaceMotion.cs` as a camera/standalone workaround;
- do not change `KiwiInferenceFaceTracker.cs` as a camera/standalone workaround;
- do not introduce strong smoothing or Kalman filtering;
- do not relax tracking thresholds;
- do not reintroduce FIFO/stale queues;
- do not alter stable Native Camera code merely because of this standalone work;
- do not promote the chat's D3D11 suggestion to current Production requirement;
- do not overwrite current project metadata with the older `KiwiVRM` / Unity 2022.3 context;
- do not claim exact Production provenance without local SHA verification;
- do not treat this functional run as Performance Authority;
- do not create/commit/push changes without explicit instruction.

---

## PROJECT MASTER REPORT UPDATE CANDIDATES

The local MASTER REPORT was not directly modified.

Recommended minimal additions, if this standalone work is relevant to the current project:

New Validated Decision:
Standalone MediaPipe runtime model loading can be made operational using `StreamingAssets`; tested standalone path reached Face Landmarker tracking and OBS Spout display.

New Rejected Approach:
Do not modify tracking math to solve standalone model/resource-loading failures.

New Superseded Conclusion:
Package `Runtime/Resources` was not the usable source assumed during troubleshooting; the tested workflow used the model under `Assets/StreamingAssets`.

Open Issue:
Map/verify this chat result against current `D:\KiwiAvatarSystem` Production before treating it as current Production implementation.

Current Next Action for this chat topic:
None unless user requests one-click operational launch.

Chat Archive Name:
`KiwiChat_StandaloneBuildSpoutOBS_Updated_20260902-JST.zip`

LastWorkUpdate:
2026-09-02

---

## HANDOFF

To resume this exact thread:

1. Treat the standalone + Spout + OBS path as **functionally passed for the build tested in this chat**.
2. The key standalone fix was:
   - MediaPipe `AppSettings.asset` asset loader set to `StreamingAssets`;
   - `face_landmarker_v2_with_blendshapes.bytes` placed under `Assets/StreamingAssets`.
3. User confirmed:
   - standalone operation became normal;
   - OBS displayed the output.
4. No final performance/provenance evidence was captured, so do not overstate the result.
5. The chat-generated helper `KiwiStandaloneRuntime.cs` has SHA256:
   `19A0BB7BAE071EB210BE650B161E248E76570B53BC902F2A13F8387B8E89E5C9`
   but this is not verified as the final local deployed file.
6. The old chat environment metadata conflicts with current project-wide authority:
   - old chat context: `D:\Kiwi3D_Maker\Unity\KiwiVRM`, Unity 2022.3.62f2;
   - current uploaded authority: `D:\KiwiAvatarSystem`, Unity 6000.0.80f1 / DX12.
   Use the current project authority for future global project work.
7. Do not resume by rewriting working tracking/native code.
8. If this topic continues, likely next convenience work is a one-click launcher / OBS operational packaging.
9. If main KiwiAvatarSystem work resumes instead, follow the separate current project authority chain; the uploaded project-wide material states v44.55.24 Pair-Bound Shadow Output Snapshot is the next main investigation.

---

## REPORT QUALITY / SELF-AUDIT

- Topic matches the actual technical work in this chat: YES
- Archive timestamp uses report creation time: NO
- Exact LastWorkUpdate time guessed: NO; DATE_ONLY used
- Local Production directly verified: NO; explicitly marked
- Old project metadata promoted to current authority: NO
- User runtime observation separated from exact provenance: YES
- Correctness/Performance/Visual separated: YES
- Observer-heavy performance values used: NO
- SHA guessed: NO
- Tracking/native redesign suggested as cleanup: NO
- Obsolete failure state retained as current: NO
- Next action reflects user stop: YES
- Current project-wide v44.55.x investigation mixed into chat result: NO

