# KiwiAvatarSystem Chat Permanent Report

ChatTopic: Webcam Motion Capture Static Audit / File Handoff / Project Authority Sync
ChatTitle: WMC比較調査・ZIP受け渡し診断・最新Authority同期
ArchiveName: KiwiChat_WMCStaticAuditAndFileHandoff_Updated_20260902-JST.zip
LastWorkUpdate: 2026-09-02
LastWorkUpdatePrecision: DATE_ONLY
ArchiveCreated: 2026-09-02 23:22 JST
ArchiveTimestampBasis: LAST_RELEVANT_WORK_BEFORE_ARCHIVE_REQUEST
Project: D:\KiwiAvatarSystem
Unity: 6000.0.80f1 / Windows / DX12
CurrentInvestigationVersion: v44.55.23 confirmed / v44.55.24 planned
Status: PARTIALLY_DONE

Archive: KiwiChat_WMCStaticAuditAndFileHandoff_Updated_20260902-JST.zip
Topic: WMC比較、ZIP/File handoff診断、Project Authority同期
Supersedes: このチャット初期の「v44.55.16が次作業」というCurrent前提
SupersededBy: NONE
NextArchiveCandidate: v44.55.24完了後、またはWMC残りREPORT再監査完了後

## EXECUTIVE SUMMARY

このチャットでは、v44.55.15 FIX5後の引継ぎを起点に、Webcam Motion Capture（WMC）をKiwiAvatarSystemの最重要商用品質比較対象として調査した。WMC本体ZIPを通常チャットへ渡す方式は正常に解析されず、Codexでローカル静的解析し、Markdown/CSV/TXTのREPORTだけを通常チャットへ戻して再監査するworkflowへ変更した。

ZIP問題は、約297MBだけでなく、8KB程度の.md 1ファイルのみを含むZIP、英数字名test.zipでも再現した。一方、test.md / テスト.md単体はFile Searchで正常に読めた。Project Sourcesは0件、Storageは20GB中5.38GB使用であり、Project上限・容量不足は否定的。root causeは未確定で、attachment→file-processing/File Search/sandbox handoff側の制限または不具合を最有力仮説として一旦保留した。

WMC AI Model Auditでは、MediaPipe Tasks 0.10.35、5個の.task、内部TFLite、face/hand/pose task、Windows版TFLite CPU + XNNPACKの可能性が高いことを確認した。ただしruntime delegate/thread数/cadenceは未確定。WMC backendをそのままKiwiへ移植する判断はしない。

その後、2026-09-02版の最新Project Authorityを受領。Currentはv44.55.23 Observer Validity PASS、115/115 Runtime PASS、MIXED_TRANSACTIONは暫定、次作業はv44.55.24 Pair-Bound Shadow Output Snapshot。よって、このチャット初期のv44.55.16前提はSUPERSEDED。

## OBJECTIVE

- WMCの公開/静的設計をKiwiと比較する。
- WMCから採用可能な設計原則のみ抽出する。
- 大型binary/archive解析をCodexへ寄せ、通常チャットで再監査する。
- ZIP handoff問題を切り分ける。
- 最新Project Authorityへ同期し、古いCurrent判断を残さない。

## CONFIRMED FACTS

### Kiwi Current
2026-09-02提供のAuthority/統合最新版による:
- Face Landmarker Primary / Source of Truth維持。
- Native CameraはPath B SystemMemoryNV12。
- latest-frame、FIFO/stale accumulation禁止。
- fixed Unity-visible texture identity。
- Tracking/Presentation cadence分離。
- Head single rigid authority。
- Root/Eye/Mouth authority分離。
- Correctness ObserverとPerformance Benchmarkを分離。
- Semantic PASS前のProduction CPU化禁止。
- Production lane.input direct oracleはREJECT。
- LIVE CAMERAは560x315でCompile/Runtime/Visual PASS、Production Accepted / CLOSED。
- v44.55.23: completed 115/115、Observer Validity PASS。
- v44.55.23 MIXED_TRANSACTIONは暫定。Worker allocator output lifecycle race未排除。
- 次作業はv44.55.24 Pair-Bound Shadow Output Snapshot。

### WMC static audit
対象: C:\Program Files\Webcam Motion Capture
- 全1,454ファイル探索。
- 独立AI modelは5個の.task。
- face_landmarker.task / hand_landmarker.task / pose lite/full/heavy。
- .task内部にTFLite model。
- Face detector input 128x128x3 FP32。
- Face landmark input 256x256x3 FP32。
- landmark output 1434 float = 478x3と強く整合。
- blendshape input 146x2、output 52。
- Hand detector 192x192、landmark 224x224。
- Pose detector 224x224、landmark 256x256、lite/full/heavy。
- MediaPipe Tasks 0.10.35 / libmediapipe.dll。
- XNNPACK文字列あり。
- CUDA/cuDNN/DirectML/ONNX Runtime DLL/direct importは見つからない。

Strong evidence:
Windows版WMCはTFLite CPU + XNNPACK backendの可能性が高い。

未確定:
delegate実選択、thread数、affinity、task並列性、runtime latency/cadence。

### ZIP/File handoff
再現:
- 約297MB WMC ZIP
- REPORTS.zip
- tiny ZIP
- ASCII test.zip / test(1).zip
観測:
- Chat attachment/file IDは発行。
- ZIPはFile Searchへ正常indexされないケースが継続。
- direct .mdはFile Search成功。
- 日本語/ASCII .md双方成功。
Project UI:
- Sources 0件
- Storage 5.38GB / 20GB
- Library files 1,115
結論:
size/name/EXE-DLL/Project Sources/storage単独原因は否定的。
root cause未確定。ZIP問題はPAUSED。

## PUBLIC DESIGN PRINCIPLES

WMCから参考になる:
- detectorとlandmark/fittingの段階分離
- face/hand/pose task分離
- quality/load tier
- channel別処理
- TrackingとAvatar receiver/presentationの責務分離
- global smoothingだけで品質を作らない
- live inputで古いsampleを無条件に積まない

Kiwiで維持:
- latest-frame
- persistent ROI
- source liveness/source age分離
- timestamp/generation/transaction safety
- bounded lanes
- single authority
- same-sample transaction
- Temporal owner/Prediction各1層
- strong smoothing/Kalmanで上流問題を隠さない

## INFERENCES / HYPOTHESES

WMC:
- Windows runtime backend = TFLite CPU + XNNPACKはStrong evidenceだがruntime未確定。
- exact filter式、prediction、latest-slot、ROI state、timestamp方式は未確定。

ZIP:
- attachment→file processing/File Search/sandbox handoff問題が最有力仮説。
- ZIP形式制限、Project固有pipeline、backend障害、archive ingestion policy等は未確定。

## PRODUCTION AUTHORITY

優先:
1. local Production実体 + SHA
2. same-Production最新Runtime
3. 実使用Package Source
4. 最新KiwiValidation/Consolidated REPORT
5. 公式Documentation/Source
6. local Git history
7. GitHub main
8. 過去version/diagnostic

LOCAL_PRODUCTION_NOT_DIRECTLY_VERIFIED

この通常チャットからD:\KiwiAvatarSystem実配置を直接監査していないため、過去SHAをCurrent SHAとして再宣言しない。

GitHub:
https://github.com/midori-kiwi/KiwiAvatarSystem/tree/main

## WORK PERFORMED

1. v44.55.15引継ぎ受領。当時はv44.55.16 Canonical Semantic Gateが次候補。
2. WMCを最重要比較対象として調査。
3. WMC本体ZIP直接解析を試行したがhandoff不調。
4. Codex local static audit→REPORT→normal-chat re-audit workflowを決定。
5. ZIP問題をsize/name/content/Project Sources/storageで切り分け。
6. WMC AI Model Auditを受領しMediaPipe Tasks/TFLite構成を確認。
7. 5,000文字カスタム指示版を整理。
8. 2026-09-02統合最新版Authorityを受領しProject Currentをv44.55.23/v44.55.24へ同期。

## VALIDATED DECISIONS

Decision: WMCを最重要商用品質比較対象として維持。
Reason: Kiwi品質目標との比較価値が高い。
Still current: YES

Decision: WMC binary-heavy解析はCodex local audit→REPORT→normal-chat再監査。
Still current: YES

Decision: ZIP問題中は.md/.csv/.txt単体受け渡しを使用。
Still current: YES

Decision: WMCがCPUらしいことをKiwi CPU化根拠にしない。
Still current: YES

Decision: Current Next Actionはv44.55.24。
Still current: YES

## REJECTED APPROACHES

Rejected: 「297MBだからZIP失敗」
Evidence: tiny ZIPでも再現。

Rejected: 日本語ファイル名原因
Evidence: ASCII test.zipでも再現、Japanese/ASCII .mdは成功。

Rejected: EXE/DLL混入原因
Evidence: .mdだけのtiny ZIPでも再現。

Rejected: Project Sources上限
Evidence: Sources 0件。

Rejected: Storage不足
Evidence: 5.38/20GB。

Rejected: WMC backend/modelをそのままKiwiへ移植。
Reason: Kiwi Production authority/semantic gateを壊す根拠なし。

## SUPERSEDED CONCLUSIONS

OLD: 次作業=v44.55.16。
NEW: 次作業=v44.55.24。
WHY: v44.55.17～23まで後続Evidenceが進行済み。

OLD: LIVE CAMERAは将来未解決課題。
NEW: CLOSED / Production Accepted。
WHY: 560x315でCompile/Runtime/Visual PASS。

OLD: ZIPは大容量が主因かもしれない。
NEW: size-only原因は否定的。

## OBSERVER / VALIDATOR FINDINGS

- Validator/Observer PASSを無条件に信用しない。
- v44.55.22 Production lane.input direct oracleは方式自体REJECT。
- v44.55.23ではlogical tensor lengthとbacking capacity混同bugを修正。
- Inference Engine 2.4.1 sourceでcapacity >= logical lengthが正常と確認。
- 修正後v44.55.23は115/115 PASS。
- ただしWorker output lifecycle race未排除なのでMIXED_TRANSACTIONは暫定。
- Chat attachment metadataとFile Search/sandbox availabilityも同一とみなさない。

## FILES / SHA256

Current local Production:
LOCAL_PRODUCTION_NOT_DIRECTLY_VERIFIED
SHA256=NOT_AVAILABLE_IN_NORMAL_CHAT

Reference:
- Github-リポジトリ.txt
- KiwiAvatarSystem-情報源・Authority一覧.txt
- KiwiAvatarSystem-統合最新版カスタム指示-情報源-作業履歴-今後計画-更新基準-2026-09-02.txt
- 通常チャット用-恒久REPORT・ZIP直接作成指示.txt
SHA256=NOT_AVAILABLE_IN_NORMAL_CHAT

WMC task hashes from audit:
face_landmarker.task:
64184e229b263107bc2b804c6625db1341ff2bb731874b0bcc2fe6544e0bc9ff
hand_landmarker.task:
fbc2a30080c3c557093b5ddfc334698132eb341044ccee322ccf8bcf3607cde1
pose_landmarker_lite.task:
59929e1d1ee95287735ddd833b19cf4ac46d29bc7afddbbf6753c459690d574a
pose_landmarker_full.task:
4eaa5eb7a98365221087693fcc286334cf0858e2eb6e15b506aa4a7ecdcec4ad
pose_landmarker_heavy.task:
64437af838a65d18e5ba7a0d39b465540069bc8aae8308de3e318aad31fcbc7b

## RUNTIME EVIDENCE

v44.55.23:
Authority type: CORRECTNESS
- completed 115/115
- observerFault 0
- snapshot failures 0
- anomalous 8
- Production=REF exact 5
- Production=MODE2 exact 0
- Neither exact 3
- Observer Validity PASS
- MIXED_TRANSACTION PROVISIONAL
Performance authority: NO

WMC audit:
Authority type: STATIC_ONLY / SUPPORTING_ONLY
No WMC runtime latency/cadence assertion。

ZIP tests:
Authority type: SUPPORTING_ONLY

## CURRENT RESULT

Kiwi:
- Tracking Core stable
- Native Camera Path B stable
- LIVE CAMERA CLOSED
- same-tensor backend差は主要原因ではない
- unresolved: Preprocessing / Transaction Semantic
- v44.55.23 Observer Validity PASS
- MIXED_TRANSACTION provisional
- v44.55.24 next

WMC:
- initial public comparison DONE
- AI model/task/backend static audit DONE
- full tracking/filter/camera/receiver/runtime audit NOT DONE

ZIP issue:
UNRESOLVED / PAUSED
Workaround: individual .md/.csv/.txt + Codex local analysis

## OPEN ISSUES

1. v44.55.24でWorker output lifecycle race排除。
2. 3件NEITHER_EXACT再判定。
3. Production Output Transaction Authority確定。
4. Reference Transaction Authority確定。
5. Semantic PASS後のみCPU Production候補へ。
6. WMC残りREPORT再監査。
7. ZIP handoff root causeは保留。
8. Current Production SHAはnormal chatから未確認。

## NEXT ACTION

v44.55.24 Pair-Bound Shadow Output Snapshot。

目的:
v23のNEITHER_EXACTが実Production差かObserver lifecycle artifactか確定。

固定:
- same pair lifetime中にobserver-owned GPU bufferへsnapshot
- pair token / record index / sequence / NativeHostTicks / ManagedHostTicks / LaneStartedHostTicks固定
- record完成後に初めてPeekOutputして補完しない
- Production/Native/Tracking/threshold write 0
- performance authority 0

## DO NOT CHANGE

- Face Landmarker Primary
- Native Path B
- latest-frame / FIFO禁止
- fixed texture identity
- timestamp/generation/session epoch
- Tracking/Presentation cadence分離
- single rigid head authority
- Root/Eye/Mouth分離
- same-sample transaction
- threshold
- strong smoothing/Kalman
- KiwiFaceMotion/KiwiInferenceFaceTrackerをcamera workaroundとして変更
- Production lane.input oracle再採用
- Native speculative rebuild
- Semantic PASS前のProduction CPU化
- Observer run Performance正式採用
- LIVE CAMERA 560x315 accepted state
- Working Production Coreの不要な再設計
- 明示指示なしcommit/push

## HANDOFF

次チャット開始時:
1. Currentはv44.55.23 confirmed / v44.55.24 planned。
2. v44.55.16はSUPERSEDED。
3. MIXED_TRANSACTIONは暫定。
4. Worker output lifecycle race未排除。
5. 次はv44.55.24。
6. v24完了までProduction CPU化/Native/Tracking変更へ進まない。
7. WMCはMediaPipe Tasks/TFLite task構成を確認済み。
8. CPU+XNNPACKはStrong evidenceでruntime確定ではない。
9. WMC backendをコピーせず設計原則のみ比較。
10. WMC残りREPORTは.md/.csv/.txt単体で再監査。
11. ZIP issueはPAUSED。
12. critical変更前にlocal/CodexでSHAを再確認。

## MASTER REPORT UPDATE CANDIDATES

Validated:
- WMC最重要比較対象
- Codex local audit→normal-chat re-audit
- ZIP問題中はtext report単体受け渡し

Rejected:
- size-only/name-only/EXE-DLL-only/Project-limit/storage explanations

Superseded:
- v44.55.16 Current Next
- LIVE CAMERA unresolved

Open:
- v44.55.24
- WMC full architecture audit
- ZIP handoff root cause paused

## SOURCE PROVENANCE

Primary sources:
- KiwiAvatarSystem-情報源・Authority一覧.txt
- KiwiAvatarSystem-統合最新版カスタム指示-情報源-作業履歴-今後計画-更新基準-2026-09-02.txt
- Github-リポジトリ.txt
- 通常チャット用-恒久REPORT・ZIP直接作成指示.txt
- WMC AI Model Audit
- current chat upload tests/screenshots

Later 2026-09-02 Project Authority supersedes earlier chat handoff where they conflict.

## FINAL ARCHIVE STATUS

Status: PARTIALLY_DONE

- WMC initial static audit: DONE
- ZIP handoff root-cause: PAUSED / unresolved
- Project Authority sync: DONE
- Current Kiwi semantic investigation: IN_PROGRESS
- Next: v44.55.24
