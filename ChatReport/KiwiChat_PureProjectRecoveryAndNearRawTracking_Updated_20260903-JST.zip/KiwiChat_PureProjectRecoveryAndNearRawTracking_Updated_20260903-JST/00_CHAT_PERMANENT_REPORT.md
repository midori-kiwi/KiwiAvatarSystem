# KiwiAvatarSystem Chat Permanent Report

ChatTopic: PureProjectRecoveryAndNearRawTracking
ChatTitle: Pure Project/Safe Mode Recovery + Near-Raw Tracking Refinement + Avatar System Next Plan
ArchiveName: KiwiChat_PureProjectRecoveryAndNearRawTracking_Updated_20260903-JST.zip
LastWorkUpdate: 2026-09-03
LastWorkUpdatePrecision: DATE_ONLY
ArchiveCreated: 2026-09-03 00:35 JST
ArchiveTimestampBasis: LAST_RELEVANT_WORK_BEFORE_ARCHIVE_REQUEST
Project: D:\KiwiAvatarSystem
Unity: 6000.0.80f1 is the latest project-wide authority as of 2026-09-02; older v3.7.1 package artifacts in this chat originated from a Unity 2022.3.62f2-era branch/context.
CurrentInvestigationVersion: v3.7.1 Near-Raw / Jitter-Minimized tracking refinement; RollArcFix intended but final source-artifact parity is unresolved.
Status: PARTIALLY_DONE
ProductionVerification: LOCAL_PRODUCTION_NOT_DIRECTLY_VERIFIED

---

## EXECUTIVE SUMMARY

This chat recovered a Unity/UniVRM project from Safe Mode/compile-related blockers, then iteratively refined `KiwiFaceMotion` toward a near-raw Face Landmarker presentation policy: rightward movement maps rightward, future prediction is minimized in near-raw mode, static micro-jitter is locally suppressed, and large/fast motion is intended to pass with minimal added latency.

Runtime observations exposed several coupled-motion regressions: moving right originally moved the kiwi left; motion jitter remained; pure Yaw caused false horizontal Root translation; a Yaw/X decoupling experiment then broke eye tracking and was withdrawn; pure Roll then produced a U/arc-shaped Root path. The intended Roll fix was to use the Runner's virtual-neck convention (`1.30`) / direct Runner center for Root translation while leaving Eye/Mouth landmark presentation untouched.

A critical archive-time self-audit found that the currently materialized `KiwiFaceMotion.cs` does **not** match the later RollArcFix validation report. The current file SHA-256 is `ac9d703e...`, contains `virtualNeckExtension = 1.65f`, and therefore cannot be treated as the claimed final RollArcFix. The validation report itself claims it validated a different source SHA (`32b22e9a...`). This makes the latest RollArcFix delivery **VALIDATION_PENDING / artifact-parity unresolved**, despite the earlier assistant statement of `20/20 PASS`.

The user then uploaded `Assets(2).zip` and requested a much broader final system redesign/implementation: at least three architectural directions, scored comparison, best direction reviewed ten times, low-latency/high-accuracy tracking, near-zero jitter, model switching/import, non-spherical avatars, automatic eye/mouth placement, spring/tail motion, in-app tuning, Windows-first plus Android/iOS (no iOS physical-device test). That full integration had not begun before the archive request.

---

## OBJECTIVE

1. Recover the Unity project to a no-red-error state.
2. Preserve Face Landmarker as the tracking source of truth while reducing visible latency and jitter.
3. Correct directionality and separate Root translation from Yaw/Roll/Eye/Mouth motion.
4. Preserve established eye/mouth behavior while refining Root/Head motion.
5. Prepare for a broader avatar architecture supporting runtime model import/switch, arbitrary shapes, automatic face-part binding, spring/dangle parts, in-app tuning, Windows/Android/iOS.
6. Archive the real current state, including failed/withdrawn approaches and validator/artifact inconsistencies.

---

## CONFIRMED FACTS

### Editor / project recovery

- UniGLTF/UniVRM recommended switching Color Space from Gamma to Linear; the user accepted it.
- A red Humanoid error reported `Required human bone 'LeftLowerArm' not found` for an old/incomplete `Assets/kiwi.vrm` path.
- The old/incomplete VRM was separated from the intended `Assets/Models/uni_kiwi_textured_rigged.vrm` path.
- The user subsequently reported: **red errors = none**.

### User-observed tracking behavior

The following are direct user observations from this chat:

- Initially: moving right made the kiwi move left.
- After direction work: visible motion jitter remained while moving.
- User requested motion to remain almost raw Face Landmarker motion.
- Pure horizontal head turn caused false left/right kiwi translation.
- The Yaw/X decoupling attempt caused eye tracking to break.
- After restoring the earlier basis, pure Roll/side tilt caused a U-shaped / arc-like kiwi Root path.

These observations are more authoritative for the visible behavior than synthetic checks alone.

### Actual artifact audit performed while creating this archive

Actual bytes currently available in the active artifact workspace:

- `/mnt/data/KiwiFaceMotion.cs`
  - SHA256: `ac9d703e0976722be260b19ee72ad8172fc19ac35daa4d6f13beb21dbeea1d2c`
  - Contains `public float virtualNeckExtension = 1.65f;`
  - Therefore it is **not byte-equivalent to the intended RollArcFix described by its validator**.

- `/mnt/data/KiwiFaceMotion_RollArcFix_VALIDATION.txt`
  - File SHA256: `f503da5dd08799bb229054f412172fe8916374cfbbef7f1194bbf169fa382778`
  - Report claims the validated source SHA was `32b22e9a79ef7024b4252f5cd38c5593efc81ad02986aa5ae818e3523ebdc23d`.
  - Report claims `virtualNeckExtension = 1.30` and direct Runner face center.
  - This does **not** match the currently materialized source above.

- `/mnt/data/KiwiFaceMotion_JitterMinimized_VALIDATION.txt`
  - File SHA256: `131ab86a3b3b2934e65f1ca35ec32d1a75690fd495447224dab867245c17f56e`

- `/mnt/data/KiwiFaceMotion_NearRaw_VALIDATION.txt`
  - File SHA256: `619553ed8c9e029358bc369ac50ae430c07020a16870e3f1f9797a641a2c6f05`

- `/mnt/data/KiwiFaceMotion_YawDecoupling_VALIDATION.txt`
  - File SHA256: `879d2560206fc918497b3903e62143ee54886411e676aed06c40b8ec7e9d5b84`

- `/mnt/data/KiwiPrecisionTrackingInstaller.cs`
  - SHA256: `8b22914efa23dd5d4022607aa70f3ed1081e71e62655604d930eed6b27fc4e99`

- `/mnt/data/KiwiAvatarSystem_PureProject_v3.7.1_Hotfix1.zip`
  - SHA256: `30fbdd86eb6991c9b0fb76ae3fb9a714394fafffaf1bcd954167ef92e3e40255`

### Production authority

- Current project authority documents state that local `D:\KiwiAvatarSystem` Production + exact SHA outranks chat-generated artifacts, reports, GitHub main, and older diagnostic versions.
- This normal-chat session cannot directly inspect `D:\KiwiAvatarSystem`; therefore **none of the v3.7.1 chat-generated files are automatically Production-authoritative**.
- Project-wide authority updated 2026-09-02 also states the current mainline investigation is v44.55.24 Pair-Bound Shadow Output Snapshot and that tracking changes should not be advanced on current Production without resolving that authority/semantic sequence or explicitly separating the work as another branch/package.

---

## PUBLIC DESIGN PRINCIPLES

No new external-web research was completed in this specific chat before the archive request. The following are established project design principles carried into this work from the project's authority/custom-instruction sources:

- Face Landmarker remains Primary / Source of Truth.
- Tracking cadence and display/presentation cadence must be separated.
- Latest-frame priority; no stale FIFO accumulation.
- Normal accepted samples should traverse the shortest low-latency path; abnormal samples and transitions are locally suppressed.
- Strong temporal smoothing/Kalman filtering must not be used to hide upstream camera/inference problems.
- Root, Head, Eye, Mouth are separate authority channels; Yaw/Pitch/Roll and Eye/Mouth must not create Root translation.
- Eye/Mouth texture/crop/mask should remain same-sample/coherent and should not be forced to follow a model-root correction coordinate system that breaks landmark alignment.
- Same-frame spatial stabilization is preferable to broad frame-to-frame averaging when it can reduce noise without added temporal latency.
- Avatar support should remain `Tracking Core + Avatar Adapter + Model Profile + Runtime Import + Transactional Hot Swap`; model-specific adaptation must not flow backward into Tracking Core.
- Windows is the primary runtime target; Android/iOS are supported without requiring an iOS physical-device test.

---

## INFERENCES / HYPOTHESES

These are not yet proven by real webcam telemetry:

1. The U-shaped Roll motion is consistent with Root translation using a virtual pivot that is not coincident with the real/Runner virtual neck pivot. The RollArc validator's constructed similarity test supports this mechanism, but the claimed source file was not actually preserved in the current artifact.
2. The Yaw/X cheek+nose correction broke eye tracking because it changed Root/FaceAnchor presentation geometry without maintaining the exact FacePart landmark coordinate relationship. This is strongly consistent with the observed regression, but requires a runtime transaction/transform trace for definitive proof.
3. A safer future solution is to keep Eye/Mouth presentation unchanged and implement Root translation as an isolated translation estimator driven by the same accepted sample, rather than changing landmark geometry or FacePart coordinates.
4. “Faster than LandMarker” can only mean lower end-to-end/presentation latency than a naïve LandMarker integration; it cannot create newer source observations than the LandMarker result itself. The practical path is latest-sample consumption, coherent timestamps, minimal presentation delay, actual-sample late latch, and avoidance of unnecessary smoothing/buffering.

---

## PRODUCTION AUTHORITY

Authority order used for this archive:

1. Local Production exact files + SHA — **not directly accessible here**.
2. Same-Production Runtime evidence — not supplied for these v3.7.1 tracking refinements.
3. Actual package/source bytes available in this chat/container.
4. Project authority/custom-instruction reports dated 2026-09-02.
5. User runtime observations/screenshots in this chat.
6. Static/synthetic validator reports.
7. Older package/version reports.

Important separation:

- The current project mainline in `D:\KiwiAvatarSystem` is not proven to be the same code line as the v3.7.1 PureProject/Assets branch handled in this chat.
- GitHub main must not override newer local Production.
- The user-provided `Assets(2).zip` is intended as the next implementation baseline, but its actual bytes were not successfully materialized/audited before this archive was created.

---

## WORK PERFORMED

### 1. Safe Mode / UniVRM recovery

Purpose: get the Unity project compiling and out of blocker state.

Result:
- Linear Color Space recommendation accepted.
- Invalid/incomplete `Assets/kiwi.vrm` identified as the Humanoid `LeftLowerArm` failure source.
- User reported zero red errors afterward.

Status: **PASS by user observation**.

### 2. Horizontal movement sign correction

Purpose: rightward real movement must produce rightward avatar translation.

Intended change:
- Screen-space X mapping changed from subtraction to addition.
- Legacy X mapping intended to match the same direction.

Result:
- Directional invariant established: right movement -> right movement.

Status: **behavioral requirement accepted; exact final-source parity should be rechecked from the next real baseline**.

### 3. Initial motion-jitter mitigation

Purpose: reduce visible trembling while moving.

Approach:
- Position-only adaptive stabilization.
- Position prediction reduced/disabled.

Result:
- User then explicitly prioritized “almost raw LandMarker” feel, so broad stabilization was not retained as the target philosophy.

Status: **SUPERSEDED by Near-Raw design**.

### 4. Near-Raw LandMarker mode

Purpose: accepted samples should reach the avatar with minimal temporal manipulation.

Intended design:
- near-raw accepted samples.
- microscopic static hold only.
- no future velocity prediction in near-raw mode.
- actual newer sample may be consumed at `onBeforeRender`.
- secondary body transform animation off by default in near-raw mode.
- catastrophic spike guard retained.

Validator report:
- 33/33 static/synthetic checks claimed PASS.

Status: **design direction accepted; exact source artifact from that revision is not the current final file**.

### 5. Ten-pass Jitter-Minimized refinement

Purpose: reduce visible micro-jitter as far as possible without creating sticky/laggy tracking.

Intended design:
- same-frame geometry stabilization.
- fixed Near-Raw micro-filter coefficients rather than per-frame quality coefficient pumping.
- direct snap for large/fast motion.
- no future prediction in near-raw mode.
- no per-frame allocations in the added filter path.

Validator report claimed:
- 34/34 PASS.
- Design source SHA: `b8de0d04221b7c6b3e05ed0ce43264470568038b06ba951e21f38dbb2a7ac56d`.

Status: **conceptual baseline retained, but must be reconstructed/verified from actual bytes before Production use**.

### 6. Yaw-induced false X translation

Purpose: turning the head sideways should rotate the kiwi without moving its Root horizontally.

Attempt:
- cheek midpoint + nose/cheek residual + face-width normalized correction.

Synthetic validator claimed:
- 38/38 PASS.

Runtime result:
- User: eye tracking broke.

Decision:
- **REJECT / ROLLBACK**.

### 7. Eye tracking regression rollback

Purpose: restore proven Eye/Mouth landmark behavior.

Decision:
- remove the Yaw/X cheek+nose decoupling approach.
- restore the pre-decoupling Jitter-Minimized behavior.
- future Root translation correction must not modify Eye/Mouth landmark presentation basis.

Status: **validated decision based on user-visible regression**.

### 8. Roll U/arc Root translation diagnosis

Purpose: side tilt should primarily be Roll, not U-shaped Root translation.

Diagnosis:
- Runner virtual neck convention uses eye-to-chin extension `1.30`.
- Later Jitter-Minimized Root anchor path was described as using `1.65`.
- Intended fix: direct Runner face center for Near-Raw Root translation and `1.30` fallback extension.

Validator claimed:
- 20/20 PASS.
- claimed candidate source SHA `32b22e9a...`.

Archive-time audit:
- actual current `KiwiFaceMotion.cs` still has `1.65` and SHA `ac9d703e...`.

Status: **VALIDATION_PENDING / delivery mismatch**.

### 9. Full-system final request using `Assets(2).zip`

User requested:
- maximize tracking speed/accuracy.
- BigMouse-like near-zero perceived latency.
- near-zero jitter.
- correct right / right-tilt / down-right directions.
- easy model switching in-app.
- non-spherical avatar support.
- easy external model import.
- automatic eye/mouth placement.
- natural tail/spring motion.
- app-side tuning for features/motion amounts.
- Windows primary + Android/iOS; no iOS real-device test.
- at least three architecture directions.
- compare/evaluate, select highest-scoring direction.
- review/refine selected direction ten times.
- modify completed files when justified.
- avoid `(1)` duplicate filename suffixes.

Status: **NOT STARTED / interrupted by archive request**.

---

## VALIDATED DECISIONS

### Decision: Face Landmarker remains Primary / source of truth
Reason: project-level invariant and required behavior.
Evidence: project authority/custom instructions and all tracking design in this chat.
Regression constraints: do not add a second tracker to mask problems.
Still current: YES.

### Decision: Directional invariants
Reason: user-defined visible behavior.
Evidence: direct user requirement and correction cycle.
Regression constraints:
- right movement -> right movement.
- right head turn -> kiwi's right.
- right tilt -> kiwi's right.
- down-right -> kiwi's down-right.
- preserve established `Yaw = -SignedAngle(euler.y)` and `Roll = -SignedAngle(euler.z)` conventions unless a new coordinate-authority audit proves otherwise.
Still current: YES.

### Decision: Eye/Mouth must not be “fixed” by Root coordinate hacks
Reason: Yaw/X correction produced a direct eye-tracking regression.
Evidence: user runtime observation.
Regression constraints: Root translation estimator must be separate from raw Eye/Mouth landmark presentation.
Still current: YES.

### Decision: Avoid broad smoothing in normal motion
Reason: user prioritizes near-raw low latency; project rules forbid hiding upstream problems with strong smoothing.
Evidence: user requirements + project design principles.
Regression constraints: micro-jitter suppression only in a narrow local region; large/fast valid motion should pass rapidly.
Still current: YES.

### Decision: Yaw/X cheek+nose decoupling is not accepted
Reason: caused eye tracking regression.
Evidence: user runtime observation.
Regression constraints: do not re-enable without a same-sample transform/authority design proving FacePart alignment.
Still current: YES.

### Decision: Current RollArcFix validator is not sufficient proof of the downloadable source
Reason: report/source SHA mismatch found at archive time.
Evidence: actual SHA/content inspection.
Regression constraints: future validators must verify the exact final artifact bytes after final write.
Still current: YES.

---

## REJECTED APPROACHES

### Rejected: Strong global temporal smoothing / Kalman as a jitter cure
Why considered: it can reduce visible numerical jitter.
Why rejected: adds latency/stickiness and can hide source/camera/inference issues.
Evidence: project invariant + user near-raw requirement.
Revisit condition: only with real telemetry proving a specific localized channel requires it and latency remains acceptable.

### Rejected: Near-Raw future velocity prediction as the main latency solution
Why considered: extrapolation can reduce apparent phase lag.
Why rejected: overshoot/reversal risk and not an actual newer observation.
Evidence: user preference and prior Near-Raw design review.
Revisit condition: only as one bounded presentation owner with measured benefit and no double-prediction.

### Rejected: Cheek/nose Yaw-X decoupling implementation
Why considered: synthetic tests removed false Yaw translation while preserving synthetic translation.
Why rejected: user-visible Eye tracking regression.
Evidence: runtime observation outranks synthetic validator.
Revisit condition: redesign as an isolated Root translation estimator that leaves FacePart landmarks/transactions unchanged.

### Rejected: Treating `KiwiFaceMotion_RollArcFix_VALIDATION.txt` as proof of current `KiwiFaceMotion.cs`
Why considered: validator claimed 20/20 PASS.
Why rejected: actual source SHA/content does not match the validator's claimed candidate.
Evidence: archive-time SHA/content audit.
Revisit condition: rebuild exact candidate, atomically write final filename, re-hash, re-run validator against that exact file, then Unity runtime test.

---

## SUPERSEDED CONCLUSIONS

### OLD
“The Roll U-path fix has been delivered as `KiwiFaceMotion.cs`, 20/20 PASS, with direct face center and `virtualNeckExtension = 1.30`.”

### NEW
At archive time, the actual available `KiwiFaceMotion.cs` has SHA `ac9d703e...` and still contains `virtualNeckExtension = 1.65f`. The RollArc validator refers to a different source SHA `32b22e9a...`.

### WHY
Artifact/version parity was not closed after repeated same-filename revisions.

### EVIDENCE
Direct hash/content inspection during archive creation.

---

### OLD
“Synthetic 38/38 Yaw/X decoupling is a valid improvement.”

### NEW
The approach is rejected because it caused real eye-tracking regression.

### WHY
Runtime visual behavior outranks synthetic success.

### EVIDENCE
User observation: “目の追従が崩れるようになった”.

---

## OBSERVER / VALIDATOR FINDINGS

1. **Final artifact parity bug**
   - Multiple revisions reused the same public filename `KiwiFaceMotion.cs`.
   - This is desirable for the user's “no `(1)` suffix” requirement, but unsafe unless writes are transactional and final SHA is revalidated.
   - The current workspace file and RollArc validator are inconsistent.

2. **Validator scope problem**
   - Synthetic/static PASS does not establish webcam/runtime correctness.
   - The Yaw/X validator passed synthetically but produced a visible Eye regression.

3. **RollArc validator/source mismatch**
   - Validator claims source SHA `32b22e9a...`.
   - Current artifact SHA is `ac9d703e...`.
   - Current artifact still contains `1.65`.
   - Therefore the validator is **not authority for the current artifact**.

4. **Required future validator pattern**
   - Build candidate in temp path.
   - validate candidate.
   - write/replace exact final target.
   - hash final target.
   - compare final target hash to validated candidate hash.
   - only then expose/download the final artifact.
   - Unity compile/runtime validation must use that exact SHA.

---

## FILES / SHA256

| File | Role | SHA256 | State |
|---|---|---|---|
| `KiwiFaceMotion.cs` | current materialized chat artifact | `ac9d703e0976722be260b19ee72ad8172fc19ac35daa4d6f13beb21dbeea1d2c` | CURRENT_ARTIFACT_BUT_NOT_PROVEN_ROLL_FIX |
| `KiwiFaceMotion_NearRaw_VALIDATION.txt` | Near-Raw static/synthetic report | `619553ed8c9e029358bc369ac50ae430c07020a16870e3f1f9797a641a2c6f05` | SUPPORTING_ONLY |
| `KiwiFaceMotion_JitterMinimized_VALIDATION.txt` | ten-pass jitter report | `131ab86a3b3b2934e65f1ca35ec32d1a75690fd495447224dab867245c17f56e` | SUPPORTING_ONLY |
| `KiwiFaceMotion_YawDecoupling_VALIDATION.txt` | rejected Yaw/X experiment report | `879d2560206fc918497b3903e62143ee54886411e676aed06c40b8ec7e9d5b84` | REJECTED_APPROACH_EVIDENCE |
| `KiwiFaceMotion_RollArcFix_VALIDATION.txt` | intended Roll fix report | `f503da5dd08799bb229054f412172fe8916374cfbbef7f1194bbf169fa382778` | VALIDATOR_ARTIFACT_MISMATCH |
| `KiwiPrecisionTrackingInstaller.cs` | v3.7.1 installer Hotfix1 source | `8b22914efa23dd5d4022607aa70f3ed1081e71e62655604d930eed6b27fc4e99` | STATICALLY_INSPECTED |
| `KiwiAvatarSystem_PureProject_v3.7.1_Hotfix1.zip` | earlier PureProject recovery package | `30fbdd86eb6991c9b0fb76ae3fb9a714394fafffaf1bcd954167ef92e3e40255` | HISTORICAL_CHAT_ARTIFACT |
| `Assets(2).zip` | user-provided next baseline | `SHA256=NOT_AVAILABLE_IN_NORMAL_CHAT` | UPLOADED_BUT_NOT_AUDITED |

Important historical design-SHA claims retained for traceability, but **not treated as current artifact authority**:

- Near-Raw validator design SHA: `9313c740fe209b521a829b0798daa8cb15d0e30d6c8afb6ffd6a3657420888d6`
- Jitter-Minimized validator design SHA: `b8de0d04221b7c6b3e05ed0ce43264470568038b06ba951e21f38dbb2a7ac56d`
- Yaw/X validator design SHA: `85df919bc0eacda40dc782c8516903665935196d7298717295856bbd9d8a364d`
- RollArc validator design SHA: `32b22e9a79ef7024b4252f5cd38c5593efc81ad02986aa5ae818e3523ebdc23d`

The above design-SHA claims are report provenance only; they must not be used as final deployed hashes unless the corresponding actual source bytes are recovered and reverified.

---

## RUNTIME EVIDENCE

### CORRECTNESS

Available:
- User-reported no-red-error state after Unity/VRM recovery.
- User-observed movement direction/jitter/Yaw coupling/Eye regression/Roll U-path.
- Unity screenshots earlier in chat.

Not available for the final tracking candidate:
- Formal CSV.
- Player.log tied to an exact final `KiwiFaceMotion.cs` SHA.
- MP4 tied to an exact final `KiwiFaceMotion.cs` SHA.

Result:
- User visual reports establish that several regressions were real.
- No exact final candidate has end-to-end correctness authority yet.

### PERFORMANCE

No clean performance A/B was produced in this chat for these v3.7.1 tracking edits.

Do not infer:
- exact latency improvement.
- exact jitter reduction.
- BigMouse/Instagram/TikTok/SNOW parity.

### VISUAL

Only interactive user observations/screenshots; no archived final MP4 for frame-by-frame comparison.

### PROVENANCE

The local `D:\KiwiAvatarSystem` Production was not directly inspected. Chat artifacts are not Production authority.

---

## CURRENT RESULT

### What is established

- Unity editor red-error blocker was cleared according to user observation.
- Direction requirements are explicit and stable.
- Face Landmarker remains Primary.
- Near-Raw, narrow micro-jitter suppression, actual-sample-first presentation, and Eye/Mouth-vs-Root authority separation are the desired design principles.
- The cheek/nose Yaw-X correction is rejected because it broke Eye tracking.
- The Roll U-path likely requires Root pivot/translation authority correction, not Eye/Mouth changes.

### What is **not** established

- The currently available `KiwiFaceMotion.cs` is **not proven to contain the claimed RollArcFix**.
- No final webcam runtime validation exists for an exact final source SHA.
- `Assets(2).zip` has not yet been audited or integrated.
- The requested three-way full architecture comparison and ten-pass final implementation has not yet been executed.
- This v3.7.1 chat branch is not automatically the current `D:\KiwiAvatarSystem` Production branch.

---

## OPEN ISSUES

1. Recover/rebuild an exact Roll-safe Root translation implementation and close final-artifact SHA parity.
2. Verify Eye tracking remains correct after any Root translation correction.
3. Resolve false X translation during pure Yaw without changing Eye/Mouth landmark presentation basis.
4. Verify pure Roll no longer produces U/arc Root translation.
5. Real webcam test: static, slow move, fast move, reversal, stop, Yaw-only, Roll-only, Pitch-only, down-right, depth, lost/reacquire.
6. Determine whether `Assets(2).zip` is:
   - an isolated legacy/pure-project branch to be upgraded, or
   - intended to overwrite/merge into current v44.55.x Production.
7. Audit `Assets(2).zip` before any broad rewrite.
8. Perform the user-requested minimum-three architecture comparison.
9. Select one design and review it ten times.
10. Implement model switching, runtime import, arbitrary shape adaptation, auto Eye/Mouth placement, spring/tail, in-app tuning, Windows/Android/iOS.
11. Project-wide authority conflict: latest project instructions say v44.55.24 is the next mainline task and tracking changes should not advance on current Production until that semantic/authority work is closed or the target is explicitly separated.

---

## NEXT ACTION

1. Materialize and SHA-256 `Assets(2).zip`; extract it to a clean temporary root without creating `(1)` duplicates.
2. Determine its lineage by comparing critical files/SHA against:
   - current local Production (if accessible through Codex/local tooling),
   - v3.7.1 PureProject/Hotfix1,
   - current project-wide v44.55.x authority.
3. Do **not** apply the current chat `KiwiFaceMotion.cs` as a RollArcFix; its bytes do not match the validator.
4. Inventory Tracking Core, FacePart, AvatarRuntimeManager/Profile, model import, SpringBone, UI, platform bridge.
5. Design at least three candidate architectures. Initial comparison set for the next chat:
   - A: Minimal Core Preservation + Root Translation Estimator patch.
   - B: Core Preservation + dedicated Tracking Presentation/Translation Estimator + strengthened Avatar Adapter/Profile/Hot Swap.
   - C: Fully modular tracking/presentation/avatar adaptation rewrite.
6. Score on latency, jitter, directional correctness, Eye/Mouth regression risk, arbitrary-model adaptability, import/hot-swap safety, spring compatibility, mobile compatibility, lifecycle safety, maintenance, and Production regression risk.
7. Select the highest-scoring architecture only after source/authority comparison; then perform ten explicit review passes.
8. Produce one final integrated artifact with exact SHA and final-write validation, then perform Unity compile/runtime checks.

Given existing project principles, option B is a strong hypothesis, but **must not be declared the winner before the actual `Assets(2).zip` and current Production are compared**.

---

## DO NOT CHANGE

Until new exact-source/runtime evidence exists:

- Do not replace Face Landmarker.
- Do not add a second detector/tracker as a workaround.
- Do not introduce strong smoothing/Kalman to hide jitter.
- Do not modify Eye/Mouth landmark coordinate semantics to compensate Root translation.
- Do not re-enable the rejected cheek/nose Yaw-X method without a new authority-safe design.
- Do not treat the current `KiwiFaceMotion.cs` as the proven RollArcFix.
- Do not modify stable Native Camera / DX12 / Presentation paths as a tracking workaround.
- Do not overwrite current local Production based only on this chat branch.
- Do not commit/push unless explicitly requested.
- Do not create `(1)`, `(2)` duplicate final filenames; use transactional replacement and exact SHA verification instead.

---

## HANDOFF

### Immediate context

The next chat should start from the user-provided `Assets(2).zip`, not from an assumed chat-generated `KiwiFaceMotion.cs`.

### Required first checks

1. Obtain actual `Assets(2).zip` bytes and SHA.
2. Extract and list critical files.
3. Identify all `FaceLandmarkerRunner.cs` / `KiwiFaceMotion.cs` duplicates semantically, not filename-only.
4. Hash critical source and compare with known branches.
5. Determine whether this is legacy v3.7.1 or current v44.55.x Production lineage.
6. Confirm the target Unity version/package versions from the actual project files.
7. Audit Eye/Mouth/FacePart transform hierarchy and Root authority before implementing Yaw/Roll translation decoupling.

### Tracking invariants to preserve

- Face Landmarker = Primary / source of truth.
- Right move -> right Root movement.
- Right turn -> kiwi's right turn.
- Right tilt -> kiwi's right tilt.
- Down-right -> kiwi's down-right.
- Yaw/Pitch/Roll must not create unintended Root translation.
- Eye/Mouth must not move Root.
- Eye/Mouth landmark presentation must remain coherent with the same sample/texture/crop/mask transaction.
- Near-Raw normal sample path should be as short as possible.
- Only abnormal samples/transitions should be locally suppressed.

### Full-system user requirements to carry forward

- near-zero perceived latency / BigMouse-like responsiveness target.
- near-zero jitter without sticky motion.
- easy in-app model switcher.
- external model import.
- arbitrary/non-spherical model support.
- automatic Eye/Mouth placement.
- natural SpringBone/tail/dangle behavior.
- in-app tuning of motion/features.
- Windows primary; Android/iOS support.
- iOS implementation/static/build prep only; no physical iOS validation required.
- compare >=3 designs, select one, review/fix it ten times.
- modify completed files only when justified.
- final filenames without `(1)` suffixes.

---

## PROJECT MASTER REPORT UPDATE CANDIDATES

Archive: `KiwiChat_PureProjectRecoveryAndNearRawTracking_Updated_20260903-JST.zip`
Topic: PureProjectRecoveryAndNearRawTracking
LastWorkUpdate: 2026-09-03
Status: PARTIALLY_DONE

Validated Decision candidates:
- Eye/Mouth coordinate path must remain separate from Root translation correction.
- Yaw/X cheek+nose decoupling rejected due runtime Eye regression.
- Final artifact must be SHA-verified after final write, not only before/candidate validation.

Rejected Approach candidate:
- cheek/nose Yaw-X decoupling as implemented in this chat.

Superseded Conclusion candidate:
- prior claim that the downloadable RollArcFix `KiwiFaceMotion.cs` was proven 20/20 PASS.

Open Issue candidates:
- exact RollArc candidate reconstruction + webcam validation.
- `Assets(2).zip` lineage/audit.
- full avatar-system three-design comparison and ten-pass implementation.

Next Action candidate:
- inspect actual `Assets(2).zip` + compare authority/SHA before any further code change.

Normal chat did not update any local Project Master Report directly.

---

## CHAT ARCHIVE INDEX

Archive: KiwiChat_PureProjectRecoveryAndNearRawTracking_Updated_20260903-JST.zip
Topic: PureProjectRecoveryAndNearRawTracking
LastWorkUpdate: 2026-09-03
Status: PARTIALLY_DONE
Supersedes: preliminary text-only current-chat summaries that treated RollArcFix delivery as proven
SupersededBy: NONE
NextArchiveCandidate: Assets2_ArchitectureComparisonAndIntegratedAvatarSystem

---

## SOURCE / PROVENANCE NOTES

Sources consulted while producing this archive:

- Current conversation messages and generated artifacts.
- `KiwiAvatarSystem_PermanentReport_2026-09-02.txt` as a preliminary current-chat history source; corrected here where archive-time artifact audit found stronger evidence.
- `KiwiAvatarSystem-情報源・Authority一覧.txt`.
- `KiwiAvatarSystem-統合最新版カスタム指示-情報源-作業履歴-今後計画-更新基準-2026-09-02.txt`.
- `通常チャット用-恒久REPORT・ZIP直接作成指示.txt`.
- Actual artifact bytes available under `/mnt/data` at archive creation.

No claim is made that local `D:\KiwiAvatarSystem` files were directly inspected in this normal chat.

---

## ARCHIVE VALIDATION

Expected archive content:

- `00_CHAT_PERMANENT_REPORT.md`

Report encoding: UTF-8
Archive filename timestamp precision: DATE_ONLY, because the exact minute of the last substantive technical work before the archive request is not independently available and was not guessed.

ZIP SHA-256 is intentionally reported outside this file after ZIP creation to avoid self-reference.
