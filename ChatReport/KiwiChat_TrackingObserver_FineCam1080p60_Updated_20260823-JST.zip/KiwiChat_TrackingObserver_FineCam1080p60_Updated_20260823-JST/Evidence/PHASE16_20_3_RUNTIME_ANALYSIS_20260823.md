# Phase16.20.3 runtime diagnosis

## Input run
- Unity 6000.0.80f1
- DX12
- CSV: KiwiFrameComparison_20260823_230652.csv
- MP4 duration: about 39.2 s
- CSV duration: about 39.93 s
- CSV rows: 1429

## Camera
- sourceWidth/sourceHeight: **1280x720 for 100% of rows**
- cameraFresh: **1397 / 1429 = 97.8%**
- observed fresh-event count over CSV duration: about **35.0 events/s**
- CSV row sampling rate: about **35.8 rows/s**
- runnerFreshSourceHz median: **39.49 Hz**
- renderFps median: **37.41 fps**

Interpretation: the camera is fresh on nearly every rendered frame, but the
selected source mode is still 720p. Because the Unity render loop is below
60 fps, cameraFresh cannot prove/disprove an underlying 60-fps device stream.

## Inference / age
- inferenceLatencyMs median: **76.34 ms**
- inferenceLatencyMs p95: **81.50 ms**
- inferenceAcceptedSourceAgeMs median: **78.18 ms**
- inferenceAcceptedSourceAgeMs p95: **82.86 ms**
- inferenceDroppedFreshCount: **0**
- inferenceDiscardedStaleSourceCount: **0**

## Authority / transaction integrity
- quality10LegacyWriteViolationCount: **0**
- handoffAuthorityViolationCount: **0**
- facePartPresentationEpochViolationCount: **0**
- faceTextureMissCount: **0**
- faceTextureHoldCount: **0**
- faceTextureExternalWriterCount: **0**

This means the camera-profile failure is isolated from Root authority,
Provider handoff ownership, and FacePart transaction integrity.

## Root cause found in current project source
The current AppSettings has a separate CM831/UGREEN preferred profile at
1280x720@60, and BuildWebCamSource forwards it to WebCamSource. WebCamSource
uses that profile whenever the camera name matches the preferred keywords.
Therefore changing only `_preferredDefaultWebCamWidth` cannot override CM831.

## Correction
Phase16.20.3 changes the dedicated preferred profile itself to 1920x1080@60,
preserves all existing fallback modes, and leaves tracking/presentation code
untouched.
