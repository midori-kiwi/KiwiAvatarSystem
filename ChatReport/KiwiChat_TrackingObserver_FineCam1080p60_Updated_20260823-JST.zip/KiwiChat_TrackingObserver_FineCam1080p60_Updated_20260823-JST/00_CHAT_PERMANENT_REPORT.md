# KiwiAvatarSystem Chat Permanent Report

ChatTopic: TrackingObserver_FineCam1080p60
ChatTitle: Phase16.19.5 Live/Matched Observer Separation → Phase16.20 DX11/DX12 Inference A/B → Phase16.20.3 FineCam Preferred 1080p60
ArchiveName: KiwiChat_TrackingObserver_FineCam1080p60_Updated_20260823-JST.zip
LastWorkUpdate: 2026-08-23
LastWorkUpdatePrecision: DATE_ONLY
ArchiveCreated: 2026-09-02T23:21+09:00
ArchiveTimestampBasis: LAST_RELEVANT_WORK_BEFORE_ARCHIVE_REQUEST
Project: D:\KiwiAvatarSystem
Unity: 6000.0.80f1
CurrentInvestigationVersion: KiwiAvatarSystem v5.1.0 Phase16.20.3
Status: SUPERSEDED

Archive:
KiwiChat_TrackingObserver_FineCam1080p60_Updated_20260823-JST.zip
Topic: Tracking observer separation, FacePart strict contract, DX11/DX12 inference A/B, FineCam Lite 4K 1080p60 profile investigation
LastWorkUpdate: 2026-08-23
Supersedes: Phase16.20.2 generic-width-only FineCam profile conclusion
SupersededBy: 2026-09-02 project authority: Windows Native Camera Path B SystemMemoryNV12 / 1920x1080@60 and later v37-v44/v44.55.x work
NextArchiveCandidate: current project v44.55.24 Pair-Bound Shadow Output Snapshot investigation

---

## EXECUTIVE SUMMARY

This chat covered four connected technical themes:

1. Phase16.19.5 separated **LIVE CAMERA** from **MATCHED LANDMARK DEBUG** so that the normal camera preview no longer visually froze while a semantic-matched diagnostic snapshot was intentionally held.
2. Phase16.19.5.1 repaired the persistent FacePart strict runtime contract after Release Candidate Preflight correctly exposed that local `FacePartCropper.cs` / `KiwiTrackingQuality10Controller.cs` still contained pre-contract defaults.
3. Phase16.20 measured Unity Inference Engine under DX11 and DX12. DX12 substantially reduced per-sample inference/source age, but one A/B run regressed source/result/canonical cadence, so DX12 was **not** promoted to the baseline in this chat.
4. Phase16.20.2 attempted to request UGREEN FineCam Lite 4K (CM831) at 1920x1080@60 through generic MediaPipe AppSettings. Runtime remained 1280x720. Source audit then found a **dedicated CM831/UGREEN preferred camera profile at 1280x720@60** that bypassed the generic preferred width. Phase16.20.3 corrected the preferred-profile authority to 1920x1080@60 with static validation PASS, but Unity compile/runtime retest after that correction was not completed in this chat.

At archive creation time, newer project-wide authority dated 2026-09-02 has superseded the pending Phase16.20.3 path: current Windows Production is documented as **UGREEN Camera 4K, 1920x1080@60, Native NV12, DX12, Path B SystemMemoryNV12**, and LIVE CAMERA is documented as Production Accepted. Therefore this archive preserves the design and debugging history, but its pending WebCamTexture/AppSettings migration must **not** be restored as current Production without checking current local Production first.

---

## OBJECTIVE

Primary objective during the chat:

- preserve established tracking/authority correctness;
- fix an observer/debug presentation issue without changing Tracking Core;
- investigate the dominant inference latency;
- determine whether DX12/DirectML-like acceleration was beneficial;
- establish UGREEN FineCam Lite 4K as the assumed Windows camera and test a 1920x1080@60 capture request;
- keep camera/inference/presentation problems separated so no tracking-math workaround hides upstream issues.

---

## CONFIRMED FACTS

### Phase16.19.5 observer separation

The matched camera diagnostic introduced in Phase16.19.3 intentionally held a semantic-timestamp-matched snapshot until the next semantic result. That behavior could look like a camera freeze during fast motion even while the underlying WebCamTexture was advancing.

The adopted design separated:

- LIVE CAMERA = latest live texture;
- MATCHED LANDMARK DEBUG = semantic-timestamp-matched camera snapshot + canonical landmarks.

The Phase16.19.4 mirror correction remained in place: camera-preview mirror handling was retained while the canonical landmarks did not receive another horizontal mirror.

### Phase16.19.5.1 FacePart contract

The Full Preflight screenshot showed 14 critical failures. They included both missing migration markers and unsafe active defaults:

- `enablePrediction = true`
- `compensateMatchedFrameAge = true`
- `directPositionDuringMotion = true`

The issue was not the Phase16.19.5 display separation itself. The Preflight already expected the persistent Phase16.19 FacePart runtime contract, while the local runtime files still represented the prior state.

The hotfix restored the intended strict contract:

- `enablePrediction = false`
- `compensateMatchedFrameAge = false`
- `directPositionDuringMotion = false`
- `hidePartsWhenLost = false`

and reasserted the contract from the policy/runtime side rather than weakening the Preflight.

Static validation artifact is preserved in `Evidence/PHASE16_19_5_1_PERSISTENT_FACEPART_CONTRACT_REPAIR_VALIDATION.json`.

### Phase16.19.5.1 Runtime

The later same-run MP4 + CSV analysis found the non-regression contracts intact across the run:

- single presentation authority = true;
- Quality10 policy-only = true;
- legacy Quality10 Root writes = 0;
- handoff authority violations = 0;
- strict FacePart presentation epoch = true;
- FacePart prediction disabled = true;
- FacePart matched-age compensation disabled = true;
- FacePart direct-motion path disabled = true;
- FacePart epoch violations = 0.

The Live/Matched separation behaved as intended: semantic frames could hold while the live camera kept advancing.

### DX11 baseline

The chat fixed a stable-window rule of discarding the first 2.0 seconds for the DX11 baseline.

Preserved baseline summary:

- inference latency median: 101.18 ms
- inference latency P95: 105.86 ms
- accepted source age median: 102.47 ms
- inference completion interval median: 35.40 ms
- runner fresh source median: 48.54 Hz
- runner result median: 27.64 Hz
- canonical adoption median: 29.67 Hz
- render median: 48.45 FPS
- inference schedule CPU median: 0.711 ms
- inference decode CPU median: 0.128 ms

This supported the conclusion that schedule/decode CPU time was not the dominant latency source.

### DX12 A/B

The first DX12 A/B showed strong per-sample latency improvement:

- inference latency: 101.18 ms → 56.64 ms
- accepted source age: 102.47 ms → 57.54 ms

but cadence regressed in that run:

- runner fresh source: 48.54 Hz → 20.95 Hz
- runner result: 27.64 Hz → 20.13 Hz
- canonical adoption: 29.67 Hz → 20.32 Hz

Therefore the predeclared cadence gate was not met, and DX12 was not promoted to the baseline in this chat.

Preserved evidence:

- `Evidence/KiwiPhase16_20_DX11_Baseline.json`
- `Evidence/KiwiPhase16_20_DX11_vs_DX12_Comparison.csv`
- `Evidence/KiwiPhase16_20_DX12_AB_Result.json`

### FineCam Phase16.20.2 Runtime

The user supplied:

- `KiwiAvatarSystem - Face Landmark Detection - Windows, Mac, Linux - Unity 6.0 (6000.0.80f1) _DX12_ 2026-08-23 23-06-57.mp4`
- `KiwiFrameComparison_20260823_230652.csv`

The CSV had about 39.93 seconds / 1429 rows.

Confirmed during that analysis:

- source width = 1280 for every row;
- source height = 720 for every row;
- cameraFresh = 1397 / 1429 rows = 97.8%;
- render FPS median ≈ 37.4;
- inference latency median ≈ 76.34 ms;
- inference latency P95 ≈ 81.50 ms;
- accepted source age median ≈ 78.18 ms;
- accepted source age P95 ≈ 82.86 ms;
- inferenceDroppedFreshCount = 0;
- inferenceDiscardedStaleSourceCount = 0;
- Quality10 legacy write violations = 0;
- handoff authority violations = 0;
- FacePart presentation epoch violations = 0;
- FaceTexture misses = 0;
- FaceTexture holds = 0;
- FaceTexture external writer count = 0.

This proved that Phase16.20.2 had **not** produced a 1920x1080 source in that run, while camera freshness at the render-observer boundary was high.

### Phase16.20.2 root cause

Current project source inspected through GitHub showed:

`Assets/MediaPipeUnity/Samples/Common/Scripts/AppSettings.cs`

contained a dedicated preferred camera profile:

- preferred keywords: `CM831`, `UGREEN`
- `_preferredWebCamProfileWidth = 1280`
- `_preferredWebCamProfileHeight = 720`
- `_preferredWebCamProfileFrameRate = 60`

and `BuildWebCamSource()` forwarded those fields.

Current `WebCamSource.cs` then used the dedicated preferred profile whenever the camera name matched the preferred keywords.

Therefore changing only `_preferredDefaultWebCamWidth` to 1920 could not override the CM831-specific 1280x720@60 profile.

### Phase16.20.3 static result

Phase16.20.3 changed the **preferred-device profile authority** rather than tracking logic:

- preferred default width = 1920
- preferred profile width = 1920
- preferred profile height = 1080
- preferred profile frame rate = 60
- ensure `CM831` and `UGREEN` preferred keywords
- ensure 1920x1080@60 exists

It intentionally preserved 1920x1080@30 and all other resolution modes.

Static validation PASS included:

- contract marker present;
- lexical bracket balance PASS;
- required profile fields present;
- 1920x1080@60 target constants present;
- existing resolution modes not deleted;
- no Root transform write scan hit;
- no FaceLandmarkerRunner / KiwiFaceMotion / ProviderHub / KiwiInferenceFaceTracker runtime-type mutation scan hit;
- no Kalman;
- no SmoothDamp;
- backup path present;
- post-write validation present.

Unity compile and Runtime retest after Phase16.20.3 were **not** executed in this chat.

---

## PUBLIC DESIGN PRINCIPLES

The external/official research used in this chat supported these principles:

1. **Tracking cadence and rendering/display cadence are different authorities.**
   Commercial VTuber software and open systems expose camera/tracking rates separately from avatar/display presentation.

2. **Optional camera/debug preview is not tracking authority.**
   VTube Studio, Warudo, Animaze, VSeeFace/OpenSeeFace and similar tools publicly separate tracking operation from preview/visualization behavior.

3. **Live camera texture and explicit snapshot are distinct concepts.**
   AR systems such as Lens Studio expose a live camera texture and snapshot/copy operations as separate concepts. This maps cleanly to Kiwi's LIVE CAMERA vs MATCHED DEBUG separation.

4. **MediaPipe LIVE_STREAM can drop inputs to reduce latency.**
   Face Landmarker async/live-stream semantics do not guarantee one semantic result for every input camera frame. A live preview therefore must not wait for semantic completion.

5. **Do not perturb inference frame-copy synchronization to repair an observer-only presentation issue.**
   MediaPipeUnityPlugin history includes fixes where improper GPU copy timing could show older frames. Production inference timing should not be changed merely to make a debug view look live.

6. **Requested camera FPS is not proof of delivered FPS.**
   Camera/driver/runtime negotiation must be verified with actual runtime evidence.

7. **Render-bound `didUpdateThisFrame` is an observer of camera updates, not an independent 60-Hz capture clock.**
   When the Unity render loop is below 60 FPS, a 60 FPS camera stream cannot be proven solely from one observation per render frame.

---

## INFERENCES / HYPOTHESES

These were hypotheses or provisional interpretations, not Production facts:

- The DX12 latency reduction was consistent with the possibility of a more favorable GPU/DirectML path for Unity Inference Engine, but this chat did not prove the exact internal acceleration mechanism for every operator.
- The first DX12 cadence regression might have been Editor-specific, texture-upload related, GPU contention related, or a combination. The planned Standalone isolation was not completed here.
- FineCam 1080p60 was expected to reduce camera-sampling latency and improve fast-motion temporal resolution, but the Phase16.20.3 runtime proof did not occur in this chat.
- A `cameraFresh` rate near render FPS does not prove full physical 60 FPS capture.

---

## PRODUCTION AUTHORITY

### Authority actually available in this chat

1. same-run Runtime CSV + MP4 uploaded by the user;
2. current project source files inspected from the user's GitHub repository;
3. generated static validation artifacts;
4. official/public source research;
5. prior project handoff/context.

### Local Production limitation

`LOCAL_PRODUCTION_NOT_DIRECTLY_VERIFIED`

Normal chat did not directly inspect `D:\KiwiAvatarSystem` at archive creation. Local Production remains higher authority than this archive.

GitHub main was used for source investigation only and must not be treated as higher authority than newer local cumulative Phase16 changes.

### Archive-time cross-check against newer project authority

The 2026-09-02 project authority files state that later work established:

- Windows / DX12;
- UGREEN Camera 4K 1920x1080@60;
- Native NV12;
- Path B SystemMemoryNV12;
- LIVE CAMERA Production Accepted / CLOSED;
- later v37-v44 and v44.55.x investigations.

Therefore the Phase16.20.3 WebCam/AppSettings migration is **historical and superseded as current Production direction**.

---

## WORK PERFORMED

### 1. Phase16.19.5 design research

Purpose:
Remove apparent camera freeze without changing tracking math.

Result:
Selected dual observer presentation:
- live latest camera;
- matched semantic snapshot debug.

Impact:
Kept diagnostic epoch correctness while preventing matched-debug hold from masquerading as a live-camera freeze.

Status:
PASS at design/static level, later supported by Runtime.

### 2. Phase16.19.5 implementation

Modified observer/preflight only.

Did not modify:
- FaceLandmarkerRunner;
- KiwiFaceMotion;
- ProviderHub;
- KiwiInferenceFaceTracker;
- FacePart Production transaction;
- thresholds;
- 3-lane inference.

Status:
Static PASS.

### 3. Preflight failure diagnosis

Purpose:
Investigate 14 Critical failures after the observer change.

Result:
Identified missing persistent FacePart runtime contract in local runtime sources.

Decision:
Fix runtime defaults/contract; do not weaken validator.

Status:
Root cause confirmed from source/preflight messages.

### 4. Phase16.19.5.1 hotfix

Purpose:
Persist strict FacePart runtime contract.

Result:
Safe defaults + runtime/policy reassertion.

Status:
Static PASS; Runtime contract later PASS.

### 5. Phase16.20 DX11 baseline

Purpose:
Freeze a numeric baseline before Graphics API experiment.

Result:
~101 ms inference service/source age with ~0.7 ms scheduling CPU and ~0.13 ms decode CPU.

Impact:
Focused investigation on GPU/inference service rather than decode/scheduling.

### 6. Phase16.20 DX12 A/B

Purpose:
Measure whether DX12 materially improves inference.

Result:
Large latency win, cadence regression in the tested run.

Decision:
Do not promote DX12 baseline yet.

Status:
PARTIAL / inconclusive for Production adoption.

### 7. FineCam Lite 4K assumption

Purpose:
Define the intended Windows webcam target.

Decision:
Prefer 1920x1080@60 for tracking over 4K30.

Status:
Design target only at this chat stage.

### 8. Phase16.20.2 generic camera profile

Purpose:
Request 1920x1080@60 without rewriting Tracking Core or MediaPipe package source.

Result:
Static migration created, but Runtime remained 1280x720.

Status:
FAIL for intended capture-mode effect.

### 9. Source audit after Phase16.20.2 failure

Purpose:
Find why runtime remained 720p.

Result:
Found dedicated CM831/UGREEN preferred profile authority at 1280x720@60.

Status:
Root cause confirmed.

### 10. Phase16.20.3 preferred-profile correction

Purpose:
Correct the actual camera-profile authority.

Result:
Editor migration updated to target preferred profile 1920x1080@60 while preserving fallback modes.

Status:
STATIC PASS / RUNTIME NOT TESTED IN THIS CHAT.

---

## VALIDATED DECISIONS

### Decision: Separate LIVE CAMERA and MATCHED LANDMARK DEBUG

Reason:
Matched semantic diagnostic snapshots are allowed to hold; live preview must not inherit semantic cadence.

Evidence:
Phase16.19.5 Runtime analysis and semantic-hold/live-camera-advance behavior.

Regression constraints:
Do not remove matched epoch coherence. Do not add prediction/interpolation to diagnostic landmarks solely to align with live camera.

Still current:
Conceptually yes; later project authority documents LIVE CAMERA as Production Accepted.

### Decision: Keep Preflight strict and repair FacePart runtime contract

Reason:
The validator exposed real unsafe defaults/missing contract markers.

Evidence:
Critical messages + source comparison + Phase16.19.5.1 runtime contract fields.

Regression constraints:
No new FacePart prediction/matched-age/direct-motion residual path without independent evidence.

Still current:
The broader same-sample/strict-epoch principle remains current.

### Decision: Do not remove 3-lane inference based on the ~100 ms single-job latency

Reason:
The lanes were being used to overlap expensive jobs rather than create a stale FIFO.

Evidence:
DX11 completion/canonical throughput and prior single-flight findings summarized in this chat.

Regression constraints:
Measure before changing scheduling topology.

Still current:
Historical decision; verify against current v44.55.x Production before reuse.

### Decision: DX12 not promoted after first A/B

Reason:
Latency improved strongly but cadence gate regressed.

Evidence:
Preserved DX11/DX12 comparison.

Regression constraints:
Graphics API adoption must include source/result/canonical cadence and authority safety, not latency alone.

Still current:
This exact conclusion is historical; later project state uses DX12 Production.

### Decision: FineCam preferred-profile authority was the correct Phase16.20.3 fix

Reason:
Dedicated CM831/UGREEN profile bypassed generic width.

Evidence:
AppSettings/WebCamSource source audit and 720p runtime.

Regression constraints:
Do not change tracking math to repair camera profile selection.

Still current:
No. It is archived as the correct fix for that historical WebCamSource path, but current Production later moved to Native Path B.

---

## REJECTED APPROACHES

### Rejected: Replace matched snapshot with latest camera

Why considered:
Would visually avoid hold.

Why rejected:
Destroys camera/semantic epoch coherence in the diagnostic.

Evidence:
Purpose of Phase16.19.3 transaction matching.

Revisit condition:
None unless the panel is explicitly redefined as non-diagnostic.

### Rejected: Predict/interpolate matched landmarks onto live camera

Why considered:
Could make overlay appear smoother.

Why rejected:
Diagnostic would stop representing an actually measured sample and would introduce another temporal layer.

Revisit condition:
Only as a clearly separate non-authoritative visualization.

### Rejected: Change tracking/inference cadence to fix matched debug freeze

Why considered:
Freeze appeared correlated with semantic cadence.

Why rejected:
Root cause was observer presentation, not camera freeze.

Revisit condition:
Only for independently measured inference/cadence problems.

### Rejected: Weaken Phase16.19 Preflight

Why considered:
Preflight produced 14 Critical errors.

Why rejected:
It was detecting real missing persistent-contract state.

Revisit condition:
Only if the validator itself is later proven wrong.

### Rejected: Promote DX12 immediately based only on ~44% latency improvement

Why considered:
Very large inference latency reduction.

Why rejected:
Runner fresh/result/canonical cadence regressed below the predeclared gate.

Revisit condition:
Independent current Production A/B with all correctness/cadence gates.

### Rejected: Delete 1920x1080@30 in Phase16.20.3

Why considered:
Earlier generic comparator concern.

Why rejected:
Current preferred-profile comparator can explicitly target 60 FPS; deleting the 30 FPS mode would unnecessarily reduce fallback compatibility.

Revisit condition:
Only if actual driver negotiation proves fallback mode ambiguity.

---

## SUPERSEDED CONCLUSIONS

### OLD
The Phase16.20.2 generic `_preferredDefaultWebCamWidth=1920` migration should make FineCam use 1080p60.

### NEW
CM831/UGREEN had a dedicated preferred profile at 1280x720@60, so the generic width was not the actual authority.

### WHY
Runtime remained 1280x720 and source audit found the dedicated profile path.

### EVIDENCE
2026-08-23 DX12 MP4/CSV + AppSettings/WebCamSource source.

---

### OLD
The first DX12 cadence regression justified leaving DX11 as the assumed Production direction.

### NEW
Archive-time 2026-09-02 project authority documents Windows DX12 as current Production and later Native Camera Path B work.

### WHY
Subsequent project work superseded the early Editor/WebCamTexture A/B.

### EVIDENCE
`KiwiAvatarSystem-統合最新版カスタム指示-情報源-作業履歴-今後計画-更新基準-2026-09-02.txt`
and `KiwiAvatarSystem-情報源・Authority一覧.txt`.

---

### OLD
Phase16.20.3 FineCam WebCamSource migration was the immediate next Production test.

### NEW
Historical only. Current Production authority later establishes Native Camera Path B SystemMemoryNV12 at 1920x1080@60.

### WHY
Later Native camera work resolved and replaced this branch of investigation.

### EVIDENCE
2026-09-02 project authority files.

---

## OBSERVER / VALIDATOR FINDINGS

1. **Matched camera debug hold was observer semantics, not proof of camera freeze.**
   Production camera freshness and matched semantic snapshot cadence had to be measured separately.

2. **Preflight was not the defect in the 14-Critical case.**
   The runtime source was missing the persistent contract expected by the validator.

3. **`cameraFresh` is render-bound.**
   A render loop below 60 FPS cannot prove full 60-Hz camera delivery using `WebCamTexture.didUpdateThisFrame` alone.

4. **Do not use observer-heavy runs as final performance authority.**
   The project rule remains: correctness observer first; dedicated performance A/B after semantic correctness.

5. **GitHub source was investigative authority only.**
   It was useful for AppSettings/WebCamSource behavior, but local cumulative Production was not directly verified.

---

## FILES / SHA256

### Local Production

Path:
`D:\KiwiAvatarSystem`

Role:
Production project root.

SHA256:
NOT_APPLICABLE_DIRECTORY

Verification:
LOCAL_PRODUCTION_NOT_DIRECTLY_VERIFIED

Current/Obsolete:
Current Production is external to this normal-chat archive.

### Phase16.20.3 generated migration

Path:
`Assets/KiwiAvatarSystem/Editor/KiwiFineCamLite4KProfileMigration.cs`

Role:
Historical Editor migration correcting CM831 preferred-profile authority.

SHA256:
A01B27D082701CD11FF3C36D135721941326B65641BE3E33FCB9D0985C625145

Before/After:
Phase16.20.2 generic-width-only logic → Phase16.20.3 dedicated preferred-profile correction.

Current/Obsolete:
OBSOLETE_AS_PRODUCTION_DIRECTION / HISTORICAL_REFERENCE

### Phase16.20.3 package generated in this chat

Filename:
`KiwiAvatarSystem_v5_1_0_Phase16_20_3_FineCamPreferredProfile1080p60.zip`

SHA256:
D888235C1EECD11B97F5F4A476949D9C883953858AF36198D68AC2464C915592

Current/Obsolete:
Historical implementation artifact; not current project Production authority.

### Current local critical-file SHA

`FaceLandmarkerRunner.cs`: SHA256=NOT_AVAILABLE_IN_NORMAL_CHAT
`KiwiFaceMotion.cs`: SHA256=NOT_AVAILABLE_IN_NORMAL_CHAT
`KiwiInferenceFaceTracker.cs`: SHA256=NOT_AVAILABLE_IN_NORMAL_CHAT
`KiwiTrackingProviderHub.cs`: SHA256=NOT_AVAILABLE_IN_NORMAL_CHAT
`FacePartCropper.cs`: SHA256=NOT_AVAILABLE_IN_NORMAL_CHAT
`KiwiTrackingQuality10Controller.cs`: SHA256=NOT_AVAILABLE_IN_NORMAL_CHAT

No SHA is inferred or copied from unrelated older reports.

---

## RUNTIME EVIDENCE

### `KiwiFrameComparison_20260823_230652.csv`

Authority:
CORRECTNESS + SUPPORTING PERFORMANCE

Purpose:
Verify Phase16.20.2 capture mode, freshness, inference age, and authority non-regression.

Result:
- source stayed 1280x720;
- cameraFresh 97.8% of sampled rows;
- inference median ~76.34 ms;
- accepted source age median ~78.18 ms;
- authority/FacePart/FaceTexture violation counters remained zero.

Archive:
Not duplicated as original CSV in this ZIP; key results are preserved in the report and analysis evidence.

### `KiwiAvatarSystem ... _DX12_ 2026-08-23 23-06-57.mp4`

Authority:
VISUAL

Purpose:
Same-run visual inspection of tracking/camera behavior.

Result:
Supported the corresponding runtime diagnosis; no reported authority/presentation corruption that would justify Tracking Core changes.

Archive:
Not duplicated due to size.

### Phase16.19.5.1 runtime CSV/MP4

Authority:
CORRECTNESS + VISUAL

Purpose:
Validate strict FacePart contract and Live/Matched separation.

Result:
PASS for the tested authority/epoch invariants.

Archive:
Original large evidence not duplicated; static contract JSON is preserved.

### `KiwiPhase16_20_DX11_Baseline.json`

Authority:
SUPPORTING PERFORMANCE

Archive:
Included.

SHA256:
F8AC55993DE2B17275F4491163DEF8AFBEBB55591596E84C79C21697ED388632

### `KiwiPhase16_20_DX11_vs_DX12_Comparison.csv`

Authority:
SUPPORTING PERFORMANCE

Archive:
Included.

SHA256:
ABD7862B755451E712237535DA485E0689E6E082B0731A8951BEC501619B41DB

### `KiwiPhase16_20_DX12_AB_Result.json`

Authority:
SUPPORTING PERFORMANCE / DECISION

Archive:
Included.

SHA256:
7DD4774AF613403FD208F9A60AC5E72E8010D0FCD25741CF76366B6CE6FE37F1

### `PHASE16_20_3_STATIC_VALIDATION.json`

Authority:
STATIC_ONLY

Archive:
Included.

SHA256:
5740F04B5771B48D8BC98E2D455CA142B85D549D59C7D5E5B2DDBF810601F784

### `PHASE16_20_3_RUNTIME_ANALYSIS_20260823.md`

Authority:
CORRECTNESS / SUPPORTING_ONLY

Archive:
Included.

SHA256:
BD76ECFC5DD39A11CEA0AD030958C31E8407FAC7DC56BBAF0323A69C2BC6D610

---

## CORRECTNESS / PERFORMANCE / VISUAL / PROVENANCE SEPARATION

### Correctness

Strongest chat conclusions:

- Phase16.19.5 Live/Matched observer separation preserved semantic-match diagnostic behavior.
- Phase16.19.5.1 strict FacePart contract was restored.
- Tested authority/FacePart violation counters remained zero.
- FineCam Phase16.20.2 runtime remained 1280x720.
- Dedicated preferred-profile selection caused the generic-width migration to miss its intended target.

### Performance

DX11/DX12 measurements were useful A/B evidence but should not be treated as current Production performance authority in 2026-09-02 because subsequent pipeline/Native changes supersede them.

### Visual

MP4 was used to validate observer/presentation behavior. It was not used to infer hidden internal pipeline semantics beyond what the CSV/source supported.

### Provenance

Local Production was not directly inspectable in this normal chat.
GitHub main source was used only as lower authority than local Production.

---

## CURRENT RESULT

### At the end of this chat's technical work

Phase16.19.5.1:
Runtime Tracking/Authority = PASS for the tested fields.

Phase16.20:
DX12 inference-latency benefit = confirmed in A/B.
DX12 Production adoption = not confirmed in this chat.

Phase16.20.2:
FineCam intended 1080p60 capture effect = FAIL.
Cause = dedicated CM831/UGREEN 1280x720@60 preferred profile overrode generic width.

Phase16.20.3:
Preferred-profile 1920x1080@60 correction = STATIC PASS.
Unity compile = NOT VERIFIED IN THIS CHAT.
Runtime after correction = NOT VERIFIED IN THIS CHAT.

### At archive creation, after cross-checking newer project authority

This chat is historical/superseded.

Current project authority dated 2026-09-02 reports the Windows camera Production direction as Native Path B SystemMemoryNV12, 1920x1080@60, DX12, with LIVE CAMERA accepted. The active project investigation is later v44.55.x semantic/transaction authority work, not Phase16.20.3 camera-profile migration.

---

## OPEN ISSUES

Historical open issues at chat end:

1. Would Phase16.20.3 actually negotiate 1920x1080@60 in Unity?
2. What was the real physical capture cadence independent of render-bound `cameraFresh`?
3. Would DX12 retain latency gains once source cadence and standalone confounds were removed?
4. Would Standalone DX11/DX12 behave differently from Editor?
5. Would FineCam 1080p60 improve canonical responsiveness without increasing GPU/resource contention?

Archive-time resolution status:
These are **not current project blockers** unless newer Native/Production evidence reopens them.

Current project blocker belongs to the later project authority:
v44.55.24 Pair-Bound Shadow Output Snapshot / Production output transaction semantic authority.

---

## NEXT ACTION

For this historical chat itself:
No direct continuation should be performed from Phase16.20.3 without checking current local Production.

For the current KiwiAvatarSystem project:
Follow the newer 2026-09-02 authority and continue the currently active v44.55.24 Pair-Bound Shadow Output Snapshot investigation.

Before touching any critical file:
1. inspect current local Production;
2. record exact SHA256;
3. compare latest same-Production Runtime;
4. ensure the work is not already superseded;
5. preserve the currently validated Native/Tracking/LIVE CAMERA paths.

---

## DO NOT CHANGE

Unless new independent evidence requires it:

- Face Landmarker Primary / Source of Truth;
- latest-frame design;
- no FIFO/stale queue;
- persistent ROI / short-dropout tolerance;
- single rigid Head authority;
- Provider normalization single owner;
- Root vs Eye/Mouth separation;
- FaceTexture/Crop/Mask same-sample transaction;
- strong smoothing/Kalman prohibition as upstream-workaround;
- thresholds without measurement;
- `KiwiFaceMotion.cs` as camera-cadence workaround;
- `KiwiInferenceFaceTracker.cs` as camera-cadence workaround;
- current stable Native Camera Production path;
- LIVE CAMERA accepted path;
- Production lane.input direct oracle rejection;
- Semantic-PASS-before-Production-CPU rule.

Do not resurrect Phase16.20.3 AppSettings/WebCamTexture migration simply because it is present in this archive.

---

## PROJECT MASTER REPORT UPDATE CANDIDATES

Archive Name:
`KiwiChat_TrackingObserver_FineCam1080p60_Updated_20260823-JST.zip`

LastWorkUpdate:
2026-08-23 (DATE_ONLY)

Validated Decision:
Live camera and semantic-matched debug presentation must be separated.

Validated Decision:
Persistent FacePart strict contract should be repaired at runtime/source rather than by weakening Preflight.

Rejected Approach:
Promote DX12 solely on inference latency.

Superseded Conclusion:
Generic preferred width controls CM831 capture mode.

Open Issue:
Historical only; later Native Path B supersedes the WebCamSource camera-profile branch.

Current Next Action:
Use current 2026-09-02 authority and proceed with v44.55.24, not Phase16.20.3.

---

## HANDOFF

If this archive is opened without the original chat:

1. Treat it as a **historical** Phase16.19.5 → Phase16.20.3 archive.
2. Do not assume the Phase16.20.3 generated script is current Production.
3. Current local `D:\KiwiAvatarSystem` + SHA is higher authority.
4. The major durable design result from this chat is the observer separation:
   - LIVE CAMERA uses current/latest presentation;
   - MATCHED DEBUG uses matched semantic transaction;
   - observer presentation issues must not be fixed by mutating Tracking Core.
5. The durable validation lesson is:
   - Preflight/Observer can be wrong, but they must be audited rather than bypassed;
   - in the 14-Critical case the validator was exposing a real source/runtime contract mismatch.
6. The DX11/DX12 data demonstrates that a backend/API can improve latency while worsening cadence; adoption requires both.
7. The FineCam diagnosis demonstrates that camera mode authority must be traced through actual selection logic, not inferred from one generic preference field.
8. Newer 2026-09-02 project authority supersedes this camera-profile branch:
   - Native Path B SystemMemoryNV12;
   - 1920x1080@60;
   - DX12;
   - LIVE CAMERA accepted;
   - active work moved to v44.55.x transaction/semantic authority.
9. For any new change, start from current local Production, verify SHA/source identity, and then follow:
   external research → similar-system comparison → Kiwi audit → root cause → alternatives → best single design → implementation → static validation → Runtime correctness → Performance A/B → Visual.

---

## ARCHIVE VALIDATION NOTES

Archive timestamp uses the last confidently known technical work **date**, not the 2026-09-02 archive request time.

Exact completion time of Phase16.20.3 was not independently verifiable from the available archive context, so no minute was guessed.

LastWorkUpdatePrecision:
DATE_ONLY

ArchiveTimestampBasis:
LAST_RELEVANT_WORK_BEFORE_ARCHIVE_REQUEST

Outer ZIP SHA256 is intentionally reported outside this file to avoid self-reference.
