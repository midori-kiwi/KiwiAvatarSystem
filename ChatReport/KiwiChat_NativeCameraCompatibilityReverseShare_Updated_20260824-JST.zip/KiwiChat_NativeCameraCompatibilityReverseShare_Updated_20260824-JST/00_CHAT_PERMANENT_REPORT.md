# KiwiAvatarSystem Chat Permanent Report

ChatTopic: NativeCameraCompatibilityReverseShare
ChatTitle: Windows Native Camera 1080p60 / Unity D3D12 Compatibility Reverse Share診断
ArchiveName: KiwiChat_NativeCameraCompatibilityReverseShare_Updated_20260824-JST.zip
LastWorkUpdate: 2026-08-24
LastWorkUpdatePrecision: DATE_ONLY
ArchiveCreated: 2026-09-02T23:21:00+09:00
ArchiveTimestampBasis: LAST_RELEVANT_WORK_BEFORE_ARCHIVE_REQUEST
Project: D:\KiwiAvatarSystem
Unity: 6000.0.80f1 / Windows / DX12
CurrentInvestigationVersion: Phase16.20.7 v11 EXTERNAL_TEXTURE_FORMAT_FIX
Status: SUPERSEDED
ArchiveSHA256: NOT_EMBEDDED_SELF_REFERENCE

ArchiveStatusNote:
このREPORTは2026-08-24時点のNative Camera統合診断履歴を恒久保存する。
2026-09-02時点のProject AuthorityではNative Camera ProductionはPath B SystemMemoryNV12で安定済みとされており、
本チャット終盤の「Compatibility Reverse ShareをProduction統合する」という当時のNext Actionは現在のProduction AuthorityとしてはSUPERSEDED。
LOCAL_PRODUCTION_NOT_DIRECTLY_VERIFIED。

## EXECUTIVE SUMMARY

本チャットでは、Unity WebCamTextureの1920x1080入力が約20Hzに制限される問題に対し、
Windows Media Foundation + D3D11/D3D12 Native Camera経路をUnity 6 / DX12へ統合するため段階診断を行った。

Standaloneでは1080p60 Native NV12取得とD3D11 GPU処理が成立していたが、初期Unity統合ではPlay時フリーズが発生。
RAW / COPY / CONVERT / SHAREへ分解し、RAW・COPY・CONVERTはPASS、SHAREでフリーズを確認した。

D3D11-owned shared resourceをUnity D3D12側で開くforward-shareは不採用。
Unity D3D12-owned resourceをD3D11側で開くreverse-shareでは通常CreateCommittedResourceだとOpenSharedResource1がE_INVALIDARG。
そこでID3D12CompatibilityDevice::CreateSharedResourceへ変更し、D3D11-facing flagsを明示したところ、06/07/08/09診断が正式PASSした。

09初回は`PASS_TEXTURE_CONSUMPTION_ALIVE`が出た一方、Native resource UNORM(28)に対しUnityがsRGB(29) SRVを要求し、
`non compatible format` / `NULL or empty texture`エラーを出していたため偽陽性と判定。
Unity CreateExternalTextureを`linear=true`へ修正後、最終09は以下で正式PASSした。

- capture=291
- presented=180
- dropped=0
- producerFenceCompleted=291
- unityFrames=207
- status=PASS_TEXTURE_CONSUMPTION_ALIVE
- D3D12 format error=0
- NULL/empty texture error=0
- Freeze=なし

ただし2026-09-02時点では後続Project AuthorityがPath B SystemMemoryNV12をProduction stableとしているため、
本chatのreverse-share成果はHistorical Diagnostic Authorityとして保存し、現Productionを置換する直接根拠にはしない。

## OBJECTIVE

1. WebCamTexture 1080pの約20Hz cadence制限を回避する。
2. UGREEN Camera 4Kの1920x1080@60 Native NV12をUnity DX12へ低遅延で渡す。
3. FIFO/stale queueを使わずlatest-frame / bounded ring / non-blockingを維持する。
4. Tracking Core / Face Landmarker / 3-lane inference / AuthorityをCamera workaroundで変更しない。
5. shared resource / fence / external texture境界のfreeze原因を局所化する。

## CONFIRMED FACTS

### Environment
- Project: D:\KiwiAvatarSystem
- Unity: 6000.0.80f1
- Windows / DX12
- Ryzen 9 5950X / RTX 4090
- Camera: UGREEN Camera 4K
- Target: 1920x1080@60 Native NV12
- MediaPipeUnityPlugin: v0.16.3
- Scene: Face Landmark Detection

### Pre-Native baseline
旧1080p DX12 WebCamTexture runtime:
- camera eventHz ≈ 17.873
- median camera interval ≈ 51.071ms
- canonical ≈ 20.360Hz
- inference ≈ 77.781ms

720p DX12 baseline:
- canonical ≈ 34.681Hz
- inference ≈ 76.164ms

### Native capability already demonstrated
- Media Foundation exact native 1080p60
- NV12 GPU-backed DXGI surface
- D3D11 shared bridge約60fps
- CPU pixel copy不要
- D3D11On12 1080p Production案は不採用

### Native DLL build
初回build失敗原因はUnity IUnityGraphicsD3D12.hより先にWindows SDK D3D12/DXGI型が定義されていなかったこと。
`<dxgi1_6.h>` / `<d3d12.h>`を先にincludeして解消。
`KiwiNativeCamera.dll` buildはExitCode=0、STDERR空でPASS。

### Staged runtime
- SAFE: 正常
- CAPTURE_ONLY: Freeze
- RAW: PASS
- COPY: PASS
- CONVERT: PASS
- SHARE: FREEZE

この結果からMF / D3D11 camera texture / local CopyResource / NV12→RGBA computeまではUnity内でも成立し、
問題はshared-resource境界へ限定された。

### Precise reverse-share failure
Plain D3D12 CreateCommittedResource方式:
- CreateCommittedResource: PASS
- CreateSharedHandle: PASS
- D3D11 OpenSharedResource1: FAIL
- HRESULT: 0x80070057 / E_INVALIDARG

### Compatibility Reverse Share TRUE PASS
D3D12 resource:
- DXGI_FORMAT_R8G8B8A8_UNORM
- DEFAULT heap / SHARED
- initial state COMMON
- D3D12_RESOURCE_FLAG_ALLOW_SIMULTANEOUS_ACCESS

D3D11-facing flags:
- D3D11_BIND_SHADER_RESOURCE
- D3D11_RESOURCE_MISC_SHARED
- D3D11_RESOURCE_MISC_SHARED_NTHANDLE

06 REVERSE_CREATE:
`capture=180 dropped=0 publishedSeq=180 producerFenceCompleted=0 unityFrames=593 status=PASS_STAGE_ALIVE`

07 REVERSE_WRITE:
`capture=180 dropped=0 publishedSeq=180 producerFenceCompleted=0 unityFrames=596 status=PASS_STAGE_ALIVE`

08 REVERSE_FENCE:
`capture=180 dropped=0 publishedSeq=180 producerFenceCompleted=180 unityFrames=584 status=PASS_STAGE_ALIVE`

09 first run:
PASS文字列は出たがDXGI 29(sRGB) vs resource 28(UNORM) mismatchとNULL texture errorがありINVALID。

09 final v11:
`capture=291 presented=180 dropped=0 producerFenceCompleted=291 unityFrames=207 status=PASS_TEXTURE_CONSUMPTION_ALIVE`
加えてD3D12 incompatible-format error 0、NULL/empty texture error 0、freezeなし。

## PUBLIC DESIGN PRINCIPLES

1. D3D12 resourceをD3D11からopenするにはD3D11互換shared description/metadataが必要。
2. Compatibility shared resourceではD3D11-facing flagsを明示する。
3. D3D12-owned shared fenceをD3D11 OpenSharedFenceで開き、D3D11 Signal / D3D12 GetCompletedValueで同期可能。
4. Unity CreateExternalTextureのformat/color-space解釈はNative resourceと一致させる。
5. Unity graphics queueをcamera producer fenceで直接Waitさせず、producer completionはnon-blockingで確認する。
6. fixed ring slotごとにfixed Unity Texture wrapperを対応させresource identity/lifetimeを明確化する。

## INFERENCES / HYPOTHESES

- Plain CreateCommittedResource reverse-shareのE_INVALIDARGはD3D11互換shared metadata不足が主因だった可能性が高いが、内部実装詳細まで断定しない。
- 初期forward-share freezeはresource ownership/lifetime/synchronization境界の組合せ問題と推定するが、単一APIだけを根本原因と断定しない。
- v11診断成功後にCurrent ProductionがPath B SystemMemoryNV12へどう収束したかは本chat単独では直接検証していない。

## PRODUCTION AUTHORITY

Chat内Authority:
1. Same-chat Unity Runtime diagnostics
2. Native build log
3. Microsoft D3D11/D3D12 interoperability design
4. Unity D3D12 PluginAPI / CreateExternalTexture behavior
5. prior Native standalone probes

Archive-time Authority cross-check:
2026-09-02 Project AuthorityではNative Camera ProductionはPath B SystemMemoryNV12 stable。

Therefore:
- v11 = Historical Diagnostic Authority
- Current Production実体ではない
- LOCAL_PRODUCTION_NOT_DIRECTLY_VERIFIED
- Current Production SHA = NOT_AVAILABLE_IN_NORMAL_CHAT

## WORK PERFORMED

1. Phase16.20.7 initial integration → Native build FAIL。
2. include順修正 → Native DLL BUILD PASS。
3. installer literal marker mismatch → safe abort。
4. semantic exact-once patcherへ改善。
5. Full Unity integration → Play freeze。
6. SAFE_SYNCでもfreeze。
7. SAFE正常 / CAPTURE_ONLY freeze。
8. RAW/COPY/CONVERT PASS / SHARE freezeでshared boundaryへ絞り込み。
9. Reverse-share plain committed resourceを試行。
10. 初期06/07/09をfallback込みで誤PASS判定。
11. precise HRESULT instrumentation追加。
12. OpenSharedResource1 E_INVALIDARGを確定。
13. ID3D12CompatibilityDevice::CreateSharedResource導入。
14. 06 TRUE PASS。
15. 07 TRUE PASS。
16. 08 TRUE PASS。
17. 09 first runはSRV format mismatchでfalse-positive。
18. CreateExternalTexture linear=trueへ修正。
19. v11 09 FINAL TRUE PASS、errors=0、dropped=0、freezeなし。

## VALIDATED DECISIONS

### Decision: forward-share reject
Reason: SHARE stageでUnity freeze。
Evidence: RAW/COPY/CONVERT PASS、SHARE freeze。
Regression constraints: 新Evidenceなしに復活させない。
Still current: Historical decisionとしてYES。

### Decision: plain committed reverse-share reject
Reason: D3D11 OpenSharedResource1 E_INVALIDARG。
Still current: YES。

### Decision: Compatibility Reverse Share diagnostic PASS
Reason: 06/07/08/09 true PASS。
Evidence: final runtime logs。
Regression constraints:
- Compatibility shared resource
- D3D11-facing flags
- reverse shared fence
- non-blocking producer completion
- fixed external texture wrapper ring
- linear=true / UNORM coherence
Still current: Historical design evidenceとしてYES。Current Production authorityとしてはSUPERSEDED。

### Decision: ExternalTexture linear=true for UNORM RGBA8
Reason: linear=falseでsRGB view(29)を要求しUNORM resource(28)と不一致。
Evidence: v11修正後error 0。
Still current: 当該resource contractに対してYES。

## REJECTED APPROACHES

- Unity graphics queue direct Wait: freezeリスクのためREJECT。
- D3D11-owned shared RGBA → Unity D3D12 open: SHARE freezeでREJECT。
- Plain D3D12 CreateCommittedResource → D3D11 OpenSharedResource1: E_INVALIDARGでREJECT。
- ExternalTexture linear=false on UNORM resource: DXGI 28/29 mismatchでREJECT。
- PASS文字列だけをvalidator authorityにする: initial 09 false-positiveのためREJECT。

## SUPERSEDED CONCLUSIONS

OLD: 初期06/07 reverse-share PASS。
NEW: plain committed版はstart failedを伴い真のPASSではなかった。
WHY: fallback後の正常動作をdiagnostic successと誤認。
EVIDENCE: v9 `ReverseShare.OpenSharedResource1 failed. hr=0x80070057`。

OLD: first 09 PASS_TEXTURE_CONSUMPTION_ALIVE = PASS。
NEW: INVALID / FALSE POSITIVE。
WHY: incompatible SRV format + NULL texture error。

OLD: 次はCompatibility Reverse ShareをProduction統合。
NEW: 2026-09-02 Project AuthorityではNative ProductionはPath B SystemMemoryNV12 stable。Historical next actionはSUPERSEDED。

## OBSERVER / VALIDATOR FINDINGS

1. 初期build scriptは一次compile errorの保存が弱かった → full build log保存へ改善。
2. installer literal markerはlocal formatting差でsafe abort → semantic exact-once patchへ改善。
3. freezeしないだけではPASSではない。fallbackを誤認可能。
4. first 09 validatorはpresented countだけでPASSしD3D12 bind errorを見逃した。
5. 最終validator条件へD3D12 format error=0 / NULL texture error=0を追加。
6. Observer/Validator自体を疑うというKiwi QA原則を再確認。

## FILES / SHA256

Path: KiwiAvatarSystem_v5_1_0_Phase16_20_7_v11_EXTERNAL_TEXTURE_FORMAT_FIX.zip
Role: Compatibility Reverse Share + ExternalTexture linear=true final diagnostic package
SHA256: D3A15CC29ED6DF915B7C386B139BF400D51ABB2A097AD306B82850E079B11834
Current/Obsolete: Historical diagnostic artifact / Current Production authorityではない

Path: KiwiNativeCamera_Build_20260824_004951.txt
Role: Unity 6000.0.80f1 Native DLL compile/link PASS evidence
SHA256: NOT_AVAILABLE_IN_NORMAL_CHAT
Current/Obsolete: Historical build evidence

Local Production critical files:
- D:\KiwiAvatarSystem\Native\...
- D:\KiwiAvatarSystem\Assets\Plugins\x86_64\KiwiNativeCamera.dll
- D:\KiwiAvatarSystem\Assets\KiwiAvatarSystem\Runtime\Camera\...
SHA256: NOT_AVAILABLE_IN_NORMAL_CHAT
Authority: LOCAL_PRODUCTION_NOT_DIRECTLY_VERIFIED

## RUNTIME EVIDENCE

CORRECTNESS:
- v6 staged: RAW/COPY/CONVERT PASS, SHARE FREEZE
- v9 precise: OpenSharedResource1 E_INVALIDARG
- v10 06: PASS_STAGE_ALIVE
- v10 07: PASS_STAGE_ALIVE
- v10 08: PASS_STAGE_ALIVE / producerFenceCompleted=180
- v11 09: PASS_TEXTURE_CONSUMPTION_ALIVE / dropped=0 / errors=0 / freezeなし

STATIC_ONLY:
- v2 Native build ExitCode=0
- semantic installer exact-once guards
- v11 static validation

PERFORMANCE:
診断runはobserver/diagnostic workloadを含むためPerformance Authorityにしない。

VISUAL:
first 09 screenshotでD3D12 incompatible-format / NULL texture errorを確認。
final v11はユーザー報告でerror 0。

PROVENANCE:
Native build logにUnity 6000.0.80f1 PluginAPI pathとMSVC commandあり。

## CURRENT RESULT

Historical chat result at 2026-08-24:
Compatibility Reverse Share diagnostic = PASS。

成立:
- Native 1080p60 source capability
- D3D11 camera path
- CopyResource
- NV12→RGBA compute
- D3D12 Compatibility shared resource
- D3D11 OpenSharedResource1
- reverse shared fence
- non-blocking producer completion
- fixed external texture ring
- Unity texture consumption
- UNORM/linear format coherence

Final 09:
- capture 291
- presented 180
- dropped 0
- producerFenceCompleted 291
- D3D12 errors 0
- NULL texture errors 0
- freezeなし

Archive-time Current Project Result at 2026-09-02:
このchatのProduction integration Next ActionはSUPERSEDED。
Native Camera current authority = Path B SystemMemoryNV12 stable。
Current Project next priority = v44.55.24 Pair-Bound Shadow Output Snapshot。

## OPEN ISSUES

Historical unresolved at chat end:
1. v11 pathをProduction providerへ統合した場合のFace Landmarker / 3-lane end-to-end runtime。
2. Production camera fresh Hz / canonical Hz / accepted source age。
3. lifecycle / restart / no-frame / provider switch。
4. long-run resource stability。

Archive-time note:
後続Projectで一部または全部SUPERSEDED/RESOLVEDの可能性あり。
現Productionへ再適用する前にlocal Production + latest Runtimeを確認する。

## NEXT ACTION

Historical next action:
v11 Compatibility Reverse ShareをProduction WindowsNativeWebCamSourceへ統合し1080p60でFace Landmarker + 3-lane inferenceをCSV評価。

Current next action at archive time:
上記Historical next actionを実行しない。
2026-09-02 Project Authorityに従い`v44.55.24 Pair-Bound Shadow Output Snapshot`を優先。
Native CameraはPath B SystemMemoryNV12 stableとして新しい独立Evidenceなしに変更しない。

## DO NOT CHANGE

新しい独立Evidenceなしに変更しない:
- Face Landmarker Primary / Source of Truth
- KiwiFaceMotion.csをcamera workaroundとして変更
- KiwiInferenceFaceTracker.csをcamera workaroundとして変更
- 3-lane latest-frame scheduling
- Head single rigid authority
- Root / Eye / Mouth authority separation
- FIFO / stale queue
- blocking GPU wait
- Unity D3D12 queue Wait復活
- UpdateExternalTexture復活
- rotating texture identity
- strong smoothing / Kalmanによる問題隠蔽
- thresholdの実測なし変更
- Current Native Production pathをhistorical diagnosticだけで置換

## HANDOFF

1. このArchiveは2026-08-24 Native Camera interop診断の恒久記録。
2. D3D11-owned forward-shareはSHARE stage freeze。
3. Plain D3D12 committed reverse-shareはOpenSharedResource1 E_INVALIDARG。
4. ID3D12CompatibilityDevice::CreateSharedResourceで解消。
5. 06/07/08 true PASS。
6. 09 first runはvalidator false-positive。UNORM(28)にsRGB(29) viewを要求。
7. CreateExternalTexture linear=trueへ修正。
8. v11 final 09: capture=291 / presented=180 / dropped=0 / producerFenceCompleted=291 / errors=0 / freezeなし。
9. ただしchatの「次はProduction integration」は2026-09-02 current AuthorityではSUPERSEDED。
10. Current Production変更前にlocal Production actual placement + SHA → latest Runtime → actual Package Sourceを再確認。
11. Current Project priorityはv44.55.24 Pair-Bound Shadow Output Snapshot。
12. NativeはPath B SystemMemoryNV12 stable。新しい独立Evidenceなしに変更しない。

## PROJECT MASTER REPORT IMPACT

Historical Validated Decisionsとして記録価値:
- D3D11-owned forward-share Unity path REJECT
- Plain D3D12 committed reverse-share REJECT
- Compatibility shared resource interop diagnostic PASS
- ExternalTexture UNORM contract requires linear=true
- GPU bind error 0をvalidator条件へ含める

Superseded:
- Compatibility Reverse Shareを次Production pathへする、という当時のnext action

Current Project-wide Open Issue:
v44.55.24 transaction authority。

## CHAT ARCHIVE INDEX

Archive: KiwiChat_NativeCameraCompatibilityReverseShare_Updated_20260824-JST.zip
Topic: NativeCameraCompatibilityReverseShare
LastWorkUpdate: 2026-08-24
LastWorkUpdatePrecision: DATE_ONLY
Status: SUPERSEDED
Supersedes: initial forward-share / plain reverse-share diagnostic conclusions
SupersededBy: 2026-09-02 current Native Production authority: Path B SystemMemoryNV12 stable
NextArchiveCandidate: v44.55.24 Pair-Bound Shadow Output Snapshot completion archive

## FINAL ARCHIVE NOTE

このREPORTは「当時どの仮説を、どのRuntimeで棄却/採用したか」を保存する恒久証拠。
現在のProduction変更判断には、このREPORT単独ではなくlocal Production + latest Runtime + current Package Sourceを優先する。
