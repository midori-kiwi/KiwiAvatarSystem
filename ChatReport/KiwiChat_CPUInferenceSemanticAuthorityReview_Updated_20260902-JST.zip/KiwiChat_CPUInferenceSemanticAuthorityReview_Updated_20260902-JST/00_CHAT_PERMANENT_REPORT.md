# KiwiAvatarSystem Chat Permanent Report

ChatTopic: CPU Inference Semantic Authority / Exact-HostTicks Preprocess Validation / Whole-System Architecture Review  
ChatTitle: v44.55.15 Exact-HostTicks CPU Semantic Gate and Whole-System Review  
ArchiveName: KiwiChat_CPUInferenceSemanticAuthorityReview_Updated_20260902-JST.zip  
LastWorkUpdate: 2026-09-02  
LastWorkUpdatePrecision: DATE_ONLY  
ArchiveCreated: 2026-09-02T23:22+09:00  
ArchiveTimestampBasis: LAST_RELEVANT_WORK_BEFORE_ARCHIVE_REQUEST  
Project: D:\KiwiAvatarSystem  
Unity: 6000.0.80f1 / Windows / DX12  
CurrentInvestigationVersion: v44.55.15 FIX5 in this chat; later project authority has advanced through v44.55.23 with v44.55.24 next  
Status: SUPERSEDED  
LocalProductionVerification: LOCAL_PRODUCTION_NOT_DIRECTLY_VERIFIED  

---

## EXECUTIVE SUMMARY

This chat focused on proving whether KiwiAvatarSystem could safely move its Face Landmark inference path from the current three-lane GPUCompute Production authority toward a CPU Production path without changing Tracking Core, Native Camera Production Path B, FaceTexture transaction rules, or tracking math.

The immediate technical thread was v44.55.15, an observer-only Exact-HostTicks CPU Preprocess Semantic Gate. The intended comparison was:

- Left: `CURRENT_FLOAT_EXACT_SNAPSHOT -> CPU Worker`
- Right: `PRESENTATION_PLUS_FINAL_UNORM8_MODE2_EXACT_SNAPSHOT -> CPU Worker`

with the same exact diagnostic native snapshot, same native sequence / hostTicks, same Production crop transform, same model, and no Production authority writes.

A number of defects were found in the validation/launcher infrastructure itself before a valid Runtime measurement was obtained. These were not Production defects and must remain separated from product correctness:

- historical Production launcher name assumption,
- Editor vs Player log confusion,
- insufficient runtime-duration guidance,
- `OnApplicationQuit`-only report persistence,
- BAT inherited `ERRORLEVEL` false failure,
- a semantically unrelated exact mesh-triangle count accidentally used as an inference readiness gate.

FIX5 removed the incorrect triangle gate, retained it only as informational telemetry, added gate diagnostics, retained Production GPU authority, and completed a valid 60-second observer run.

The valid FIX5 Runtime completed 16 numerical pairs with zero pair errors, zero non-finite output pairs, zero presence decision mismatches, and zero semantic presence mismatches. Raw landmark agreement was already close: landmark 2D p95 was about 0.726 px, 99.96% were within 1 px, and 100% were within 2 px. However, the previously fixed proxy semantic gate rejected 12/16 pairs because centroid p95 (~0.587 px) and bbox-center p95 (~0.527 px) exceeded the predeclared 0.25 px thresholds.

The whole-system review performed later in the chat revised the interpretation of that result: it is not sound to decide Production suitability primarily from raw landmark/centroid/bbox proxy thresholds when the actual KiwiAvatarSystem authority consumes canonical outputs such as accepted/rejected state, center, scale, depth, yaw/pitch/roll, eye/mouth channels, transaction identity, and final avatar authority values. Thresholds must not be relaxed after seeing data, but the validation target should be the actual canonical semantics, not only raw subpixel proxy metrics.

The base Kiwi architecture was judged sound and should not be rewritten:

- Face Landmarker remains Primary / Source of Truth.
- Native Camera Path B remains Production.
- latest-frame only / no FIFO remains correct.
- fixed Unity-visible Presentation Texture identity remains correct.
- source/submission/completed/presentation cadence separation remains correct.
- strict hostTicks/sequence/generation/stale/cross-system authority remains correct.
- FaceTexture strict same-sample transaction remains correct.
- bounded asynchronous inference lanes remain correct.
- Tracking Core must not be modified as a camera/performance workaround.
- Correctness, Performance, Visual, and Provenance evidence must remain separate.

This chat originally concluded that the next experiment should be v44.55.16 Canonical Semantic Equivalence. That recommendation is now historical. The current authority documents uploaded at archive time show that the project subsequently progressed through v44.55.17, v44.55.19, v44.55.20, v44.55.21, v44.55.22, and v44.55.23. The latest current project state is:

- v44.55.17 Canonical Semantic: FAIL.
- v44.55.19 Production GPU Authority Triangulation: both CURRENT_FLOAT and mode2 rejected as Production CPU authority.
- v44.55.20 Common Tensor Backend Isolation: backend difference excluded; `PREPROCESSING_CONFIRMED`.
- v44.55.21 Border / Footprint Isolation: border hypothesis rejected.
- v44.55.22 direct Production `lane.input` oracle: measurement method itself rejected as authority.
- v44.55.23 Production Output Transaction Authority: observer validity PASS, 115/115 completed, provisional `MIXED_TRANSACTION`.
- v44.55.24 Pair-Bound Shadow Output Snapshot: current next action to eliminate Worker output lifecycle / allocator reuse race before making any final transaction-authority conclusion.

Therefore this archive is a historical permanent record of the v44.55.15 investigation and the design-review pivot that led toward canonical/transaction authority testing. It must not be used to override the newer v44.55.23/v44.55.24 project authority chain.

---

## OBJECTIVE

Primary objective of this chat:

1. Determine whether a CPU Production inference direction is technically justified.
2. Keep the current Production camera/tracking authority untouched while testing CPU semantics.
3. Isolate preprocessing differences from backend differences.
4. Avoid mutable Presentation Texture identity races during comparison.
5. Audit the validation methodology itself for false positives/false negatives.
6. Re-evaluate the entire KiwiAvatarSystem architecture, implementation direction, and validation coverage before continuing.
7. Minimize Runtime submissions by maximizing static proof and combining only necessary Runtime checks.
8. Preserve a clean rollback path to the known GPU Production authority.

---

## CONFIRMED FACTS

### Environment

Project: `D:\KiwiAvatarSystem`  
Unity: `6000.0.80f1`  
Graphics: Windows / DX12  
CPU: Ryzen 9 5950X  
GPU: RTX 4090  
Camera: UGREEN Camera 4K, 1920x1080@60, Native NV12  
MediaPipeUnityPlugin: v0.16.3  
Unity Inference Engine: 2.4.1  
Active Scene: Face Landmark Detection

### Production critical SHA evidence used in this chat

`KiwiInferenceFaceTracker.cs`  
SHA256: `52C046EE44B41A4FF50B85AEF503BC29DD31B57EAF58C0D160CCC33C5D4B7695`

`FaceLandmarkerRunner.cs`  
SHA256: `6C65C075270F10C791F6B044E3BC04C6024AADF916D65283F0EEFFA3448BBB93`

`KiwiNativeCameraInterop.cs`  
SHA256: `AC473ADBADE5EDC89726211ECAF03D040B5CC00FCA39BEA4A0D16195FA53E8B5`

Active `KiwiNativeCamera.dll`  
SHA256: `82D1FC2910468056C02E8BAE1C72996D8492173A84BEBBCAE322EBEF435678A5`

Canonical Native source available to the audits:  
`Native\KiwiNativeCamera\Source\KiwiNativeCameraPlugin.cpp`

Observed source SHA256:  
`636D76251F9CB3BB785F4497D3D0722033FC0CE36CB4A574B65EDA58B5ABE32A`

The source carried a reconstructed-candidate provenance marker in the audits. Therefore source-to-active-DLL provenance was treated cautiously in this chat. Later project authority states that the v44.55.12 Original Package Audit strongly improved provenance confidence, but Native rebuilds still require an explicit source→build→artifact chain.

### Existing Tracker architecture

The current Tracker baseline used in this chat was confirmed to have:

- Production `BackendType.GPUCompute`.
- Three-lane asynchronous scheduling.
- `TextureConverter.ToTensor`.
- `ReadbackRequest` and non-blocking `IsReadbackRequestDone`.
- lane activity tracking.
- generation / stale / cross-system gates.
- reset by generation advancement and natural lane drain.
- no `WaitForCompletion`.
- no `UpdateExternalTexture`.

### Existing Runner architecture

The current Runner baseline used in this chat was confirmed to:

- separate source cadence, submission cadence, and result cadence,
- publish completed results with source identity metadata,
- preserve source hostTicks identity,
- depend on the existing private recovery/bootstrap signature: `InitializeSentisTracker(Texture,bool,bool)`.

Do not break this signature casually.

### Existing Interop/native capability

The active managed/native contract already exposes exact-hostTicks CPU crop functionality:

`KiwiNativeCamera_CopyCpuCropNchwFloatByHostTicks`

with the wrapper verifying:

`matchedHostTicks == expectedHostTicks`.

The active DLL also exposes diagnostic snapshot and quantized crop APIs, including mode2 / final-UNORM8 diagnostic paths. This is why v44.55.15 could compare same-snapshot CURRENT_FLOAT and mode2 without replacing the Production Native DLL.

### v44.55.15 FIX5 static validation

FIX5 Static Validation passed all reported checks, including:

- tracker SHA PASS,
- runner SHA PASS,
- interop SHA PASS,
- native DLL SHA PASS,
- validation SHA PASS,
- observer-only PASS,
- Production GPU authority preserved PASS,
- triangle gate removed PASS,
- triangle informational-only PASS,
- same-snapshot identity PASS,
- both observer workers CPU PASS,
- no GPUCompute observer PASS,
- no identity-neighbor decision PASS,
- edit-mode safe destroy PASS,
- Unity compile PASS.

### v44.55.15 FIX5 valid Runtime

Final valid report: `KiwiExactCpuInputSemantic_v44_55_15_20260831_233640.txt`

Result: `status=COMPLETE`

Measurement:
- durationSeconds = 60
- requestedPairHz = 1
- warmupPairCount = 2
- pairAttemptCount = 18
- pairCompletedCount = 16
- pairErrorCount = 0
- outputPairCompletedCount = 16
- outputPairErrorCount = 0
- outputNonFinitePairCount = 0
- presenceDecisionMismatchCount = 0
- semanticPresenceMismatchCount = 0
- semanticPairPassCount = 4
- semanticPairFailCount = 12

Snapshot/identity:
- snapshotArmCount = 64
- snapshotReadyCount = 64
- snapshotMatchTimeoutCount = 3
- snapshotArmFailureCount = 0
- snapshotCropFailureCount = 0
- snapshotManagedTimestampMapFailureCount = 0
- laneRaceDiscardCount = 0
- laneChangedAfterFreezeCount = 0
- snapshotTensorMismatchCount = 0
- identity-neighbor correction used = 0

Raw semantic agreement highlighted in the chat:
- landmark 2D p95 ≈ 0.726 px
- within 1 px ≈ 99.96%
- within 2 px = 100%
- bbox width p95 ≈ 0.455 px
- bbox height p95 ≈ 0.242 px
- centroid p95 ≈ 0.587 px
- bbox center p95 ≈ 0.527 px
- presence decision mismatch = 0

The predeclared 0.25 px centroid/bbox-center proxy gate therefore failed. No post-result threshold relaxation was accepted.

### v44.55.15 observer cost

CURRENT_FLOAT native crop:
- median ≈ 2.62 ms
- p95 ≈ 3.24 ms

mode2 native crop:
- median ≈ 3.51 ms
- p95 ≈ 4.45 ms

CPU Worker left:
- median ≈ 14.79 ms

CPU Worker right:
- median ≈ 13.67 ms

Completion:
- generally within 1 frame.

However the observer readback itself was heavy:
- snapshot readback median ≈ 130 ms
- tensor readback median ≈ 137 ms
- about 3 frames.

Therefore this Runtime is correctness evidence, not Production performance authority.

---

## PUBLIC DESIGN PRINCIPLES

The external review in this chat supported the following public principles:

1. MediaPipe live-stream style processing is asynchronous and benefits from limiting in-flight work rather than building stale queues.
2. Media Foundation Source Reader supports asynchronous callback-driven acquisition.
3. Real-time tracking systems commonly separate tracking cadence from render/presentation cadence.
4. CPU vs GPU backend choice is a resource/performance decision only after semantic correctness is demonstrated.
5. Mutable GPU resources and asynchronous work require explicit lifetime/identity discipline; metadata alone is not sufficient authority if the underlying resource may have advanced.
6. Correctness observers that add readback, dumps, or heavy diagnostic compute must not be treated as performance benchmarks.
7. Package source for the exact installed Unity Inference Engine version is stronger authority than generic web descriptions when implementation semantics matter.

These are design principles only. They do not prove closed-source commercial internals.

---

## INFERENCES / HYPOTHESES

The following were hypotheses or intermediate interpretations during this chat and must not be promoted to confirmed Production facts without newer evidence:

1. `CURRENT_FLOAT` might still have been Production-viable if final canonical semantics were effectively identical despite raw centroid/bbox proxy failures.
2. Native mode2 might have been needed if canonical semantics failed.
3. The unresolved source provenance could become a blocker only if a Native rebuild became necessary.
4. Raw landmark subpixel equality alone is not necessarily the correct Production acceptance metric for a VTuber system.
5. The correct final authority comparison should be the same side-effect-free decode/canonical pipeline that actually drives avatar behavior.

These hypotheses led toward later canonical/transaction authority work. Later project evidence has already superseded several of them.

---

## PRODUCTION AUTHORITY

Authority order used for this archive:

1. Current local Production + SHA — not directly accessible from normal chat at archive creation: `LOCAL_PRODUCTION_NOT_DIRECTLY_VERIFIED`
2. Same-Production Runtime evidence supplied in this chat.
3. Exact installed package/source audits already captured in project reports.
4. Current uploaded KiwiAvatarSystem Authority / integrated custom instruction.
5. Official documentation/source.
6. GitHub main and history.
7. Older diagnostics.

Important: GitHub main must not override newer local Production when main is older.

---

## WORK PERFORMED

### 1. v44.55.15 FIX2 static gate

Purpose: Create an observer-only same-snapshot CPU-vs-CPU preprocessing semantic gate.  
Result: Static checks and Unity compile passed.  
Impact: Runtime execution was allowed without changing Production authority.

### 2. Launcher failure: historical Production BAT dependency

Observed: `[ERROR] Production launcher not found.`

Root cause: The wrapper assumed a historical fixed filename: `Launch_KiwiAvatarSystem_DX12_PRODUCTION.bat`

Decision: Do not depend on that historical launcher name.

FIX3: direct known Production Path B Editor launch with `KIWI_NATIVE_CAMERA_MODE=`, `KIWI_CAMERA_CAPTURE_TRANSPORT=B`, Unity 6000.0.80f1, `-projectPath`, `-force-d3d12`.

### 3. Logging / evidence mismatch

Observed: supplied `Player.log` belonged to an old v44.55.12 Standalone build.

Clarification: FIX3/4 launched Unity Editor directly; relevant log was Editor.log.

Impact: evidence-source identity became part of the validation contract.

### 4. Missing report after first Editor Runtime

Root causes:
- “60 seconds” guidance omitted gate + stability + warmup time,
- Editor Play Stop does not guarantee `OnApplicationQuit`,
- report persistence depended too heavily on quit behavior.

FIX4:
- ARMED proof,
- fixed Editor log,
- partial report on `OnDisable`,
- stronger launch proof,
- longer runtime guidance,
- no Production authority change.

### 5. FIX4 false launcher failure

Observed: BAT printed `[ERROR] Failed to launch Unity.` while Unity actually launched.

Root cause: inherited `ERRORLEVEL` from `tasklist | find`.

Impact: launcher defect, not Production defect.

### 6. FIX4 measurement never started

Observed:
- durationSeconds = 0
- pairAttemptCount = 0
- snapshotArmCount = 0

Root cause: semantic readiness incorrectly required `enabled skinned triangles == 254296`.

In Editor Runtime mesh optimization was not active and the enabled mesh remained at the original topology (~1,017,188 triangles).

Decision: mesh triangle count is not an inference semantic prerequisite.

### 7. FIX5

Changes:
- remove exact triangle count from semantic readiness,
- retain triangle count as informational telemetry,
- log each gate condition,
- correct BAT post-launch verification,
- correct Edit Mode destroy behavior,
- keep Production code frozen.

Static: PASS.  
Runtime: COMPLETE, 16 numerical pairs, 0 pair errors.

### 8. v44.55.15 semantic interpretation

Initial strict interpretation: proxy semantic gate rejected CURRENT_FLOAT because centroid and bbox-center exceeded 0.25 px.

Whole-system review: do not relax the old threshold, but do not let a proxy metric become the sole Production acceptance authority.

Revised target: compare the actual side-effect-free canonical output pipeline used by KiwiAvatarSystem.

### 9. Whole-system architecture review

Reviewed current design direction, validation methodology, implementation constraints, official/OSS/commercial public principles, GitHub/current Production authority distinction, and validation coverage gaps.

Conclusion: no architectural rewrite is justified. The main weakness was validation focus and validator reliability, not the established Tracking/Camera authority architecture.

### 10. Validation coverage review

Added/raised priority for:
- canonical center,
- scale,
- depth,
- yaw/pitch/roll,
- final eye/mouth parameters,
- accepted/rejected exact agreement,
- duplicate/out-of-order publish,
- mixed-generation/mixed-backend epoch protection,
- CPU lane starvation,
- p95/p99 CPU service,
- Native crop main-thread cost,
- GC/memory growth,
- backend-switch warp,
- rollback behavior,
- Recovery reflection ABI,
- source→build→DLL provenance.

De-emphasized:
- bit-identical tensor/output equality as a Production requirement,
- raw subpixel proxy metrics as sole acceptance criteria.

---

## VALIDATED DECISIONS

### Decision: Preserve Face Landmarker as Primary / Source of Truth
Reason: established Tracking Core and project requirement.  
Regression constraints: no replacement tracker as workaround.  
Still current: YES.

### Decision: Preserve Native Camera Production Path B
Reason: Path B solved prior camera cadence issues and preserves latest-frame semantics.  
Regression constraints: no FIFO, no IMFSample retention, no Unity queue wait, no rotating texture identity.  
Still current: YES.

### Decision: Preserve latest-frame / strict identity architecture
Reason: low-latency real-time tracking should not accumulate stale work.  
Regression constraints: no stale queue and no weakened hostTicks/generation checks.  
Still current: YES.

### Decision: Keep Production GPU authority unchanged during semantic observers
Reason: observer experiments must not mutate the authority under test.  
Regression constraints: no tracker/ROI/FaceTexture/Production-worker writes from observer.  
Still current: YES.

### Decision: Correctness and Performance must be separated
Reason: v44.55.15 observer imposed ~125–137 ms diagnostic readback and is not representative of Production performance.  
Regression constraints: heavy readback/dump/log runs cannot become Performance Authority.  
Still current: YES.

### Decision: Do not change thresholds after seeing results
Reason: post-hoc threshold relaxation invalidates the gate.  
Regression constraints: predeclare acceptance criteria.  
Still current: YES.

### Decision: Validator/observer code is itself a test subject
Reason: several false failures and blocked runs came from launcher/validator/gate mistakes.  
Regression constraints: PowerShell 5.1, paths, cardinality, ABI, lifecycle, environment inheritance, duration, gate dependencies, and output paths must be audited before Runtime.  
Still current: YES.

---

## REJECTED APPROACHES

### Rejected: Historical fixed-name Production launcher dependency
Why rejected: file no longer present.  
Evidence: FIX2 launch failure.  
Revisit condition: none; prefer explicit current launch contract.

### Rejected: Treating old Player.log as current Editor Runtime evidence
Why rejected: FIX3/4 launched Editor directly.  
Evidence: provided Player.log identified older v44.55.12 build.  
Revisit condition: only with matching new Standalone build identity.

### Rejected: `OnApplicationQuit` as sole report persistence
Why rejected: Editor Play Stop does not guarantee that path.  
Evidence: missing report behavior.  
Revisit condition: never as sole persistence path.

### Rejected: Exact mesh triangle count as semantic readiness gate
Why rejected: render topology is not a prerequisite for CPU inference semantic comparison.  
Evidence: FIX4 remained at durationSeconds=0/pairAttemptCount=0.  
Revisit condition: only in dedicated mesh/visual audit.

### Rejected: Production adoption based only on pixel-parity best candidate
Why rejected: pixel parity is not semantic/canonical authority.  
Evidence: later v44.55.17/v44.55.19 chain.  
Revisit condition: none without semantic/canonical proof.

### Rejected: Production `lane.input` direct readback oracle
Why rejected: queue/lifetime/reuse interactions can create false differences.  
Evidence: later authority chain explicitly rejects this method.  
Revisit condition: do not reuse as Production authority without a fundamentally different lifetime-safe mechanism.

### Rejected: Semantic PASS assumption from Backend speed alone
Why rejected: backend speed does not prove preprocessing or transaction semantic equivalence.  
Evidence: v44.55.20 later confirms backend itself is not the main difference.  
Revisit condition: Performance A/B only after semantic authority is closed.

---

## SUPERSEDED CONCLUSIONS

### OLD
“v44.55.15 0.25 px centroid/bbox-center failure means plain CURRENT_FLOAT should be immediately rejected as the final Production CPU path.”

### NEW
The v44.55.15 proxy gate failure remains factual, but Production decision must be based on canonical/transaction semantics rather than that proxy alone.

### WHY
Raw subpixel metrics do not directly equal final avatar authority semantics.

### EVIDENCE
Whole-system review plus later canonical/transaction audit chain.

---

### OLD
“Next action is v44.55.16 Canonical Semantic Equivalence.”

### NEW
Historical only. Later work already progressed beyond this point. Current authority at archive time: v44.55.23 completed; v44.55.24 Pair-Bound Shadow Output Snapshot is next.

### WHY
Subsequent project work performed canonical, triangulation, backend isolation, border isolation, lane.input oracle rejection, and Production output transaction audits.

---

### OLD
“Native source provenance is an immediate blocker to CPU investigation.”

### NEW
Avoid unnecessary Native rebuilds, but current project authority reports that v44.55.12 Original Package Audit strongly supports Native provenance. Provenance remains mandatory before any future Native rebuild/change.

---

## OBSERVER / VALIDATOR FINDINGS

Permanent rule from this chat:

**A failed validation run is not automatically a Production failure. First determine whether the observer/validator itself is valid.**

Observed defects:
1. historical launcher dependency,
2. Editor/Player evidence-source mismatch,
3. runtime-duration guidance too short,
4. report persistence tied to wrong lifecycle event,
5. BAT inherited `ERRORLEVEL`,
6. unrelated mesh triangle condition used as semantic readiness,
7. misleading use of observer-heavy performance.

Required future validator preflight:
- Windows PowerShell 5.1 compatibility,
- safe 0/1/N collection handling,
- explicit empty/null behavior,
- exact paths,
- no obsolete version/path tokens,
- ABI / DllImport / export match,
- Unity Editor vs Standalone lifecycle,
- environment inheritance,
- fixed writable report/log path,
- duration includes gate/warmup/measurement,
- readiness gates only include actual prerequisites,
- observer self-load quantified,
- Production writes forbidden unless explicitly part of A/B,
- rollback validated.

---

## FILES / SHA256

### Production critical guards

`Assets\Script\KiwiInferenceFaceTracker.cs`  
Role: Production inference tracker  
SHA256: `52C046EE44B41A4FF50B85AEF503BC29DD31B57EAF58C0D160CCC33C5D4B7695`  
Current/Obsolete: current-at-chat baseline; reverify actual local Production before edits.

`Assets\Script\FaceLandmarkerRunner.cs`  
Role: Face Landmarker runner / authority orchestration  
SHA256: `6C65C075270F10C791F6B044E3BC04C6024AADF916D65283F0EEFFA3448BBB93`  
Current/Obsolete: current-at-chat baseline; reverify actual local Production.

`Assets\KiwiAvatarSystem\Runtime\Camera\KiwiNativeCameraInterop.cs`  
Role: managed/native camera ABI  
SHA256: `AC473ADBADE5EDC89726211ECAF03D040B5CC00FCA39BEA4A0D16195FA53E8B5`  
Current/Obsolete: current-at-chat baseline; reverify actual local Production.

`Assets\Plugins\x86_64\KiwiNativeCamera.dll`  
Role: active Native Camera DLL  
SHA256: `82D1FC2910468056C02E8BAE1C72996D8492173A84BEBBCAE322EBEF435678A5`  
Current/Obsolete: current-at-chat baseline; reverify actual local Production.

`Native\KiwiNativeCamera\Source\KiwiNativeCameraPlugin.cpp`  
Role: canonical Native source candidate used in audits  
SHA256: `636D76251F9CB3BB785F4497D3D0722033FC0CE36CB4A574B65EDA58B5ABE32A`  
Current/Obsolete: provenance caution applies.

### v44.55.15 validation packages

`KiwiAvatarSystem_v44_55_15_ExactHostTicksCpuPreprocessSemanticGate_FIX3.zip`  
SHA256 recorded in chat: `A84774FA39C9F5C03E788D6B08330764BDB160E4E97212FF3C54D733FAEEEC20`  
Status: SUPERSEDED.

`KiwiAvatarSystem_v44_55_15_ExactHostTicksCpuPreprocessSemanticGate_FIX4.zip`  
SHA256 recorded in chat: `C73C5226A6CC53A5E4BF7B4C70D45C0B71A25F1F992BB747D27C240779108207`  
Status: SUPERSEDED.

`KiwiAvatarSystem_v44_55_15_ExactHostTicksCpuPreprocessSemanticGate_FIX5.zip`  
SHA256 recorded in chat: `B57E9B5446DA99A552E1A399D7D99AA85AEA9C06A16B84FEA649CC971328A4B1`  
Status: VALID historical v44.55.15 observer package.

These hashes are retained from chat evidence and were not recomputed from the user's local filesystem during archive creation.

---

## RUNTIME EVIDENCE

### CORRECTNESS

`KiwiExactCpuInputSemantic_v44_55_15_20260831_233640.txt`  
Purpose: same exact snapshot CPU-vs-CPU preprocessing semantic comparison.  
Authority: CORRECTNESS  
Result: COMPLETE; 16 pairs; no pair errors; no non-finite outputs; 0 presence decision mismatch; proxy semantic gate 4 PASS / 12 FAIL.  
Performance authority: NO.

`KiwiV44_55_15_FIX5_StaticValidation.txt`  
Purpose: SHA/static/observer-authority/compile validation.  
Authority: STATIC_ONLY  
Result: PASS.

`KiwiV44_55_15_Editor.log`  
Purpose: Editor launch, observer lifecycle, gate, Path B and report evidence.  
Authority: SUPPORTING_ONLY / CORRECTNESS lifecycle support.

`KiwiV44_55_15_LaunchProof.txt`  
Purpose: environment/Path B/observer opt-in proof.  
Authority: STATIC_ONLY / SUPPORTING_ONLY.

### PERFORMANCE

No v44.55.15 observer run in this chat should be accepted as final Production performance authority because the observer added large readback cost.

### VISUAL

Same-run MP4 was supplied during the v44.55.15 sequence.  
Authority: VISUAL only if exact frame-by-frame analysis is completed.

Important: at one point the analysis sandbox did not expose the MP4/CSV as local files, so a claim of full frame-by-frame analysis must not be inferred from this archive unless a dedicated report explicitly states completion.

### SUPPORTING / NON-AUTHORITY

An old `Player.log` from v44.55.12 was uploaded during the Editor-run sequence. It is not Runtime authority for v44.55.15.

---

## CURRENT RESULT

### Chat-local result

v44.55.15 FIX5 is a valid completed observer run.

It proved:
- same-snapshot CURRENT_FLOAT vs mode2 CPU comparison can be executed,
- no non-finite/presence-decision failures in this test,
- old proxy gate rejects most pairs because centroid/bbox-center thresholds are exceeded,
- the old proxy gate must not be retroactively relaxed,
- Production acceptance should instead be tied to final canonical/transaction semantics.

### Current project result at archive time

This chat's proposed v44.55.16 next step is superseded by later project work.

Current uploaded project authority says:
- v44.55.17 Canonical Semantic: FAIL
- v44.55.19 Production GPU Triangulation: both Production CPU candidates rejected
- v44.55.20 Backend Isolation: backend itself excluded; preprocessing confirmed
- v44.55.21 Border/Footprint: rejected as cause
- v44.55.22 direct `lane.input` oracle: method rejected as authority
- v44.55.23 Production Output Transaction Authority: 115/115 completed, observer validity PASS, Production=REF exact 5 anomalous pairs, Production=MODE2 exact 0, Neither exact 3, provisional `MIXED_TRANSACTION`
- v44.55.23 is not final domain authority because Worker output lifecycle / allocator reuse race remains unexcluded
- v44.55.24 Pair-Bound Shadow Output Snapshot is the current next action.

---

## OPEN ISSUES

1. Eliminate Worker output lifecycle / allocator reuse race in Production-output authority observation.
2. Determine whether v44.55.23 `NEITHER_EXACT` pairs survive pair-bound shadow snapshots.
3. Finalize Production Output Transaction Authority.
4. Finalize Reference Transaction Authority.
5. Only after transaction authority is closed: pixel-center convention, crop transform arithmetic, TextureConverter sampling semantics, Native sampling arithmetic, and if necessary HLSL FMA/MAD/precise behavior.
6. Re-establish preprocessing semantic PASS.
7. Only after semantic correctness: Production CPU candidate, CPU/GPU Performance A/B, lifecycle/recovery, long-run resource stability, final Visual MP4.
8. Keep Native source→build→DLL provenance closed before any future Native rebuild.

---

## NEXT ACTION

**v44.55.24 Pair-Bound Shadow Output Snapshot**

Purpose: eliminate the remaining observer lifecycle race from v44.55.23.

Required behavior:
- snapshot REF_FROZEN_GPU and MODE2 B_GPU output while the same pair is still alive,
- bind snapshot to pair token / record / sequence / hostTicks / lane-start identity,
- do not first reacquire `Worker.PeekOutput()` after the record is complete,
- compare packed 1405-float output bitwise against the Production completed `pendingOutput`,
- preserve the existing anomaly selector and decision rules,
- do not alter Production CPU authority, Native DLL, Tracking Core, or threshold policy.

Decision branch:

A. `NEITHER_EXACT` disappears and Production aligns with REF: v44.55.23 MIXED_TRANSACTION was an observer Worker-lifecycle artifact.

B. Pair-bound snapshot still reproduces `NEITHER_EXACT`: only then treat it as evidence of a real Production-vs-shadow output transaction difference.

---

## DO NOT CHANGE

Until v44.55.24 closes transaction authority:

- Face Landmarker Primary / Source of Truth
- Native Camera Path B
- stable Presentation Texture identity
- latest-frame only
- no FIFO / stale queue
- hostTicks/sequence/generation/stale/cross-system gates
- FaceTexture strict same-sample transaction
- Tracking Core math
- `KiwiFaceMotion.cs` as camera workaround
- `KiwiInferenceFaceTracker.cs` as camera workaround
- tracking thresholds
- strong smoothing
- Kalman as an upstream-problem mask
- `UpdateExternalTexture`
- Unity D3D12 queue waits
- blocking GPU waits
- rotating texture identity
- direct Production `lane.input` oracle
- Production CPU backend
- Native C++/DLL without independent necessity/provenance proof
- post-hoc semantic threshold relaxation
- commit/push without explicit instruction

---

## HANDOFF

The next chat should not resume from the historical v44.55.15 “v44.55.16 next” recommendation.

Use the current authority chain.

Start with:
1. Read this permanent report as historical context.
2. Read the current Authority list and integrated project instruction.
3. Verify actual local Production/SHA through Codex/local access when needed.
4. Confirm v44.55.23 artifacts and observer validity.
5. Implement/review v44.55.24 Pair-Bound Shadow Output Snapshot.
6. Ensure pair-bound capture occurs while the same shadow pair is alive.
7. Preserve exact Production output identity.
8. Do not reacquire shadow output from a reused Worker allocator after pair completion.
9. Keep decision thresholds and anomaly selector unchanged.
10. Perform static/compile/ABI/authority/write-target validation.
11. Run only the Runtime required to decide the v24 transaction-authority question.
12. Keep Correctness and Performance separate.
13. If v24 closes the observer lifecycle issue, update Production Output Transaction Authority before moving into pixel-center/FMA arithmetic investigation.

---

## PROJECT MASTER REPORT UPDATE CANDIDATES

Archive: `KiwiChat_CPUInferenceSemanticAuthorityReview_Updated_20260902-JST.zip`  
Topic: CPU Inference Semantic Authority / Exact-HostTicks validation / architecture review  
LastWorkUpdate: 2026-09-02  
Status: SUPERSEDED  
Validated Decision: Keep Tracking/Native/authority architecture; validation must target canonical/transaction semantics and treat observers as fallible.  
Rejected Approach: Production decisions based solely on raw proxy metric thresholds or direct Production `lane.input` oracle.  
Superseded Conclusion: v44.55.16 is no longer the next action; later work advanced to v44.55.23.  
Open Issue: Production output transaction authority is not final until Worker output lifecycle race is removed.  
Next Action: v44.55.24 Pair-Bound Shadow Output Snapshot.

---

## CHAT ARCHIVE INDEX

Archive: `KiwiChat_CPUInferenceSemanticAuthorityReview_Updated_20260902-JST.zip`  
Topic: CPUInferenceSemanticAuthorityReview  
LastWorkUpdate: 2026-09-02  
Status: SUPERSEDED  
Supersedes: earlier v44.55.15 FIX2/FIX3/FIX4 local conclusions and launcher assumptions.  
SupersededBy: later CPU semantic/transaction authority chain through v44.55.23.  
NextArchiveCandidate: v44.55.24 Pair-Bound Shadow Output Snapshot completion / Production Output Transaction Authority resolution.

---

## SELF-AUDIT

- Archive request timestamp was NOT used as LastWorkUpdate.
- Exact previous technical-work time could not be established safely; DATE_ONLY was used.
- Local Production was NOT claimed as directly verified.
- Known SHA values were copied only from explicit project evidence.
- Correctness / Performance / Visual / Provenance were separated.
- Observer defects were not labeled as Production defects.
- v44.55.15 historical conclusions were reconciled with newer v44.55.23/v44.55.24 authority.
- Current next action was updated to v44.55.24 rather than preserving obsolete v44.55.16 guidance.
- No Runtime evidence was invented.
- No MP4 full-frame analysis was claimed where the active analysis environment did not prove it.
- GitHub main was not treated as stronger than current local Production authority.
- ZIP contains one primary report file to minimize file count.
