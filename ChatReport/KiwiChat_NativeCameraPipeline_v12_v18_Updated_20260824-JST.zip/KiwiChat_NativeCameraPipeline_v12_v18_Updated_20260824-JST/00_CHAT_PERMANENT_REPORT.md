# KiwiAvatarSystem Chat Permanent Report

ChatTopic: Native Camera Pipeline v12-v18 / 1080p60 DX12 acquisition-cadence diagnosis
ChatTitle: Native Camera Pipeline Optimization
ArchiveName: KiwiChat_NativeCameraPipeline_v12_v18_Updated_20260824-JST.zip
LastWorkUpdate: 2026-08-24
LastWorkUpdatePrecision: DATE_ONLY
ArchiveCreated: 2026-09-02 23:21 JST
ArchiveTimestampBasis: LAST_RELEVANT_WORK_BEFORE_ARCHIVE_REQUEST
Project: D:\KiwiAvatarSystem
Unity: 6000.0.80f1 / Windows / DX12
CurrentInvestigationVersion: v18 completed; v19 Capture Transport A/B was the next proposal in this chat
Status: DONE
LocalProductionVerification: LOCAL_PRODUCTION_NOT_DIRECTLY_VERIFIED

> Historical/current-authority note: This archive preserves the Native Camera investigation as it stood at the end of this chat. The later project authority supplied on 2026-09-02 states that **Path B SystemMemoryNV12 was subsequently established and Native Camera is now stable**. Therefore the end-of-chat conclusion that Native acquisition was still stuck around 13-20 Hz is historical and **SUPERSEDED/OBSOLETE as a current Production statement**. The validated architectural lessons from v13-v18 remain relevant unless later Runtime evidence explicitly supersedes them.

---

## EXECUTIVE SUMMARY

This chat investigated why the Windows Native Camera path for UGREEN Camera 4K at native NV12 1920x1080@60 could sustain ~60 Hz in standalone Media Foundation probes but fell to roughly 13-20 Hz inside Unity 6 DX12 Production.

The work progressed through v12-v18 rather than rewriting the Tracking Core. The investigation established several durable fixes: one stable Unity-visible Presentation Texture, cameraGeneration as a session/texture epoch instead of frame sequence, QPC-to-Managed Stopwatch timestamp normalization, strict FaceTexture same-sample transaction matching, no callback-to-worker IMFSample retention, latest-frame/no-FIFO ingest, Immediate D3D11 Flush at the camera-copy boundary, separate Capture/Processing D3D11 devices, and finally zero ingest-side D3D11 GPU Waits with fence polling only.

The key v18 Runtime result was diagnostic rather than a Production success: both Capture and Processing GPU Wait counters were zero; Ready replacement, all-slots-busy drop, ingest/processing failures and fence lag were effectively absent; nevertheless the source cadence remained ~13.39 Hz. This rejected the hypothesis that ring depth, ready replacement, producer/consumer waits, or processing throughput were the direct primary cause of the slowdown.

The best next experiment at the end of this chat was therefore v19 Capture Transport A/B Isolation: compare the existing MF DXGI GPU transport against native system-memory NV12, while directly measuring camera-copy GPU completion and MF sample residence. The later 2026-09-02 project authority reports that this direction eventually converged on **Path B SystemMemoryNV12**, and Native Camera is currently considered stable. Thus v19 is preserved here as the historically correct next step, not as an outstanding current task.

---

## OBJECTIVE

1. Preserve Face Landmarker / Tracking correctness while restoring the Native Camera acquisition path toward 1920x1080@60.
2. Separate camera source cadence, processing cadence and presentation cadence.
3. Prefer the newest frame and never build a stale FIFO backlog.
4. Identify the actual slowdown boundary using Runtime telemetry instead of masking it with tracking thresholds, smoothing or prediction.
5. Keep all previously validated authority/transaction protections intact while modifying only the Native camera boundary justified by evidence.

---

## CONFIRMED FACTS

### Environment / target

- Project root used throughout the work: `D:\KiwiAvatarSystem`.
- Unity: `6000.0.80f1`, Windows DX12.
- Camera: UGREEN Camera 4K.
- Target camera format: native NV12, 1920x1080@60.
- Hardware context: Ryzen 9 5950X / RTX 4090.
- MediaPipeUnityPlugin: v0.16.3.
- Active scene: Face Landmark Detection.

### Standalone camera capability was proven

Native probes established that the device/driver/MF stack was capable of 1080p60:

- MF DXGI Surface Probe: 363 frames / 6.0025 s = **60.3084 fps**; arrival median 15.9860 ms; source timestamp median 16.0029 ms.
- Native D3D11 Shared Bridge Probe: camera DXGI NV12 -> D3D11 `CopyResource` -> 3-slot shared NV12 -> D3D12 open, also sustained roughly **60.33 fps**.
- Therefore plain MF native NV12, DXGI backing, `CopyResource`, and a small shared ring were not by themselves 15-fps-limited.

### D3D11On12 1080p was rejected

- D3D11On12 1280x720@60 probe succeeded at roughly 60.38 fps.
- D3D11On12 1920x1080@60 produced zero frames and HRESULT `0x80070057`.
- Therefore D3D11On12 1080p was not accepted as the Production camera path.

### v13 correctness fixes held

- Unity downstream sees a stable `KiwiNativeCameraPresentation` texture identity rather than rotating ring-slot texture identities.
- `cameraGeneration` is treated as camera session / texture identity epoch, not frame sequence.
- Provider boundary performs the required Y normalization once.
- These changes eliminated the earlier cross-system invalidation caused by changing source texture identity.

### v14 timestamp-domain fix held

- Native QPC timestamps were calibrated into the Managed Stopwatch domain.
- Strict FaceTexture matching recovered.
- Subsequent runs repeatedly showed `faceTextureMissCount=0`, `faceTextureHoldCount=0`, stable generation/epoch behavior and no continuous cross-system discard.

### v15 disproved retained-IMFSample as the sole cause

- Cross-callback IMFSample retention was removed.
- A Kiwi-owned 3-slot NV12 ingest ring was introduced.
- Worker selected newest Ready only and did not build FIFO.
- Source, ingest and processing remained around **15.10 Hz**, with zero ingest failure, zero processing failure and zero superseded frames.
- Callback copy and worker submission CPU costs were only around 0.1 ms.

### v16 proved Production could run the camera around 60 Hz when Unity rendering was stalled

- Immediate callback-side D3D11 `Flush()` was added after `CopyResource` + ingest fence Signal and before requesting the next sample.
- Boundary telemetry separated callback cost, ReadSample request CPU cost, MF source timestamp interval and callback arrival interval.
- During a ~3.6 s Unity-side stall, the Native source counter advanced by about 217 frames: roughly **60 Hz**.
- During normal Unity rendering, source cadence fell back to roughly **15.6 Hz**.
- Callback CPU was about 0.13 ms, callback-to-next-request about 0.125 ms, and async `ReadSample()` request CPU about 0.007 ms.
- This strongly moved the investigation away from CPU callback cost and plain camera capability.

### v17 Capture Device Isolation was structurally successful but not sufficient

- Capture D3D11 Device A and Processing D3D11 Device B were separated.
- Capture/Processing multithread protection was active.
- Shared NV12 producer/consumer fence flow worked without failure.
- Source cadence improved to roughly **19.58 Hz** but remained far below 60 Hz.
- The remaining Capture-side `ID3D11DeviceContext4::Wait(consumerFence)` was then re-evaluated as a possible GPU-queue backpressure source.

### v18 removed ingest-side GPU Waits but still did not restore 60 Hz

v18 package:
`KiwiAvatarSystem_v5_1_0_Phase16_20_7_v18_COMMERCIAL_FULLY_DECOUPLED_LATEST_FRAME_NO_GPU_WAIT.zip`

Known archive SHA256 from this chat:
`9260de54c0eed6129b0be333f48799ae7ed6518234da4ca72853a5230c393e1f`

Static validation reported:
- 111 / 111 PASS.
- Native exports = 52.
- C# DllImports = 52.
- Telemetry Publish declaration/call = 50 / 50.
- ingest bridge `->Wait(` = 0.
- `g_unityD3D12Queue->Wait` = 0.
- callback-crossing `sample->AddRef()` = 0.
- FIFO queue/deque = 0.
- `UpdateExternalTexture` = 0.

Latest v18 Runtime evidence in this chat:
- MP4: `KiwiAvatarSystem - Face Landmark Detection - Windows, Mac, Linux - Unity 6.0 (6000.0.80f1) _DX12_ 2026-08-24 23-09-11.mp4`
- CSV: `KiwiFrameComparison_20260824_230912.csv`
- CSV width: 295 columns.
- source resolution fixed at 1920x1080.
- sourceTextureId fixed at `-2502` in the observed run.
- cameraGeneration fixed at 2.
- Capture Device Isolation active.
- Capture and Processing D3D11 multithread protection active.
- Capture GPU Wait count = 0.
- Processing GPU Wait count = 0.
- Ready replacement = 0.
- All-slots-busy drop = 0.
- Ingest failure = 0.
- Processing failure = 0.
- Native drop = 0.
- Superseded = 0.
- Producer/consumer fence lag effectively near zero.
- Native source ~= **13.39 Hz**.
- Native ingest ~= **13.39 Hz**, tracking source.
- Native processing/capture ~= **13.39 Hz**.
- Native presented ~= **12.62 Hz**.
- MF source timestamp interval median ~= **64 ms**.
- callback arrival interval median ~= **67 ms**.
- callback CPU median ~= **0.20 ms**.
- ReadSample request CPU median ~= **0.01 ms**.
- processing submit CPU median ~= **0.26 ms**.
- inference latency median ~= **74.84 ms**.
- accepted source age median ~= **100.68 ms**.
- canonical cadence ~= **10.37 Hz**.
- FaceTexture commit ~= **10.31 Hz**.
- FaceTexture miss / hold = 0 / 0.
- cross-system discard = 0.
- Root / handoff / FacePart epoch authority violations = 0.

Visual inspection at that stage found no obvious DX12 corruption, camera orientation regression, FacePart texture breakage or gross matched-landmark misalignment. It was explicitly not accepted as final eye/motion-quality evidence because the source cadence remained too low.

---

## PUBLIC DESIGN PRINCIPLES

The external review in this chat supported the following general low-latency principles:

1. **Do not block the camera producer because analysis is slower.**
   - Android CameraX exposes `KEEP_ONLY_LATEST` and warns that blocking analysis can affect the whole camera device pipeline.
2. **Drop/replace late work rather than building backlog.**
   - AVFoundation defaults to discarding late video frames.
   - MediaPipe LIVE_STREAM may drop input work to reduce overall latency.
   - GStreamer supports leaky/drop queue behavior for real-time paths.
3. **Fence polling and explicit resource lifetime are preferable to hidden blocking for this use case.**
   - D3D11 fence `Wait` blocks future work on that context until the fence condition is met; therefore a capture-device Wait can indirectly delay camera-copy work even if the CPU call itself returns quickly.
4. **A GPU zero-copy design is not automatically lower-latency than one bounded CPU copy.**
   - For a real-time latest-frame pipeline, producer independence and minimum frame age can be more important than minimizing copy count.

Commercial VTuber/AR software internals were not treated as proven facts when implementation details were not public. The chat used them only for publicly observable/product-level comparison and did not assert non-public internal queue/fence designs.

---

## INFERENCES / HYPOTHESES

### Hypotheses rejected or weakened by v18

The following was the leading v17 hypothesis:

`processing delay -> ingest ring pressure -> capture consumer-fence Wait -> camera copy queued behind Wait -> MF surface pool pressure -> source cadence collapse`

v18 removed both Capture-side and Processing-side ingest GPU Waits and still measured ~13.39 Hz while replacement/drop/fence-lag remained near zero. Therefore ring depth, Ready replacement policy and ingest producer/consumer Waits were **not supported as the direct primary cause** of the remaining slowdown.

### End-of-chat leading hypothesis

The next likely boundary was the transport/lifetime interaction around the MF camera-owned DXGI surface itself:

`MF camera-owned DXGI texture -> used as GPU CopyResource source -> COM refs released -> GPU may still be consuming resource -> surface may remain unavailable to driver/MF longer than CPU submit telemetry suggests`

This was explicitly still a hypothesis at the end of the chat. `nativeIngestCopySubmitMs` measured CPU submission time, not actual GPU completion latency.

The proposed v19 experiment was designed to distinguish this from higher-level SourceReader scheduling effects rather than declaring the hypothesis proven.

---

## PRODUCTION AUTHORITY

Authority actually available to this normal chat:

1. Latest Runtime evidence uploaded in this chat, including v16-v18 CSV/MP4 results.
2. Generated v16-v18 integration/static-validation artifacts and their reported SHA/contract checks.
3. Standalone Native probe reports proving 1080p60 camera/MF/D3D11 capability.
4. Official Microsoft / MediaPipe / platform design documentation consulted during the design review.
5. Project history and prior validated Tracking constraints available in the conversation context.
6. Later 2026-09-02 project authority document supplied with the archive request, which says Native Camera currently uses stable **Path B SystemMemoryNV12**.

Not directly verified here:

`LOCAL_PRODUCTION_NOT_DIRECTLY_VERIFIED`

This normal chat cannot directly inspect the current `D:\KiwiAvatarSystem` working tree, installed Production DLL or current local SHA. Current local Production statements must therefore be attributed to the supplied project authority, not represented as a fresh local inspection.

---

## WORK PERFORMED

### v12 - Reverse Compatibility Share

Purpose:
- Bring MF native NV12 into the Unity DX12 path using internal ring/shared resources.

Result:
- Camera orientation/bridge worked enough to expose the next correctness problem.
- Rotating native texture identities caused generation churn and cross-system invalidation.

Impact:
- Led directly to v13 stable Presentation Texture.
- Unity D3D12 queue `Wait` was identified as unsafe after a freeze and became a permanent prohibition.

### v13 - Stable Presentation / orientation / epoch fix

Purpose:
- Decouple internal native ring identity from Unity-visible texture identity.

Result: PASS for the targeted correctness issue.
- Stable Unity-visible presentation texture.
- Physical Y normalization at provider boundary.
- cameraGeneration treated as session epoch.

Impact:
- Became a durable invariant.

### v14 - Native async timestamp-domain fix

Purpose:
- Eliminate QPC vs Managed Stopwatch domain mismatch that broke strict FaceTexture matching.

Result: PASS for transaction/timestamp correctness.
- FaceTexture miss/hold recovered to zero in healthy operation.
- cross-system stale/generation behavior remained clean.

Impact:
- Timestamp normalization and strict same-sample transaction retained permanently.

### v15 - Kiwi-owned NV12 ingest ring

Purpose:
- Remove callback-to-worker IMFSample retention and separate camera sample lifetime from conversion lifetime.

Result:
- Source remained ~15.10 Hz.
- Ingest/processing tracked source with no meaningful failure or queue pressure.

Impact:
- Rejected IMFSample retention as the sole cause.
- Latest-ready/no-FIFO ingest design retained.

### v16 - Immediate Flush + callback-boundary telemetry

Purpose:
- Match the callback submission boundary of the successful standalone shared bridge and expose where time was actually spent.

Result:
- Callback and ReadSample CPU costs were tiny.
- Crucially, Production DLL source advanced at ~60 Hz while Unity rendering was stalled, then degraded once normal rendering resumed.

Impact:
- Shifted the investigation toward GPU/transport interaction rather than MF configuration or tracking math.

### External design review after v16/v17

Purpose:
- Validate whether “capture never waits / latest only / replace stale” was consistent with official real-time camera frameworks and similar systems.

Result:
- Direction supported by CameraX, AVFoundation, MediaPipe LIVE_STREAM and GStreamer-style low-latency behavior.
- Capture-side D3D11 fence Wait was considered unsuitable for a non-blocking producer boundary.

Impact:
- Led to the v18 no-ingest-GPU-Wait design.

### v17 - Capture/Processing D3D11 Device Isolation

Purpose:
- Decouple MF capture command stream from Unity-facing processing command stream.

Result:
- Isolation itself worked.
- Source improved to ~19.58 Hz but remained well below 60 Hz.

Impact:
- Device isolation retained, but the Capture-side consumer GPU Wait was targeted next.

### v18 - Fully decoupled latest-frame / no-ingest-GPU-Wait

Purpose:
- Remove both ingest-side GPU Waits without sacrificing resource-lifetime safety.
- Poll fence completion only.
- Use FREE slot first, otherwise replace oldest unclaimed Ready slot, and drop only when all slots are truly busy.

Static result: PASS 111/111.

Runtime result: FAIL for 60-Hz acquisition, PASS for many correctness invariants.
- Source ~13.39 Hz despite zero ingest GPU Waits and no meaningful ring pressure.

Impact:
- Rejected ingest ring/Wait pressure as primary direct cause.
- Pointed the next experiment toward MF transport itself.

### v19 proposal - Capture Transport A/B Isolation Diagnostic

Planned Path A:
- Existing MF DXGI GPU transport.
- Add direct GPU-copy completion and MF sample residence timing.

Planned Path B:
- Source Reader without `MF_SOURCE_READER_D3D_MANAGER`.
- Native system-memory NV12.
- Immediate memcpy into Kiwi-owned CPU latest buffer.
- Release MF sample immediately.
- Processing thread uploads only latest CPU NV12 to GPU.

Planned telemetry included:
- `nativeCaptureTransportId`
- `nativeSystemMemoryCaptureEnabled`
- `nativeMfSampleResidenceMs`
- `nativeCaptureCopyGpuSubmitMs`
- `nativeCaptureCopyGpuCompletionMs`
- `nativeCpuNv12CopyMs`
- `nativeCpuLatestReplacementCount`
- `nativeGpuUploadSubmitMs`

Historical significance:
- This chat stopped after defining v19. Later project authority reports that **Path B SystemMemoryNV12 was ultimately established and Native Camera became stable**.

---

## VALIDATED DECISIONS

### Decision: Preserve Face Landmarker / Tracking Core during camera diagnosis

Reason:
Camera/MF/transport defects must not be hidden by tracking math changes.

Evidence:
Standalone Native probes and Native Runtime telemetry isolated the cadence problem upstream of tracking.

Regression constraints:
- Do not change `KiwiFaceMotion.cs` or `KiwiInferenceFaceTracker.cs` as camera-cadence workarounds.
- Do not relax thresholds or add strong smoothing/Kalman to mask source issues.

Still current: YES.

### Decision: Stable Unity-visible Presentation Texture

Reason:
Internal rotating ring-slot identities caused downstream generation/texture-authority churn.

Evidence:
v13 and all later healthy transaction runs.

Regression constraints:
Do not restore rotating Unity-visible texture identity or `UpdateExternalTexture` workaround.

Still current: YES.

### Decision: cameraGeneration is session/texture epoch, not frame sequence

Reason:
Frame-level generation churn invalidated otherwise coherent data.

Still current: YES.

### Decision: QPC -> Managed Stopwatch timestamp normalization

Reason:
Strict FaceTexture same-sample matching requires one coherent time domain.

Evidence:
v14 and later miss/hold=0 behavior.

Still current: YES.

### Decision: Latest-frame only; no FIFO / stale backlog

Reason:
Real-time face tracking values latency/freshness over processing every historical camera frame.

Evidence:
Official real-time camera framework design principles plus Kiwi Runtime goals.

Still current: YES.

### Decision: Immediate callback-side D3D11 Flush at the camera-copy submission boundary

Reason:
Force recorded copy/signal commands toward submission before the next SourceReader request, without CPU/GPU completion waiting.

Still current in the historical DXGI path: YES; current Path B implementation details should be verified from local Production before assuming identical placement.

### Decision: No blocking ingest GPU Waits

Reason:
A D3D11 context Wait can stall future work on that context; camera producer must not be indirectly queued behind a slow consumer.

Evidence:
Official D3D11 fence semantics and v17/v18 diagnostic path.

Still current as design principle: YES.

---

## REJECTED APPROACHES

### Rejected: `g_unityD3D12Queue->Wait(...)`

Why considered:
Direct GPU synchronization between Native and Unity-owned DX12 work.

Why rejected:
Caused Unity freeze and violates non-blocking Production requirement.

Revisit condition:
NONE without a completely different proven synchronization contract; do not casually restore.

### Rejected: `UpdateExternalTexture`

Why considered:
Could swap Unity-visible native texture pointer each frame.

Why rejected:
Breaks the stable texture identity strategy and was explicitly prohibited by the proven Production path.

### Rejected: FIFO / stale queue

Why considered:
Could preserve every camera frame.

Why rejected:
Increases latency and frame age; contradicts latest-frame real-time tracking goals.

### Rejected: Holding IMFSample across callback/worker

Why considered:
Easy asynchronous ownership model.

Why rejected:
Potential camera surface retention/backpressure risk; v15 removed it without losing correctness.

### Rejected: D3D11On12 1080p Production camera path

Why considered:
Potential tighter DX12 interop / zero-copy route.

Why rejected:
1080p60 probe produced 0 frames / `0x80070057` while 720p60 worked.

### Rejected as primary direct cause: ingest ring depth / Ready replacement / producer-consumer Wait

Why considered:
Could explain source cadence matching a small ring cycle.

Why rejected:
v18 had zero ingest GPU Waits, near-zero fence lag, no Ready replacements or busy drops, yet source still ran ~13.39 Hz.

Revisit condition:
Only if new Runtime shows actual ring pressure on the current Production transport.

---

## SUPERSEDED CONCLUSIONS

### OLD
“Native Camera is currently stuck around 13-20 Hz and v19 transport A/B is the next required project task.”

### NEW
The 2026-09-02 project authority says Native Camera currently uses stable **Path B SystemMemoryNV12**, and the old 13-20 Hz state is obsolete.

### WHY
This chat ended before the subsequent Path B work was completed. Later project evidence has higher temporal authority for the current Production state.

### EVIDENCE
2026-09-02 integrated project authority / custom instructions supplied with this archive request.

---

## OBSERVER / VALIDATOR FINDINGS

- v16-v18 telemetry was intentionally diagnostic and should not be confused with a clean Performance benchmark.
- CPU submission time such as `nativeIngestCopySubmitMs` does **not** prove GPU completion latency.
- `nativeCallbackCpuMs` is effectively callback wall duration measured with QPC; its name must not be over-interpreted as pure CPU execution time.
- v18 zero Wait counters plus zero ring pressure were useful correctness/diagnostic signals, but they did not prove the transport itself was free from GPU scheduling/resource-lifetime interference.
- The final archive must not treat v18 observer-heavy latency/cadence numbers as current Production performance authority.

No Validator defect specific to the v18 111/111 static suite was proven in this chat, but static PASS was never treated as sufficient for Production acceptance.

---

## FILES / SHA256

### v18 installer archive

Path/Name:
`KiwiAvatarSystem_v5_1_0_Phase16_20_7_v18_COMMERCIAL_FULLY_DECOUPLED_LATEST_FRAME_NO_GPU_WAIT.zip`

Role:
v18 installer / implementation package.

SHA256:
`9260de54c0eed6129b0be333f48799ae7ed6518234da4ca72853a5230c393e1f`

State:
Historical diagnostic package; not current Production authority.

### v18 Static Validation

Name:
`PHASE16_20_7_V18_STATIC_VALIDATION.json`

Role:
Static contract/interop/prohibition checks.

SHA256:
`SHA256=NOT_AVAILABLE_IN_NORMAL_CHAT`

State:
Historical supporting evidence.

### v18 Runtime CSV

Name:
`KiwiFrameComparison_20260824_230912.csv`

Role:
Primary v18 correctness/cadence diagnostic evidence.

SHA256:
`SHA256=NOT_AVAILABLE_IN_NORMAL_CHAT`

State:
Historical Runtime evidence.

### v18 Runtime MP4

Name:
`KiwiAvatarSystem - Face Landmark Detection - Windows, Mac, Linux - Unity 6.0 (6000.0.80f1) _DX12_ 2026-08-24 23-09-11.mp4`

Role:
Visual regression evidence.

SHA256:
`SHA256=NOT_AVAILABLE_IN_NORMAL_CHAT`

State:
Historical visual evidence.

### Current local Production files

Paths include:
- `D:\KiwiAvatarSystem\Assets\`
- `D:\KiwiAvatarSystem\Native\`
- `D:\KiwiAvatarSystem\Installer\`
- `D:\KiwiAvatarSystem\Assets\Plugins\x86_64\KiwiNativeCamera.dll`

SHA256:
`SHA256=NOT_AVAILABLE_IN_NORMAL_CHAT`

Verification status:
`LOCAL_PRODUCTION_NOT_DIRECTLY_VERIFIED`

---

## RUNTIME EVIDENCE

### `KiwiMfDxgiSurfaceProbe_20260824_002024.txt`

Authority: CORRECTNESS / SUPPORTING_ONLY

Purpose:
Prove exact native NV12 1080p60 camera/MF/DXGI capability outside Unity.

Result:
PASS, ~60.3084 fps.

### `KiwiMfD3D11SharedBridgeProbe_20260824_002920.txt`

Authority: CORRECTNESS / SUPPORTING_ONLY

Purpose:
Prove camera DXGI -> D3D11 CopyResource -> shared NV12 ring -> D3D12 open can sustain ~60 fps outside Unity.

Result:
PASS, ~60.33 fps.

### v16 Runtime CSV/MP4

Authority: CORRECTNESS / SUPPORTING_ONLY

Key result:
Production DLL source ran ~60 Hz while Unity rendering was stalled, but fell to ~15.6 Hz during normal rendering; callback and ReadSample request CPU costs stayed tiny.

### v17 Runtime CSV/MP4

Authority: CORRECTNESS / SUPPORTING_ONLY

Key result:
Capture/Processing device isolation worked; source improved to ~19.58 Hz but remained below target.

### `KiwiFrameComparison_20260824_230912.csv`

Authority: CORRECTNESS / SUPPORTING_ONLY

Key result:
v18 zero-ingest-Wait design still measured source ~13.39 Hz with no meaningful ring pressure.

### v18 MP4 2026-08-24 23-09-11

Authority: VISUAL

Key result:
No obvious orientation, FacePart, matched-landmark or DX12 corruption regression; not final motion-quality authority due low source cadence.

Performance note:
These diagnostic runs contained substantial telemetry/observer activity and are **not** authoritative clean Production performance benchmarks.

---

## CURRENT RESULT

### Historical result of this chat

The v12-v18 Native camera investigation successfully hardened the correctness architecture and rejected several plausible causes of the Unity DX12 acquisition slowdown. v18 specifically disproved “ingest GPU Wait / ring pressure is the primary direct cause” under that Production experiment. The chat ended with a higher-information v19 A/B transport experiment proposal.

### Current project authority as of archive creation

The later 2026-09-02 project authority states:

- Native Camera current Production direction: **Path B SystemMemoryNV12**.
- Native Camera is considered stable.
- Old conclusions that Native Camera is still at 13-20 Hz are obsolete.
- New independent evidence is required before changing stable Native C++/DLL again.

Because this normal chat has not directly inspected the local Production tree, this current statement is recorded as **supplied project authority**, not a fresh local verification.

---

## OPEN ISSUES

### Native-camera topic

No open Native camera redesign is carried forward solely from this chat. The v19 A/B proposal is historical because later project authority reports that Path B was established.

Native camera should be reopened only if new Runtime evidence shows a regression in:
- source identity,
- 1920x1080@60 native acquisition,
- timestamp/session epoch,
- fixed presentation identity,
- restart/recovery,
- latency/cadence,
- resource stability,
- or visual output.

### Project-wide current issue outside this archive's main topic

The latest supplied project authority identifies the current top investigation as `v44.55.24 Pair-Bound Shadow Output Snapshot` in the CPU/GPU preprocessing/transaction semantic investigation. That is outside the Native-camera work preserved here.

---

## NEXT ACTION

### For this archived Native-camera theme

**Do not continue v19 merely because this archive ended there.** Preserve the currently stable Path B SystemMemoryNV12 Production unless new independent Runtime evidence demonstrates a Native regression.

### Current project-wide next action supplied on 2026-09-02

`v44.55.24 Pair-Bound Shadow Output Snapshot` to remove Worker allocator output-lifecycle observer ambiguity before any Production CPU conversion or deeper preprocessing arithmetic investigation.

---

## DO NOT CHANGE

Without new independent Runtime evidence, do not:

- replace Face Landmarker as Primary / Source of Truth;
- modify `KiwiFaceMotion.cs` or `KiwiInferenceFaceTracker.cs` as a camera workaround;
- relax tracking thresholds to hide camera/inference issues;
- add strong smoothing/Kalman as a root-cause workaround;
- reintroduce FIFO/stale frame queues;
- reintroduce callback/worker-crossing IMFSample retention;
- reintroduce `g_unityD3D12Queue->Wait(...)`;
- reintroduce blocking GPU waits on the camera producer path;
- reintroduce `UpdateExternalTexture`;
- reintroduce rotating Unity-visible texture identity;
- treat cameraGeneration as frame sequence;
- weaken cross-system stale/generation gating;
- weaken FaceTexture same-sample transaction matching;
- restore D3D11On12 1080p Production camera path based only on zero-copy preference;
- change the now-stable Native Path B without current Runtime evidence;
- interpret diagnostic observer runs as clean Performance authority.

---

## PROJECT MASTER REPORT DELTA

Archive Name:
`KiwiChat_NativeCameraPipeline_v12_v18_Updated_20260824-JST.zip`

LastWorkUpdate:
2026-08-24 (DATE_ONLY)

Validated decisions to retain:
- stable Unity-visible Presentation Texture;
- cameraGeneration=session/texture epoch;
- QPC->Managed timestamp normalization;
- strict FaceTexture same-sample transaction;
- latest-frame / no FIFO;
- no callback-crossing IMFSample retention;
- Immediate Flush where applicable to DXGI submission path;
- no capture-side blocking GPU wait;
- Capture/Processing responsibility separation;
- Tracking Core not used as camera workaround.

Rejected approaches to retain:
- Unity D3D12 queue Wait;
- UpdateExternalTexture;
- FIFO/stale queue;
- D3D11On12 1080p Production camera;
- treating v17/v18 ring-pressure hypothesis as proven root cause.

Superseded conclusion:
- “Native camera still unresolved at 13-20 Hz / implement v19 next” -> superseded by later Path B SystemMemoryNV12 stabilization authority.

Current Native-camera open issue:
- none from this archive without new regression evidence.

Current project-wide next action:
- v44.55.24 Pair-Bound Shadow Output Snapshot.

---

## CHAT ARCHIVE INDEX

Archive: KiwiChat_NativeCameraPipeline_v12_v18_Updated_20260824-JST.zip
Topic: Native Camera Pipeline v12-v18 / 1080p60 DX12 cadence diagnosis
LastWorkUpdate: 2026-08-24
Status: DONE
Supersedes: earlier v12-v17 Native-camera diagnostic conclusions where v18 supplied stronger evidence
SupersededBy: later Path B SystemMemoryNV12 Production stabilization authority (project status supplied 2026-09-02)
NextArchiveCandidate: current CPU/GPU Production Output Transaction / v44.55.24 investigation archive

---

## HANDOFF

If this archive is opened later, use it as the historical record of how KiwiAvatarSystem reached the decision to isolate Native camera transport from downstream GPU workload.

Do **not** resume by implementing the historical v19 proposal blindly. First check current local Production + exact SHA and current Runtime authority. As of the 2026-09-02 project authority supplied with archive creation, Native Camera has already moved to stable **Path B SystemMemoryNV12** and the old v18 13.39-Hz state is obsolete.

The lasting engineering conclusions from this chat are:

1. The camera/device/MF stack can do native 1080p60.
2. Stable Unity-visible texture identity and session epoch are mandatory correctness boundaries.
3. Native and Managed timestamps must share a calibrated monotonic domain for strict transaction matching.
4. The camera producer must not be blocked by slow downstream processing.
5. Latest-frame is preferred over FIFO/backlog.
6. CPU submit timing is not a proxy for GPU completion timing.
7. Observer/telemetry results must be interpreted by what they actually measure.
8. Tracking Core must not be modified to hide camera/inference defects.
9. A bounded CPU-copy transport can be preferable to nominal zero-copy if it cleanly decouples producer liveness from Unity GPU workload.
10. Current Production authority outranks this historical diagnostic archive.

Before any new Native change, verify:
- exact current local DLL/source SHA;
- current Path B source/build provenance;
- source identity and 1080p60 Runtime cadence;
- session/timestamp coherence;
- FaceTexture transaction;
- restart/recovery;
- no blocking waits / stale queues;
- and no regression in LIVE CAMERA / Spout / Tracking.
