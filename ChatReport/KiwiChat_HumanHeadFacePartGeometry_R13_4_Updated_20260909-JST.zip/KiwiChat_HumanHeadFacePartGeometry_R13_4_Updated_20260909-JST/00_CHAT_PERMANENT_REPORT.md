# KiwiAvatarSystem Chat Permanent Report

ChatTopic: Human-Head FacePart Geometry / H1 Hybrid Continuity / R13.4 Integrated Reaudit
ChatTitle: KiwiAvatarSystem Human-Head FacePart Geometry and Integrated Roadmap Reaudit
ArchiveName: KiwiChat_HumanHeadFacePartGeometry_R13_4_Updated_20260909-JST.zip
LastWorkUpdate: 2026-09-09
LastWorkUpdatePrecision: DATE_ONLY
ArchiveCreated: 2026-09-09 01:18 JST
ArchiveTimestampBasis: LAST_RELEVANT_WORK_BEFORE_ARCHIVE_REQUEST
Project: D:\KiwiAvatarSystem
Unity: 6000.0.80f1
CurrentInvestigationVersion: Integrated Information / Roadmap R13.4
Status: IN_PROGRESS

Archive:
KiwiChat_HumanHeadFacePartGeometry_R13_4_Updated_20260909-JST.zip
Topic:
Human-Head FacePart Geometry / H1 Hybrid Continuity / IE→MediaPipe Geometry Contract
LastWorkUpdate:
2026-09-09
Status:
IN_PROGRESS
Supersedes:
R13 / R13.1 / R13.2 / R13.3 integrated-information artifacts for current baseline use
SupersededBy:
NONE_AT_ARCHIVE_TIME
NextArchiveCandidate:
After IE_TO_MEDIAPIPE_GEOMETRY_CONTRACT_DETAILED_AUDIT or the subsequent External Comparative Design Gate reaches a stable decision

---

## EXECUTIVE SUMMARY

This chat moved KiwiAvatarSystem's FacePart design from ad-hoc camera-facing / roll-only correction thinking to a stricter "Kiwi model = rigid human head" semantic contract.

The final current baseline is **Integrated Information / Roadmap R13.4**.

The key product semantics are:

- Treat the Kiwi model as a rigid human head.
- Do not deform the model to compensate for head-pose normalization.
- Keep Eye/Mouth non-rigid expression changes.
- Remove only the source person's rigid view pose from FacePart appearance.
- Map the head-local/canonical FacePart appearance to the existing fitted fixed surface.
- Apply the visible Kiwi Head rigid pose exactly once.
- Keep source-appearance de-rigidization authority separate from visible Kiwi Head pose authority.

The first H1 implementation candidate was **NO_GO and fully rolled back**. The reason was not that the H1 concept was disproven. The candidate worked only on MediaPipe frames and fell back on high-rate InferenceEngine frames because those frames did not have a same-sample FaceGeometry pose. Runtime sampling reported H1=7, SAFE_FALLBACK=21, and mode transitions=10. Therefore the candidate did not provide one coherent hybrid geometry contract.

The next investigation was narrowed from an immediate live dual-backend parity probe to a source-grounded contract audit. The current first unresolved Static boundary is:

`CURRENT_LOCAL_IE_DECODE_TO_INSTALLED_MEDIAPIPE_NORMALIZED_LANDMARK_CONTRACT`

The downstream target boundary is:

`NORMALIZED_468_TO_METRIC_FACE_GEOMETRY`

The runtime capability gap is:

`HIGH_RATE_IE_FRAME_LACKS_SAME_SAMPLE_FACEGEOMETRY_POSE`

R13.4 further corrected three Authority issues:
1. two historical reports contain different MediaPipe 0.16.3 archive SHA values, so the exact archive path/size/hash must be reconciled;
2. the P2 Canonical implementation path/SHA is historical and must not be promoted to current-local method authority without revalidation;
3. MediaPipe-equivalent FaceGeometry pose is a **source-appearance de-rigidization reference**, not an automatic replacement for the visible Kiwi Head rigid-pose authority.

R12's `VALIDATION_REDUCTION_WITHOUT_QUALITY_LOSS` principle remains active. The project must reduce redundant ownership, diagnostic branches, and repeated validation rather than weaken the final Definition of Done.

Production change at archive time: **NO**.
Commit/push: **NO**.

---

## OBJECTIVE

The main objectives of this chat were:

1. Redefine FacePart presentation around the assumption that the Kiwi model behaves visually like a rigid human head.
2. Compare the design against MediaPipe, public research, OSS, and known VTuber/AR systems.
3. Audit KiwiAvatarSystem's GitHub/current-source structure at method / statement / dataflow granularity.
4. Prepare highly specific Codex instructions that start from product semantics and trace exact files, methods, equations, ownership, timestamp/generation, lifecycle, and validation gates.
5. Reduce unnecessary Runtime and validator work without reducing final quality.
6. Reconcile older R12 integrated information with the new Human-Head / H1 work.
7. Merge integrated information and roadmap into one current baseline document.
8. Re-audit repeatedly until the baseline reached R13.4.

---

## CONFIRMED FACTS

### Current normal-chat Authority state

`NORMAL_CHAT_LIVE_LOCAL_PRODUCTION_NOT_DIRECTLY_VERIFIED`

Normal chat does not directly inspect the current live `D:\KiwiAvatarSystem` tree.

The latest local states used in this chat are **Codex report-time snapshots**, not automatically current now.

### Historical P1/P2 report-time snapshot

Git HEAD:
`27281c622d7b8bf2ececf711b037fc8f9e029004`

Workspace:
`DIRTY_USER_OWNED`

Important identities at that snapshot included:

- `FaceLandmarkerRunner.cs`
  `6C65C075270F10C791F6B044E3BC04C6024AADF916D65283F0EEFFA3448BBB93`
- `KiwiInferenceFaceTracker.cs`
  `CF860F4EF686BD5FDAC4140D4F3E73E64B6F390C3BC64204CF346011AC69380D`
- `KiwiFaceMotion.cs`
  `D00D4C86FB79B7F9B9AE3CFE791D7A819449D24D27154B31FFDF45964D8650C6`
- `FacePartCropper.cs`
  `39C06FEC43B4EA47AD783C233991E830E10B18DA285148E7A34B0C13DAD52CFE`
- `KiwiFacePartTextureTransaction.cs`
  `DC78488DCD1D2E45E5AA6F40065D4983087014B501B5FD5A8E37B6D8E0F68849`

### H1 report-time snapshot

Branch:
`work/raw-direct-motion`

HEAD:
`dff213b8a76677426e7810c8d9e4827185803602`

Initial status:
clean

Scene SHA:
`9BAC89F64B45429B38D41C1A2539C63D5E9A442E8EF920EE13B59245BE166735`

Scene coordinate contract:
- `mirrorX=0`
- `swapEyes=0`

The H1 candidate tracked changes were fully rolled back to baseline.

Commit/push:
NO.

### H1 Runtime result

Development compile/build:
PASS

Sampled runtime:
- H1=7
- SAFE_FALLBACK=21
- mode transition=10

High-rate IE frames had same-sample 468 Vector3 landmarks but no same-sample FaceGeometry pose.

Decision:
- `H1_PREVIOUS_CANDIDATE=NO_GO_ROLLED_BACK`
- `H1_CONCEPT=KEEP_UNPROVEN`
- `H1_MEDIAPIPE_ONLY_PRODUCTION=REJECT`
- `H1_HYBRID_CONTINUITY=FAIL`
- `PRODUCTION_CHANGE=NO`

H1 candidate Human Visual:
NOT_RUN

H1 Performance Authority:
NONE

### Prior same-build Human Visual retained as product evidence

- ROTATION_MATCH=FAIL
- EYE_TWIST=FAIL
- MOUTH_TWIST=FAIL
- MOUTH_SIZE=TOO_SMALL
- SURFACE_CLIP=FAIL
- LIVE_CAMERA=PASS

These Human Visual decisions are not overwritten by validator/log PASS.

### R12 / P2 Source-Grounded audit

The R12 `CAMERA_TO_MEDIAPIPE_TO_CANONICAL_SOURCE_GROUNDED_METHOD_DATAFLOW_SIMPLIFICATION_AUDIT` was later completed under P2.

P2 mode:
READ_ONLY

Production change:
NO

Runtime:
NO

P2 Source-grounded responsibility decisions included KEEP for:
- Native Path B contract
- latest-wins Native ownership
- immediate NV12 detach
- fixed Unity texture identity
- Runner pre-input fresh/latest mailbox
- MediaPipe internal FlowLimiter
- callback-time deep copy/lifetime contract
- claim-scoped timestamp/generation correlation
- Canonical coherent latch at that snapshot
- singular provider authority
- current Kiwi geometric rigid-head Primary authority
- current texture transaction until F2 proves failure
- Sentis hybrid until necessity/removal is measured

Important:
These are historical P2 responsibility decisions.
Exact current method/path/statement authority must be revalidated when paths/SHA changed.

### F3

Static owner plurality exists between:
- RigidSampleFrame
- SharedTiltLock

The later F3 Player experiment did not establish a valid Product Visual improvement.

Final:
- F3=INCONCLUSIVE
- SharedTiltLock retirement=NO_GO_NOT_AUTHORIZED

Therefore static plurality alone is not sufficient to retire SharedTiltLock.

### MediaPipe archive identity conflict

The current integrated baseline records a path-specific conflict:

Historical local tgz hash:
`CC3E77A219E0B99618AE3BE64C31A566197DEEDC69C1E136ACF52D65D7CF2E79`

Historical P2 archive hash:
`CC3E92785C890F1EC862185C30B31E7144BC51F1D8794FAFDEFA212C45242E79`

Consistent package.json SHA:
`EEBBFF4550FA9CA3C2C76AB05BD0EDBDB3A0A4C2800883E244DC9E40D8FF2A2D`

Therefore:
`MEDIAPIPE_ARCHIVE_SHA_CONFLICT=OPEN_PATH_SPECIFIC_RECONCILIATION`

No assumption that the two archive hashes represent the same artifact is allowed.

### Canonical implementation drift

Historical P2 Canonical path:
`Assets/KiwiAvatarSystem/Runtime/TrackingFoundation/KiwiCanonicalTrackingFrame.cs`

Historical P2 SHA:
`A10EC7889025BAABEB4B621956D5D0C7B8F6BA47B3674D0A8E12B7F968769DA9`

Later H1 report-time Canonical SHA:
`458FF33E98E054B766F20EB17CE6BDD242C9AD9FD6E73AF53D60BD3961822AFA`

Thus P2 exact method/path statements are historical only until current-local revalidation.

### LIVE CAMERA historical evidence

2026-09-06 P1-2:
- Original LIVE=560x315
- Audit FULL=560x315
- Audit 1:1=560x315
- same source/comparison texture
- 108/108 DIRECT_SAME_TEXTURE
- observerBlit=0
- observerReadback=0
- Human decision=BOTH_BAD_SIMILAR

Decision:
`DISPLAY_MINIFICATION_ONLY=REJECTED_OR_STRONGLY_WEAKENED`

But later scenarios could show LIVE CAMERA acceptable/PASS while FacePart remained bad.

Current classification:
- historical acceptance scopes can coexist
- LIVE CAMERA redesign priority is low
- keep 560x315 / 16:9 / Bilinear until new boundary-specific evidence

---

## PUBLIC DESIGN PRINCIPLES

### MediaPipe Face Landmarker / LIVE_STREAM

Public MediaPipe design supports:
- asynchronous live-stream operation
- bounded internal flow limiting
- explicit result/image/timestamp ownership
- landmark, blendshape, and facial transformation outputs

Kiwi pre-input latest/freshness and MediaPipe internal FlowLimiter are not automatically duplicate responsibilities; they operate at different boundaries.

### MediaPipe landmark postprocess

Public design follows the general chain:
model tensor
→ normalized landmarks
→ letterbox removal
→ ROI projection to source image
→ Z scale using projected crop X-axis

This is the reference family against which Kiwi's current IE decode contract must be compared.

### MediaPipe FaceGeometry

Public FaceGeometry design uses:
normalized screen landmarks
→ perspective camera metric space
→ weighted Procrustes scale estimation
→ unprojection
→ canonical→runtime pose
→ inverse-pose alignment to canonical metric landmarks

Important:
The facial transformation matrix is a canonical 3D→runtime rigid transform.
It is not a direct 2D camera-pixel inverse-warp matrix.

### Human-head design principle

For Kiwi:
- source-person rigid view pose should be removed from FacePart appearance
- non-rigid expression should remain
- the visible Kiwi Head pose should be applied exactly once
- source appearance de-rigidization and visible Head pose authority are separate claims

### External reuse principle

Source-public systems:
audit at method/statement/dataflow level.

Public API/sample systems:
audit at component/API level.

Closed commercial systems:
use documentation and lawful black-box behavior only.

Do not assert non-public internals.

Reuse only if:
- Kiwi responsibility decreases
- bug surface decreases
- latency/resource/lifecycle contract does not regress
- superseded Kiwi responsibility is retired

---

## INFERENCES / HYPOTHESES

The strongest current design hypothesis is still:

`SOURCE_VIEW_GEOMETRY_AND_MODEL_SURFACE_POSE_ARE_NOT_IN_A_SINGLE_CANONICAL_FACEPART_SPACE`

This hypothesis explains rotation/twist better than a simple Roll-only or billboard explanation, but it is not yet Production-proven.

The following remain hypotheses, not confirmed defects:

- current-local IE normalized landmark output is numerically/semantically identical to installed MediaPipe normalized landmark output
- a MediaPipe-equivalent metric geometry solver can be reused or minimally ported without lifecycle/resource regressions
- H1 will resolve ROTATION_MATCH / EYE_TWIST / MOUTH_TWIST once hybrid coverage is coherent
- MOUTH_SIZE and SURFACE_CLIP share the H1 root
- F1/F2/F3/F4 are current Product root causes
- Sentis/IE can be simplified or removed without losing current high-rate behavior

---

## PRODUCTION AUTHORITY

Priority used in this chat:

1. current local Production + SHA — unavailable directly in normal chat
2. same-Production Runtime
3. installed package source
4. latest Codex/Validation report-time snapshot
5. official documentation/source
6. local Git history / GitHub
7. older diagnostic evidence
8. articles/discussions/videos

Current normal-chat marker:
`NORMAL_CHAT_LIVE_LOCAL_PRODUCTION_NOT_DIRECTLY_VERIFIED`

The current baseline document is:
`KiwiAvatarSystem_最新統合情報_統合ロードマップ_R13_4_0909.txt`

Its role:
integrated current project state + roadmap baseline.

It does not replace current-local SHA verification.

---

## WORK PERFORMED

### 1. Human-head product semantics selected

Objective:
Make the Kiwi model behave visually like a rigid human head.

Result:
Adopted the design principle:
source rigid pose removed from appearance → head-local FacePart → fixed fitted surface → Kiwi Head pose once.

Impact:
Camera-facing billboard and direct 2D inverse-4x4 approaches were downgraded/rejected for Production semantics.

### 2. Public research / OSS / commercial comparison framing

Objective:
Use papers, public source, videos, OSS, and commercial software to avoid isolated Kiwi-only design.

Result:
Established evidence tiers and reuse gates.
MediaPipe FaceGeometry became the primary public mathematical reference, with Webcam Motion Capture and other VTuber/AR systems as comparative references.

Impact:
External Comparative Design Gate became mandatory before Production H1 implementation.

### 3. Static FacePart ownership audit

Objective:
Find actual owners for crop, UV, surface placement, roll sampling, expression zoom, visibility, and Head pose.

Result:
Confirmed owner plurality and missing full yaw/pitch/perspective canonicalization in the selected path.
SharedTiltLock alone was not accepted as full root.

Impact:
Moved focus from one Roll owner to source-view canonicalization.

### 4. H1 candidate design and Codex task packaging

Objective:
Test head-local source appearance normalization using MediaPipe same-result pose/landmarks.

Result:
Created detailed Codex task packages with method/statement/dataflow expectations.

Impact:
Local current implementation could be attempted without normal chat pretending to inspect `D:\KiwiAvatarSystem`.

### 5. H1 candidate runtime / rollback review

Result:
Compile/build PASS.
Runtime H1=7 / fallback=21 / transition=10.
Candidate rolled back.

Decision:
NO_GO for Production candidate.
H1 concept remains open.

Impact:
Established hybrid coverage/capability continuity as a prerequisite.

### 6. Immediate Runtime parity plan re-audited

Old idea:
live same-sample IE vs MediaPipe parity probe first.

New:
first close source/postprocess equivalence against current local + installed package.
Use deterministic self-test.
Runtime only for a remaining source-inconclusive claim.

Impact:
Reduced unnecessary observer/runtime work.

### 7. Detailed Codex instruction standard created

Codex instructions now must include:
GOAL
→ Authority
→ current dataflow
→ target design
→ exact file/class/method
→ statement/equation
→ owner
→ identity/timestamp/generation
→ lifecycle/resource
→ implementation
→ prohibited changes
→ Static Gate
→ Runtime only if required
→ validator self-audit
→ fixpoint
→ rollback
→ one report
→ one next action

Impact:
Avoids vague "audit and implement" prompts.

### 8. Integrated information / roadmap revisions

R13:
initial Human-Head integration.

R13.1:
restored Avatar architecture, source-comparison discipline, PS5.1 hardening, Native provenance.

R13.2:
corrected Static first boundary and moved External Comparative Gate before code changes.

R13.3:
merged integrated information + roadmap and restored R12/P2/F1-F4/historical evidence.

R13.4:
corrected Authority scope:
- MediaPipe archive SHA conflict
- P2 Canonical method/path historical-only
- source appearance FaceGeometry authority separate from visible Head authority

Final current baseline:
R13.4.

---

## VALIDATED DECISIONS

### Decision: Kiwi model = rigid human head

Reason:
Product requirement and more coherent head/FacePart authority.

Evidence:
Current design audit + public FaceGeometry principles.

Regression constraints:
No model deformation workaround.
No extra rigid owner.
No Root contamination.

Still current:
YES.

### Decision: H1 previous candidate rejected, H1 concept retained

Reason:
Hybrid coverage failed because high-rate IE frames lacked same-sample FaceGeometry pose.

Evidence:
H1 runtime 7/21/10 and rollback.

Regression constraints:
Do not reintroduce stale MP pose on IE frames.
Do not force MediaPipe-only Production.

Still current:
YES.

### Decision: first current Static boundary is IE decode → installed MediaPipe normalized landmark contract

Reason:
Current-local parity is not yet claim-closed.

Evidence:
R13.2/R13.4 re-audit.

Regression constraints:
Do not skip model provenance/letterbox/flip/index/timestamp identity.

Still current:
YES.

### Decision: External Comparative Design Gate before Production H1 code change

Reason:
User requirement and architecture-risk reduction.

Evidence:
R13.2+ roadmap.

Still current:
YES.

### Decision: visible Kiwi Head authority is separate from source appearance de-rigidization reference

Reason:
P2 maintained Kiwi geometric rigid-head Primary, while H1 uses FaceGeometry for source appearance normalization.

Regression constraints:
FaceGeometry solver must not automatically become visible Head owner.

Still current:
YES.

### Decision: R12 Validation Reduction retained

Reason:
Reduce responsibility/owner/diagnostic count rather than weaken final DoD.

Still current:
YES.

---

## REJECTED APPROACHES

### Rejected: MediaPipe-only H1 Production path

Why considered:
Same-result pose/landmarks provide coherent H1 data.

Why rejected:
Would fail hybrid continuity / remove current high-rate behavior.

Revisit condition:
Only if product architecture intentionally changes provider policy with evidence.

### Rejected: camera-facing billboard as final FacePart semantics

Why considered:
Could visually reduce twist.

Why rejected:
Violates rigid human-head surface semantics.

Revisit condition:
Diagnostic negative control only.

### Rejected: direct 2D inverse application of facialTransformationMatrix

Why considered:
Looks like an easy inverse-pose solution.

Why rejected:
The matrix is a 3D canonical→runtime rigid transform, not a 2D pixel inverse warp.

### Rejected: retire SharedTiltLock from Static plurality alone

Why considered:
Two sampling rotation owners exist.

Why rejected:
F3 Product Visual comparison was inconclusive.

Revisit condition:
After valid H1/control baseline, if a sampling-rotation-specific defect remains.

### Rejected: sequential F1→F2→F3→F4 mass Runtime

Why considered:
Would close every known candidate.

Why rejected:
Contradicts R12 Validation Reduction; many claims can be source-closed or deferred.

### Rejected: display-minification-only as LIVE CAMERA root

Evidence:
P1-2 BOTH_BAD_SIMILAR / same source.

### Rejected: CommandBuffer form alone as primary async/inference cause

Evidence:
v44.55.29 Direct/CB Graphics exact; CB Async remained different.

### Rejected without evidence:
- speculative Fence
- Wait
- queue flush
- async disable
- strong smoothing/Kalman workaround
- threshold relaxation
- FIFO/permanent delay
- external tracker Primary replacement
- Big-Bang rewrite
- neural replacement as Primary

---

## SUPERSEDED CONCLUSIONS

### OLD:
R12 NEXT_SINGLE_ACTION =
`CAMERA_TO_MEDIAPIPE_TO_CANONICAL_SOURCE_GROUNDED_METHOD_DATAFLOW_SIMPLIFICATION_AUDIT`

### NEW:
That P2 audit is COMPLETE.
Current NEXT_SINGLE_ACTION =
`IE_TO_MEDIAPIPE_GEOMETRY_CONTRACT_DETAILED_AUDIT`

### WHY:
P2 closed the broad Camera→MediaPipe→Canonical responsibility map enough to protect the existing working core. Current unresolved work is narrower and FaceGeometry-specific.

---

### OLD:
Immediate live same-sample IE/MediaPipe Runtime parity probe.

### NEW:
Current-local + installed-package source contract audit first, then deterministic solver self-test, then only residual same-image replay if required.

### WHY:
Public/remote source suggested structural parity sufficient to justify a Static-first closure.

---

### OLD:
Full Matrix4x4 availability is the sole feasibility gate for canonicalization.

### NEW:
A 3D pose matrix alone is not a 2D camera-pixel inverse warp. Correct geometry requires pose + projection/correspondence, or equivalent landmark-based canonical mapping.

---

### OLD:
R13 / R13.1 / R13.2 / R13.3 as current integrated baseline.

### NEW:
R13.4.

### WHY:
Repeated re-audit restored historical contract state and corrected Authority scope.

---

## OBSERVER / VALIDATOR FINDINGS

1. An H1 diagnostic field `maskPixelMapping` was not an independent producer comparison and was effectively hard-coded telemetry.
2. `owners=1` was mapper-derived rather than an independent read of all writers.
3. These values cannot be treated as proof of mask transaction equality or global single-owner authority.
4. P1-1 1280x720 visual measurement was NOT_EVALUABLE because audit surfaces overlapped.
5. F3 Product Visual comparison was inconclusive; no retirement authorization.
6. Observer-heavy H1 runs have no Performance Authority.
7. Performance and Correctness remain separate.
8. Future validator/collector must independently read producer identities and compare at collection time.

---

## FILES / SHA256

### Current integrated baseline

Path:
`KiwiAvatarSystem_最新統合情報_統合ロードマップ_R13_4_0909.txt`

Role:
Current integrated information + roadmap baseline

SHA256:
`33C7C57C3A44E045A9E1DC6CDFC69F5782FF82BB3A700DC513093B50896F9543`

Current/Obsolete:
CURRENT

### R13.4 integrated package

File:
`KiwiAvatarSystem_R13_4_IntegratedInfoRoadmap_Reaudit_20260909.zip`

Role:
Distribution package for R13.4 baseline

SHA256:
`8F917082298F4E2AB940C62DFBC5CD020DE404C360943FBF9A0ED586FEE2FEFD`

Current/Obsolete:
CURRENT_REFERENCE_PACKAGE

### Detailed Codex task package created earlier

File:
`KiwiChat_IEFaceGeometrySourceEquivalence_DetailedCodex_20260908-2330JST.zip`

SHA256:
`C48404647EA0EBEB2F6D0A1973F99A724E54626282684CEDCE9C3AA7D779E9EC`

Role:
Detailed method/statement/dataflow Codex instruction package.

Current/Obsolete:
PARTIALLY_SUPERSEDED_AS_EXECUTION_PAYLOAD

Reason:
It predates R13.4 Authority corrections:
- MediaPipe archive SHA conflict
- P2 Canonical path historical-only rule
- source appearance pose reference vs visible Head authority split

Its instruction style remains valid, but the task content should be regenerated or amended before the next Codex execution.

### Source-equivalence task package

File:
`KiwiChat_IEFaceGeometrySourceEquivalence_Updated_20260908-2321JST.zip`

SHA256:
`3F6963785CB54FAF990DFE87807AC11F1BD56EFDFFADFCBDEDB016F0118810A8`

Current/Obsolete:
SUPERSEDED_BY_DETAILED_TASK_AND_R13_4_CORRECTIONS

### R13.2 integrated package

SHA256:
`F3852E3EE0322E9FD73BA6A5C1189A5BC588F43030BB7307EC0838A7B21C8E41`

Current/Obsolete:
SUPERSEDED

### R13.3 integrated package

SHA256:
`71B9E9E1637773A25F1D5213E63F6BB452164E4E3DC16F645288FC15FAA3A18D`

Current/Obsolete:
SUPERSEDED_BY_R13_4

### Live local Production files

Normal chat status:
`SHA256=NOT_AVAILABLE_IN_NORMAL_CHAT` unless provided by a Codex report-time snapshot.

Do not invent current SHA.

---

## RUNTIME EVIDENCE

### H1 Runtime

Authority:
CORRECTNESS / SUPPORTING
NOT PERFORMANCE

Result:
H1=7
SAFE_FALLBACK=21
transition=10

Decision:
H1 hybrid continuity FAIL.
Candidate rolled back.

### P1-2 LIVE CAMERA

Authority:
VISUAL / CORRECTNESS-SUPPORTING
NOT PERFORMANCE

Result:
same source texture, FULL and 1:1 comparison both visually bad/similar.

Decision:
display-minification-only root rejected/strongly weakened.

### F3 Player

Authority:
DIAGNOSTIC / VISUAL-INCONCLUSIVE

Decision:
SharedTiltLock retirement not authorized.

### Clean Performance

Authority:
UNAVAILABLE for current H1/current workspace.

---

## CURRENT RESULT

Current integrated baseline:
**R13.4**

Current product design:
**Rigid Human-Head semantics**

Current H1 state:
**Previous candidate NO_GO / fully rolled back; concept KEEP_UNPROVEN**

Current first Static unresolved boundary:
`CURRENT_LOCAL_IE_DECODE_TO_INSTALLED_MEDIAPIPE_NORMALIZED_LANDMARK_CONTRACT`

Current downstream geometry target:
`NORMALIZED_468_TO_METRIC_FACE_GEOMETRY`

Current runtime capability gap:
`IE_FRAME_LACKS_SAME_SAMPLE_FACEGEOMETRY_POSE`

Current visible Head authority:
`KEEP_KIWI_GEOMETRIC_PRIMARY_UNTIL_SEPARATE_EVIDENCE`

Current source-appearance pose reference candidate:
`FACEGEOMETRY_CANDIDATE`

Production change:
NO.

Commit/push:
NO.

---

## OPEN ISSUES

1. Current live local branch/HEAD/status/SHA are not directly verified in normal chat.
2. MediaPipe 0.16.3 archive SHA conflict requires exact path/size/hash reconciliation.
3. Current Canonical file path/class/SHA must be re-resolved after historical path/state drift.
4. Exact IE model provenance/input-output contract remains to be closed.
5. Exact current-local IE normalized landmark contract versus installed MediaPipe remains open.
6. Installed FaceGeometry reuse vs version-matched minimal solver port remains undecided.
7. External Comparative Design Gate must be refreshed against the exact P1 boundary before Production H1 code.
8. H1 all-provider coherent hybrid geometry remains unimplemented.
9. F1 expression input authority remains DEFERRED_OPEN.
10. F2 exact native FacePart transaction identity remains DEFERRED_OPEN.
11. F3 sampling-rotation retirement remains DEFERRED_OPEN / DO_NOT_RETIRE.
12. F4 temporal plurality remains DEFERRED_OPEN.
13. MOUTH_SIZE and SURFACE_CLIP remain separate unproven boundaries.
14. Clean Production Performance Authority remains unavailable.
15. Full Native reproducible source→build→artifact→installed SHA closure remains incomplete.
16. Latest custom-instruction artifact predates R13.4 Authority corrections and should eventually be synchronized.
17. Existing Detailed Codex task ZIP predates R13.4 corrections and should be regenerated/amended before execution.

---

## NEXT ACTION

Primary project action:
`IE_TO_MEDIAPIPE_GEOMETRY_CONTRACT_DETAILED_AUDIT`

Before sending to Codex:
Regenerate or amend the detailed Codex task ZIP so it explicitly includes R13.4 corrections:

- resolve exact MediaPipe archive path/size/SHA conflict
- resolve current Canonical path/class/SHA
- treat P2 exact method/path as historical until current-local revalidation
- keep FaceGeometry source-appearance de-rigidization authority separate from visible Kiwi Head authority
- keep Runtime disabled by default
- stop on exact first Static failing boundary
- no Production H1 implementation in P1

P1 required immediate result:
`STATIC_NORMALIZED_LANDMARK_CONTRACT=PASS|FAIL|INCONCLUSIVE`

If PASS:
Proceed to **External Comparative Design Gate** before any Production H1 code change.

If FAIL/INCONCLUSIVE:
Return exact first failing method/statement/dataflow boundary and stop.

---

## DO NOT CHANGE

Without new boundary-specific evidence, do not change/reintroduce:

- Face Landmarker Primary / Source of Truth
- Native Path B
- latest-frame principle
- Runner pre-input latest/freshness responsibility
- MediaPipe internal FlowLimiter responsibility
- persistent ROI
- bounded/nonblocking
- FIFO / stale queue / permanent frame delay
- stale prediction
- strong smoothing / Kalman workaround
- threshold relaxation
- stable Unity-visible texture identity
- UpdateExternalTexture
- IMFSample retention across callback/worker
- rotating Unity-visible texture
- D3D11On12 1080p
- D3D12 queue Wait / blocking GPU wait
- speculative Fence / Wait / flush / async disable
- Root/Head/Eye/Mouth authority separation
- Head single rigid authority
- Provider normalization owner=1
- Resume != Provider Switch
- same-sample Texture/Crop/Mask/FacePart transaction
- 560x315 exact 16:9 / Bilinear LIVE CAMERA configuration
- KiwiFaceMotion / KiwiInferenceFaceTracker as camera/display workaround
- forced MediaPipe-only Production
- SharedTiltLock retirement from Static plurality alone
- external tracker Primary replacement
- Big-Bang rewrite
- neural face replacement as Primary

---

## HANDOFF

A new chat can resume from this report plus the current R13.4 integrated baseline.

Start state:

1. Use R13.4 as the current integrated information + roadmap baseline.
2. Treat all local SHA states as report-time snapshots unless Codex re-freezes current local.
3. Do not return to R12's old NEXT_SINGLE_ACTION; P2 broad Source-Grounded audit is complete.
4. Do not mass-run F1/F2/F3/F4.
5. Do not reopen LIVE CAMERA display tuning without new boundary-specific evidence.
6. Do not interpret FaceGeometry pose as visible Head authority.
7. Before the next Codex run, update the Detailed Codex task package to R13.4.
8. Execute P1 read-only:
   `IE_TO_MEDIAPIPE_GEOMETRY_CONTRACT_DETAILED_AUDIT`
9. If P1 PASS, run the External Comparative Design Gate.
10. Only then implement/test the metric geometry solver and later H1 Production candidate.

Current critical chain:

Authority Preflight
→ IE normalized-landmark contract
→ External Comparative Design Gate
→ deterministic metric FaceGeometry solver/self-test
→ residual same-image replay only if required
→ H1 hybrid implementation
→ transaction/ownership closure
→ same-build Human Visual rotation/twist
→ Mouth Size / Surface Clip separate closure
→ lifecycle/golden replay/simplification
→ Avatar product/runtime
→ clean performance
→ release/Windows acceptance

---

## PROJECT MASTER REPORT UPDATE CANDIDATES

Archive Name:
`KiwiChat_HumanHeadFacePartGeometry_R13_4_Updated_20260909-JST.zip`

LastWorkUpdate:
2026-09-09

Validated Decision:
Rigid Human-Head semantics; H1 previous candidate NO_GO but concept retained; Static-first IE→MediaPipe contract audit; source-appearance FaceGeometry authority separated from visible Head authority.

Rejected Approach:
MediaPipe-only H1 Production; billboard semantics; direct 2D inverse-4x4; sequential F1-F4 Runtime; speculative GPU synchronization; SharedTiltLock retirement without valid Visual proof.

Superseded Conclusion:
R12 old NEXT action; R13/R13.1/R13.2/R13.3 baselines; immediate live parity probe.

Open Issue:
MediaPipe archive SHA conflict, current Canonical path/SHA, IE normalized landmark contract, H1 hybrid coverage.

Next Action:
R13.4-aligned detailed Codex P1 audit.

---

## SOURCE BASIS

Primary chat/project sources referenced in this archive:

- `KiwiAvatarSystem_最新統合情報_統合ロードマップ_R13_4_0909.txt`
- `KiwiAvatarSystem_最新統合情報_ValidationReduction_R12_0906_1525*.txt`
- `KiwiAvatarSystem 情報源・Authority一覧`
- `Github-リポジトリ.txt`
- `KiwiAvatarSystem 通常チャット用 恒久REPORT・ZIP直接作成指示`
- Prior Codex reports and Runtime results summarized/referenced by R13.4
- Current-chat generated H1 / IE geometry / R13.x artifacts

External/public design basis summarized in the chat:
- MediaPipe Face Landmarker / FaceGeometry / landmark projection / weighted Procrustes public source
- Microsoft Media Foundation SourceReader async model
- public OSS/commercial comparison framework

No external public source is treated as current-local Implementation Authority.

---

END_OF_CHAT_PERMANENT_REPORT
