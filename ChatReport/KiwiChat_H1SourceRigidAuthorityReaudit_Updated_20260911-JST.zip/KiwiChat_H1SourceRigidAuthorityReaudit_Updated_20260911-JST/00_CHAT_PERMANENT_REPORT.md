# KiwiAvatarSystem Chat Permanent Report

ChatTopic: H1 Local Activation Authority Static Closure Reaudit / Source-Rigid Authority Design Correction  
ChatTitle: H1 Static Closure 再監査と source-rigid authority 最小設計修正  
ArchiveName: KiwiChat_H1SourceRigidAuthorityReaudit_Updated_20260911-JST.zip  
LastWorkUpdate: 2026-09-11  
LastWorkUpdatePrecision: DATE_ONLY  
ArchiveCreated: 2026-09-11 19:22 JST  
ArchiveTimestampBasis: LAST_RELEVANT_WORK_BEFORE_ARCHIVE_REQUEST  
Project: D:\KiwiAvatarSystem  
Unity: 6000.0.80f1  
CurrentInvestigationVersion: H1_LOCAL_ACTIVATION_AUTHORITY_STATIC_CLOSURE → H1_SOURCE_RIGID_AUTHORITY_AND_PRODUCT_BRIDGE_DESIGN_FREEZE  
Status: PARTIALLY_DONE

## EXECUTIVE SUMMARY

このチャットでは、Codex成果物
`KiwiCodexConsolidatedReport_H1_LocalActivationAuthorityStaticClosure_20260911-173119JST(1).txt`
を基準に、H1 minimal same-sample Human Head FacePart Product Integration の実装前Static Closureを通常チャット側で独立再監査した。

Codex REPORTの主要結論である以下は維持した。

- current Productには accepted FaceGeometry Pose16 → actual Product FacePart consumer bridge が存在しない。
- P3D Product activation は current static default では OFF。
- visible AvatarMotionRoot rigid writer は KiwiFaceMotion 1系統。
- current source appearance roll removal は
  `KiwiFacePartRigidSampleFrame` と `KiwiFacePartSharedTiltLock`
  の2系統が独立してProduction-activeで、同じsource in-plane roll removal責務へ累積適用される。
- よって Classification C は妥当。
- H1 Implementation Ready は「9 static claimsが閉じ、次のDesign Freezeへ進める」という限定的意味でのみYES。Runtime/Human Visual/Performance PASSではない。

一方、Codex REPORT末尾の設計候補
「RigidSampleFrameを残し、SharedTiltLockを退役」
を最終H1設計としてそのまま採用することは、このチャットで棄却した。

理由:
H1のPose16 Product bridge自身が full source-rigid de-rigidization を担う場合、
RigidSampleFrameが独立してbilateral-eye rollを再推定・再除去すると、
Pose16 de-rigidization + legacy roll removal の二重authorityになる。
これは Human-Head契約の
「source rigid poseを1回だけ除去」
およびsingle-owner原則に反する。

このチャットでの最善の次設計候補は、
**Pose16 Product bridgeをsource-rigid de-rigidizationの唯一のauthorityにする**
こと。
RigidSampleFrame / SharedTiltLock は独立roll estimator/temporal authorityとしてはH1-active pathから外し、
再利用する場合も計算済み結果を適用するstateless sinkに限定する。

コード変更、Unity compile/build、Runtime、Human Visual、Performance測定、commit/pushは行っていない。

## OBJECTIVE

P3Dで成立したsame-sample FaceGeometry poseを、Eye/Blink/Mouth/Expressionのnon-rigid appearanceを保持したままKiwiのfixed fitted surfaceへhead-localで適用するH1へ進む前に、

- Product activation
- identity
- source appearance de-rigidization authority
- visible Head rigid authority
- temporal authority
- existing bridge有無

をStatic/Package evidenceで閉じ、
複数rigid-normalization ownerを追加しない最小設計へ収束させる。

最終ユーザー可視要件への直接寄与:
ROTATION_MATCH / EYE_TWIST / MOUTH_TWIST / Root non-movementを正しく閉じるための前提Authority設計。

## CONFIRMED FACTS

### Confirmed Static / Codex report-time snapshot

Source REPORTによるreport-time identity:

- Project: `D:\KiwiAvatarSystem`
- Unity: `6000.0.80f1`
- branch: `work/raw-direct-motion`
- HEAD: `7969a47342c712aa2a5bdfa13a5967a73db5e0e0`
- tree: `166446995724b17b3cb6297c4feb3a569977ff02`
- Subject: `p3d`
- P3D Product activation default: OFF
- Existing accepted Pose16 → Product FacePart bridge: NONE FOUND
- Visible rigid authority: 1 (`KiwiFaceMotion -> AvatarMotionRoot.localRotation`)
- Source appearance roll-removal active independent owners: 2
  - `KiwiFacePartRigidSampleFrame`
  - `KiwiFacePartSharedTiltLock`
- Classification: C
- FULL_AUDIT_1: PASS
- FULL_AUDIT_2: PASS
- AUDIT_DISAGREEMENT: NONE
- Unity compile/build/runtime: NOT RUN BY SCOPE

Important source SHA256 from the Codex report:

- `KiwiFaceMotion.cs`
  `D00D4C86FB79B7F9B9AE3CFE791D7A819449D24D27154B31FFDF45964D8650C6`
- `KiwiFaceGeometryTransactionService.cs`
  `4751F9E4CE2FFE51B5ECEAF5AC1E223C899779B727AFD5BF39E51B005E423A72`
- `KiwiFacePartRigidSampleFrame.cs`
  `578CE2ED93A2A78EE1B19D8FF309A115A2FA53596E79BAAB0534A27AC10077C0`
- `KiwiFacePartSharedTiltLock.cs`
  `0BCCA0B7BD6982B78C0FC18058ACD54D073D786820F7B027B8C2F218EF2CAE70`
- `KiwiFacePartTextureTransaction.cs`
  `DC78488DCD1D2E45E5AA6F40065D4983087014B501B5FD5A8E37B6D8E0F68849`
- `FacePartCropper.cs`
  `39C06FEC43B4EA47AD783C233991E830E10B18DA285148E7A34B0C13DAD52CFE`

### Confirmed Package

Codex REPORTによるinstalled package identity:

- MediaPipeUnityPlugin: `0.16.3`
- Inference Engine: `2.4.1`

このチャットではPackage Source自体を再変更・再検証していない。

### Normal-chat verification scope

通常チャットから現在の `D:\KiwiAvatarSystem` live-local Productionは直接確認していない。

Authority label:
`NORMAL_CHAT_LIVE_LOCAL_PRODUCTION_NOT_DIRECTLY_VERIFIED`

CodexのHEAD/SHAはreport-time snapshotであり、current live Productionへ自動昇格しない。

GitHub remote上で同commit/tree参照の整合確認を行ったが、
remoteはLocal Production Authorityではなくsupporting/reference evidenceに限定した。

## PUBLIC DESIGN PRINCIPLES

このチャットで新規の外部公開情報調査は行っていない。

適用したProject-level design principles:

- Face Landmarker = Primary / Source of Truth
- source appearance de-rigidization と visible Head rigid authority は別責務
- source rigid poseは1回だけ除去する
- visible Head rigid poseは1回だけ適用する
- Root / Head / Eye / Mouth authorityを分離する
- RootへYaw/Pitch/Roll/Blink/Mouth/Eyeを混入しない
- same-sample identityを維持する
- duplicate/out-of-order/stale/mixed epoch publishを許可しない
- new FIFO/history/prediction/strong smoothingを追加しない
- working Camera/Native/backend/Tracking CoreをH1の都合で変更しない
- Static/Packageで閉じるclaimを不要にRuntime化しない

## INFERENCES / HYPOTHESES

### Design inference accepted in this chat

Pose16 Product bridgeがyaw/pitch/rollを含むfull source-rigid appearance removalを担当するなら、
`RigidSampleFrame`が独立roll estimatorとして残ることは二重source-roll authorityになる。

このため最終H1候補では:

- Pose16 bridge = 唯一のsource-rigid de-rigidization authority
- `RigidSampleFrame` = 独立roll estimator/temporal ownerとしては停止
- `SharedTiltLock` = 独立roll estimator/temporal ownerとしては停止
- legacy componentを再利用する場合 = stateless applier/sinkに限定

とするのがsingle-owner契約に最も整合する。

### Still unverified

- Pose16 matrix direction
- coordinate system / handedness
- inverse適用方向
- 実装後のEye/Mouth visual semantic correctness
- same-build Runtime identity/lifecycle
- Human Visual
- clean Performance

これらは推測でPASSにしない。

## PRODUCTION AUTHORITY

Claim-scoped authority:

1. Current local Production source + SHA
2. Same-build/same-Production Runtime
3. Actually installed Package Source
4. Current Codex Consolidated REPORT
5. Official/public source
6. GitHub remote/reference

本チャットのLocal Production:
`NOT_DIRECTLY_VERIFIED`

使用Authority:
- Primary static basis: Codex report-time local snapshot
- Supporting: GitHub remote consistency check
- Normal-chat design review: source effects / authority contract comparison

未使用:
- old H1 high-rate IE candidate
- superseded 78933d... authority
- diagnostic-only resultsのProduction昇格

## WORK PERFORMED

### 1. H1 Local Activation Authority Static Closure report受領
目的:
Codexが閉じた9 static claims、activation graph、identity、rigid/temporal ownerを独立再監査する。

結果:
Source REPORTの大枠は整合。

判定:
PASS / retain with scope limits.

影響:
Classification Cを維持。

### 2. Authority scope再確認
目的:
report-time HEAD/SHAとcurrent live Productionを混同しない。

結果:
`7969a473...` はCodex report-time snapshotとしてのみ採用。
Normal Chat live-localは未確認。

判定:
PASS.

### 3. Existing bridge / activation / visible rigid owner再監査
目的:
H1前に既存Product bridgeやalternate visible Head writerがないか確認。

結果:
- Existing Pose16 Product bridge absent.
- P3D Product activation default OFF.
- visible rigid writer remains KiwiFaceMotion one path.

判定:
PASS/CLOSED at static scope.

### 4. Source appearance roll authority再監査
目的:
`RigidSampleFrame` と `SharedTiltLock` の効果が本当に同責務か評価。

結果:
Codex REPORTの
mesh UV rotation + shader UV rotation が累積し、
両者が独立したsource in-plane roll removal ownerであるという結論を維持。

判定:
SOURCE_ROLL_OWNER_COUNT=2 / overlap confirmed statically.

### 5. Codex REPORT next-design recommendation再評価
目的:
「RigidSampleFrameを残す」案が最終H1 single-owner契約を満たすか確認。

結果:
そのままでは満たさない。
Pose16 full source-rigid removalを追加すると、
legacy roll ownerを1つ残しただけでも二重authorityになる可能性が高い。

判定:
REPORT candidate recommendation requires correction.

### 6. H1 source-rigid authority design correction
目的:
first proven boundaryだけに限定し、最小責務でsingle-owner化する。

結果:
Pose16 Product bridgeをsource-rigid de-rigidizationの唯一のauthorityとする方針を採用。
legacy roll estimator 2系統はH1-active authorityから外す。

判定:
DESIGN_DIRECTION_ACCEPTED / implementation not yet authorized.

## VALIDATED DECISIONS

Decision:
`Classification C` を維持。

Reason:
既存Pose16 Product bridgeなし + current source-roll independent owner overlapあり。

Evidence:
Codex Static Closure report + normal-chat independent review.

Regression constraints:
Camera/Native/backend/Tracking Coreへ拡張しない。

Still current:
YES.

---

Decision:
Final H1ではPose16 Product bridgeをsource-rigid appearance removalの唯一のauthority候補とする。

Reason:
Human-Head契約はsource rigid pose removal exactly onceを要求する。
legacy independent roll estimatorを残すと二重authorityになる。

Evidence:
Current source-effect ledger:
RigidSampleFrame mesh-UV rotation / SharedTiltLock shader-UV rotation /
future Pose16 full rigid removal responsibilities.

Regression constraints:
- KiwiFaceMotion remains sole visible AvatarMotionRoot rigid writer.
- No Root translation publication from H1.
- No FIFO/history/prediction/new smoothing.
- No legacy per-frame fallback switching to another roll owner.

Still current:
YES, as normal-chat design freeze candidate pending exact transform contract.

## REJECTED APPROACHES

Rejected:
`Pose16 source-rigid removal + RigidSampleFrame independent roll estimation` as final H1 active design.

Why considered:
Codex REPORT statically favored retaining RigidSampleFrame and retiring SharedTiltLock.

Why rejected:
source rigid poseを1回だけ除去する契約に対し、
Pose16 + residual independent roll removal の二重authorityになる。

Evidence:
Static effect responsibilities.

Revisit condition:
RigidSampleFrameがindependent estimatorではなく、
Pose16計算済み結果のstateless application sinkへ限定されることがSourceで証明された場合。

---

Rejected:
`SharedTiltLock`をH1-active independent source-roll ownerとして継続。

Why rejected:
duplicate source roll authorityを維持するため。

Revisit condition:
none unless responsibility is changed to a non-authoritative stateless application role.

## SUPERSEDED CONCLUSIONS

OLD:
Codex REPORT next-design candidate:
「RigidSampleFrameを残し、SharedTiltLockを退役」

NEW:
Pose16 bridgeを唯一のsource-rigid de-rigidization authorityとし、
RigidSampleFrame / SharedTiltLockの双方をindependent roll estimator/temporal authorityから外す。

WHY:
Pose16 full rigid removal導入後は、legacy roll ownerを1つ残すだけでも二重source-rigid authorityになるため。

EVIDENCE:
Static effect chain and Human-Head single-owner contract.

Scope:
design conclusion only.
No Production implementation has been changed.

## OBSERVER / VALIDATOR FINDINGS

- Source REPORT自身はStatic/Package scopeをRuntimeへ昇格していない。
- FULL_AUDIT_1 / FULL_AUDIT_2はreport上一致。
- Observer/Validator defectは本チャットで新規発見していない。
- Human VisualをStatic PASSで代替していない。
- Performance Authorityは取得していない。
- Diagnostic-only P3D activationをProduct activationとは扱っていない。

## FILES / SHA256

Path:
`/mnt/data/KiwiCodexConsolidatedReport_H1_LocalActivationAuthorityStaticClosure_20260911-173119JST(1).txt`

Role:
Primary uploaded Codex evidence for this chat.

SHA256:
`5140866E975B56BACD66FCBF50D7CFA28856D865CE0FE57643E984B1B87CED1E`

Before/After:
Unmodified / read-only basis.

Current/Obsolete:
CURRENT supporting report-time evidence for this chat.
Not current-live Local Production by itself.

No source code was modified in this chat.

## RUNTIME EVIDENCE

New Runtime evidence:
NONE.

Compile/build:
NONE.

Human Visual:
NONE.

Performance benchmark:
NONE.

Authority categories used:
- STATIC_ONLY: Codex H1 Local Activation Authority Static Closure report
- SUPPORTING_ONLY: GitHub remote consistency lookup
- CORRECTNESS/PERFORMANCE/VISUAL new evidence: NONE

Past P3D Runtime remains retained historical/current report-scope evidence but was not re-run here.

## CURRENT RESULT

`STATIC_CLOSURE=ACCEPT_WITH_ONE_DESIGN_CORRECTION`

Retained:
- Classification C
- Existing bridge absent
- P3D default Product activation OFF
- visible Head rigid authority count=1
- current independent source-roll authority count=2
- Static scope closed
- Runtime/Human Visual/Performance not passed

Corrected:
- Do not freeze `RigidSampleFrame` as an independent surviving roll authority beside Pose16 full de-rigidization.
- Final H1 design candidate should use Pose16 bridge as the single source-rigid de-rigidization authority.

Implementation:
NOT YET AUTHORIZED BY THIS CHAT.

## OPEN ISSUES

1. Pose16 matrix directionをexact source contractで確定。
2. Coordinate system / handedness / inverse directionを確定。
3. Product-owned activation/lifecycleを定義。
4. accepted Pose16 identity tupleをProduct FacePartへ最小handoffする方法をfreeze。
5. RigidSampleFrame / SharedTiltLockのH1-active authority retirement方法をexact sourceで決定。
6. generation mismatch/restart時にlegacy ownerへper-frame fallbackしないことを契約化。
7. 実装後 exact Unity compile。
8. targeted same-build Runtime identity/transaction/lifecycle。
9. same-build Human Visual:
   neutral / yaw / pitch / roll / combined /
   Eye / Blink / Mouth / Expression /
   Root non-movement。
10. clean PerformanceはH1 correctness/visual後の適切なgateで実施。

## NEXT ACTION

`H1_SOURCE_RIGID_AUTHORITY_AND_PRODUCT_BRIDGE_DESIGN_FREEZE`

最小scope:

- Pose16 transform contract
- one source-rigid authority
- Product activation owner
- accepted same-sample identity handoff
- generation/lifecycle behavior
- legacy roll owner retirement semantics

禁止:
Camera / Native / backend / tracking threshold / smoothing / prediction / Root math最適化を混ぜない。

Design Freezeが独立監査で閉じた後にのみ、
first proven boundaryへ最小Production実装を行う。

## DO NOT CHANGE

次Evidenceまで変更しない:

- Face Landmarker Primary / Source of Truth
- Native Path B SystemMemoryNV12
- Camera cadence / queue / fence / async mode
- KiwiInferenceFaceTracker
- KiwiFaceMotion visible rigid ownership
- Root translation contract
- Tracking Core thresholds/math
- strong smoothing / Kalman / stale prediction
- FIFO/history/permanent buffering
- existing fixed fitted surface architecture
- P3D Geometry Core correctness/lifecycle contract

## PROJECT MASTER REPORT UPDATE CANDIDATES

Archive:
`KiwiChat_H1SourceRigidAuthorityReaudit_Updated_20260911-JST.zip`

LastWorkUpdate:
`2026-09-11` DATE_ONLY

Validated Decision:
Classification C retained.
Pose16 Product bridge should be the single source-rigid de-rigidization authority candidate.

Rejected Approach:
Pose16 full de-rigidization + independent surviving RigidSampleFrame roll estimator.

Superseded Conclusion:
Codex report candidate retaining RigidSampleFrame as independent active owner is not accepted as final H1 design.

Open Issue:
Exact Pose16 transform/activation/identity/lifecycle design freeze.

Next Action:
`H1_SOURCE_RIGID_AUTHORITY_AND_PRODUCT_BRIDGE_DESIGN_FREEZE`

Local MASTER REPORT update:
NOT PERFORMED in normal chat.

## CHAT ARCHIVE INDEX

Archive: `KiwiChat_H1SourceRigidAuthorityReaudit_Updated_20260911-JST.zip`  
Topic: H1 Source-Rigid Authority Reaudit  
LastWorkUpdate: 2026-09-11  
Status: PARTIALLY_DONE  
Supersedes: none as whole archive; supersedes the report's tentative final-H1 owner recommendation only  
SupersededBy: none  
NextArchiveCandidate: H1 Source-Rigid Authority and Product Bridge Design Freeze completion

## HANDOFF

次チャットでは以下から再開する。

Current trusted state:
- P3C_1=RETAIN_PASS.
- P3D FaceGeometry Correctness/Lifecycle=PASS within prior scope.
- H1 Runtime/Human Visual/Performance=NOT PASS / NOT RUN.
- Codex report-time local snapshot for this task:
  `work/raw-direct-motion / 7969a47342c712aa2a5bdfa13a5967a73db5e0e0`.
- Normal-chat current live local:
  `NORMAL_CHAT_LIVE_LOCAL_PRODUCTION_NOT_DIRECTLY_VERIFIED`.
- H1 Static Closure:
  `Classification C`.
- Existing accepted Pose16 Product bridge:
  NONE FOUND.
- visible rigid writer:
  `KiwiFaceMotion -> AvatarMotionRoot`, single.
- current legacy source-roll owners:
  RigidSampleFrame + SharedTiltLock, two independent cumulative paths.
- This chat's design correction:
  final H1 must not keep either legacy component as an independent roll estimator beside Pose16 full source-rigid removal.
  Pose16 bridge is the single de-rigidization authority candidate.
- Next:
  `H1_SOURCE_RIGID_AUTHORITY_AND_PRODUCT_BRIDGE_DESIGN_FREEZE`.
- Do not broaden into Camera/Native/backend optimization.
- Do not implement before matrix direction / coordinate / inverse / activation / identity / lifecycle contract is frozen.
