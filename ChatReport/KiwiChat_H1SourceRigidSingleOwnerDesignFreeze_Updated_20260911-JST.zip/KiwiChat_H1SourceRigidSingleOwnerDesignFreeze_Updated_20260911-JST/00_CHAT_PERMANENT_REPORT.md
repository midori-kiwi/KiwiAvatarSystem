# KiwiAvatarSystem Chat Permanent Report

ChatTopic: H1SourceRigidSingleOwnerDesignFreeze  
ChatTitle: H1 Source Rigid Single-Owner Design Freeze / Local Retirement Authorization  
ArchiveName: KiwiChat_H1SourceRigidSingleOwnerDesignFreeze_Updated_20260911-JST.zip  
LastWorkUpdate: 2026-09-11  
LastWorkUpdatePrecision: DATE_ONLY  
ArchiveCreated: 2026-09-11 19:38:43 +09:00  
ArchiveTimestampBasis: LAST_RELEVANT_WORK_BEFORE_ARCHIVE_REQUEST  
Project: D:\KiwiAvatarSystem  
Unity: 6000.0.80f1 / Windows / DX12  
CurrentInvestigationVersion: H1_MINIMAL_SAME_SAMPLE_HUMAN_HEAD_FACEPART_PRODUCT_INTEGRATION  
Status: IN_PROGRESS

AuthorityNotice: NORMAL_CHAT_LIVE_LOCAL_PRODUCTION_NOT_DIRECTLY_VERIFIED

---

## EXECUTIVE SUMMARY

このチャットでは、直前に完了した `H1_LOCAL_ACTIVATION_AUTHORITY_STATIC_CLOSURE` を再監査し、
H1 Human-Head FacePart Product Integration の最初の未閉鎖boundaryを確定した。

Static Closure report-time authorityでは:

- branch=`work/raw-direct-motion`
- HEAD=`7969a47342c712aa2a5bdfa13a5967a73db5e0e0`
- tree=`166446995724b17b3cb6297c4feb3a569977ff02`
- H1 static 9 claims=CLOSED
- FULL_AUDIT_1=PASS
- FULL_AUDIT_2=PASS
- AUDIT_DISAGREEMENT=NONE
- CLASSIFICATION=C
- H1_IMPLEMENTATION_READY=YES

ただし `H1_IMPLEMENTATION_READY=YES` は「H1実装済み」「Runtime PASS」「Human Visual PASS」を意味しない。
Classification C の契約上、Production修正前に source rigid de-rigidization authority を1つへ凍結する必要がある。

Static Closureで確認された first blocker は、
`KiwiFacePartRigidSampleFrame` と `KiwiFacePartSharedTiltLock` が
source in-plane roll removalを独立かつ累積していること。

このチャットで Design Freeze を行い、H1 Product path の唯一の source-roll removal ownerを:

`KiwiFacePartRigidSampleFrame`

と採用した。

`KiwiFacePartSharedTiltLock` は:

`RETIRE_FROM_H1_PRODUCT_PATH`

とした。

これは `GLOBAL_DELETE` の承認ではない。
過去F3 Runtimeは SharedTiltLock 全削除の妥当性まで証明していないため、
他の合法scope/consumerがlive localに残る場合はクラス自体を保持する。

次に実行するlocal taskとして
`H1_SOURCE_RIGID_SINGLE_OWNER_LOCAL_RETIREMENT`
を定義した。

このtaskでは最小変更だけを行い、H1 Product path から duplicate SharedTilt ownershipを外す。
このboundaryがStatic/compileで閉じた後の次のfirst blockerは:

`P3D_TO_FACEPART_SAME_SAMPLE_BRIDGE`

である。

このチャットではコード変更、Unity compile/build、Runtime、Human Visual、commit、pushは実行していない。

---

## OBJECTIVE

最終製品ゴール:

Face LandmarkerをPrimary / Source of Truthとして、
Eye / Blink / Mouth / Mouth Shape/Open / Expression のnon-rigid appearanceを維持し、
source rigid poseだけを除去してKiwiのfixed fitted surfaceへhead-local表示し、
visible Head rigid poseをexactly once適用する。

今回の直接目的:

1. P3D→FacePart Product bridgeを追加する前にrigid authority overlapを閉じる。
2. source rigid roll除去ownerをexactly 1にする。
3. 正常なTracking/Camera/Native/P3D Coreを理由なく再設計しない。
4. owner closure後にsame-sample Pose16 Product handoffへ進める。

---

## AUTHORITY / CLAIM-SCOPED STATUS

### Confirmed at H1 Static Closure report-time

Source:
`KiwiCodexConsolidatedReport_H1_LocalActivationAuthorityStaticClosure_20260911-173119JST.txt`

Report time:
`2026-09-11 17:31:19 +09:00`

Local report-time identity:
- Project=`D:\KiwiAvatarSystem`
- Unity=`6000.0.80f1`
- branch=`work/raw-direct-motion`
- HEAD=`7969a47342c712aa2a5bdfa13a5967a73db5e0e0`
- tree=`166446995724b17b3cb6297c4feb3a569977ff02`

Evidence mode:
`STATIC_AND_INSTALLED_PACKAGE_SOURCE_ONLY`

Code change:
`NONE`

Unity compile/build/runtime:
`NOT_RUN_BY_SCOPE`

### Current normal-chat authority

`NORMAL_CHAT_LIVE_LOCAL_PRODUCTION_NOT_DIRECTLY_VERIFIED`

通常チャットは、上記17:31 report-time local Production snapshotを
current-live local Productionへ自動昇格しない。

このチャットではGitHub exact ref `7969a47342c712aa2a5bdfa13a5967a73db5e0e0`
とのremote source comparisonも行ったが、
remoteはLocal Production Authorityではなく比較参照に限定する。

---

## CONFIRMED FACTS

### Static

H1 Static Closureの独立2監査は以下で一致した:

- all required static claims closed
- `FULL_AUDIT_1=PASS`
- `FULL_AUDIT_2=PASS`
- `AUDIT_DISAGREEMENT=NONE`
- `REMAINING_UNRESOLVED_STATIC_CLAIMS=NONE_WITHIN_ASSIGNED_SCOPE`
- `CLASSIFICATION=C`
- `H1_IMPLEMENTATION_READY=YES`

Static Closureが確認したcurrent report-time Product structure:

- visible rigid writer:
  `KiwiFaceMotion.RenderRotation -> AvatarMotionRoot.localRotation`
- `VISIBLE_HEAD_RIGID_AUTHORITY_COUNT=1`
- FacePart residual/constraint pathsはAvatarMotionRootへ書かない
- P3D accepted `Pose16` はProduct FacePart/Head-local consumerへpublishされていない
- `NO_EXISTING_BRIDGE_FOUND`
- `enableInferenceFaceGeometryTransactions=false` がProduct default
- diagnostic reflection activationはProduct activation ownerではない

### Source rigid roll authority overlap

Owner 1:
`KiwiFacePartRigidSampleFrame`

Static effect:
- bilateral-eye lineからrollを求める
- `SurfaceFittedRawImage.SetSampleFrameRotationDegrees`
- mesh sampling UV0 + mask UV1を回転
- crop-local sample/mask frameを同じrotationで扱う

Owner 2:
`KiwiFacePartSharedTiltLock`

Static effect:
- bilateral-eye lineから独立にrollを求める
- calibration/interpolationを持つ
- material `_SampleRotationRad/_SamplePivot/_SourceAspect` を書く
- `FacePartSoftMask` shaderで既に供給済みUVを再回転する

Static Closure verdict:
- `SOURCE_APPEARANCE_ROLL_ACTIVE_OWNER_COUNT=2`
- `PRODUCTION_ACTIVE_INDEPENDENT_RIGID_AUTHORITY_OVERLAP=YES`
- 両effectは累積
- same responsibilityのduplicate rigid normalization

### Package

H1 Static Closure report-time installed package evidence:

MediaPipe Unity Plugin:
- `com.github.homuler.mediapipe`
- installed/locked version=`0.16.3`

Inference Engine:
- `com.unity.ai.inference`
- installed/locked version=`2.4.1`

このチャットではPackage sourceを変更していない。

---

## RUNTIME

Current chat:
`NOT_RUN`

H1 Static Closure:
`NOT_RUN_BY_SCOPE`

したがって以下は未PASS:
- H1 Runtime activation
- single-owner変更後のsemantic effect
- Human Visual
- clean Performance
- Resource telemetry
- Product Acceptance
- Windows Acceptance

過去Runtimeをcurrent activation proofへ昇格していない。

---

## PUBLIC / PROJECT DESIGN PRINCIPLES RETAINED

- Face Landmarker=Primary / Source of Truth
- latest-frame / bounded / nonblocking
- FIFO / stale queue / stale prediction禁止
- Root / Head / Eye / Mouth authority分離
- Head=single rigid authority
- source appearance referenceとvisible Head authorityは別
- Eye/Mouth non-rigid appearanceを残しsource rigid poseだけ除去
- fixed fitted surfaceを維持
- visible Head poseをexactly once適用
- Texture/Crop/Mask/FacePart=same-sample transaction
- Camera/Inference問題をtracking mathで隠さない
- strong smoothing/Kalman/根拠なきthreshold緩和禁止
- duplicate temporal/prediction/normalization ownerを増やさない
- Working CoreをEvidenceなしに再設計しない
- commit/pushは明示指示時のみ

---

## DESIGN FREEZE — VALIDATED DECISION

### Adopted

H1 Product pathのsource rigid roll de-rigidization owner:

`KiwiFacePartRigidSampleFrame`

Decision:
`KEEP_AS_H1_SINGLE_SOURCE_ROLL_OWNER`

理由:

1. source sample/crop-local frameで処理する。
2. texture sampling UVとmask UVを同一frameで扱う。
3. presentation後段で別のrigid補償ownerを追加しない。
4. visible Head rigid authorityを奪わない。
5. H1の
   `source rigid removal -> head-local Eye/Mouth -> fixed surface -> visible Head once`
   に責務位置が合う。

### Retired from H1 Product path

`KiwiFacePartSharedTiltLock`

Decision:
`RETIRE_FROM_H1_PRODUCT_PATH`

理由:

- RigidSampleFrameと同じsource roll responsibilityを独立に再計算する。
- RigidSampleFrame適用後にshader UVへ追加rotationを与える。
- H1でFaceGeometry-based source rigid removalを追加する前に残すと、
  rigid normalization pathがさらに増える。
- calibration/interpolation/fallback/clampを別ownerとして維持する合理性が
  H1 single-owner contractでは証明されていない。

### Explicit limitation

`RETIRE_FROM_H1_PRODUCT_PATH != GLOBAL_DELETE`

過去F3 evidenceはSharedTiltLock全削除のProduct妥当性を閉じていない。
live local sourceで他の合法scope/consumerがないことまで確認できた場合のみ
global deletionを別claimとして判断する。

---

## INFERENCE / DESIGN REASONING

Static effect comparisonから、
RigidSampleFrameを残しSharedTiltLockをH1 pathから退役させる方が
責務・owner・temporal stateを少なくできる。

これはRuntime visual improvementの証明ではない。

これは:
- Static owner closureの最善設計判断
- H1 implementation前のauthority freeze

であり、
Visual/Performance PASSへ昇格しない。

---

## REJECTED / SUPERSEDED

### Rejected in this chat

- duplicate roll ownerを残したままPose16 bridgeを追加する
- H1のためにP3D Geometry Coreを再設計する
- Camera/Native/backend/queue/fence/thresholdへ原因を拡散する
- tracking smoothing/KalmanでFacePart presentationを隠す
- SharedTiltLockをEvidenceなしにglobal deleteする
- 新disable flag、compatibility state、second gate、runtime branchを安易に追加する
- RigidSampleFrameのrotation sign/mathを同taskで変更する
- 複数unknownを同時修正する

### Superseded / historical only

- 旧H1 high-rate IE candidate:
  same-sample FaceGeometry pose欠如により `NO_GO_ROLLED_BACK`
- 古いreport-time HEAD `cd37cbe...`:
  current live local authorityではない
- 旧 `78933d...`:
  current authorityに再昇格しない
- 旧「H1_IMPLEMENTATION_READY=NOT_YET」:
  2026-09-11 Static Closureによって、
  static-closure contract上は `H1_IMPLEMENTATION_READY=YES` へ更新された

ただしYESは実装済みを意味しない。

---

## OBSERVER / VALIDATOR / BENCHMARK FINDINGS

- H1 Static ClosureはStatic/Package scope。
- Runtime observerなし。
- Performance Authorityなし。
- Human Visualなし。
- validator/log PASSでHuman Visualを上書きしていない。
- double full auditはstatic claimsについてのみAuthorityを持つ。
- remote source一致をlocal Production Runtime Authorityへ昇格していない。

---

## FILE / SHA / PROVENANCE NOTES

H1 Static Closure report-time source-reported hashes:

- `KiwiAvatarSystem_CoreRules_20260910_GoalAligned_v3.txt`
  SHA256=`2165427AC7D65410829CC49DB35F83EE8E2EB120685516D3EE004F50319F9F1D`
- `KiwiAvatarSystem_CurrentRoadmap_20260910_GoalAligned_v3.txt`
  SHA256=`491D79264297D7F4968E5A86DD524F6619280C40EA9A06D5CE7B7365EF42FC14`
- `KiwiAvatarSystem_CustomInstructions_20260910_GoalAligned_v3.txt`
  SHA256=`53300857BE44595BFA5EC73BFCAD82B6951D69CC985901EA4BBC2695452EE522`

Priority source report-time hashes:
- `KiwiFacePartRigidSampleFrame.cs`
  SHA256=`578CE2ED93A2A78EE1B19D8FF309A115A2FA53596E79BAAB0534A27AC10077C0`
- `KiwiFacePartSharedTiltLock.cs`
  SHA256=`0BCCA0B7BD6982B78C0FC18058ACD54D073D786820F7B027B8C2F218EF2CAE70`
- `SurfaceFittedRawImage.cs`
  SHA256=`1EA5B0493A48BE9B64AFD6316C8FBD4A4EC172848F06F8879BA733BB73535167`
- `Face Landmark Detection.unity`
  SHA256=`9BAC89F64B45429B38D41C1A2539C63D5E9A442E8EF920EE13B59245BE166735`

これらは2026-09-11 17:31 report-time local snapshotのsource-reported hashes。
current-live local file hashesとしては未再確認。

Source report file SHA256:
`SHA256=NOT_AVAILABLE_IN_NORMAL_CHAT`

---

## OPEN ISSUES / UNKNOWN

1. current-live local branch/HEAD/status/file SHA
2. report-time 7969a473... 以後のlocal変更有無
3. H1 Product pathからSharedTiltLock ownershipを外した後のexact active owner cardinality
4. SharedTiltLockがH1外で合法consumerを持つか
5. source change後のUnity compile/import
6. source change後のlifecycle/reset/restart behavior
7. P3D accepted Pose16のProduct activation/bridge owner
8. Pose16とFacePart appearance transactionのsame-sample exact identity contract
9. H1 Runtime correctness
10. same-build Human Visual:
    - ROTATION_MATCH
    - EYE_TWIST
    - MOUTH_TWIST
    - Eye/Blink/Mouth/Expression
    - Root non-movement
11. MOUTH_SIZE / SURFACE_CLIP
    - same-buildで再現時のみOPEN
12. clean Production Performance
13. Final Product / Windows Acceptance

---

## NEXT ACTION

### NEXT_SINGLE_ACTION

`H1_SOURCE_RIGID_SINGLE_OWNER_LOCAL_RETIREMENT`

実行場所:
local `D:\KiwiAvatarSystem`

開始時Preflight:
- `ProjectVersion.txt`
- exact Unity path/version
- branch/HEAD/status
- dirty protection
- touched files before SHA256
- report-time snapshotとの差分確認
- mismatchがProduct decisionへ影響する場合はSTOP/REPORT
- reset/checkout/clean禁止

最小変更:
- H1 Product Scene/Prefab/runtime wiringから
  `KiwiFacePartSharedTiltLock` のactive source-roll ownershipを外す
- `KiwiFacePartRigidSampleFrame` を唯一ownerとして残す
- new flag/state/gate/temporal ownerを増やさない
- RigidSampleFrame mathは同taskで変更しない
- P3D→FacePart bridgeは同taskで実装しない

Static exit:
1. H1 Product path source rigid roll writer count=exactly 1
2. owner=`KiwiFacePartRigidSampleFrame`
3. sample frame + mask frame transaction維持
4. 後段duplicate `-roll` active writerなし
5. SharedTilt fallbackがH1へ到達しない
6. new owner/state/queue/copy/readback/thread/temporal layerなし
7. Root/Head authority変更なし
8. lifecycleでstale rotationを新たに残さない

必要時:
- exact Unity 6000.0.80f1 compile
- FULL_AUDIT_1
- independent FULL_AUDIT_2

Success:
`H1_SOURCE_RIGID_SINGLE_OWNER_STATIC=PASS`

### NEXT AFTER PASS

`P3D_TO_FACEPART_SAME_SAMPLE_BRIDGE`

ここで初めて:
- accepted P3D identity tuple + Pose16
- exact matching FacePart appearance transaction

を1つのProduct boundaryとして接続する。

保持条件:
- source rigid removal once
- head-local Eye/Mouth
- existing fixed fitted surface
- visible Head rigid pose once
- no Root translation
- no duplicate/stale/out-of-order/mixed epoch publish

---

## DO NOT CHANGE

次taskで変更禁止:

- Native Camera / SystemMemoryNV12 baseline
- camera cadence
- MediaPipe package
- inference backend / async execution / fence / queue flush
- Tracking Core math
- thresholds
- smoothing / Kalman
- Root movement
- P3D Geometry Core
- `KiwiFaceMotion.cs`
- `KiwiInferenceFaceTracker.cs`
- Face Landmarker Primary
- texture identity
- prediction/history/FIFO

新Evidenceでfirst failing boundaryが変わらない限り、
これらへ作業を拡散しない。

---

## HUMAN VISUAL / PERFORMANCE STATUS

Human Visual:
`NOT_RUN / PASS_NOT_CLAIMED`

Performance:
`NO_CURRENT_H1_PERFORMANCE_AUTHORITY`

Final Production Acceptance:
`NOT_CLAIMED`

P3D Runtime PASSをH1 Runtime PASSへ昇格させない。

---

## MASTER UPDATE CANDIDATE

Archive Name:
`KiwiChat_H1SourceRigidSingleOwnerDesignFreeze_Updated_20260911-JST.zip`

LastWorkUpdate:
`2026-09-11`

Validated Decision:
`H1 Product source-roll owner = KiwiFacePartRigidSampleFrame`
`KiwiFacePartSharedTiltLock = RETIRE_FROM_H1_PRODUCT_PATH`

Rejected Approach:
duplicate roll ownerを残したままPose16 bridge追加。
EvidenceなしのSharedTilt global delete。
Camera/Native/backend/tracking workaround。

Superseded Conclusion:
`H1_IMPLEMENTATION_READY=NOT_YET`
はStatic Closure scopeでは
`H1_IMPLEMENTATION_READY=YES`
へ更新。ただし実装/Runtime/Visual PASSではない。

Open Issue:
local single-owner retirement実施と、
その後のP3D→FacePart same-sample Product bridge。

Next Action:
`H1_SOURCE_RIGID_SINGLE_OWNER_LOCAL_RETIREMENT`

---

## CHAT ARCHIVE INDEX

Archive:
`KiwiChat_H1SourceRigidSingleOwnerDesignFreeze_Updated_20260911-JST.zip`

Topic:
`H1SourceRigidSingleOwnerDesignFreeze`

LastWorkUpdate:
`2026-09-11`

Status:
`IN_PROGRESS`

Supersedes:
H1 Static Closure直前の
`H1_IMPLEMENTATION_READY=NOT_YET`
をCurrentとして扱う状態。

SupersededBy:
`NONE`

NextArchiveCandidate:
`H1_SOURCE_RIGID_SINGLE_OWNER_LOCAL_RETIREMENT`
完了時、または
`P3D_TO_FACEPART_SAME_SAMPLE_BRIDGE`
の設計/実装/検証完了時。

---

## HANDOFF

次チャットでは全履歴を再展開せず、以下を優先する:

1. Current CoreRules
2. Current Roadmap
3. `KiwiCodexConsolidatedReport_H1_LocalActivationAuthorityStaticClosure_20260911-173119JST.txt`
4. このArchive

開始時のCurrent statement:

- P3C_1=RETAIN_PASS
- P3D Correctness/Lifecycle=PASS_WITH_SCOPE_LIMITS
- H1 static activation/identity/owner closure=PASS
- Classification=C
- H1_IMPLEMENTATION_READY=YES under static verdict contract
- H1 source-roll Design Freeze=COMPLETE in normal chat
- RigidSampleFrame=KEEP as H1 single source-roll owner
- SharedTiltLock=RETIRE_FROM_H1_PRODUCT_PATH
- local Production change=NOT_YET_EXECUTED
- Runtime/Human Visual/Performance=NOT_PASS
- current-live local Production=NORMAL_CHAT_LIVE_LOCAL_PRODUCTION_NOT_DIRECTLY_VERIFIED
- NEXT=H1_SOURCE_RIGID_SINGLE_OWNER_LOCAL_RETIREMENT
- after PASS=P3D_TO_FACEPART_SAME_SAMPLE_BRIDGE

END_OF_REPORT
