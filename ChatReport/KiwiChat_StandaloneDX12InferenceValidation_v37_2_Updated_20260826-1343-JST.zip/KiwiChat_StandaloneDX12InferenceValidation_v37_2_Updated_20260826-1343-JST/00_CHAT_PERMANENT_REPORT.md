# KiwiAvatarSystem Chat Permanent Report

ChatTopic: Standalone DX12 Inference / Compute Shader Packaging / Editor Exclusion
ChatTitle: v35-v37.2 Windows Standalone DX12 Inference Validation
ArchiveName: KiwiChat_StandaloneDX12InferenceValidation_v37_2_Updated_20260826-1343-JST.zip
LastWorkUpdate: 2026-08-26 13:43 JST
LastWorkUpdatePrecision: DATE_TIME
ArchiveCreated: 2026-09-02 23:37 JST
ArchiveTimestampBasis: LAST_RELEVANT_WORK_BEFORE_ARCHIVE_REQUEST
Project: D:\KiwiAvatarSystem
Unity: 6000.0.80f1 / Windows / DX12
CurrentInvestigationVersionAtChatEnd: v37.2
Status: SUPERSEDED
ChatLocalStatusAtLastWork: IN_PROGRESS

> IMPORTANT AUTHORITY NOTE
>
> This archive preserves the state and decisions of this specific v35-v37.2 chat.
> It is NOT the current global KiwiAvatarSystem Production authority.
> By 2026-09-02, later project work had advanced to v44.55.x; the integrated
> project authority places v44.55.24 Pair-Bound Shadow Output Snapshot as the
> current next investigation. Use this archive as historical evidence only when
> it does not conflict with newer Production/Runtime/Package-source authority.

---

## EXECUTIVE SUMMARY

This chat isolated a major Editor-vs-Standalone performance question and then
discovered that early Standalone runs were invalid because the Player did not
execute the same GPUCompute workload as the Editor.

The investigation progressed through:

1. v35.x Windows Standalone build isolation.
2. Release/RC gate diagnosis.
3. Development Standalone diagnostic path.
4. Discovery that v35.3 Player had missing compute kernels:
   - `TextureToTensorExact`
   - `Match`
5. v36 observer-only compute-shader packaging audit.
6. Rejection of the initial "shader stripping" hypothesis because both required
   kernels reached Player compute compilation with nonzero variants.
7. An initially incorrect inference that `d3d11` serialization text meant DX12
   shader payload was absent.
8. Correction using Unity's public D3D compiler semantics.
9. v37/v37.1 Installer regressions exposing stale v35/v36 tokens.
10. User-requested stronger package self-review.
11. v37.2 clean transactional package with cross-file consistency review.
12. v37.2 720p Standalone Runtime proving the missing-kernel failure was fixed.

Final v37.2 720p Runtime facts:
- Windows Player actually ran Direct3D 12.
- Native Path B camera remained healthy at ~60.18 Hz.
- `TextureToTensorExact` missing: 0 occurrences.
- `Match` missing: 0 occurrences.
- GPU inference scheduling/readback advanced normally.
- Active inference lanes were normally 3.
- Render FPS median remained ~38.41.
- inference request→done median remained ~74.02 ms.
- accepted source age median remained ~86.26 ms.
- GPU utilization median ~98%, graphics/SM clock 2925 MHz.
- FaceTexture miss/hold remained 0 and cross-system discard remained 0.

Therefore the early v35.3 "Standalone performance" run was invalid, but v37.2
established a valid Development Standalone GPUCompute workload. The original
performance problem was not solved by merely leaving the Editor: the valid
720p Standalone still ran around 38 FPS with high GPU utilization.

Additional lifecycle/resource warnings remain:
- one early `no GPU readback completion` recovery restart;
- 378 `ComputeTensorData` undisposed warnings at shutdown;
- 378 `ComputeBuffer` GC-disposal warnings at shutdown;
- one persistent native leak report (24 allocations);
- one D3D12 upload-buffer-too-small warning.

These resource findings were NOT resolved in this chat.

---

## OBJECTIVE

Primary objective:

Determine whether the Unity Editor/Game View was the dominant cause of the
observed 30-50 FPS oscillation / inflated GPU inference completion latency,
without changing the proven Native camera, Face Landmarker authority,
tracking math, ROI, model semantics, thresholds, or presentation transaction
rules.

Secondary objective:

Make the Windows Standalone diagnostic workload equivalent enough to the
proven Editor GPUCompute path that timing comparisons are meaningful.

---

## CONFIRMED FACTS

### Environment

- Project: `D:\KiwiAvatarSystem`
- Unity: `6000.0.80f1`
- Graphics: Windows DX12
- Hardware: Ryzen 9 5950X / RTX 4090
- Camera: UGREEN Camera 4K / 1920x1080@60 / Native NV12
- MediaPipeUnityPlugin: v0.16.3
- Unity Inference Engine: 2.4.1
- Active scene: Face Landmark Detection
- Native camera Production direction: Path B SystemMemoryNV12

### v35.2 build gate facts

Full Preflight passed, but a later final RC gate rejected non-Development build
because a Phase 15 RC1 passing stamp did not exist.

The gate was treated as intentional safety behavior and was not bypassed.

### v35.3 invalid Standalone workload

v35.3 Development Standalone excluded the Editor, but Player GPUCompute was not
equivalent to Editor because required compute kernels were missing at runtime.

Observed:
- `Kernel 'TextureToTensorExact' not found`
- `Kernel 'Match' not found`
- `inferenceScheduledCount = 0`
- `inferenceReadbackCompletedCount = 0`
- `inferenceActiveLanes = 0`

Therefore v35.3 timing could not answer the Editor-isolation performance
question.

### v36 compute shader packaging audit

Observer-only build audit showed:

`TextureToTensorExact`
- present in Editor asset
- reached Player compute compile callback
- nonzero variants (2)

`Match`
- present in Editor asset
- reached Player compute compile callback
- nonzero variants (1)

Therefore:
- "asset absent" rejected
- "kernel stripped before compile callback" rejected
- "all variants removed" rejected

### Unity D3D compiler interpretation correction

The prior conclusion that build-log text `d3d11` proved DX12 payload absence
was incorrect.

Unity's public shader compiler platform semantics use the D3D compiler platform
for both D3D11 and D3D12 on Windows.

Therefore `d3d11`-looking serialization text alone is NOT proof that a DX12
Player lacks the shader/kernel.

### v37.2 build/package validity

v37.2:
- clean transactional package
- DX12-only Windows build configuration retained
- Full Preflight retained
- Development diagnostic retained
- Autoconnect Profiler OFF
- Deep Profiling OFF
- Runtime source changes 0
- Native changes 0
- tracking math changes 0
- Release Gate changes 0
- shader compiler data mutation 0
- production CSV schema remained 321 columns

Package self-review:
- 108/108 checks PASS
- legacy v35/v36 active-script hits: 0
- ZIP integrity PASS

### v37.2 720p Runtime

Evidence recording duration:
~38.069 s, 1520 CSV rows.

Direct3D:
- Player forced Direct3D 12
- Direct3D 12 feature level 12.1
- Renderer RTX 4090

Native camera:
- source count: 1878 -> 4169
- measured count-rate: ~60.18 Hz
- ingest count: 1878 -> 4169
- GPU upload count: 1878 -> 4169
- source interval median: 16.0755 ms
- source age median: 11.3567 ms
- CPU NV12 copy median: 1.4410 ms

Inference:
- `TextureToTensorExact` missing count: 0
- `Match` missing count: 0
- scheduled: 1059 -> 2502
- readback completed: 1056 -> 2499
- completed: 847 -> 2211
- active lanes median: 3
- request→done median: 74.0240 ms
- request→done P95: 82.3354 ms
- poll interval median: 25.1762 ms
- inference latency median: 74.2004 ms
- accepted source age median: 86.2642 ms

Presentation / transaction:
- cross-system discard count: 0
- FaceTexture miss count: 0
- FaceTexture hold count: 0

Render:
- render FPS median: 38.4111
- render FPS P95: 42.3156
- render FPS min/max: 32.2807 / 46.3056
- native presented count-rate: ~38.04 Hz
- canonical adoption count-rate: ~35.83 Hz

External GPU telemetry:
- GPU utilization median: 98%
- GPU utilization P95: 100%
- graphics clock median: 2925 MHz
- SM clock median: 2925 MHz
- power median: 115.45 W
- GPU temperature median: 50 C

Lifecycle/resource warnings:
- Hybrid GPU initialization logged twice.
- one `Restarted Inference Engine (no GPU readback completion)` occurred early.
- 378 `Found unreferenced, but undisposed ComputeTensorData` warnings at exit.
- 378 `GarbageCollector disposing of ComputeBuffer` warnings at exit.
- one `Leak Detected : Persistent allocates 24 individual allocations`.
- one `d3d12: upload buffer was too small...` warning.

---

## PUBLIC DESIGN PRINCIPLES

### Unity Editor vs Player

Unity publicly documents that Editor Play Mode is not an isolated target
performance environment. Target Player is the correct environment for
release-performance confirmation.

Development Build can itself add overhead/debug capability, so Development
Standalone is valid for Editor exclusion and correctness diagnostics, but
should not automatically be treated as final Release performance authority.

### Build graphics API

Unity exposes:
- `PlayerSettings.SetUseDefaultGraphicsAPIs`
- `PlayerSettings.SetGraphicsAPIs`

Build-time graphics API configuration and runtime `-force-d3d12` selection are
separate controls and should be kept coherent.

### Compute shader build observation

Unity exposes `IPreprocessComputeShaders` to observe compute shader kernels and
compiler variants presented during build.

Observer code should not mutate `ShaderCompilerData` unless the goal is
explicit stripping/preservation logic.

### Kiwi application principle

Do not "fix" camera/inference cadence by changing:
- Face Landmarker authority
- `KiwiFaceMotion`
- tracking thresholds
- strong smoothing
- Kalman filtering
- Native camera stable path

The diagnostic must first prove the actual failing layer.

---

## INFERENCES / HYPOTHESES

The following were NOT fully proven in this chat:

1. The ~38 FPS valid v37.2 Standalone result strongly suggests the Editor alone
   was not the full cause of the performance limitation.

2. Because external GPU telemetry remained ~98-100% while valid 3-lane GPU
   inference ran, graphics + GPUCompute competition remains a strong candidate.

3. The one startup recovery may be a transient initialization/recovery timing
   issue rather than a steady-state correctness failure, because subsequent
   scheduling and readback counters advanced continuously.

4. The mass shutdown resource warnings may be related to worker/recovery/lane
   ownership or Development shutdown behavior, but this chat did not establish
   the exact owner or leak origin.

5. The single D3D12 upload-buffer-too-small warning may be unrelated to the
   sustained inference latency. It requires separate source/owner tracing before
   any fix.

These must not be promoted to Production facts without new evidence.

---

## PRODUCTION AUTHORITY

Authority used in this chat, highest first:

1. Same-configuration Runtime CSV / Player log / external GPU telemetry.
2. Actual v37.2 build output and shader packaging audit.
3. Actual Unity 6000.0.80f1 / Inference Engine 2.4.1 behavior.
4. Unity public documentation / Scripting API.
5. Prior Kiwi diagnostic versions and chat history.

LOCAL_PRODUCTION_NOT_DIRECTLY_VERIFIED from normal chat.

No current local Production SHA was invented.

Global project authority note:
A later 2026-09-02 integrated project state supersedes this chat as the global
current authority and places work at v44.55.x.

---

## WORK PERFORMED

### v35 / v35.1 — Windows Standalone build runner

Purpose:
Exclude Editor from the performance test.

Result:
Initial PowerShell runner used GUI-process behavior incorrectly around
`$LASTEXITCODE`.

Fix:
Switched to `Start-Process -Wait -PassThru` and explicit `.ExitCode`.

Decision impact:
Runner lifecycle bug separated from actual Unity build failures.

### v35.2 — mandatory Full Preflight integration

Purpose:
Respect Kiwi release safety instead of bypassing the build gate.

Result:
Full Preflight passed, then a later Phase15 RC1 gate blocked non-Development
build.

Decision:
Do not bypass or forge the release gate.

### v35.3 — Development Standalone Editor exclusion

Purpose:
Use the gate's permitted Development diagnostic path.

Result:
Build/Player started, but GPUCompute workload was invalid because required
kernels were missing.

Status:
INVALID FOR PERFORMANCE COMPARISON.

### v35.3.1 — Installer guard correction

Finding:
`BuildOptions.Development` was simultaneously required and forbidden by the
Apply script.

Fix:
Removed the contradictory forbidden entry only.

Lesson:
Static PASS alone was insufficient because Validator/Installer logic itself
contained contradictions.

### v36 — observer-only compute shader packaging audit

Purpose:
Identify whether kernels were absent, stripped, or compiled.

Result:
Both required kernels reached build compilation with nonzero variants.

Decision:
Broad shader stripping workarounds rejected.

### v37 — DX12 Player build API lock

Purpose:
Test the hypothesis that build/runtime graphics API mismatch caused missing
kernels.

Result:
Installer still contained stale v35 marker and failed before meaningful build
application.

### v37.1 — Installer marker fix

Purpose:
Remove stale v35 build-helper marker.

Result:
Another stale v36 audit-output token remained.

### User-requested self-review policy upgrade

User explicitly required stronger pre-artifact self-review.

New mandatory checks adopted:
- stale version marker scan
- required/forbidden token intersection
- Apply/Validate/Build/Run contract consistency
- version/phase/path/launcher consistency
- PowerShell lifecycle/exit-code review
- write-target/backup/rollback symmetry
- installed-state revalidation
- change-scope guard
- final package-wide search before ZIP creation

### v37.2 — clean transactional package

Purpose:
Stop patching inherited v35/v36 scripts piecemeal.

Result:
Clean current-contract package:
- 108/108 self-review PASS
- active old v35/v36 hits 0
- ZIP integrity PASS
- runtime/core changes 0

### v37.2 720p Runtime

Purpose:
Re-test Standalone only after compute kernel failure was eliminated.

Result:
GPUCompute became operational.
Native 60 Hz remained healthy.
Performance remained ~38 FPS with ~74 ms request→done.

Decision impact:
The early invalid Standalone workload problem was solved.
The broader GPU/render/inference performance limitation remained unresolved.

---

## VALIDATED DECISIONS

### Decision: Do not bypass the final RC gate

Reason:
It is an independent release qualification layer.

Evidence:
Full Preflight passed while final RC gate still correctly rejected an
unqualified non-Development build.

Regression constraints:
No fake stamp, no gate disable, no release-artifact relabeling.

Still current:
Historical decision remains sound.

### Decision: Development Standalone is diagnostic-only

Reason:
It excludes Editor while respecting gate design.

Evidence:
v35.3/v37.2 Players ran independently of Editor.

Regression constraints:
Do not call its timing final Release performance.

Still current:
Yes as a diagnostic principle.

### Decision: v35.3 performance result is invalid

Reason:
GPU inference never scheduled due missing compute kernels.

Evidence:
schedule/readback/active-lane counters were zero.

Regression constraints:
Never compare v35.3 FPS directly against valid Editor GPUCompute as equivalent
workload.

Still current:
Yes.

### Decision: broad compute-shader stripping fix rejected

Reason:
v36 proved both kernels reached Player compile with nonzero variants.

Evidence:
TextureToTensorExact variants=2, Match variants=1.

Regression constraints:
Do not disable shader stripping globally without new evidence.

Still current:
Yes.

### Decision: `d3d11` log text alone is not DX12-missing evidence

Reason:
Unity's D3D compiler platform covers D3D11/D3D12 semantics.

Evidence:
v37.2 later ran DX12 and both kernels were available.

Regression constraints:
Do not infer build API payload solely from that serialization label.

Still current:
Yes.

### Decision: stronger artifact self-review is mandatory

Reason:
v35.3, v37, and v37.1 each exposed stale/contradictory package guards that
earlier static checks missed.

Evidence:
- Development token required+forbidden
- stale v35 marker
- stale v36 audit filename

Regression constraints:
Whole-package contract review before future ZIP generation.

Still current:
Yes.

---

## REJECTED APPROACHES

### Rejected: Release gate bypass

Why considered:
Needed a standalone Player quickly.

Why rejected:
Would break Kiwi release-safety authority.

Revisit condition:
None; use legitimate qualification path.

### Rejected: fake/fabricated Phase15 RC1 passing stamp

Why considered:
Could force a Release build.

Why rejected:
Would create false qualification evidence.

Revisit condition:
Never.

### Rejected: global shader stripping disable

Why considered:
Player kernels were missing.

Why rejected:
v36 compile audit showed required kernels survived with nonzero variants.

Revisit condition:
Only if future build evidence proves a stripping failure at a later stage.

### Rejected: copy package compute shaders into Assets by guess

Why considered:
Could force inclusion.

Why rejected:
Package compute shaders already reached build compilation; duplication would
create package drift.

Revisit condition:
Only with exact package/resource provenance evidence.

### Rejected: treat v35.3 GPU telemetry as equivalent inference performance

Why considered:
GPU was busy even with inference schedule count 0.

Why rejected:
The workload was materially different.

Revisit condition:
Never for that run.

---

## SUPERSEDED CONCLUSIONS

### OLD
`d3d11` build-log serialization means DX12 shader payload was not built.

### NEW
That label alone does not prove DX12 payload absence.

### WHY
Unity's D3D compiler platform semantics are shared for Windows D3D11/D3D12,
and v37.2 ran Direct3D12 with both previously missing kernels available.

---

### OLD
Standalone test shows Editor exclusion does not help performance.

### NEW
The first v35.3 Standalone result was invalid because inference never ran.
Only v37.2 is a valid Development Standalone GPUCompute datapoint.

### WHY
v35.3 schedule/readback counts were zero; v37.2 schedule/readback counters
advanced and 3 lanes were active.

---

### OLD
Kernel missing is most likely caused by shader stripping.

### NEW
Build stripping before compile callback is rejected by v36 evidence.

### WHY
Both kernels reached compute build callbacks with nonzero variants.

---

## OBSERVER / VALIDATOR FINDINGS

### Installer/Validator defect: v35.3

`BuildOptions.Development` existed in both required and forbidden token sets.

Classification:
VALIDATOR/INSTALLER DEFECT, not Production runtime defect.

### Installer defect: v37

Apply script still required historical v35.3 marker after build helper was
updated to v37.

Classification:
PACKAGE CONTRACT DEFECT.

### Installer defect: v37.1

Apply script still required historical `KiwiComputeShaderPackagingAudit_v36.json`
after audit outputs had moved to v37.x.

Classification:
PACKAGE CONTRACT DEFECT.

### Self-review finding

Earlier "static PASS" totals were insufficient because the checks did not
challenge the validator/installer assumptions themselves.

Permanent lesson:
Observer, Validator, installer guards, and package metadata are themselves part
of the test system and must be audited.

### Runtime observer validity

v37.2 CSV/telemetry is suitable for:
- correctness
- cadence observation
- supporting performance comparison

It is NOT final Release performance authority because:
- Development Build is used
- runtime CSV logging is active
- this remains a diagnostic Player

---

## FILES / SHA256

### Current chat artifact

Path:
`KiwiAvatarSystem_v5_1_0_Phase16_20_25_v37_2_DX12_PLAYER_BUILD_API_LOCK_CLEAN_TRANSACTIONAL.zip`

Role:
Current final diagnostic package produced in this chat.

SHA256:
`71446c38c5d2cdf55f323d2689148d7c5718d7aae5d1503e96b3de06f318f37f`

Current/Obsolete:
CURRENT FOR THIS HISTORICAL CHAT; globally superseded by later project work.

### Earlier artifacts

v35.2:
`KiwiAvatarSystem_v5_1_0_Phase16_20_23_v35_2_WINDOWS_STANDALONE_MANDATORY_PREFLIGHT_INTEGRATED.zip`
SHA256:
`17ba9d4961d5a8e650873827a35ec54a43ec5f07b1401151bef6e3bf4fe9c313`
Status: OBSOLETE

v35.3:
`KiwiAvatarSystem_v5_1_0_Phase16_20_23_v35_3_DEVELOPMENT_STANDALONE_EDITOR_EXCLUSION_DIAGNOSTIC.zip`
SHA256:
`bce452f523b33932e86754df9672faa8749d8ede5a47634f99fcbd9131f3aff5`
Status: OBSOLETE / INVALID PERFORMANCE WORKLOAD

v35.3.1:
`KiwiAvatarSystem_v5_1_0_Phase16_20_23_v35_3_1_DEVELOPMENT_STANDALONE_INSTALLER_GUARD_FIX.zip`
SHA256:
`4e31f18ce519666bce5e09bcad9dd6b1546c52b263bdfd98cec6d06dc2336f4b`
Status: OBSOLETE

v36:
`KiwiAvatarSystem_v5_1_0_Phase16_20_24_v36_STANDALONE_COMPUTE_SHADER_PACKAGING_AUDIT.zip`
SHA256:
`1d9bbdeec0af299de44bb80d4b9d47e001b6df8d05786ca8b50189ef4d0cec5a`
Status: OBSOLETE AS PACKAGE; audit conclusion retained

v37:
`KiwiAvatarSystem_v5_1_0_Phase16_20_25_v37_DX12_PLAYER_BUILD_API_LOCK.zip`
SHA256:
`501cb84c9ba8a7e0faae334ad02599e8e698d791c3654df24c102d9682805306`
Status: OBSOLETE

v37.1:
`KiwiAvatarSystem_v5_1_0_Phase16_20_25_v37_1_DX12_PLAYER_BUILD_API_LOCK_INSTALLER_MARKER_FIX.zip`
SHA256:
`096df633f8cdde220f767d676a3c5f2a695f897b25e36727d7eec4c1f41b7457`
Status: OBSOLETE

### Final Runtime evidence included in this archive

`KiwiFrameComparison_20260826_134119.csv`
SHA256:
`5882a903400c140fa3df4ea0fad8c21a92c3dcf72fa8fbf06ea8909031d21ce6`

`KiwiGpuTelemetry_v37_2_DX12_DEV_STANDALONE_720P_20260826_134035.csv`
SHA256:
`9f211f4fee68e423069a662b53c0a910898b9a6ec18536b5683402e253f60302`

`KiwiStandalonePlayer_v37_2_DX12_DEV_720P_20260826_134035.log`
SHA256:
`06fb4e4137bb04510a0f630309af44bd8b780e55f0dd0177f9f084ef014b0272`

### Build/audit evidence referenced in chat but not re-embedded by normal-chat path

`KiwiStandalone_v37_2.build.log`
SHA256=NOT_AVAILABLE_IN_NORMAL_CHAT

`KiwiComputeShaderPackagingAudit_v37_2.txt`
SHA256=NOT_AVAILABLE_IN_NORMAL_CHAT

---

## RUNTIME EVIDENCE

### CORRECTNESS

`KiwiStandalonePlayer_v37_2_DX12_DEV_720P_20260826_134035.log`

Supports:
- Direct3D12 Player identity
- Native camera Path B activation
- GPU inference initialization
- absence of missing-kernel errors
- startup recovery occurrence
- shutdown resource warnings

Authority:
CORRECTNESS / LIFECYCLE / SUPPORTING_RESOURCE

### CORRECTNESS + SUPPORTING PERFORMANCE

`KiwiFrameComparison_20260826_134119.csv`

Supports:
- 321-column Production-compatible diagnostic schema
- native source cadence
- inference schedule/readback counts
- active lane count
- request→done
- accepted source age
- render FPS
- transaction counters
- FaceTexture miss/hold

Authority:
CORRECTNESS + SUPPORTING_PERFORMANCE

Not final Release performance authority because it is a Development diagnostic
run with CSV observation.

### SUPPORTING PERFORMANCE

`KiwiGpuTelemetry_v37_2_DX12_DEV_STANDALONE_720P_20260826_134035.csv`

Supports:
- GPU utilization
- GPU clocks
- power
- temperature

Authority:
SUPPORTING_PERFORMANCE

### STATIC / BUILD

v36/v37.2 compute shader packaging audit

Supports:
- required kernel build visibility
- nonzero variant counts
- DX12 build configuration

Authority:
STATIC_ONLY / BUILD_CORRECTNESS

### VISUAL

No final MP4 visual evidence was required for this specific packaging /
Standalone correctness stage.

Authority:
NOT APPLICABLE

---

## CURRENT RESULT

### Chat-local result at v37.2

PASS:
- v37.2 clean package self-review
- DX12 Standalone build path
- missing compute kernel problem resolved
- GPU inference actually schedules and readbacks complete
- Native Path B remains ~60 Hz
- strict FaceTexture transaction counters remain healthy

NOT SOLVED:
- valid Standalone remains only ~38 FPS
- request→done remains ~74 ms
- accepted source age remains ~86 ms
- GPU remains near saturation
- startup recovery occurred once
- shutdown GPU resource ownership/disposal warnings remain
- final Release-grade performance not measured

### Global project status as of 2026-09-02

This archive is historical.
Later project work superseded the v37 branch and had advanced to v44.55.x.

Current integrated project next action:
`v44.55.24 Pair-Bound Shadow Output Snapshot`

Do NOT resume v37 optimization as if it were the latest Production task unless
the user explicitly wants historical re-evaluation.

---

## OPEN ISSUES

Historical v37 branch open issues:

1. Why valid Standalone GPUCompute still runs ~38 FPS at 720p.
2. Whether 1080p materially changes the same valid Standalone workload.
3. Exact ownership/recovery source of the shutdown ComputeTensorData /
   ComputeBuffer warnings.
4. Whether the one startup `no GPU readback completion` recovery is expected
   transient behavior or a lifecycle issue.
5. Source/impact of the one D3D12 upload-buffer-too-small warning.
6. Release-grade performance still requires a properly qualified non-Development
   build if this historical branch were revisited.

Global current project open issue is different:
v44.55.24 must resolve Worker output lifecycle race before Production Output
Transaction Authority is finalized.

---

## NEXT ACTION

### Historical next action at end of this chat

If continuing exactly from v37.2 history:

1. Run the matching v37.2 1080p Development Standalone with identical protocol.
2. Compare 720p vs 1080p:
   - render FPS
   - request→done
   - accepted source age
   - GPU utilization
   - camera 60 Hz non-regression
3. Keep resource/lifecycle warnings as a separate investigation.
4. Do not change Native/Tracking/thresholds to improve the result.

### Current project next action as of archive creation

Do NOT continue v37 by default.

Follow the newer project authority:
`v44.55.24 Pair-Bound Shadow Output Snapshot`

Purpose:
Eliminate Worker allocator output lifecycle race before final Production Output
Transaction Authority is established.

---

## DO NOT CHANGE

Without new independent evidence:

- Face Landmarker Primary / Source of Truth
- Path B Native SystemMemoryNV12
- latest-frame policy
- fixed presentation texture identity
- cameraGeneration session-epoch semantics
- strict FaceTexture same-sample transaction
- cross-system stale/generation gates
- `KiwiFaceMotion.cs` as camera/performance workaround
- `KiwiInferenceFaceTracker.cs` tracking math as camera workaround
- thresholds
- strong smoothing
- Kalman
- FIFO / stale queue
- `UpdateExternalTexture`
- blocking GPU waits
- Unity D3D12 queue `Wait(...)`
- D3D11On12 1080p camera Production
- Release gate integrity
- Production CPU adoption before semantic correctness is established

Also:
Do not infer correctness from Validator PASS alone.
Validator/Observer/Installer are themselves subjects of QA.

---

## HANDOFF

To resume this historical chat branch:

1. Treat v35.3 performance as INVALID.
2. Treat v36 build audit as valid evidence that both required kernels reached
   compute compilation with nonzero variants.
3. Treat the old `d3d11 log == no DX12 shader` conclusion as SUPERSEDED.
4. v37.2 is the first valid Development Standalone datapoint in this branch
   with GPU inference actually operating.
5. v37.2 720p:
   - Native source ~60.18 Hz
   - render median ~38.41 FPS
   - 3 inference lanes
   - request→done median ~74.02 ms
   - accepted source age median ~86.26 ms
   - GPU median ~98%
   - missing kernels 0
   - cross-system discard 0
   - FaceTexture miss/hold 0
6. Do not confuse Development diagnostic timing with final Release performance.
7. Keep shutdown resource warnings and the startup recovery separate from the
   steady-state performance question.
8. If historical continuation is explicitly requested, obtain 1080p v37.2 A/B
   before changing inference or tracking.
9. Otherwise defer to the newer v44.55.x Project Authority.

---

## MASTER REPORT UPDATE CANDIDATES

Archive:
`KiwiChat_StandaloneDX12InferenceValidation_v37_2_Updated_20260826-1343-JST.zip`

Topic:
Standalone DX12 Inference / Compute Shader Packaging / Editor Exclusion

LastWorkUpdate:
2026-08-26 13:43 JST

Validated Decisions:
- v35.3 performance invalid due missing GPUCompute kernels
- broad shader stripping hypothesis rejected by v36
- `d3d11` serialization label is insufficient DX12-missing evidence
- v37.2 valid DX12 Standalone GPUCompute path
- stronger whole-package self-review required

Rejected Approaches:
- Release gate bypass
- fake RC stamp
- global shader stripping disable
- guessed package shader duplication

Superseded Conclusions:
- v35.3 as equivalent Standalone performance evidence
- d3d11 serialization == DX12 payload missing

Open Issues:
- valid Standalone ~38 FPS / ~74 ms request→done
- resource disposal warnings
- startup recovery

NextArchiveCandidate:
Later v44.55.x Production Output Transaction Authority work should remain in its
own archive rather than being merged into this historical v37 archive.

---

## CHAT ARCHIVE INDEX

Archive:
KiwiChat_StandaloneDX12InferenceValidation_v37_2_Updated_20260826-1343-JST.zip

Topic:
StandaloneDX12InferenceValidation_v37_2

LastWorkUpdate:
2026-08-26 13:43 JST

Status:
SUPERSEDED

Supersedes:
Earlier v35-v37.1 diagnostic packages within this chat.

SupersededBy:
Later KiwiAvatarSystem v37-v44 and v44.55.x project work.

NextArchiveCandidate:
ProductionOutputTransactionAuthority / v44.55.24 Pair-Bound Shadow Output Snapshot

---

## FINAL ARCHIVE NOTE

This report intentionally preserves both:
- what was true at the end of this chat; and
- the fact that later project evidence supersedes it globally.

Do not silently merge historical v37 hypotheses into current v44.55.x
Production decisions.
