# KiwiAvatarSystem Chat Permanent Report

ChatTopic: FaceGeometry normalized semantic / reuse / same-sample transaction / lifecycle closure  
ChatTitle: P2C → P3C FaceGeometry Contract and Transaction Lifecycle  
ArchiveName: KiwiChat_FaceGeometryTransactionLifecycle_Updated_20260909-2248-JST.zip  
LastWorkUpdate: 2026-09-09 22:48 JST  
LastWorkUpdatePrecision: DATE_TIME  
ArchiveCreated: 2026-09-09 22:54:56 JST  
ArchiveTimestampBasis: LAST_RELEVANT_WORK_BEFORE_ARCHIVE_REQUEST  
Project: D:\KiwiAvatarSystem  
Unity: 6000.0.80f1  
Primary: Windows / DX12  
MediaPipeUnityPlugin: 0.16.3  
Inference Engine: 2.4.1  
CurrentInvestigationVersion: P3C_1_CALLBACK_DESTRUCTION_AND_GRAPH_DISPOSAL_LIFECYCLE_REPAIR  
Status: BLOCKED_AT_P3C_CALLBACK_DESTRUCTION_LIFECYCLE_STATIC_GATE  

Authority note: Normal chat does not directly inspect the current live local project. Local implementation facts in this archive are report-time Codex snapshot evidence unless separately marked otherwise.  
NORMAL_CHAT_LIVE_LOCAL_PRODUCTION_NOT_DIRECTLY_VERIFIED

---

## EXECUTIVE SUMMARY

This chat closed the normalized landmark semantic path far enough to prove that the current IE first468 output can be used as MediaPipe FaceGeometry-style input, validated reuse of the installed MediaPipe FaceGeometry pipeline, designed a bounded same-sample geometry transaction, and implemented that transaction behind a default-OFF Production gate.

The major progression was:

P2C B10/B11 semantic correction  
→ P1-S normalized semantic PASS  
→ P3A installed FaceGeometry reuse + deterministic self-test PASS  
→ P3B same-sample transaction/lifecycle design  
→ normal-chat re-audit superseded an artificial pose-only managed-boundary blocker  
→ P3C minimal Production implementation + exact Unity compile + synthetic deterministic diagnostic PASS  
→ final independent re-audit found one remaining Static lifecycle defect at CalculatorGraph callback destruction/quiescence.

The current project decision is therefore **not** “P3C fully closed” and **not** “proceed to P3D”. The correct current gate is:

- P3C transaction implementation: substantially validated Static/synthetic.
- Callback destruction lifecycle: FAIL at the pre-Dispose quiescence assumption.
- P3D live same-build runtime: NOT AUTHORIZED yet.
- H1: NOT AUTHORIZED.
- Next single action: `P3C_1_CALLBACK_DESTRUCTION_AND_GRAPH_DISPOSAL_LIFECYCLE_REPAIR`.

No commit or push was performed in this chat.

---

## OBJECTIVE

The chat objective evolved through four exact claims:

1. Correct P2C Boundary 10/11 semantics without conflating model preprocessing with final normalized landmark semantics.
2. Determine whether installed MediaPipe FaceGeometry can be reused for IE first468 without duplicate face inference or a custom solver.
3. Define and implement a minimal, latest-frame, same-sample, epoch-safe geometry transaction.
4. Prevent the new geometry path from introducing FIFO, stale publication, duplicate temporal ownership, unnecessary Native/package work, or unsafe lifecycle behavior.

The product objective remains unchanged:

> Deliver valid current samples to the Avatar with minimum latency; reject only invalid/stale/mixed-authority samples and transitions locally.

---

## CONFIRMED FACTS

### A. P2C B10/B11

From `KiwiCodexConsolidatedReport_P2C_B10SemanticCorrection_B11Closure_20260909-155715JST.txt`:

- Report-time branch: `work/raw-direct-motion`.
- Report-time HEAD: `2637b089fa5d0673f92887eecda4e9eb4e9de25c`.
- `P2C_B1_TO_B9_CURRENT_REUSE_GATE=PASS`.
- MediaPipe explicit source-rotation preprocessing and IE no-explicit-rotation preprocessing are different statements.
- This preprocessing difference does **not** imply a surviving difference in final normalized landmark coordinates.
- MediaPipe v0.10.22 final Face Landmarker coordinates are returned in the unrotated/uncropped task-input image coordinate system.
- IE final first468 landmarks project back to the normalized tracking semantic plane using the audited same-sample crop matrix.
- `B10_FINAL_NORMALIZED_ROTATION_SEMANTIC=PASS`.
- `BOUNDARY_11_FLIP_MIRROR=PASS`.
- `P1_S_WINDOWS_NATIVE_PRODUCTION=PASS`.
- `P1_R_RECURRENCE_POLICY=ACCEPTABLE_PROVIDER_SPECIFIC_DIFFERENCE_CARRIED_FORWARD`.
- `P1_I_GEOMETRY_IDENTITY_CARRIER=NONE` at that stage.
- Nonzero WebCamTexture fallback rotation remains an open operational compatibility claim, separate from P1-S.

### B. P3A FaceGeometry reuse

From `KiwiCodexConsolidatedReport_P3A_FaceGeometryReuseContract_DeterministicSelfTest_20260909-163536JST.txt`:

- `P3_RESULT=PASS`.
- Reuse classification: `LOW_LEVEL_CALCULATOR_GRAPH_REUSE`.
- Installed MediaPipeUnityPlugin 0.16.3 native calculators could execute the version-matched v0.10.22 FaceGeometry pipeline using arbitrary 468 normalized landmarks and explicit IMAGE_SIZE, without running a second face model.
- P3 input was frozen as first468 XYZ normalized in tracking semantic plane T with TOP_LEFT origin.
- Current exact Task-oracle baseline IMAGE_SIZE was 480x270; 1920x1080 was proven exact 16:9 aspect-equivalent for the diagnostic fixture.
- 480x270 and 1920x1080 produced byte-identical FaceGeometry output in the deterministic diagnostic.
- Default Task Environment used for P3 baseline: TOP_LEFT_CORNER, VFOV 63.0°, near 1.0 cm, far 10000.0 cm.
- Canonical vertex count: 468.
- Canonical metric unit: centimeter.
- Geometry metadata resource: `geometry_pipeline_metadata_landmarks.binarypb`.
- Metadata SHA256: `BDBCDA96DFCB7DA883DA124AAA2C55DEE49770D934F0FCC71747F8C21BDC75B4`.
- Output FaceGeometry mesh is pose-normalized/canonical-aligned residual metric geometry, not an already-posed runtime mesh.
- Pose transform matrix maps canonical/output-mesh coordinates to runtime metric face coordinates.
- Deterministic diagnostic used five repeats per fixture and passed serialized-byte determinism, finite 468-vertex output, pose structure and reprojection.
- Maximum observed reprojection XY error: `1.143324937202445E-07` normalized units.
- `PROCRUSTES_CORE_SELFTEST=NOT_REQUIRED_OFFICIAL_IMPLEMENTATION_REUSED`.
- No live camera Runtime or Performance Authority.

### C. P3B design

From `KiwiCodexConsolidatedReport_P3B_SameSampleGeometryTransaction_LifecycleDesignFreeze_20260909-213452JST.txt`:

The Codex report itself returned `P3B_RESULT=FAIL_POSE_ONLY_MANAGED_BOUNDARY_NOT_CLOSED`.

Its underlying design nevertheless closed or provisionally closed:

- Existing accepted `FacePrecisionTrackingData.frameId` as geometry correlation token.
- `sourceHostTicks` remains freshness/source-age authority and is not overloaded as calculator timestamp.
- Identity tuple: `{frameId, sourceHostTicks, cameraGeneration, trackingSessionGeneration, providerGeneration, modelGeneration, backend=InferenceEngine, semanticFrameWidth, semanticFrameHeight}`.
- Exactly one immutable first468 copy: 5616 bytes.
- One in-flight geometry transaction plus one overwriteable latest pending transaction.
- No FIFO / no historical backlog.
- Persistent CalculatorGraph separate from publication epochs.
- Graph retained across ordinary camera/provider/model/session authority transitions when graph invariants are unchanged.
- Graph reset on semantic dimensions, Environment/metadata/package identity changes, graph fault, or shutdown.
- Installed `SidePacketToStreamCalculator + ImagePropertiesCalculator` selected provisionally for IMAGE_SIZE delivery without a per-frame ImageFrame.
- Output acquisition candidate: `ObserveOutputStream` static AOT-safe callback.
- Old-epoch, duplicate, out-of-order and unknown correlation rejection policies specified.
- Resume remains distinct from Provider Switch.

### D. Normal-chat P3B re-audit

The P3B FAIL was independently rejected by normal chat.

Reason:

- “Do not permanently copy/publish the 468 mesh” is a performance/resource optimization goal, not a same-sample correctness requirement.
- Installed official bindings serialize/deserialize complete FaceGeometry before pose extraction.
- The inability to do pose-only native extraction is therefore **not** a correctness blocker.
- Native/package modification without measured benefit would increase provenance/ABI/lifecycle surface.

Corrected project decision:

`P3B_RESULT=PASS_DESIGN_CLOSED_WITH_TRANSIENT_FULL_FACEGEOMETRY_MANAGED_BOUNDARY`

with transient full FaceGeometry at the official binding boundary, persistent Kiwi payload limited to pose + identity, and pose-only native extraction deferred until clean runtime/performance evidence proves material harm.

### E. P3C implementation

From `KiwiCodexConsolidatedReport_P3C_MinimalGeometryTransaction_StaticValidation_20260909-223229JST.txt`:

Report-time HEAD remained `2637b089fa5d0673f92887eecda4e9eb4e9de25c`.

Production changes attributed to P3C:

1. `Assets\Script\FaceLandmarkerRunner.cs`
   - before SHA256: `027C61F6A4B42E772F355719CFF93D5D8DF1D0C3C100AE6C07E2E3083EC4F90E`
   - after SHA256: `77708DF460584C0FCC041A345CE1736E7E6F4F5950A2D445565926058E662875`

2. New `Assets\KiwiAvatarSystem\Runtime\TrackingFoundation\KiwiFaceGeometryTransactionService.cs`
   - SHA256: `B85A4E2A4A6FC94FE720690B3D0E1CC4A844FDA0F608CFBF2192BE4C2D976129`

3. New meta `Assets\KiwiAvatarSystem\Runtime\TrackingFoundation\KiwiFaceGeometryTransactionService.cs.meta`
   - SHA256: `29B4B65B3FA4439A89154CDB96ECB877E04DE1D9FD388D7FD1C9AC27BE5F6CD1`

Protected unchanged at P3C report time:

- `KiwiInferenceFaceTracker.cs`: `17F55087EFA7D42B14EF7453F35B0720EE79A23A64CB239391171C45241E3744`
- `KiwiFaceMotion.cs`: `D00D4C86FB79B7F9B9AE3CFE791D7A819449D24D27154B31FFDF45964D8650C6`
- `KiwiRuntimeGenerationContext.cs`: `E74887450A8EBD881A3AEDE7B4789C5D83E4A7C5B7F5A6D4C427DB134D250C40`
- `KiwiTrackingProviderHub.cs`: `A5C7DE387FA2E02862BCF64942363AECFB9C7830B52DF5B8953404DF884ECCB1`
- `KiwiCanonicalTrackingFrame.cs`: `458FF33E98E054B766F20EB17CE6BDD242C9AD9FD6E73AF53D60BD3961822AFA`
- Scene had no Git diff.

Package/native unchanged:

- MediaPipe TGZ: `CC3E77A219E0B99618AE3BE64C31A566197DEEDC69C1E136ACF52D65D7CF2E79`
- installed MediaPipe package.json: `EEBBFF4550FA9CA3C2C76AB05BD0EDBDB3A0A4C2800883E244DC9E40D8FF2A2D`
- installed `mediapipe_c.dll`: `B9B620F2707DEA371BE3FCEF9F2D05468CA1471FAEE3BE6637BBD7DA77E21C54`

P3C behavior:

- Dedicated owner: `KiwiFaceGeometryTransactionService`.
- Exact accepted IE frameId returned from StoreSentis boundary.
- Geometry path does not reread global latest landmarks/frameId.
- Exactly one immutable first468 transaction copy.
- Same identity tuple as P3B.
- `MAX_IN_FLIGHT_GEOMETRY=1`.
- `MAX_PENDING_GEOMETRY=1`.
- `NO_FIFO_CONTRACT=PASS`.
- No FlowLimiter.
- No PacketCloner.
- Graph internal queue policy left at installed default; external one-in-flight is Primary latest-frame owner.
- Full FaceGeometry is transient in callback only.
- Persistent mesh payload: NONE.
- Persistent completion: Pose16 + frameId/status.
- No matrix transpose/inversion/Unity handedness conversion in P3C.
- Geometry output is not published to Head, Root, Canonical, FacePart, Avatar or Spout.
- Default execution state: OFF.
- No Scene activation.
- No package/native ABI modification.
- No commit/push.

Compile:

- Unity: `C:\Program Files\Unity\Hub\Editor\6000.0.80f1\Editor\Unity.exe`
- exact Unity 6000.0.80f1.
- exit code 0.
- 0 compiler errors.
- 0 new P3C warnings.
- `COMPILE_RESULT=PASS_UNITY_6000_0_80F1_EXIT_0_ERRORS_0_NEW_P3C_WARNINGS_0`.

Synthetic deterministic diagnostic:

- SidePacketToStream/ImageProperties path PASS.
- One transaction/callback correlation PASS.
- transient FaceGeometry parse → pose-only completion PASS.
- pending supersede PASS.
- dimension graph rebuild PASS.
- bounded shutdown diagnostic PASS.
- Synthetic only; not live Product Runtime.
- Performance Authority: NONE.

### F. Final lifecycle re-audit at 22:48

Normal chat independently re-audited P3C twice and found the same Static lifecycle defect.

MediaPipe v0.10.22 CalculatorGraph contract permits output callbacks to occur after `Cancel()` / `WaitUntilDone()` until the native CalculatorGraph object is destroyed.

P3C report described shutdown around:

- non-accepting,
- retire pending/in-flight,
- CloseAllPacketSources / Cancel,
- wait for active callback count to become zero,
- dispose graph,
- release callback registry/delegate.

The defect:

`activeCallbackCount == 0` before native graph destruction is only a momentary observation. It is not proof that no future callback can start while the native graph still exists.

Therefore the no-future-callback authority boundary must be graph destruction, not the pre-Dispose zero active count.

Current classification:

`P3C_TRANSACTION_IMPLEMENTATION=PASS_STATIC`

`P3C_CALLBACK_DESTRUCTION_LIFECYCLE=FAIL_STATIC_AT_PRE_DISPOSE_QUIESCENCE_ASSUMPTION`

`P3C_RESULT=FAIL_AT_CALLBACK_DESTRUCTION_LIFECYCLE_BOUNDARY`

This does not establish a current Avatar runtime regression because P3C execution defaults OFF, no live camera Runtime was performed, and no Avatar publication path exists.

---

## PUBLIC DESIGN PRINCIPLES

These are public/package design principles, not direct local Production facts.

### MediaPipe final landmark coordinates

MediaPipe Face Landmarker v0.10.22 uses rotation/crop as preprocessing semantics but projects final landmarks back into the unrotated/uncropped task-input image coordinate system.

Therefore model-input coordinate differences must not automatically be promoted to final normalized-coordinate semantic differences.

### FaceGeometry Task contract

Version-matched Task FaceGeometry:

- consumes first468 normalized landmarks,
- consumes IMAGE_SIZE/aspect semantics,
- uses TOP_LEFT Task default Environment,
- converts screen-space landmarks to right-handed metric geometry,
- estimates canonical-to-runtime pose,
- outputs a pose-normalized/canonical-aligned residual mesh plus pose matrix.

### Same-sample identity

MediaPipe calculator timestamp is a correlation mechanism. It is not, by itself, camera/session/provider/model/sample Authority.

Kiwi must retain its authoritative source/session/generation tuple separately.

### Latest-frame

A persistent CalculatorGraph can buffer packets. Therefore latest-frame admission must remain explicitly bounded outside the graph rather than relying on graph queue behavior.

### Lifecycle

`Cancel()` aborts graph execution but is not proof that no future output callback can occur while the native graph object still exists.

The lifecycle design must separately close publication authority invalidation, native callback-generation lifetime, callback registry/delegate lifetime, and graph destruction.

### Resource optimization

A small pose-only native/managed boundary can be desirable, but it is not automatically a Correctness prerequisite.

Do not add Native/package provenance and ABI responsibilities until measured Production evidence justifies them.

---

## INFERENCES / HYPOTHESES

The following remain unconfirmed:

- Transient full FaceGeometry serialization/deserialization may be cheap enough to keep permanently.
- It may instead become a measurable allocation/latency issue in clean Production Runtime.
- Pose-only native extraction might later be useful, but benefit is currently unmeasured.
- The corrected callback destruction ordering may be sufficient without introducing blocking graph waits; this must first be closed Static/synthetic and later in P3D lifecycle Runtime.
- Actual live geometry cadence and processing latency are unknown.
- Actual camera/provider/model/session transition behavior with the geometry service is unknown.
- H1 visual quality remains unknown for the new geometry path.

Unknown != PASS.  
Unknown != Failure.

---

## PRODUCTION AUTHORITY

Claim-scoped order used in this chat:

1. Current local Production source + SHA, when frozen by Codex at report time.
2. Same-build / same-Production Runtime where available.
3. Actually installed MediaPipe / Inference Engine package source and native artifact.
4. Latest same-HEAD Codex Consolidated REPORT.
5. Version-matched official source.
6. Older roadmap/context snapshots.

Important current limitation:

Normal chat did not directly inspect `D:\KiwiAvatarSystem`.

Therefore:

`NORMAL_CHAT_LIVE_LOCAL_PRODUCTION_NOT_DIRECTLY_VERIFIED`

Latest local facts in this archive are report-time snapshot evidence, principally the P3C 22:32 report, not an assertion of current live state after 22:48.

The R13.7 integrated roadmap remains important for durable project rules, especially Universal Double Full Audit, but its volatile P1/P2 technical snapshot was superseded later on 2026-09-09 by P2C/P3A/P3B/P3C evidence.

---

## WORK PERFORMED

### 1. B10/B11 semantic correction

Purpose: Determine whether source-rotation preprocessing mismatch actually causes normalized-landmark semantic mismatch.  
Result: PASS.  
Impact: P1-S became PASS; model-input equality was rejected as the wrong semantic boundary.

### 2. B10/B11 instruction re-audit

Purpose: Prevent ambiguous source coordinate definitions, numerical-parity requirements, and incomplete provider/flip state coverage.  
Result: Instruction strengthened with explicit source/tracking semantic plane distinction, final semantic comparison, provider × transformation matrix, and separate Windows fallback operational claim.

### 3. P3A FaceGeometry reuse and deterministic self-test

Purpose: Determine whether existing installed MediaPipe FaceGeometry can be reused instead of writing a new solver.  
Result: PASS.  
Decision: Use installed low-level CalculatorGraph/FaceGeometryPipelineCalculator.  
Impact: Custom solver/port rejected as unnecessary.

### 4. P3A instruction re-audits

Purpose: Correct IMAGE_SIZE, output-mesh, handedness and test-oracle semantics.  
Result: PASS with corrections.  
Important correction: FaceGeometry output mesh is pose-normalized; pose must be applied before reprojection.

### 5. P3B transaction/lifecycle design

Purpose: Bind one accepted IE sample to one FaceGeometry result without FIFO/stale/mixed epochs.  
Codex report result: FAIL at pose-only managed boundary.  
Underlying design: mostly closed.

### 6. P3B independent normal-chat re-audits

Purpose: Determine whether the FAIL was a real correctness blocker.  
Result: The FAIL was rejected.  
Corrected decision: Transient full FaceGeometry at the official managed binding is acceptable for correctness; persist pose only.  
Impact: Native/package modification deferred.

### 7. P3C minimal implementation

Purpose: Implement the frozen geometry transaction while default OFF and without H1/Head publication.  
Result in Codex report: PASS Static + compile + synthetic deterministic graph diagnostic.  
Key implementation: new `KiwiFaceGeometryTransactionService`, minimal Runner accepted-frameId handoff, no KiwiInferenceFaceTracker change, one-in-flight + one latest pending, no FIFO, transient full FaceGeometry, pose-only Kiwi completion, default OFF.

### 8. Final P3C independent re-audit

Purpose: Decide whether P3C PASS can authorize P3D.  
Result: FAIL at one exact Static lifecycle boundary.  
Defect: pre-Dispose `activeCallbackCount==0` was treated as no-future-callback quiescence even though MediaPipe permits callbacks until native graph destruction.  
Impact: P3D not authorized.

---

## VALIDATED DECISIONS

### Decision: P1-S normalized semantic PASS

Reason: B10/B11 final coordinate semantics close despite preprocessing differences.  
Evidence: P2C B10/B11 source/equation audit.  
Regression constraints: Do not reintroduce rotation/flip correction solely to make model-input preprocessing symmetric.  
Still current: YES, subject to unchanged relevant source identity.

### Decision: installed FaceGeometry reuse

Decision: `LOW_LEVEL_CALCULATOR_GRAPH_REUSE`.  
Reason: Installed exact-version pipeline executed deterministic arbitrary landmark input without second face inference.  
Regression constraints: No custom solver unless existing component becomes unsuitable by evidence.  
Still current: YES.

### Decision: persistent payload is pose + identity, not mesh

Reason: Current Head rigid use case does not require retaining the 468 mesh; transient official binding payload is acceptable.  
Still current: YES.

### Decision: pose-only Native extraction deferred

Reason: No Performance Authority shows transient full FaceGeometry is materially harmful.  
Regression constraints: Measure first.  
Still current: YES.

### Decision: latest-frame geometry lane

Decision: One in-flight + one overwriteable latest pending; no FIFO.  
Still current: YES.

### Decision: P3C default OFF

Reason: Implementation can be compiled and statically validated without changing current Avatar behavior before live correctness/lifecycle validation.  
Still current: YES.

### Decision: P3D blocked

Reason: Callback destruction lifecycle is not fully closed.  
Still current: YES.

---

## REJECTED APPROACHES

### Rejected: P3B FAIL because pose-only Native extraction is unavailable

Why considered: Avoid copying/deserializing the full FaceGeometry mesh.  
Why rejected: Resource optimization was incorrectly promoted to a Correctness gate.  
Revisit condition: Only if clean runtime/performance evidence proves material harm.

### Rejected: custom FaceGeometry solver / broad port

Why rejected: Installed official implementation is available and validated.

### Rejected: duplicate Face Landmarker inference for IE geometry

Why rejected: Adds unnecessary model execution and latency while losing the value of current IE first468.

### Rejected: per-frame ImageFrame for IMAGE_SIZE

Why rejected: Recurring allocation/copy for data that is graph/dimension state.

### Rejected: FlowLimiter inside geometry path

Why rejected: Adds a second admission owner; Kiwi already owns bounded latest-frame admission.

### Rejected: FIFO / Queue<T> geometry backlog

Why rejected: Violates latest-frame and low-latency policy.

### Rejected: main-thread OutputStreamPoller.Next

Why rejected: Blocking.

### Rejected: graph rebuild for ordinary provider/model/session changes

Why rejected: Publication authority changes do not necessarily change FaceGeometry algorithm resources.

### Rejected: stale/hold-last geometry inside Geometry Core

Why rejected: Would create another temporal owner and conceal source age.

---

## SUPERSEDED CONCLUSIONS

### 1. P2C 15:30 B10 FAIL

OLD:  
`B10_WINDOWS_NATIVE_PRODUCTION=FAIL`  
`P1_S_WINDOWS_NATIVE_PRODUCTION=FAIL_AT_B10_WINDOWS_FALLBACK_NONZERO_ROTATION`

NEW:  
`B10_FINAL_NORMALIZED_ROTATION_SEMANTIC=PASS`  
`P1_S_WINDOWS_NATIVE_PRODUCTION=PASS`

WHY: Preprocessing/model-input difference was incorrectly treated as final normalized-coordinate difference.

### 2. P3B pose-only blocker

OLD: `P3B_RESULT=FAIL_POSE_ONLY_MANAGED_BOUNDARY_NOT_CLOSED`

NEW: `P3B_RESULT=PASS_DESIGN_CLOSED_WITH_TRANSIENT_FULL_FACEGEOMETRY_MANAGED_BOUNDARY`

WHY: Mesh-free managed boundary is not a same-sample correctness requirement.

### 3. P3C full PASS

OLD:  
`P3C_RESULT=PASS`  
`REMAINING_UNRESOLVED_P3C_STATIC_CLAIMS=NONE`

NEW:  
`P3C_TRANSACTION_IMPLEMENTATION=PASS_STATIC`  
`P3C_CALLBACK_DESTRUCTION_LIFECYCLE=FAIL_STATIC_AT_PRE_DISPOSE_QUIESCENCE_ASSUMPTION`  
`P3C_RESULT=FAIL_AT_CALLBACK_DESTRUCTION_LIFECYCLE_BOUNDARY`

WHY: Official CalculatorGraph callback lifetime extends until graph destruction; zero active callbacks before Dispose is insufficient no-future-callback proof.

---

## OBSERVER / VALIDATOR FINDINGS

### P3C validator false positive

P3C POST_IMPLEMENTATION_FULL_AUDIT_2 initially had a text-only validator match `Head`, `Canonical`, and `FacePart` words in comments.

Direct code-reference inspection found no actual calls/references.

Classification: VALIDATOR_FALSE_POSITIVE.

The validator was corrected to code-identifier inspection.

This does not validate the final callback destruction lifecycle; that defect was found later by independent source re-audit.

### Synthetic diagnostic scope

P3C deterministic diagnostic passed its named synthetic claims, including shutdown in the tested run.

However a successful synthetic shutdown run does not override a version-matched Static lifecycle contract defect.

Correctness Authority: Source/lifecycle contract remains controlling for the discovered race.

---

## FILES / SHA256

### Current P3C modified Production files at report time

Path: `Assets\Script\FaceLandmarkerRunner.cs`  
Role: Accepted IE frameId handoff / geometry transaction trigger integration.  
Before SHA256: `027C61F6A4B42E772F355719CFF93D5D8DF1D0C3C100AE6C07E2E3083EC4F90E`  
After SHA256: `77708DF460584C0FCC041A345CE1736E7E6F4F5950A2D445565926058E662875`  
Current/Obsolete: Current at P3C report time.

Path: `Assets\KiwiAvatarSystem\Runtime\TrackingFoundation\KiwiFaceGeometryTransactionService.cs`  
Role: Geometry CalculatorGraph / bounded transaction / callback / lifecycle owner.  
Before: ABSENT.  
After SHA256: `B85A4E2A4A6FC94FE720690B3D0E1CC4A844FDA0F608CFBF2192BE4C2D976129`  
Current/Obsolete: Current at P3C report time; lifecycle repair required before P3D.

Path: `Assets\KiwiAvatarSystem\Runtime\TrackingFoundation\KiwiFaceGeometryTransactionService.cs.meta`  
After SHA256: `29B4B65B3FA4439A89154CDB96ECB877E04DE1D9FD388D7FD1C9AC27BE5F6CD1`

### Protected unchanged at P3C report time

`KiwiInferenceFaceTracker.cs`: `17F55087EFA7D42B14EF7453F35B0720EE79A23A64CB239391171C45241E3744`  
`KiwiFaceMotion.cs`: `D00D4C86FB79B7F9B9AE3CFE791D7A819449D24D27154B31FFDF45964D8650C6`  
`KiwiRuntimeGenerationContext.cs`: `E74887450A8EBD881A3AEDE7B4789C5D83E4A7C5B7F5A6D4C427DB134D250C40`  
`KiwiTrackingProviderHub.cs`: `A5C7DE387FA2E02862BCF64942363AECFB9C7830B52DF5B8953404DF884ECCB1`  
`KiwiCanonicalTrackingFrame.cs`: `458FF33E98E054B766F20EB17CE6BDD242C9AD9FD6E73AF53D60BD3961822AFA`  
Installed MediaPipe package.json: `EEBBFF4550FA9CA3C2C76AB05BD0EDBDB3A0A4C2800883E244DC9E40D8FF2A2D`  
Installed mediapipe_c.dll: `B9B620F2707DEA371BE3FCEF9F2D05468CA1471FAEE3BE6637BBD7DA77E21C54`  
MediaPipe TGZ: `CC3E77A219E0B99618AE3BE64C31A566197DEEDC69C1E136ACF52D65D7CF2E79`

Normal-chat warning: these are report-time values, not independently recomputed by normal chat.

---

## RUNTIME EVIDENCE

### Live Production Runtime

Live camera Runtime: NOT RUN in P3A/P3B/P3C.  
Same-build geometry transaction Runtime: NOT RUN.  
Human Visual: NOT RUN.  
Performance benchmark: NOT RUN.  
Performance Authority: NONE.

### Deterministic diagnostic evidence

P3A: installed native FaceGeometry calculator deterministic self-test.  
Authority: DETERMINISTIC_DIAGNOSTIC / PACKAGE EXECUTION.

P3C: synthetic geometry transaction diagnostic.  
Passed named claims: graph start, dimension side-packet path, callback/correlation, transient FaceGeometry parse, pose-only completion, pending supersede, dimension graph rebuild, bounded shutdown in observed test.  
Authority: DETERMINISTIC_DIAGNOSTIC_ONLY.

Not Authority for live camera cadence, live lifecycle transition frequency, callback-destruction contract, Performance, or Human Visual.

---

## CURRENT RESULT

```text
P1_S_WINDOWS_NATIVE_PRODUCTION=PASS

P3A_RESULT=PASS
FACEGEOMETRY_REUSE_DECISION=LOW_LEVEL_CALCULATOR_GRAPH_REUSE

P3B_RESULT=
PASS_DESIGN_CLOSED_WITH_TRANSIENT_FULL_FACEGEOMETRY_MANAGED_BOUNDARY

P3C_TRANSACTION_IMPLEMENTATION=PASS_STATIC

P3C_CALLBACK_DESTRUCTION_LIFECYCLE=
FAIL_STATIC_AT_PRE_DISPOSE_QUIESCENCE_ASSUMPTION

P3C_RESULT=
FAIL_AT_CALLBACK_DESTRUCTION_LIFECYCLE_BOUNDARY

P1_I_GEOMETRY_IDENTITY_CARRIER=
IMPLEMENTED_STATIC_EXCEPT_LIFECYCLE_CLOSURE
NOT_RUNTIME_VALIDATED

P3D=NOT_AUTHORIZED
H1=NOT_AUTHORIZED

PRODUCTION_AVATAR_BEHAVIOR_CHANGE=NO
P3C_DEFAULT_EXECUTION_STATE=OFF

LIVE_CAMERA_RUNTIME=NOT_RUN
PERFORMANCE_AUTHORITY=NONE
COMMIT_PUSH=NO
```

---

## OPEN ISSUES

1. Correct `KiwiFaceGeometryTransactionService` callback-registry / graph-destruction ordering.
2. Prove no callback can access released registry/delegate/service state after native graph destruction.
3. Recompile exact Unity 6000.0.80f1.
4. Run synthetic callback/dispose stress targeted only at the repaired lifecycle boundary.
5. Perform two complete independent post-repair audits.
6. Only then authorize P3D same-build live geometry transaction Runtime.
7. In P3D measure same-sample correlation, stale/mixed epoch rejection, one-in-flight/latest-pending behavior, source age preservation, geometry cadence, transient FaceGeometry parse cost, allocation/GC.
8. Decide from clean evidence whether pose-only Native extraction is worth adding.
9. H1 remains later and separate.
10. R13.7 integrated roadmap’s volatile P1/P2 status is stale versus later 2026-09-09 P2C/P3 evidence; integrated information should be refreshed after the current lifecycle boundary is closed.

---

## NEXT ACTION

`P3C_1_CALLBACK_DESTRUCTION_AND_GRAPH_DISPOSAL_LIFECYCLE_REPAIR`

Exact target:

Current unsafe assumption:

```text
Cancel/close
→ activeCallbackCount == 0
→ Dispose native graph
→ registry release
```

Required authority direction:

```text
stop admission
→ retire pending/in-flight publication authority
→ registry non-accepting
→ Cancel/close as appropriate
→ keep registry/delegate alive
→ destroy/dispose native CalculatorGraph
→ native graph destruction becomes no-future-callback boundary
→ confirm already-entered callbacks drained
→ release registry/delegate/service callback state
```

Do not add blocking per-frame waits.

Scope must remain narrow:

- Geometry lifecycle service only where possible.
- No Runner semantic change unless exact repair requires it.
- No KiwiInferenceFaceTracker change.
- No Camera/Native/package change.
- No H1/Head/FacePart/Canonical publication.
- No performance optimization.
- No commit/push.

Required: FULL_AUDIT_1 + FULL_AUDIT_2 before and after repair.

---

## DO NOT CHANGE

Without new evidence, do not change:

- Face Landmarker Primary / Source of Truth.
- Native Path B SystemMemoryNV12.
- latest-frame principle.
- no FIFO / stale queue.
- persistent ROI principle.
- Root / Head / Eye / Mouth authority separation.
- Head single rigid authority.
- Provider normalization owner=1.
- Resume != Provider Switch.
- existing tracking freshness thresholds.
- `KiwiFaceMotion` as a camera/inference workaround.
- `KiwiInferenceFaceTracker` math for this lifecycle issue.
- Camera/Native path.
- FaceGeometry algorithm.
- default FaceGeometry Environment.
- ROI recurrence.
- smoothing / Kalman / prediction / hold-last.
- Fence / GPU Wait / graph-wide normal-operation blocking waits.
- pose-only Native extraction until Performance evidence justifies it.
- H1 until P3D and later gates close.

---

## PROJECT-WIDE DOUBLE FULL AUDIT

Current durable project rule from R13.7 remains valid:

`UNIVERSAL_DOUBLE_FULL_AUDIT=REQUIRED`

Scope: all substantive KiwiAvatarSystem technical research, design, instructions, implementation, validation, evaluation, decisions and artifacts.

Required semantics:

- FULL_AUDIT_1 = 100% of the same scope.
- FULL_AUDIT_2 = independently restart and audit 100% of the same scope again.
- Partitioning one full audit across two partial passes is rejected.
- Disagreement = STOP / UNRESOLVED.
- Side-effecting operations are not mechanically repeated twice merely to satisfy audit count.

### This archive artifact audit

ARCHIVE_FULL_AUDIT_1: PASS.  
Scope: chronology, Authority, files/SHA provenance, P2C/P3A/P3B/P3C decisions, supersession, evidence classification, open issues, next action, protected boundaries.

ARCHIVE_FULL_AUDIT_2: PASS.  
Independent restart: rechecked the same complete archive scope against the chat’s latest P2C/P3A/P3B/P3C reports and the final 22:48 lifecycle decision.

ARCHIVE_AUDIT_DISAGREEMENTS: NONE.

---

## HANDOFF

Start the next chat from this state:

1. Treat P2C normalized semantic closure as current: `P1_S_WINDOWS_NATIVE_PRODUCTION=PASS`.
2. Treat installed FaceGeometry reuse as current: `LOW_LEVEL_CALCULATOR_GRAPH_REUSE`.
3. Do not re-open P3A deterministic solver/reprojection work without new evidence.
4. Treat P3B’s original pose-only FAIL as superseded. Current design allows transient full FaceGeometry at the managed boundary and persists pose only.
5. P3C introduced minimal Runner frameId handoff, `KiwiFaceGeometryTransactionService`, immutable first468 capture, one-in-flight + one latest pending, official FaceGeometry graph, transient full FaceGeometry callback parse, Pose16 completion, default OFF, no H1 publication.
6. Do **not** accept P3C’s original full PASS as current. Final normal-chat double audit found `FAIL_STATIC_AT_PRE_DISPOSE_QUIESCENCE_ASSUMPTION`.
7. Next work is one narrow lifecycle repair: native CalculatorGraph destruction must become the no-future-callback Authority boundary before callback registry/delegate state is released.
8. After repair: exact Unity compile, targeted synthetic lifecycle diagnostic, two full audits, then P3D minimal same-build live transaction Runtime.
9. P3D is correctness/lifecycle only. No Head/H1 visual tuning. Performance data may only decide whether transient FaceGeometry parsing warrants future pose-only Native optimization.
10. H1 remains NOT AUTHORIZED.
11. Normal-chat current-local status: `NORMAL_CHAT_LIVE_LOCAL_PRODUCTION_NOT_DIRECTLY_VERIFIED`.

---

## CHAT ARCHIVE INDEX

Archive: `KiwiChat_FaceGeometryTransactionLifecycle_Updated_20260909-2248-JST.zip`  
Topic: FaceGeometry normalized semantics, installed reuse, same-sample geometry transaction and lifecycle  
LastWorkUpdate: 2026-09-09 22:48 JST  
Status: BLOCKED_AT_P3C_CALLBACK_DESTRUCTION_LIFECYCLE_STATIC_GATE  
Supersedes: P2C 15:30 B10/P1-S FAIL conclusions; P3B pose-only managed-boundary FAIL as project blocker; P3C full PASS as current lifecycle-complete decision.  
SupersededBy: NONE at archive creation.  
NextArchiveCandidate: After `P3C_1_CALLBACK_DESTRUCTION_AND_GRAPH_DISPOSAL_LIFECYCLE_REPAIR` and its double full audit, or after subsequent P3D same-build Runtime correctness/lifecycle gate.

---

## MASTER REPORT / INTEGRATED INFORMATION UPDATE CANDIDATES

Future project integrated information should incorporate:

- P1-S PASS after B10/B11 correction.
- P3A installed FaceGeometry reuse PASS.
- P3B corrected transient-full-FaceGeometry design PASS.
- P3C minimal transaction implementation exists, default OFF.
- P3C callback destruction lifecycle remains current first failing boundary.
- P3D and H1 remain not authorized.
- R13.7 Universal Double Full Audit policy remains current.
- R13.7 volatile P1 FAIL / P2-next snapshot is superseded by later same-day evidence.

Normal chat did not modify the local integrated roadmap file.

---

END_OF_CHAT_PERMANENT_REPORT
