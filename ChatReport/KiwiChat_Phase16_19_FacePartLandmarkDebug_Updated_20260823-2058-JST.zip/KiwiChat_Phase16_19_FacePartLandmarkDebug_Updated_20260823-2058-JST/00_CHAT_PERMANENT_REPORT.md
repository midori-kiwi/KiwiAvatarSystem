# KiwiAvatarSystem Chat Permanent Report

ChatTopic: Phase16.19 FacePart strict epoch / matched landmark debug alignment / live-preview separation planning  
ChatTitle: Phase16.19.2–16.19.4 Runtime Validation and Landmark Debug Repair  
ArchiveName: KiwiChat_Phase16_19_FacePartLandmarkDebug_Updated_20260823-2058-JST.zip  
LastWorkUpdate: 2026-08-23 20:58 JST  
LastWorkUpdatePrecision: DATE_TIME  
ArchiveCreated: 2026-09-02 23:25 JST  
ArchiveTimestampBasis: LAST_RELEVANT_WORK_BEFORE_ARCHIVE_REQUEST  
Project: KiwiAvatarSystem  
Unity: 6000.0.80f1  
CurrentInvestigationVersion: KiwiAvatarSystem v5.1.0 Phase16.19.4; Phase16.19.5 pending at end of this chat  
Status: PARTIALLY_DONE  
ProductionVerification: LOCAL_PRODUCTION_NOT_DIRECTLY_VERIFIED  

> Historical-scope note: this archive preserves this chat's Phase16.19.x work. It is not the current project-wide Production master state as of 2026-09-02. The later project-wide consolidated instruction/authority documents uploaded when this archive was created show that subsequent work advanced beyond this chat. Therefore this archive must not supersede later Production/runtime authority.

---

## EXECUTIVE SUMMARY

This chat closed three connected observer/presentation defects without changing the tracking core:

1. **Phase16.19.2**: found that `KiwiMatureVTuberSupervisor` reopened strict FacePart temporal options after the intended policy layer had disabled them. The Supervisor writer was corrected and Preflight was hardened. Runtime then showed the strict FacePart epoch contract, Root authority, handoff authority, and texture transaction all passing.
2. **Phase16.19.3**: found that the debug comparison panel overlaid canonical semantic landmarks on the *current live camera frame*, even though the semantic result was roughly 100 ms old. The observer was changed to display the camera snapshot already matched to that semantic transaction.
3. **Phase16.19.4**: after epoch matching exposed a remaining deterministic error, the canonical landmark annotation was found to receive an extra horizontal mirror in the debug overlay. The second annotation mirror was removed while preserving camera preview mirroring. The final retest removed the left/right inversion and preserved authority/epoch gates.

A separate visual problem was then identified: during fast motion the matched debug camera can appear to freeze for roughly 100–190 ms while waiting for a newer semantic transaction. Evidence indicated that the live camera continued advancing. The next planned repair was therefore **Phase16.19.5: separate always-live camera presentation from the timestamp-matched landmark diagnostic panel**, rather than weakening timestamp matching or changing tracking math.

A permanent process decision was also added: before future design changes, bug fixes, or optimizations, first research relevant commercial VTuber software, SNS/AR face-filter systems, MediaPipe/Unity official source, and similar OSS/GitHub implementations; then compare those principles against current Kiwi Production and Runtime evidence before choosing one best implementation.

---

## OBJECTIVE

Primary objectives of this chat:

- restore the Phase16.19 strict FacePart presentation contract;
- verify Root/provider/FacePart authority non-regression with runtime evidence;
- determine whether reported LandMarker displacement was a real semantic-coordinate defect or a bad diagnostic observer;
- repair only the observer/presentation path when evidence did not justify touching `FaceLandmarkerRunner`, `KiwiFaceMotion`, `KiwiInferenceFaceTracker`, ProviderHub, or production FacePart geometry;
- add fast-motion apparent camera freeze to the formal repair backlog;
- establish external commercial/OSS research as a mandatory pre-implementation step.

---

## CONFIRMED FACTS

### Phase16.19.2 root cause

The pre-fix runtime showed strict FacePart failure while the texture transaction itself remained coherent. The retained runtime-analysis JSON identifies the responsible late writer as `KiwiMatureVTuberSupervisor`, which re-enabled `enablePrediction` and forced `compensateMatchedFrameAge=true` after the intended strict enforcement.

The Phase16.19.2 static validation records:

- Supervisor hardening marker present;
- `enablePrediction=false`;
- `compensateMatchedFrameAge=false`;
- `directPositionDuringMotion=false`;
- old dynamic Supervisor writes removed;
- Preflight regression checks added;
- `KiwiFaceMotion.cs`, `KiwiTrackingProviderHub.cs`, `KiwiInferenceFaceTracker.cs`, `FaceLandmarkerRunner.cs`, diagnostics, and overlay were not modified by that fix.

### Phase16.19.2 post-fix runtime

The following later run used 1815 CSV rows × 247 columns and passed all recorded authority/strict FacePart gates across the run:

- `singlePresentationAuthority = 1`
- `quality10PolicyOnly = 1`
- `quality10LegacyRootWriteCount = 0`
- `quality10LegacyWriteViolationCount = 0`
- `canonicalHandoffNormalizationEnabled = 1`
- `localRootProviderBridgeActive = 0`
- `handoffAuthorityViolationCount = 0`
- `singleHandoffAuthority = 1`
- `strictFacePartPresentationEpoch = 1`
- `facePartPredictionDisabled = 1`
- `facePartMatchedAgeCompensationDisabled = 1`
- `facePartDirectMotionDisabled = 1`
- `facePartLiveResidualDisabled = 1`
- `facePartPresentationEpochAligned = 1`
- `facePartPresentationEpochViolationCount = 0`
- texture transaction operational/strict/scene-bound, with external writer count 0.

Measured values in the retained Phase16.19.3 validation input included:

- observation age median: 107.9401 ms
- inference latency median: 100.790024 ms
- accepted source age median: 102.0773 ms
- face texture match delta median: 1.1111 ms

### Phase16.19.3 observer defect

`KiwiFrameComparisonOverlay.cs` had been drawing a live camera texture while its landmark layer came from the canonical semantic frame. This compared different time epochs during motion. The production FacePart texture transaction already had a camera snapshot matched to the semantic timestamp with approximately 1 ms match delta.

Phase16.19.3 therefore added a read-only observer API to `KiwiFacePartTextureTransaction` and changed only the diagnostic overlay to draw canonical landmarks when the matched semantic camera snapshot was available. The 247-column CSV schema was preserved.

Static validation confirmed:

- matched-epoch API present;
- landmark draw gated by matched epoch;
- last committed slot tracked for observer access;
- Preflight contract added;
- CSV header block byte-identical;
- no new `AsyncGPUReadback.WaitAllRequests`;
- no new `WaitForCompletion`;
- no new `SmoothDamp`;
- no Kalman addition.

Unity compilation was **not** executed in the container for that generated fix.

### Phase16.19.3 retest / Phase16.19.4 diagnosis

The Phase16.19.3 retest used:

- `KiwiFrameComparison_20260823_202410.csv`
- 1240 rows × 247 columns
- MP4: `KiwiAvatarSystem - Face Landmark Detection - Windows, Mac, Linux - Unity 6.0 (6000.0.80f1) _DX11_ 2026-08-23 20-24-15.mp4`

The matched preview was active. An example at about 5 seconds showed:

`rigid=12067 semantic=12067 previewTs=12067 same=True`

Therefore the camera snapshot and semantic landmark epoch were matched, yet the landmark cloud appeared on the horizontally opposite side of the face. This ruled out the old time-epoch mismatch as the explanation for the remaining left/right error.

### Phase16.19.4 root cause and repair

The remaining error was observer-only horizontal double mirroring. The camera preview kept its front-facing mirror, while the canonical landmark annotation also reused `FacePartCropper.mirrorX`. That second annotation mirror was removed. Production `FacePartCropper` behavior was not changed.

Phase16.19.4 changed only:

- `Assets/KiwiAvatarSystem/Runtime/Validation/KiwiFrameComparisonOverlay.cs`
- `Assets/KiwiAvatarSystem/Editor/KiwiReleaseCandidatePreflight.cs`

Static validation records:

- lexical balance PASS;
- Phase16.19.3 matched epoch preserved;
- canonical landmark second mirror disabled;
- camera preview mirror preserved;
- Preflight contract added;
- 247 CSV columns unchanged;
- no new blocking wait / SmoothDamp / Kalman.

### Phase16.19.4 final retest

The final same-run evidence in this chat was:

- CSV: `KiwiFrameComparison_20260823_203931.csv`
- 1938 rows × 247 columns
- MP4: `KiwiAvatarSystem - Face Landmark Detection - Windows, Mac, Linux - Unity 6.0 (6000.0.80f1) _DX11_ 2026-08-23 20-39-36.mp4`

Chat analysis concluded:

- Root/presentation authority gates: 1938/1938 PASS;
- provider/handoff authority gates: 1938/1938 PASS;
- after the initial pre-semantic startup rows, FacePart strict epoch gates passed for all valid semantic rows;
- FacePart presentation violation count remained 0;
- the clear `face left -> landmark right / face right -> landmark left` inversion disappeared;
- no evidence justified adding X/Y scale, aspect-ratio, rotation, or semantic coordinate corrections.

Performance figures recorded in chat for that run:

- inference latency median ≈ 100.24 ms; P95 ≈ 103.82 ms
- accepted source age median ≈ 101.31 ms; P95 ≈ 105.06 ms
- face texture match delta median ≈ 1.09 ms; P95 ≈ 1.58 ms
- tracking rate median ≈ 23.38 Hz
- canonical adoption median ≈ 31.18 Hz

### Fast-motion apparent camera freeze

A new issue was observed after Phase16.19.4: during rapid motion the camera panel can appear to freeze briefly.

The chat analysis distinguished this from a proven WebCamTexture stall. During a long matched-snapshot hold of roughly 188 ms, the recorded live-camera indicators still advanced on most render samples (e.g. camera-fresh/live-texture advancement continued). The matched debug panel was holding the old semantic-matched snapshot until a new semantic transaction arrived.

Therefore the confirmed issue is **matched-debug presentation hold that looks like a camera freeze**. A true underlying camera-source stall was not established by this chat.

---

## PUBLIC DESIGN PRINCIPLES

### MediaPipeUnityPlugin v0.16.3

Official source reviewed during this chat showed two relevant principles:

1. `ImageTransformationOptions` computes input transformation from horizontal flip, vertical flip, and rotation state rather than treating all display mirroring as one generic coordinate operation.
2. The sample `Screen` presentation path applies front-facing display mirroring at the screen/UV layer. This supported the conclusion that reusing a FacePart raw-camera UV mirror for canonical landmark annotation can double-apply horizontal mirroring.

This is a **public source principle**, not evidence about proprietary commercial implementations.

### General observer/presentation principle validated by this chat

A diagnostic overlay that claims spatial alignment must compare data from the same source identity and time epoch. If a landmark result is delayed relative to the live camera, drawing it over the current camera frame creates an observer artifact that can be mistaken for a tracking-coordinate defect.

### New permanent research rule

Before future Kiwi design/fix/optimization work, research applicable public information from:

- Webcam Motion Capture as the highest-priority commercial comparison;
- VTube Studio, Warudo, Animaze, VSeeFace, VNyan and other VTuber systems;
- TikTok / Effect House, Snapchat / Lens Studio, Meta/Instagram public AR information, SNOW where public information exists;
- MediaPipe / Face Landmarker / MediaPipeUnityPlugin official documentation and source;
- OpenSeeFace, Kalidokit, VSeeFace-related public source and similar GitHub implementations.

For proprietary systems, separate **confirmed public facts**, **public design principles**, and **inference/speculation**. Never assert unpublished internals as fact.

---

## INFERENCES / HYPOTHESES

1. The brief fast-motion freeze seen in the matched debug panel is primarily caused by semantic cadence / inference-age-driven snapshot hold, not a camera-source stop. This is strongly supported by the live-camera advancement indicators, but the chat did not perform a dedicated camera-source stall instrumentation run.
2. High-speed motion tracking cadence reductions to approximately 5–9 Hz in some intervals may make the matched snapshot hold more visible. This is a separate performance issue from the observer display freeze.
3. The approximately 100 ms inference/service age remains a likely next optimization target, but this chat did not establish its full GPU/readback/internal scheduling breakdown.

These remain investigation targets, not reasons to alter tracking thresholds, smoothing, provider authority, or 3-lane scheduling without new evidence.

---

## PRODUCTION AUTHORITY

Authority used inside this chat:

1. same-run Runtime CSV + MP4 when both were available and identified as matching;
2. cumulative Kiwi source copies/materialized source available in the chat environment;
3. generated static-validation JSON for each repair;
4. MediaPipeUnityPlugin v0.16.3 official source for transformation/presentation behavior;
5. historical project context only where consistent with newer evidence.

Important limitation:

`D:\KiwiAvatarSystem` local Production was not directly mounted/verified by this normal chat at archive time.

Therefore:

`LOCAL_PRODUCTION_NOT_DIRECTLY_VERIFIED`

No local Production SHA is invented.

Later project-wide authority documents uploaded on 2026-09-02 supersede this chat as the current whole-project authority. This report remains a historical detailed archive of the Phase16.19.x work only.

---

## WORK PERFORMED

### 1. Strict FacePart runtime failure audit

Purpose: determine why Phase16.19 strict temporal flags were still failing after earlier enforcement.

Result: found a later Supervisor writer reopening prediction/age compensation.

Decision impact: do not strengthen Cropper/Quality10 repeatedly; fix the actual later writer and harden Preflight.

### 2. Phase16.19.2 Supervisor Policy Fix

Purpose: prevent the Supervisor from violating the strict commercial FacePart contract.

Result: static validation PASS; later runtime strict FacePart/authority gates PASS.

Decision impact: strict writer issue considered solved.

### 3. LandMarker visual mismatch audit

Purpose: determine whether canonical landmarks themselves were spatially wrong.

Result: found that the observer compared live camera pixels to delayed semantic landmarks.

Decision impact: fix measurement instrument before touching tracking semantics.

### 4. Phase16.19.3 Matched Landmark Preview Epoch Fix

Purpose: make camera pixels and canonical landmarks share the same semantic transaction.

Result: observer shows matched snapshot only; landmark overlay is suppressed when matched frame is unavailable.

Decision impact: temporal mismatch removed from visual diagnosis.

### 5. Phase16.19.3 retest

Purpose: evaluate residual alignment after time coherence was restored.

Result: time identity matched (`same=True`) but horizontal inversion remained.

Decision impact: remaining issue was a spatial transform error in the observer, not time mismatch.

### 6. MediaPipeUnityPlugin source comparison

Purpose: check expected front-camera input/display mirroring responsibilities.

Result: official source supported separating input transformation from display mirroring and did not justify a second canonical annotation mirror.

Decision impact: remove only the overlay's second landmark mirror.

### 7. Phase16.19.4 Landmark Annotation Mirror Alignment

Purpose: eliminate observer-only double mirror while preserving production paths.

Result: static PASS; final runtime removed the left/right landmark inversion with authority and FacePart gates retained.

Decision impact: LandMarker alignment issue considered resolved for this chat; no arbitrary scale/offset correction added.

### 8. Fast-motion apparent camera-freeze analysis

Purpose: determine whether rapid motion was freezing the actual camera.

Result: evidence showed live camera advancement while matched debug snapshot could hold for ~100–190 ms.

Decision impact: add Phase16.19.5 Live Camera / Matched Debug Separation; do not weaken epoch matching.

### 9. Development-process update

Purpose: reduce locally plausible but poorly benchmarked design changes.

Result: mandatory pre-implementation research of commercial VTuber, SNS/AR filter, official MediaPipe/Unity source, and similar OSS/GitHub approaches was added to the workflow.

Decision impact: Phase16.19.5 and later performance work must start with external comparison before implementation.

---

## VALIDATED DECISIONS

### Decision: Strict FacePart contract remains closed

Reason: later Supervisor writer was the actual violation source.

Evidence: Phase16.19.2 static checks plus 1815-row later runtime PASS.

Regression constraints: do not re-enable prediction, matched-age compensation, direct motion, or live residual in commercial strict mode.

Still current in this chat: YES.

### Decision: Fix observer epoch before tracking coordinates

Reason: live pixels and delayed semantic landmarks were from different moments.

Evidence: ~100 ms inference/observation age versus ~1.1 ms texture transaction match delta.

Regression constraints: matched landmark validation must use same semantic camera snapshot.

Still current in this chat: YES.

### Decision: Do not apply a second horizontal mirror to canonical landmark annotation

Reason: after time matching, the residual error was deterministic left/right inversion caused by observer mirroring.

Evidence: same timestamp identity with face/landmark appearing on opposite horizontal sides; final retest removed inversion.

Regression constraints: keep camera preview mirroring independent from canonical annotation coordinates.

Still current in this chat: YES.

### Decision: Do not add X/Y scale, aspect, rotation, or arbitrary offset compensation after Phase16.19.4

Reason: final runtime no longer supplied evidence for such correction.

Evidence: left/right alignment corrected across central/edge movement without production semantic changes.

Regression constraints: only revisit with same-epoch evidence of a reproducible transform error.

Still current in this chat: YES.

### Decision: Separate live preview from matched diagnostic preview

Reason: a historical matched frame is valid for diagnostic epoch coherence but should not masquerade as an always-live camera UI.

Evidence: matched snapshot hold while live camera advancement continued.

Regression constraints: preserve matched observer transaction; do not change tracking/camera source as a display workaround.

Still current in this chat: PLANNED / NOT YET IMPLEMENTED HERE.

### Decision: Mandatory external research before future implementation

Reason: compare mature commercial/public systems and official/OSS source before changing a stable Kiwi architecture.

Evidence: user process decision at end of this chat.

Regression constraints: separate verified facts/public principles/speculation; local Production + latest Runtime remain higher authority than analogy.

Still current: YES as a process rule.

---

## REJECTED APPROACHES

### Rejected: Modify `FaceLandmarkerRunner` to compensate the visible landmark offset

Why considered: visual landmarks appeared displaced from the face.

Why rejected: first defect was time-epoch mismatch; second defect was overlay-only horizontal double mirror.

Evidence: Phase16.19.3 same-epoch retest and Phase16.19.4 final retest.

Revisit condition: only if same-epoch observer evidence proves the production semantic transform itself is wrong.

### Rejected: Add arbitrary X/Y position or scale compensation

Why considered: apparent residual visual offset.

Why rejected: after correcting epoch and mirror, no persistent transform error justified it.

Revisit condition: reproducible same-epoch constant/edge-growing transform error.

### Rejected: Weaken matched-frame behavior to make the debug camera look smoother

Why considered: matched preview appears to freeze during high-speed motion.

Why rejected: weakening timestamp matching would invalidate the diagnostic instrument again.

Revisit condition: none; instead separate the always-live camera UI from the matched diagnostic view.

### Rejected: Solve the apparent camera freeze through `KiwiFaceMotion`, `KiwiInferenceFaceTracker`, smoothing, thresholds, or a permanent frame buffer

Why rejected: evidence points first to observer presentation behavior, not Root/tracking math.

Revisit condition: only with independent evidence of a real upstream defect.

---

## SUPERSEDED CONCLUSIONS

### OLD

`LandMarker spatial coordinates are probably wrong because the landmark cloud visibly trails/displaces during motion.`

### NEW

The first major displacement was caused by live-camera vs delayed-semantic epoch mismatch. After matching epochs, the remaining left/right inversion was caused by a second debug annotation mirror.

### WHY

The observer itself was invalid for spatial diagnosis until it used a timestamp-matched camera snapshot.

### EVIDENCE

Phase16.19.3 matched preview identity and Phase16.19.4 final runtime.

---

### OLD

`The camera may be freezing during rapid movement.`

### NEW

This chat established an apparent freeze in the matched diagnostic camera, while live-camera advancement continued during the observed hold. A true camera-source stall was not proven.

### WHY

The matched preview intentionally holds the semantic-matched snapshot until a new semantic transaction arrives.

### EVIDENCE

Fast-motion hold analysis recorded in chat.

---

## OBSERVER / VALIDATOR FINDINGS

1. **Observer defect #1 — mixed epochs**  
   `KiwiFrameComparisonOverlay` combined current camera pixels with delayed canonical landmarks. This observer could falsely suggest tracking-coordinate error.

2. **Observer defect #2 — double mirror**  
   After epoch correction, the debug overlay still applied `FacePartCropper.mirrorX` to canonical annotation, producing horizontal inversion.

3. **Validator gap — later Supervisor writer**  
   Earlier strict checks were insufficient because `KiwiMatureVTuberSupervisor` could reopen disabled options later in execution. Preflight was expanded to reject those old writer patterns.

4. **Performance caution**  
   Inference latency/age figures in these runtime comparison runs are useful diagnostic evidence, but observer-heavy runs should not automatically become final Production performance authority without checking instrumentation overhead.

---

## FILES / SHA256

### Generated Phase16.19.2 package

Path: `KiwiAvatarSystem_v5_1_0_Phase16_19_2_SupervisorPolicyFix.zip`  
Role: Supervisor strict FacePart policy repair + Preflight hardening  
SHA256: `1077f380648bf2175b59cd041afab5fd75e9c192676ced726bcacea29cefb323`  
Current/Obsolete: historical generated artifact; not proof of installed local Production.

Relevant generated source hashes from Phase16.19.2 validation:

- `KiwiMatureVTuberSupervisor.cs`: `cf0921776ad06334ff9011b0a82b787bffc727028ba4fa8ddc33476f663ed9f6`
- `KiwiReleaseCandidatePreflight.cs`: `82e78041893d5941ead1049e377717c99959957d8aca390322a5866dcec6edf4`

### Generated Phase16.19.3 package

Path: `KiwiAvatarSystem_v5_1_0_Phase16_19_3_LandmarkPreviewEpochFix.zip`  
Role: matched semantic-camera observer preview  
SHA256: `92494568ea74379135549763bc0e439497762d829f4ceefa8cb742fdc678b900`  
Current/Obsolete: historical generated artifact; not proof of installed local Production.

Relevant generated source hashes from validation:

- `KiwiFrameComparisonOverlay.cs`: `4ba8ea1e45f2fe192157e9e68f521a72d2e654fd2b72e64e3a6518f944268fd1`
- `KiwiFacePartTextureTransaction.cs`: `dc78488dcd1d2e45e5aa6f40065d4983087014b501b5fd5a8e37b6d8e0f68849`
- `KiwiReleaseCandidatePreflight.cs`: `2be1d56f2babb140cf14ccd4380db9f0faea03b0f43df4e101784f6afee9c62e`

### Generated Phase16.19.4 package

Path: `KiwiAvatarSystem_v5_1_0_Phase16_19_4_LandmarkAnnotationMirrorFix.zip`  
Role: remove second canonical annotation mirror while preserving matched epoch and camera mirror  
SHA256: `d4876c6139827d0a87ca51f2abb98d80a4e70ed0e8b74f210d84d3b6debe1251`  
Current/Obsolete: latest generated artifact inside this chat; not proof of installed local Production.

Generated source hashes currently retained in archive-creation environment:

- `KiwiFrameComparisonOverlay.cs`: `34d08936cf94a3f3cecd80fdd0dabb51814b0abb3a84ee4d794a7cb20a7be4cb`
- `KiwiReleaseCandidatePreflight.cs`: `30f92f4bf59fc28cf94613f054263beffe3099d556129e5bb990aae3842722e7`

### Local Production files

`D:\KiwiAvatarSystem\...` actual installed Production SHA: `NOT_AVAILABLE_IN_NORMAL_CHAT`  
Reason: local Production not directly verified during archive creation.

---

## RUNTIME EVIDENCE

### Phase16.19.2 failure diagnosis run

File: runtime retained in `PHASE16_19_2_RUNTIME_RETEST_ANALYSIS.json`  
CSV characteristics: 1153 rows × 247 columns  
Authority: CORRECTNESS / SUPPORTING_ONLY  
Result: strict FacePart contract failed while transaction matching remained coherent; Supervisor identified as later writer.

### Phase16.19.2 successful runtime used for Phase16.19.3 design

CSV: `KiwiFrameComparison_20260823_200554.csv`  
MP4: `..._DX11_ 2026-08-23 20-05-59.mp4`  
Rows/columns: 1815 × 247  
Authority: CORRECTNESS + VISUAL  
Result: authority and strict FacePart gates full PASS; visual landmark mismatch remained; inference/semantic age ~100 ms.

### Phase16.19.3 retest

CSV: `KiwiFrameComparison_20260823_202410.csv`  
MP4: `..._DX11_ 2026-08-23 20-24-15.mp4`  
Rows/columns: 1240 × 247  
Authority: CORRECTNESS + VISUAL  
Result: matched epoch active; residual left/right mirror proven with same timestamps.

### Phase16.19.4 final retest

CSV: `KiwiFrameComparison_20260823_203931.csv`  
MP4: `..._DX11_ 2026-08-23 20-39-36.mp4`  
Rows/columns: 1938 × 247  
Authority: CORRECTNESS + VISUAL; performance numbers are diagnostic unless separately benchmarked without observer overhead.  
Result: Root/provider authority non-regression; strict FacePart valid after startup semantic acquisition; mirror inversion removed; landmark alignment accepted.

Evidence file SHA256 values for the original uploaded CSV/MP4 are `NOT_AVAILABLE_IN_NORMAL_CHAT` at archive creation because those raw uploads are not currently present in the mounted archive-creation filesystem.

---

## CURRENT RESULT

At the end of this chat:

- Phase16.19.2 Supervisor strict FacePart writer defect: **RESOLVED / runtime validated**.
- Phase16.19.3 live-camera vs semantic-epoch diagnostic mismatch: **RESOLVED**.
- Phase16.19.4 canonical annotation double mirror: **RESOLVED / final runtime visually validated**.
- LandMarker X/Y scale/aspect/rotation correction: **NOT JUSTIFIED; do not add**.
- Fast-motion matched-debug freeze appearance: **OPEN**.
- High-speed tracking cadence drop and ~100 ms inference/service age: **OPEN, separate from debug UI freeze**.
- Mandatory commercial/SNS/OSS research before future implementation: **ADOPTED PROCESS RULE**.

Because later project-wide work exists after 2026-08-23, this report is a historical chat archive, not the current whole-project Production status.

---

## OPEN ISSUES

1. **Phase16.19.5 Live Camera / Matched Landmark Debug Separation**  
   Keep the ordinary live camera continuously current while retaining a separate same-epoch matched diagnostic view.

2. **Fast-motion tracking cadence drop**  
   Some intervals were observed around approximately 5–9 Hz. Must be investigated independently of the debug camera UI.

3. **~100 ms inference/service age**  
   Need stage-level evidence before changing 3-lane scheduling, readback policy, thresholds, or tracking math.

4. **Current local Production provenance for these historical generated fixes**  
   Not directly verified in this chat archive. Later project-wide authority should be used for current Production decisions.

---

## NEXT ACTION

Historical next action from this chat:

### Phase16.19.5 research-first design

Before implementation:

1. research Webcam Motion Capture and relevant commercial VTuber presentation/tracking separation using public evidence;
2. review VTube Studio / Warudo / Animaze / VSeeFace / VNyan public information where applicable;
3. review TikTok Effect House / Snap Lens Studio / Meta public face-filter principles;
4. inspect MediaPipeUnityPlugin v0.16.3 `Screen`, `ImageSource`, transformation, annotation, and Face Landmarker sample source;
5. inspect analogous OSS/GitHub live-preview + timestamp-matched diagnostic patterns;
6. compare against the actual current Kiwi Production source and Runtime before implementing.

Most likely design at the end of this chat:

- `LIVE CAMERA`: always latest current camera frame, not blocked on semantic transaction;
- `MATCHED LANDMARK DEBUG`: separate observer panel using semantic-matched immutable camera snapshot + canonical landmarks;
- no changes to tracking input, Root, ProviderHub, FacePart production transaction, or 3-lane inference as part of the display repair.

Important current-project note: as of 2026-09-02 later consolidated project state has advanced beyond this historical next action. Before executing Phase16.19.5 now, reconcile this archive against the newest Production/runtime authority rather than blindly resuming the old version number.

---

## DO NOT CHANGE

Until newer independent evidence requires it:

- Face Landmarker as primary/source of truth;
- `FaceLandmarkerRunner` for this observer-display issue;
- `KiwiFaceMotion` as a camera/display cadence workaround;
- `KiwiInferenceFaceTracker` as a camera/display cadence workaround;
- ProviderHub authority architecture;
- single Root/Head presentation ownership;
- commercial strict FacePart contract;
- production FacePart matched transaction;
- 3-lane inference merely because ~100 ms latency exists;
- tracking thresholds without runtime evidence;
- strong smoothing / Kalman as a root-cause mask;
- permanent one-frame presentation buffer;
- Phase16.19.3 same-epoch diagnostic capability;
- Phase16.19.4 mirror correction;
- arbitrary Landmark X/Y scale/offset/rotation compensation.

---

## PROJECT MASTER REPORT UPDATE CANDIDATES

This historical archive contributed the following durable decisions that should be preserved where still applicable:

- Observer correctness: never compare live pixels and delayed semantic landmarks as if they were the same frame.
- Canonical landmark annotation must not inherit raw-camera crop mirroring without proving coordinate equivalence.
- Fix observer/validator defects before changing Production tracking math.
- Keep live presentation and historical matched diagnostic views separate when they serve different purposes.
- External commercial/SNS/OSS research is mandatory before future design/fix/optimization decisions; public facts/principles/speculation must be separated.

Current project-wide master state must be sourced from the later 2026-09-02 authority/consolidated documents, not from this historical chat archive.

---

## HANDOFF

If this archive is read without the original chat:

1. Treat Phase16.19.2–16.19.4 as a sequence of observer/policy corrections, not a tracking-core rewrite.
2. The strict FacePart failure was caused by a late Supervisor writer and was fixed/validated.
3. The large moving LandMarker offset was initially a mixed-time observer artifact.
4. Once same-epoch preview was added, the residual left/right error was an overlay-only second mirror.
5. Final Phase16.19.4 runtime removed that inversion without changing FaceLandmarkerRunner, Root, ProviderHub, Inference tracker, or production FacePart geometry.
6. Do not add arbitrary landmark correction after that result.
7. Apparent fast-motion camera freeze was assigned to matched-debug snapshot hold; live source stoppage was not proven.
8. Historical next design was to split always-live camera display from same-epoch matched landmark diagnostics.
9. Before any new implementation, perform commercial VTuber / SNS filter / MediaPipe official / OSS source research and compare it against the **current** local Production + newest Runtime.
10. Because the project continued after this chat, reconcile this historical archive against the newest 2026-09-02 authority before applying old Phase numbers or generated files.

---

## CHAT ARCHIVE INDEX

Archive: `KiwiChat_Phase16_19_FacePartLandmarkDebug_Updated_20260823-2058-JST.zip`  
Topic: Phase16.19 FacePart strict epoch + matched landmark debug + mirror alignment + live/matched separation planning  
LastWorkUpdate: 2026-08-23 20:58 JST  
Status: PARTIALLY_DONE  
Supersedes: earlier incomplete Phase16.19.1/16.19.2 observer assumptions inside this chat  
SupersededBy: later project-wide Production/validation state after 2026-08-23; exact later chat archive not identified here  
NextArchiveCandidate: next major Runtime/Production decision after the later project-wide authority chain

---

## SOURCE / ARCHIVE PROVENANCE

Archive generation also consulted the user-provided project authority and archive-policy documents available on 2026-09-02:

- `KiwiAvatarSystem-情報源・Authority一覧.txt`
- `KiwiAvatarSystem-統合最新版カスタム指示-情報源-作業履歴-今後計画-更新基準-2026-09-02.txt`
- `通常チャット用-恒久REPORT・ZIP直接作成指示.txt`
- `Github-リポジトリ.txt`

These later documents are used only to prevent historical/current authority confusion and to follow archive policy; they do not retroactively change the runtime facts recorded from this chat.
