# KiwiAvatarSystem Chat Permanent Report

ChatTopic: Validation Reduction / Camera→MediaPipe→Canonical Simplification  
ChatTitle: R12 Validation Reduction without Quality Loss → P1/P1-2 → P2 Source-Grounded Simplification → P2 Reaudit  
ArchiveName: KiwiChat_ValidationReduction_CameraMediaPipeCanonicalSimplification_Updated_20260906-JST.zip  
LastWorkUpdate: 2026-09-06  
LastWorkUpdatePrecision: DATE_ONLY  
ArchiveCreated: 2026-09-06T19:05:39+09:00  
ArchiveTimestampBasis: LAST_RELEVANT_WORK_BEFORE_ARCHIVE_REQUEST  
Project: D:\KiwiAvatarSystem  
Unity: 6000.0.80f1 / Windows / DX12  
CurrentInvestigationVersion: R12 / P2 COMPLETE / P2 REAUDIT PASS_WITH_REQUIRED_CORRECTIONS  
Status: IN_PROGRESS  

---

## EXECUTIVE SUMMARY

このチャットでは、KiwiAvatarSystemの検証負担を減らしつつ完成品質を落とさないため、
従来の「candidateごとに大量のRuntime診断を追加する」進め方を見直し、
`VALIDATION_REDUCTION_WITHOUT_QUALITY_LOSS` をR12の中心原則として採用した。

R12では、完成時のQuality Gate
`Source Identity → Transaction → Model/Canonical Semantic → Authority → Lifecycle → Resource → Replay → Security → Clean Performance → Compatibility → Final Human Visual → Release`
は維持し、
開発途中の検証のみを
`Change-local Gate + Contract/Golden Replay Gate + Milestone Full Product Gate`
へ統合する。

この方針に沿ってP2
`Camera → MediaPipe → Canonical Source-Grounded Method/Dataflow Simplification Audit`
をCodexでREAD_ONLY実施した。

P2はCamera callbackからCanonicalまでをmethod/statement/dataflow単位で追跡し、
Native Path B、latest-frame、Runner pre-input freshness/latest、
MediaPipe internal FlowLimiter、callback内copy/lifetime、claim-scoped timestamp/epoch等は
現時点でKEEPが最善と判定した。

P2で確認された主な簡素化候補:
1. FaceLandmarkerRunner内の同一assignment 16連続 + ObserveFreshFrameSource 16連続。
   Runtime defectではなく低リスクなstatement-level MERGE candidate。
2. KiwiExpressionReactionのRunner direct expression入力とCanonical expression入力の二重authority。
   F1 static bypass confirmed。MERGE candidateだが採用前Runtime必要。
3. FacePart sampling rotationで
   KiwiFacePartRigidSampleFrameとKiwiFacePartSharedTiltLockが同時active。
   Static double-rotation pathが強く示され、SharedTiltLockが最有力RETIRE_CANDIDATE。
4. FacePartTextureTransactionはnative frame sequenceを持たず、
   Canonical submissionHostTicksとGPU capture hostTicksを55ms内nearest-time matchingしている。
   F2 exact native-sample identity gapはSource整理だけでは閉じない。
5. Sentis hybridは高cadence 468-landmark backend、persistent ROI、
   bounded GPU lanes、stale/generation rejection等の具体的役割を持つため
   Staticだけでretireしてはいけない。

P2再監査の最終判定:
`P2_STATUS=PASS_WITH_REQUIRED_CORRECTIONS`

P2主要結論は有効だが、F3を即Runtimeへ上げる前に、
R12のP3に相当する短いREAD_ONLY Ownership/Transaction Closureを行うべきと修正した。

理由:
- F3はdouble-rotation pathがStaticで強いが、angle sign / reference / pivot / aspect /
  coordinate-space / uv compositionの完全な数式閉鎖がまだ不足。
- R12はP2 Source Audit → P3 Ownership/Transaction Decision → P4 Validation Retirement →
  P5 Residual Runtimeの順であり、即F3 Runtimeは1段飛ばし。
- Sentisがhigh-cadence landmark publicationを担う一方、
  Face LandmarkerをPrimary/Source of Truthとする設計用語が曖昧で、
  P3でauthority contractを正式化する必要がある。

Production変更はこのチャットでは行っていない。
commit/pushも行っていない。

---

## OBJECTIVE

1. KiwiAvatarSystemの検証量を減らす。
2. ただし完成時のCorrectness / Lifecycle / Performance / Visual / Release品質を落とさない。
3. 検証を減らすためにSystem responsibility / owner / temporal state /
   transaction / diagnostic branch自体を減らす。
4. Camera→MediaPipe→Canonicalを公式Source、実使用Package Source、
   Local Production Source、既存Runtime Evidenceで比較する。
5. Sourceだけで閉じるclaimをRuntime化しない。
6. residual Runtime-only claimだけを後段で測る。
7. Working Coreを根拠なく再設計しない。

---

## CONFIRMED FACTS

### Project / Environment

Project:
`D:\KiwiAvatarSystem`

Unity:
`6000.0.80f1`

Platform:
Windows / DX12

MediaPipeUnityPlugin:
`0.16.3`

Installed MediaPipe lineage identified by P2:
`MediaPipe v0.10.22`

Inference Engine:
`2.4.1`

Camera:
UGREEN Camera 4K / 1920x1080@60 / Native NV12

Face Landmarker:
Primary / Source of Truthという製品設計原則を維持。

### P0 / P1 / P1-2

P0 Product Failure Triage:
COMPLETE。

P1-1:
1280x720でPixelSpaceAuditとOriginal LIVE CAMERA surfaceがoverlapし、
Visual claimはmeasurement-surface defectによりNOT_EVALUABLE。

P1-2:
exact frozen-v31 Playerでactual Win32 client=1706x901。
Original LIVE / Audit FULL / Audit 1:1は全て560x315でnon-overlap。

PixelSpaceAudit:
108/108 DIRECT_SAME_TEXTURE。
source = KiwiNativeCameraPresentation。
1920x1080。
Bilinear。
Linear。
observerBlit=0。
observerReadback=0。

Human:
ORIGINAL_LIVE_CAMERA_SYMPTOM=REPRODUCED
AUDIT_FULL_REPRESENTS_ORIGINAL=YES
PAIRED_HUMAN_DECISION=BOTH_BAD_SIMILAR

Current interpretation:
`DISPLAY_MINIFICATION_ONLY=REJECTED_OR_STRONGLY_WEAKENED`

未証明:
Native defect / PresentationTexture pixel defect / Bilinear defect /
OnGUI defect / F1/F2/F4 root cause / single common root cause。

### P2 Native / Camera

P2 Static auditでは現在のNative SourceはMicrosoft asynchronous SourceReader設計と概ね整合:
- async ReadSample
- callback OnReadSample
- callbackでQPC hostTicks/sequence取得
- IMFSampleをcallback後に保持せずKiwi-owned NV12 bufferへdetach
- CPU/GPU bounded latest slots
- stale/FIFO accumulation回避
- D3D12 blocking Waitなし
- fixed Unity-visible presentation identity
- lifecycle Stop時だけworker join/flush/release

Native C++ → installed DLLはClass-A reproducible provenance未閉鎖。
P2のNative method/dataflowはCLASS_B_STATICとして扱う。

### P2 Runner / MediaPipe

RunnerはMediaPipe/Sentisへ入れる前に:
- native sequence freshness
- one-slot pending latest
- camera generation
- one-in-flight
- optional downscale
を所有。

MediaPipe v0.10.22 LIVE_STREAM側は:
- Task submit後のFlowLimiter
- max_in_flight=1
- bounded queue
- detector / previous-rect tracking
- single-face landmark smoothing
- blendshape
- optional face geometry/transformation
を所有。

P2は
`Kiwi pre-input latest/freshness` と `MediaPipe FlowLimiter`
を同一責務とは認定しなかった。
drop boundaryと防止するbacklogが異なるため、現時点KEEP_BOTH。

MediaPipe callback result/list/imageはlifetime/reuse制約があるため、
Kiwiがcallback中に必要dataをcopyする設計はKEEP。

### P2 Timestamp / Transaction

保持するclaim-scoped tokens:
- native frame sequence
- native QPC hostTicks
- normalized managed hostTicks
- camera generation
- Runner fresh generation
- MediaPipe timestamp
- callback timestamp
- tracking frameId/session generation
- provider generation
- backend/anchor epoch
- Canonical frameId
- submissionHostTicks

これらは同じclaimではないため、1 tokenへの一括統合はREJECT。

F2:
FacePartTextureTransactionはnative frame sequenceを保持しない。
GPU capture hostTicksとCanonical submissionHostTicksのnearest match within 55ms。
generation equalityはあるが、exact native sample proofではない。

### P2 Sentis Hybrid

Staticで確認された具体的責務:
- high-cadence alternate 468-landmark backend
- persistent ROI lease
- three bounded GPUCompute lanes
- source/generation/anchor freshness rejection
- MediaPipe auxiliary expression/rotation/ROI refresh
- crop Blit / tensor conversion / output readback / decode
- second landmark publication authority surface

現時点:
`SENTIS_HYBRID_STATUS=NEEDS_RUNTIME_EVIDENCE_KEEP_CURRENTLY`

Staticだけでdelete/retireしない。

### P2 F1-F4

F1:
Runner direct expression input bypass confirmed。
MERGE candidate。
Runtime adoption evidence未取得。

F2:
exact native sample identity gap confirmed。
Runtime mismatch/causality unproven。

F3:
RigidSampleFrame + SharedTiltLock active path、
さらにshader sample rotation pathがStaticで確認。
double-rotation path HIGH confidence。
ただし完全な数式/coordinate-space closureは未完。

F4:
temporal plurality confirmed。
same-channel harmful duplicate ownershipはSourceだけでは未証明。

---

## PUBLIC DESIGN PRINCIPLES

### Microsoft Media Foundation

Async SourceReader:
- `ReadSample`はasync callback modeで即時return。
- `IMFSourceReaderCallback::OnReadSample`でsample completion。
- callbackはthread-safeである必要。
- sample timestampは100ns unit。
- applicationが次のReadSampleを要求する。

Kiwi Nativeのnonblocking / bounded / explicit identity / sample detach設計と整合する。

### MediaPipe Face Landmarker

LIVE_STREAM:
- async result callback
- input image + normalized rectへ同一timestamp
- internal FlowLimiter
- detector/tracker/landmark pipeline
- single-face smoothing
- blendshape
- facial transformation matrix

重要:
MediaPipeにFlowLimiterが存在することだけで、
Kiwi pre-input latest gateを削除してはいけない。
pre-submit backlog suppressionとpost-submit graph limitingは別責務になり得る。

### MediaPipeUnityPlugin

実使用0.16.3 Package SourceをWeb masterより優先。
callbackはUnity main thread外。
DetectAsyncはgraph completionまでblockしない。
callback result/list/imageのlifetime/reuse制約を尊重する。

### Research / YouTube

Face Mesh / BlazeFace / Attention Mesh等は
compact model-centric real-time pipelineの設計原則抽出に使用。

Official research/video > technical tutorial > anecdotal video。

YouTubeのFPS/見た目だけをRuntime/Performance/Visual Authorityにしない。

---

## INFERENCES / HYPOTHESES

1. F3は現時点のresidual claimsの中で最もStatic evidence densityが高い。
2. SharedTiltLock retirementは検証surface削減に寄与する可能性が高い。
3. ただし同じsampling rotationを「同方向へ二重適用」と完全確定するには
   angle/sign/pivot/aspect/coordinate-spaceのactual equation closureが必要。
4. Expression input ownerをCanonicalへ統一できればF1とvalidator surfaceを減らせる可能性がある。
5. Sentis hybridが本当にProduct品質へ必要かはStaticだけでは判断不能。
6. Face Landmarker Source of TruthとSentis high-cadence publication authorityは、
   conceptual Primary / semantic Primary / publication Primaryを分離して定義した方がよい可能性がある。
7. F2はidentity fieldを単純merge/renameするだけでは閉じない。

---

## PRODUCTION AUTHORITY

優先順位:
1. current local Production source + SHA
2. same-build Runtime
3. actual installed Package Source
4. current Codex Consolidated REPORT
5. official docs/source
6. Git/local history
7. GitHub main
8. old diagnostics
9. external articles/videos

この通常チャットでは:
`NORMAL_CHAT_LIVE_LOCAL_PRODUCTION_NOT_DIRECTLY_VERIFIED`

Codex P2 reportのlocal snapshot:
`CODEX_CURRENT_LOCAL_SNAPSHOT_VERIFIED_AT_REPORT_TIME`

P2 Git HEAD:
`27281c622d7b8bf2ececf711b037fc8f9e029004`

Workspace:
DIRTY_USER_OWNED。
reset / checkout / clean禁止。

---

## WORK PERFORMED

### 1. P1 instruction re-audit

Original symptom surfaceとAudit FULLを直接同一視しないよう
Human gateとobserver-surface bridge gateを追加。

結果:
measurement designをfail-closed化。

### 2. P1-1 Runtime

1280x720。
Original LIVE surfaceとPixelSpaceAuditがoverlap。

Result:
Visual claim NOT_EVALUABLE。
Production NO_CHANGE。

### 3. P1-2 Runtime

actual client geometryをWin32 GetClientRectで測定。
1706x901で3 surface独立。

Human result:
BOTH_BAD_SIMILAR。

Result:
display-minification-only hypothesis REJECTED_OR_STRONGLY_WEAKENED。

### 4. Validation Reduction policy

ユーザー要望:
検証が多く大変なので減らしたいが、完成品質低下は避けたい。

採用:
VALIDATION_REDUCTION_WITHOUT_QUALITY_LOSS。

### 5. R12 integrated roadmap

Critical Pathを:
Source-Grounded Simplification
→ Ownership/Transaction decision
→ Validation retirement
→ residual Runtime only
→ minimal fix
→ contract
→ Golden
へ変更。

### 6. External Camera / MediaPipe research

Microsoft / MediaPipe / MediaPipeUnityPlugin /
research papers / official videosを比較。

重点:
latest-frame
timestamp
FlowLimiter
async callback
model responsibilities
image conversion
lifecycle
expression/head semantics。

### 7. P2 Codex READ_ONLY audit

Camera callback→Canonicalまでmethod/statement/dataflowを監査。

Result:
P2 COMPLETE_WITH_EXPLICIT_UNKNOWNS。

### 8. P2 normal-chat re-audit

Final:
`PASS_WITH_REQUIRED_CORRECTIONS`

Correction:
即F3 Runtimeへ進まず、
P3 READ_ONLY Ownership/Transaction Closureを挟む。

---

## VALIDATED DECISIONS

### Decision: Validation Reduction without Quality Loss

Reason:
検証項目を単純削除するのではなく、
Production責務を減らし、Contract Gateへ集約する方が
検証量・observer contamination・maintenance surfaceを同時に減らせる。

Evidence:
P1/P1-2、R12、P2 Source audit。

Regression constraints:
完成時のCorrectness / Lifecycle / Resource / Performance / Visual /
Security / Release Gateは維持。

Still current:
YES。

### Decision: Native Path B KEEP

Reason:
current source/public design comparisonでwide redesignを支持するEvidenceなし。

Still current:
YES_PENDING_NEW_EVIDENCE。

### Decision: Kiwi pre-input latest + MediaPipe FlowLimiter KEEP BOTH

Reason:
boundary / prevented backlog / resource ownershipが異なる。

Still current:
YES。

### Decision: Claim-scoped timestamp/epoch KEEP

Reason:
reset scopeとauthority claimが異なる。
1 token統合はF2を隠すだけになる。

Still current:
YES。

### Decision: Sentis hybrid KEEP_CURRENTLY

Reason:
具体的なProduct責務をStaticで確認。
品質/latency benefitまたはremoval safetyは未測定。

Still current:
YES_UNTIL_RUNTIME_EVIDENCE。

### Decision: F3 strongest retirement candidate

Reason:
same sampling-rotation areaに複数current ownersがStaticで確認された。

Still current:
YES_CANDIDATE_ONLY。

### Decision: Next Runtime NOT YET

Reason:
F3 exact mathematical equivalence/authority closureと
Face Landmarker/Sentis authority terminologyをP3 Staticで先に閉じられる。

Still current:
YES。

---

## REJECTED APPROACHES

Rejected:
MediaPipe FlowLimiterがあるのでKiwi latest gateを削除。

Why rejected:
pre-inputとpost-submitでboundaryが異なる。

Revisit:
actual duplicate boundary evidenceが出た場合のみ。

---

Rejected:
timestamp/epochを1 tokenへ統合。

Why rejected:
claim/reset scopeが異なる。

Revisit:
individual token responsibilityが退役した場合のみ。

---

Rejected:
nearest hostTicksをexact sample identityと扱う。

Why rejected:
native sequenceがCanonical/FacePart transactionへ運ばれていない。

---

Rejected:
SentisをStatic比較だけで削除。

Why rejected:
high-cadence backend/ROI/fallback等の具体的責務あり。

---

Rejected:
F1/F2/F3/F4を全部順番にRuntime検証。

Why rejected:
R12 Validation Reduction方針と矛盾。
Sourceで閉じた後にresidual Runtime claimのみ測る。

---

Rejected:
P2後すぐF3 Runtime。

Why rejected:
F3 equation closureとP3 ownership decisionを先に行えるため。

---

Rejected:
Fence / Wait / queue flush / async-disable / FIFO /
strong smoothing / Kalman / stale prediction / threshold relaxation。

Why rejected:
exact defect boundary Evidenceなし。
既存principles違反。

---

Rejected:
Big-Bang rewrite / external tracker Primary replacement。

Why rejected:
Working Coreの回帰/authority/lifecycle riskが高い。

---

## SUPERSEDED CONCLUSIONS

OLD:
Execution Context-first / E2-first。

NEW:
Source-Grounded Product responsibility simplification first。

WHY:
E2→Product Visual causality未成立。
Product broad failureとvalidation complexityが確認された。

---

OLD:
F2-first。

NEW:
F1/F2/F3/F4をSource evidenceでrerankし、
residual Runtimeだけ測る。

---

OLD:
candidateを順番に全部Runtime。

NEW:
Change-local + Contract/Golden + Milestone Full Product。

---

OLD:
P2 next action = immediate F3 Runtime experiment。

NEW:
P3 READ_ONLY Ownership/Transaction Simplification Closure。

WHY:
F3 exact equationとSentis/FaceLandmarker authority contractがSourceでさらに閉じられる。

---

## OBSERVER / VALIDATOR FINDINGS

1. P1-1:
1280x720 PixelSpaceAudit layoutがOriginal LIVEをoverlap。
Measurement-surface defect。
Production defectではない。

2. P1/P1-2:
PixelSpaceAudit自体はsame Texture identity / no observer Blit/readbackで有効。

3. Historical v31:
minimumPresenceBits identity failureの一部は
JSON decimal vs CSV X8 raw-string comparisonというValidator representation defect。

4. P2:
最新R12 integrated fileがlocal KiwiValidationに存在せず、
P2はcurrent local source + R11/P1/P1-2で監査。
P2主要結論はlocal/package source直接監査に基づくためinvalidにはしない。
今後local integrated informationへP2結果を反映すべき。

5. Performance:
observer-heavy RuntimeをPerformance Authorityにしない。

---

## FILES / SHA256

### Current integrated R12 artifact used in this chat

File:
KiwiAvatarSystem_最新統合情報_ValidationReduction_R12_0906_1525.txt

SHA256:
4356964F2341BFF059BE443BDB83FE6D3B95E0BC74B1005BFEE5A8631B64D0AB

Role:
Current roadmap / integrated information generated in normal chat.

Local Production placement:
NOT_DIRECTLY_VERIFIED_IN_NORMAL_CHAT。

### P0 report

File:
KiwiCodexConsolidatedReport_ProductFailureSpecification_SymptomBoundaryTriage_20260906_093659.txt

SHA256:
B26A5A1262FCFDF55FB0C9579507D005860FE5B216FA7D4908A8B35D48C98633

### P1 report

File:
KiwiCodexConsolidatedReport_P1_LiveCameraPixelSpace_20260906_132556.txt

SHA256:
E8673B5204D5DAD97821964D8733B9E3DC5B0383C81EBBC208A29DA18BAE04D9

### P1 Runtime ZIP

File:
KiwiRuntimeEvidence_P1_LiveCameraPixelSpace_20260906_132556.zip

SHA256:
449D778BB7ADF345961BF6373F948A6B9E9918CB1E1D968B016D8724D4E7035F

### P1-2 report

File:
KiwiCodexConsolidatedReport_P1_2_ExactFrozenV31VisualLocalization_20260906_144303.txt

SHA256:
94053AFD0CF1162FD10BCE96D290F3D8300512546EEA979163E9A4F1128FC4FD

### P1-2 Runtime ZIP

File:
KiwiRuntimeEvidence_P1_2_ExactFrozenV31VisualLocalization_20260906_144303.zip

SHA256:
55A0BCE2D4A16F21E6E6770D1B920C596306E9E93901BE281DADF865DEE24092

### P2 report

File:
KiwiCodexConsolidatedReport_P2_CameraMediaPipeCanonicalSimplification_20260906_184245.txt

SHA256:
E4A66A7217E27929EAD51B6AEE4125E3B563E9CD44A06B8BFEB1B09DAC10D6AB

Role:
Latest Codex local/package Source audit in this chat.

---

## RUNTIME EVIDENCE

### P1-1

Authority:
CORRECTNESS / STATIC+RUNTIME / NOT VISUAL CAUSAL

Result:
observer activation/identity valid。
Visual surface independent gate failed。

Performance:
NONE。

### P1-2

Authority:
CORRECTNESS + VISUAL + PROVENANCE。
Performance Authorityなし。

Result:
same PresentationTexture。
FULL vs 1:1 BOTH_BAD_SIMILAR。
display-minification-only rejected/strongly weakened。

### P2

Runtime:
NO。

Authority:
STATIC / PACKAGE SOURCE / EXTERNAL OFFICIAL comparison。

Result:
Camera→Canonical Source responsibilities mapped。
Residual Runtime Claims=5 in Codex report、
ただし normal-chat reauditではF3 Runtime前にP3 Static closureを追加。

---

## CURRENT RESULT

P2:
VALID / COMPLETE as Source audit。

P2 Reaudit:
PASS_WITH_REQUIRED_CORRECTIONS。

Current Production Decision:
NO_CHANGE。

Current Runtime Decision:
NOT_YET。

Validation Reduction:
FEASIBLE=YES。

Critical-path diagnostics:
v20 / v24 / v25 / v27 / v31 / E2 / P1
→ FROZEN_HISTORICAL or ON_DEMAND candidate。

Face Landmarker:
Primary / Source of Truth principle retained,
but Sentis publication authority terminology requires P3 clarification。

F1:
STATIC_BYPASS_CONFIRMED / MERGE_CANDIDATE / RUNTIME_BEFORE_ADOPTION。

F2:
EXACT_NATIVE_SAMPLE_IDENTITY_GAP_CONFIRMED /
RUNTIME_CAUSALITY_UNPROVEN。

F3:
STATIC_DOUBLE_ROTATION_PATH_CONFIRMED /
DUPLICATE_OWNER_HIGH_CONFIDENCE /
EXACT_MATHEMATICAL_EQUIVALENCE_NOT_CLOSED /
RETIRE_CANDIDATE_NOT_AUTHORIZED_YET。

F4:
TEMPORAL_PLURALITY_CONFIRMED /
HARMFUL_DUPLICATE_OWNER_UNPROVEN。

Sentis:
KEEP_CURRENTLY / NEEDS_RUNTIME_EVIDENCE。

Runner duplicate statements:
STATIC_MERGE_CANDIDATE / DEFER。

---

## OPEN ISSUES

1. F3 actual angle/sign/reference/pivot/aspect/coordinate-space equation closure。
2. RigidSampleFrame output UVとshader GetSampleUVのexact composition。
3. Face Landmarker Primary/Source of TruthとSentis high-cadence publication authorityのformal contract。
4. F1 canonical-only expression adoption equivalence。
5. F2 exact native sample identity / symptom causality。
6. F4 actual harmful same-channel temporal overlap。
7. Sentis hybrid necessity / FaceLandmarker-only Product quality。
8. CPUAsync image-preparation clean performance。
9. Native source→installed DLL Class-A reproducible provenance。
10. clean Production performance。
11. current post-simplification same-build Full Product Visual。
12. R12/P2 current integrated informationのlocal KiwiValidation反映。

---

## NEXT ACTION

### P3 READ-ONLY Ownership / Transaction Simplification Closure

Production change:
NO。

Runtime:
NO。

Build:
NO。

主対象3点:

1. F3 mathematical closure
   - RigidSampleFrame angle/sign/pivot/aspect
   - SharedTiltLock angle/sign/pivot/aspect
   - SurfaceFittedRawImage uv0/uv1
   - FacePartSoftMask GetSampleUV
   - actual composition
   - same claim / inverse compensation / distinct spaceを決定

2. Face Landmarker / Sentis Authority contract
   - detection authority
   - semantic calibration authority
   - high-cadence landmark publication authority
   - Canonical final authority
   - Primary / Source of Truthという用語を実装に一致させる

3. Validation retirement finalization
   - CORE_GATE
   - ON_DEMAND_DIAGNOSTIC
   - FROZEN_HISTORICAL
   - RETIRE_WITH_IMPLEMENTATION

P3完了後のみresidual Runtimeを1つ選ぶ。

現時点最有力:
F3 single sampling-rotation owner change-local experiment。

ただしP3 Static closureで同一claim double applicationが確定した場合のみ。

---

## DO NOT CHANGE

新Evidenceまで:

- Face Landmarker Primary principle
- Native Path B
- latest-frame / bounded/nonblocking
- Kiwi pre-input fresh/latest
- MediaPipe internal FlowLimiter
- fixed Unity-visible PresentationTexture identity
- 560x315 / 16:9 / Bilinear
- Root/Head/Eye/Mouth authority separation
- Provider normalization owner=1
- Resume != Provider Switch
- same-sample transaction requirement
- current Sentis hybrid
- KiwiFaceMotion / KiwiInferenceFaceTrackerをcamera workaroundに使わない
- tracking mathでcamera/inference/presentation問題を隠さない
- strong smoothing / Kalman
- stale prediction
- FIFO/permanent delay
- threshold relaxation
- Fence / Wait / queue flush / async-disable
- external tracker Primary replacement
- Big-Bang rewrite

commit/push:
明示指示時のみ。

---

## PROJECT MASTER REPORT UPDATE CANDIDATES

Archive:
KiwiChat_ValidationReduction_CameraMediaPipeCanonicalSimplification_Updated_20260906-JST.zip

Topic:
Validation Reduction / Camera→MediaPipe→Canonical Simplification

LastWorkUpdate:
2026-09-06

Status:
IN_PROGRESS

Validated Decision:
R12 Validation Reduction without Quality Loss。

Validated Decision:
P2 Source-Grounded Simplification audit accepted with corrections。

Rejected:
Immediate F3 Runtime before P3 Static closure。

Superseded:
candidate-by-candidate full Runtime workflow。

Open Issue:
F3 mathematical closure / Sentis-FaceLandmarker authority contract。

Next Action:
P3 READ_ONLY Ownership / Transaction Simplification Closure。

---

## CHAT ARCHIVE INDEX

Archive:
KiwiChat_ValidationReduction_CameraMediaPipeCanonicalSimplification_Updated_20260906-JST.zip

Topic:
ValidationReduction_CameraMediaPipeCanonicalSimplification

LastWorkUpdate:
2026-09-06

Status:
IN_PROGRESS

Supersedes:
Earlier R11 Product-correctness-first planning as current workflow where inconsistent with R12.

SupersededBy:
NONE_AT_ARCHIVE_TIME

NextArchiveCandidate:
P3_OwnershipTransactionSimplificationClosure

---

## HANDOFF

次チャットは以下をCurrentとして開始する。

1. R12 `VALIDATION_REDUCTION_WITHOUT_QUALITY_LOSS` が現ロードマップ。
2. P0/P1/P1-2は完了。
3. P1-2でdisplay minification-onlyはREJECTED/STRONGLY_WEAKENED。
4. P2 Source auditはCOMPLETE。
5. P2主要KEEP:
   Native Path B / camera latest / Runner pre-input latest/fresh /
   MediaPipe FlowLimiter / callback copy/lifetime / claim-scoped timestamp。
6. P2簡素化候補:
   Runner duplicate statements、
   F1 expression input authority、
   F3 SharedTiltLock retirement。
7. F2 exact native sample identity gapは残る。
8. SentisはStaticでretireしない。
9. P2再監査により、次Runtimeはまだ実施しない。
10. 次はP3 READ_ONLY:
    F3 actual math + Sentis/FaceLandmarker authority + validation retirement closure。
11. P3後にresidual Runtimeを1つだけ選ぶ。
12. Production NO_CHANGE。
13. commit/push NO。
14. `NORMAL_CHAT_LIVE_LOCAL_PRODUCTION_NOT_DIRECTLY_VERIFIED` を維持。

END_OF_REPORT
