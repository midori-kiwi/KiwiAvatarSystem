# KiwiAvatarSystem Chat Permanent Report

ChatTopic: FacePartControlCoordinateAudit  
ChatTitle: CONTROL Human Visual → MediaPipe-only causal isolation → FacePart coordinate-contract audit  
ArchiveName: KiwiChat_FacePartControlCoordinateAudit_Updated_20260907-JST.zip  
LastWorkUpdate: 2026-09-07  
LastWorkUpdatePrecision: DATE_ONLY  
ArchiveCreated: 2026-09-09 01:20 JST  
ArchiveTimestampBasis: LAST_RELEVANT_WORK_BEFORE_ARCHIVE_REQUEST  
Project: D:\KiwiAvatarSystem  
Unity: 6000.0.80f1  
CurrentInvestigationVersion: FacePart Coordinate Contract / MediaPipe-only Causal Isolation; later superseded as current critical path by Integrated Roadmap R13.4  
Status: SUPERSEDED  

---

## EXECUTIVE SUMMARY

This chat localized a broad FacePart/rigid-motion failure without redesigning the working camera/tracking core.

The key progression was:

1. Reuse the existing current CONTROL build without rebuilding.
2. Human Visual showed the current CONTROL baseline was not visually normal:
   - face detection/tracking was not normal,
   - crop/mask was displaced/broken,
   - frontal stillness showed Head/Root jump or freeze,
   - LIVE CAMERA itself remained visually continuous/normal.
3. Existing CONTROL telemetry that had reported coherent Canonical/Transaction/Crop/Mask state was therefore demoted to a narrower claim: it proved structural/value validity in measured fields, not final spatial visual correctness.
4. Existing trace re-analysis concentrated large rigid geometry jumps in the InferenceEngine provider path.
5. A one-factor MediaPipe-only isolation run removed InferenceEngine from Runner/ProviderHub/Canonical:
   - jump/freeze improved,
   - crop/mask remained failed.
   Therefore InferenceEngine availability was supported as a motion-domain contributor, but rejected as the single cause of the whole failure.
6. A Static-first coordinate audit then proved a deterministic FacePart X-coordinate contradiction:
   - MediaPipe/Runner/Canonical semantic point: `(x, y)`
   - expected Unity presentation texture point: `(x, 1-y)`
   - current FacePartCropper with scene `mirrorX=1`: `(1-x, 1-y)`
   - current scene also had `swapEyes=1`.
   This established the first crop/mask boundary defect at Canonical → Cropper mapping.
7. The best minimal design at this chat's endpoint was:
   - `mirrorX=0`
   - `swapEyes=0`
   - no Tracking Core / Native / Inference math rewrite,
   - one MediaPipe-only same-domain validation run after the scene-only correction.

Later project state has advanced beyond this chat. Integrated Roadmap R13.4 records the scene coordinate contract as `mirrorX=0 / swapEyes=0` at the H1 report-time freeze, and the current critical path has moved to the IE → installed MediaPipe normalized-landmark geometry contract. Therefore this archive preserves the evidence and decisions from this chat, but its old Next Action must not be treated as the current project Next Action.

---

## OBJECTIVE

Primary objectives in this chat:

- Reuse the exact existing current CONTROL build for Human Visual without rebuilding.
- Determine whether CONTROL was a trustworthy visual baseline.
- Separate motion jump/freeze from FacePart crop/mask failure.
- Test whether InferenceEngine availability was a causal contributor.
- Localize the persistent crop/mask failure to the earliest defensible boundary.
- Minimize validation count in accordance with the project's Validation Reduction without Quality Loss policy.
- Avoid speculative changes to Native, Tracking Core, SharedTiltLock, QualityGuard, smoothing, thresholds, prediction, or provider priorities.

---

## CONFIRMED FACTS

### A. Existing CONTROL Human Visual

User Human Visual result from the reused CONTROL build:

- Face detection/tracking: not normal.
- Single-eye behavior could not be evaluated normally because basic detection/tracking was already abnormal.
- crop/mask: displaced/broken.
- frontal stillness: Head/Root jump or freeze observed.
- LIVE CAMERA: visually continuous/normal.
- Player exit code: 0.

This superseded any interpretation that the CONTROL build was a visually normal baseline.

### B. CONTROL static/runtime evidence before Human Visual

Codex report:
`KiwiCodexConsolidatedReport_ControlBaselineFailureLocalization_20260907_0106.txt`

Local uploaded-file SHA256:
`3C1E237A47A548F06A091AA6E7E8C277C89CBE5781B0116D4DCB47D6019C6303`

Runtime evidence ZIP:
`KiwiRuntimeEvidence_ControlBaselineFailureLocalization_20260907_0106.zip`

ZIP SHA256:
`06CBF19501FE8301D5A7639E093BB05C939F4CBCBD841E8FA6A967EC098D38DA`

Report-time CONTROL authority included:
- branch `work/raw-direct-motion`
- HEAD `38ad8d23d14a3795f47b100a1003fc506dbfa003`
- Unity `6000.0.80f1`
- enabled scene `Assets/Scenes/Face Landmark Detection.unity`
- Development DX12 build / Full Preflight PASS
- 4096 trace samples / 3123 measurement-ready samples
- transaction miss=0 / hold=0 / external texture writer=0 in the reported ready subset
- UV/sampleRect/mask/pose fields structurally valid in the measured ready subset.

Important scope correction made in this chat:
these fields did not prove that the sampled crop/mask corresponded spatially to the correct eye/mouth pixels.

### C. MediaPipe-only causal isolation

Codex report:
`KiwiCodexConsolidatedReport_MediaPipeOnlyCausalIsolation_20260907_0754.txt`

Local uploaded-file SHA256:
`CB1067B5E4D5CCA1D32E0254D19DF8C3A99B8A02730665E77C8751A2588FBF6E`

One armed Runtime run established:
- Runner MediaPipe frames > 0
- Runner InferenceEngine frames = 0
- ProviderHub MediaPipe frames > 0
- ProviderHub InferenceEngine frames = 0
- Canonical MediaPipe frames > 0
- Canonical InferenceEngine frames = 0
- configuration violations = 0
- normal application quit.

Human Visual:
- jump/freeze = IMPROVED
- crop/mask = UNCHANGED_FROM_CONTROL_FAIL
- exact Head vs Root attribution = UNKNOWN.

Decision:
- `INFERENCE_ENGINE_CAUSAL_CONTRIBUTOR=PARTIAL`
- motion jump/freeze contribution = SUPPORTED
- InferenceEngine as the whole visual failure's single cause = REJECTED
- InferenceEngine as crop/mask's single cause = REJECTED
- permanent MediaPipe-only Production adoption = REJECTED / NOT AUTHORIZED.

### D. FacePart coordinate-contract audit

Codex report:
`KiwiCodexConsolidatedReport_FacePartCoordinateContract_20260907_1730.txt`

Local uploaded-file SHA256:
`59BD4E52233D2869B96DDA57924B4B8F09B3D01D15AC5208205AF117A6A5F950`

Report-time frozen current local:
- branch `work/raw-direct-motion`
- HEAD `310c6ce785369b55d498fd241bcd68c678027490`
- status clean
- Unity `6000.0.80f1`
- scene SHA256 `E28B0B81F731B92B04B97D4AA7DB1187C8DD57C5A39F49B08B2E6799BBF5B3D1`

Protected/source identities reported:
- FaceLandmarkerRunner.cs  
  `6C65C075270F10C791F6B044E3BC04C6024AADF916D65283F0EEFFA3448BBB93`
- KiwiCanonicalTrackingFrame.cs  
  `458FF33E98E054B766F20EB17CE6BDD242C9AD9FD6E73AF53D60BD3961822AFA`
- KiwiTrackingProviderHub.cs  
  `A5C7DE387FA2E02862BCF64942363AECFB9C7830B52DF5B8953404DF884ECCB1`
- FacePartCropper.cs  
  `39C06FEC43B4EA47AD783C233991E830E10B18DA285148E7A34B0C13DAD52CFE`
- KiwiFacePartTextureTransaction.cs  
  `DC78488DCD1D2E45E5AA6F40065D4983087014B501B5FD5A8E37B6D8E0F68849`
- FacePartShapeMask.cs  
  `822D18059988F390F52C40F60DA5F11E8ECF7577008D640272C5CF8D1557D4A6`
- KiwiNativeCamera.dll  
  `82D1FC2910468056C02E8BAE1C72996D8492173A84BEBBCAE322EBEF435678A5`

Static coordinate proof:
- MediaPipe semantic space: full-image normalized X right / Y down.
- Runner semantic store: pass-through `(x,y)`.
- Canonical semantic: pass-through `(x,y)`.
- Current unmirrored Unity texture expected point: `(x,1-y)`.
- Cropper with scene `mirrorX=1`: `(1-x,1-y)`.
- X parity = deterministic FAIL except at `x=0.5`.
- Y parity = PASS exactly once.
- left eye / right eye / mouth parity = `FAIL_X_PASS_Y`.

Scene state at this audit:
- `mirrorX=1`
- `swapEyes=1`

Static decisions:
- `CROPPER_MIRROR_REQUIRED=NO`
- `CROPPER_Y_INVERSION_REQUIRED=YES`
- `SWAP_EYES_REQUIRED=NO_FOR_CURRENT_UNMIRRORED_ANATOMICAL_OUTPUT_BINDING`
- first crop/mask target boundary = `CANONICAL_TO_CROPPER_COORDINATE_MAPPING`
- ShapeMask = `DEPENDENT_LOCAL_MATCHER`, secondary to the already incorrect crop UV.
- F2 exact native sample identity remained unproven.

---

## PUBLIC DESIGN PRINCIPLES

These are design principles, not local Production facts.

- MediaPipe normalized landmarks represent image-normalized coordinates; Kiwi must transform them into Unity texture UV exactly once.
- A presentation texture copy must not silently be assumed to fix an unrelated X-coordinate reflection.
- A valid UV rectangle, mask-point count, or transaction timestamp does not prove spatial correctness.
- Same-sample identity and coordinate-space identity are separate contracts.
- A downstream mask matcher can locally fit to an already wrong crop, so local mask coherence does not prove the crop sampled the correct physical feature.
- Latest-frame / bounded / nonblocking / no-FIFO principles remain protected.
- Working Native camera behavior must not be modified to compensate for FacePart mapping defects.
- Tracking math must not hide camera, transaction, crop, mask, or presentation faults.
- Human Visual can invalidate an overly broad interpretation of observer PASS, but Visual alone does not authorize unrelated Tracking Core changes.

---

## INFERENCES / HYPOTHESES

### Supported inference

InferenceEngine availability was a likely causal contributor to motion jump/freeze because:
- prior trace re-analysis concentrated large rigid geometry jumps in InferenceEngine frames,
- MediaPipe-only isolation removed InferenceEngine from Runner/Hub/Canonical,
- Human Visual jump/freeze improved.

Exact sub-boundary remained unresolved in this chat:
- raw Inference output semantics,
- Runner transformation,
- ProviderHub handoff/transition,
- or another Inference-specific stage.

### Static causal interpretation

The extra Cropper X reflection was sufficient to explain why crop/mask could remain wrong under MediaPipe-only operation.

However:
- `STATIC_FIRST_BOUNDARY_DEFECT_PROVEN=YES`
- `FULL_VISUAL_ROOT_CAUSE=NOT_YET_PROVEN`

The chat intentionally did not claim that every remaining FacePart visual problem would disappear after the scene flag correction.

### Secondary ShapeMask hypothesis

Static source showed:
- independent eye-set / mirror / flip selection,
- startup latch risk,
- mouth orientation latch,
- an `automaticEyeMatching` serialized field with no effective read in the audited file.

These were retained as secondary candidates only.
They were not promoted ahead of the proven Cropper coordinate contradiction.

---

## PRODUCTION AUTHORITY

Claim-scoped order used in this chat:

1. Codex-frozen current local source + SHA.
2. Same-build/same-domain Runtime where available.
3. Actual installed MediaPipe/package source.
4. Current Consolidated REPORT.
5. Official source/API contracts.
6. GitHub remote only as supporting/history evidence.

Normal chat limitation:
`NORMAL_CHAT_LIVE_LOCAL_PRODUCTION_NOT_DIRECTLY_VERIFIED`

No SHA was invented.

Important claim-scoped carry-over:
the MediaPipe-only Runtime and later coordinate Static audit used different HEAD values, but the coordinate-relevant source/scene identities reported across those snapshots were substantially stable for the claim being carried forward. This allowed supporting Runtime reuse without calling the builds identical.

---

## WORK PERFORMED

### 1. Existing CONTROL launcher correction

Problem:
the first launcher assumed exactly one `.exe` in the Unity build directory.

Observed:
two `.exe` files existed.

Finding:
Unity build directories may contain the Player executable plus helper executables such as crash handler binaries.

Correction:
Player selection was changed to identify the `.exe` paired with `<PlayerName>_Data`.

Impact:
this was a launcher cardinality defect, not a Kiwi Runtime/Product defect.

### 2. Existing-build identity verification

The launcher was expanded to:
- reuse the existing CONTROL build,
- avoid rebuild,
- verify `Assembly-CSharp.dll`,
- verify full payload manifest,
- distinguish Player EXE from helper EXEs,
- clear diagnostic/F3 arm environment variables,
- run Human Visual only.

A later execution showed the command sequence continued under Windows PowerShell 5.1 even after a PS7 guard failure when pasted line-by-line.

Classification:
tooling/execution-authority issue; not a Product Runtime defect.

### 3. CONTROL Human Visual

Result:
FAIL.

Key evidence:
LIVE CAMERA was normal while detection/tracking, crop/mask, and stillness behavior were not.

Impact:
invalidated any broad conclusion that CONTROL was visually normal merely because structural observer gates passed.

### 4. Existing trace re-analysis

No new broad observer was immediately added.

Existing trace was reinterpreted:
- internal validity did not prove spatial correctness,
- large rigid geometry jumps were strongly concentrated in InferenceEngine-provider samples.

Impact:
justified a one-factor MediaPipe-only isolation instead of broad Tracking Core changes.

### 5. MediaPipe-only one-factor isolation

Result:
- motion jump/freeze improved,
- crop/mask unchanged.

Impact:
split the failure into at least two domains:
- Inference-related motion contributor,
- common MediaPipe/Canonical/FacePart crop/mask issue.

### 6. Static semantic-to-texture coordinate audit

Result:
deterministic extra X reflection proven in the current FacePartCropper scene contract.

Impact:
allowed the first crop/mask boundary to be selected without another broad Runtime trace.

### 7. Re-audits of the minimal-fix plan

The fix plan was tightened to:
- treat `mirrorX=0 + swapEyes=0` as one coherent current-scene coordinate-contract correction,
- avoid modifying code, Native, provider priorities, temporal layers, QualityGuard, SharedTiltLock, or thresholds,
- validate in the same MediaPipe-only provider domain to avoid mixing the Inference motion defect into crop/mask validation.

---

## VALIDATED DECISIONS

### Decision: current CONTROL is not a valid normal Human Visual baseline

Reason:
Human review showed tracking, crop/mask, and stillness failures despite LIVE CAMERA continuity.

Evidence:
same-build Human Visual + Player exit 0.

Regression constraints:
do not use validator/log PASS to overwrite Human Visual failure.

Still current:
historically valid for this chat; later project work moved beyond this exact baseline.

### Decision: InferenceEngine is a partial motion-domain contributor, not the whole-failure root

Reason:
MediaPipe-only provider gate passed and jump/freeze improved while crop/mask did not.

Evidence:
MediaPipe-only causal-isolation report + Human Visual.

Regression constraints:
do not permanently disable Inference or force MediaPipe-only Production.

Still current:
retained conceptually; R13.4 continues to treat high-rate IE geometry as an active critical path rather than retiring it.

### Decision: Canonical → Cropper X mapping was the first proven crop/mask boundary defect

Reason:
source-level coordinate parity contradiction.

Evidence:
FacePartCoordinateContract report.

Regression constraints:
do not compensate by changing Native, Tracking Core, smoothing, prediction, or ShapeMask first.

Still current:
the scene contract was later recorded as `mirrorX=0 / swapEyes=0`, so the old broken scene state is superseded.

### Decision: ShapeMask is secondary until Cropper coordinate parity is correct

Reason:
ShapeMask fits its orientation to the current crop and can therefore follow an already wrong crop.

Still current:
its startup-latch/mapping risks remain possible residuals, but are not the current project critical path in R13.4.

### Decision: F2 remains open

`F2_EXACT_NATIVE_IDENTITY_PROVEN=NO`

Reason:
TextureTransaction uses generation + nearest host-time matching, not an exact native frame sequence token.

Still current:
R13.4 retains F2 as Deferred Open, runtime mismatch unproven.

### Decision: F3 remains frozen / retirement not authorized

SharedTiltLock:
KEEP at this chat endpoint.

Still current:
R13.4 records F3 retirement as not authorized.

---

## REJECTED APPROACHES

### Rejected: treat CONTROL observer PASS as full Product Visual PASS

Why considered:
internal Canonical/Transaction/Crop/Mask fields were coherent in the measurement-ready subset.

Why rejected:
Human Visual showed the actual Product output was not normal.

Revisit:
only with a corrected same-build visual baseline and claim-scoped observer.

### Rejected: InferenceEngine as the single cause of crop/mask failure

Evidence:
crop/mask remained failed in MediaPipe-only isolation.

### Rejected: permanent MediaPipe-only Production

Reason:
isolation was diagnostic-only and current product design still needs high-rate hybrid continuity.

Later confirmation:
R13.4 explicitly rejects MediaPipe-only H1 Production.

### Rejected: ShapeMask as first root cause

Reason:
a deterministic upstream Cropper X mismatch already existed.

### Rejected: Native/LIVE CAMERA redesign for this FacePart defect

Reason:
LIVE CAMERA could be visually normal while FacePart failed, and coordinate contradiction was proven downstream.

### Rejected: broad new Runtime instrumentation before Static closure

Reason:
R12 validation-reduction policy and source evidence were sufficient to identify the first boundary.

### Rejected: smoothing / Kalman / threshold relaxation / prediction / FIFO

Reason:
would mask boundary defects and violate project architecture.

### Rejected: SharedTiltLock retirement in this phase

Reason:
F3 Human/Runtime harm was not proven.

### Rejected: commit/push

No explicit instruction was given.

---

## SUPERSEDED CONCLUSIONS

### OLD
`CONTROL_FAILURE_REPRODUCED=NO` interpreted broadly as current CONTROL normality.

### NEW
CONTROL Human Visual = FAIL.

### WHY
Observer measured structural state but did not prove correct final spatial presentation.

---

### OLD
`CURRENT_CONTROL_TRANSIENT_FIRST_FAILURE_BOUNDARY=FACEPART_PRESENTATION` as the main working explanation.

### NEW
Persistent crop/mask issue first proven boundary = `CANONICAL_TO_CROPPER_COORDINATE_MAPPING`.

### WHY
Static coordinate proof established an extra X reflection before downstream ShapeMask/presentation.

---

### OLD
Next Action from this chat:
scene-only `mirrorX=0 / swapEyes=0` minimal fix + one MediaPipe-only validation run.

### NEW — CURRENT PROJECT STATE
R13.4 records:
- H1 report-time scene coordinate contract: `mirrorX=0`, `swapEyes=0`
- H1 previous candidate: NO_GO / rolled back
- current critical path:
  `IE_TO_MEDIAPIPE_GEOMETRY_CONTRACT_DETAILED_AUDIT`
- Production change: NO
- Runtime: NO by default unless a residual source-inconclusive claim remains.

Therefore the old chat Next Action is historical and must not be executed as the current project Next Action.

---

### OLD tooling note
This chat temporarily moved launcher execution toward PowerShell 7 after confirming `pwsh 7.6.5`.

### CURRENT integrated roadmap
R13.4 states Windows PowerShell 5.1 fixed for Codex/tooling.

Classification:
the PS7 launcher handling in this chat is historical/tool-specific and should not override the later integrated tooling policy.

---

## OBSERVER / VALIDATOR FINDINGS

### Launcher ambiguous-cardinality defect

Fault:
`*.exe Count == 1` assumption.

Fix:
identify Player by matching `<Player>_Data`.

Product impact:
none.

### PowerShell guard execution defect

The user pasted a PS7 guard and subsequent script statements interactively under Windows PowerShell 5.1.
The guard threw, but later statements still ran.

Lesson:
a thrown line in an interactive shell does not cancel separately pasted later lines.

Product impact:
no demonstrated Product defect; execution-authority qualification only.

### CONTROL observer coverage limitation

The observer's measurement-ready gating and structural fields did not prove:
- correct physical eye/mouth spatial correspondence,
- exact native frame identity,
- final Human Visual correctness.

### Validator coverage concern retained from re-audit

The raw-direct semantic invariant check used broad token matching and could false-PASS in a future edit.
Current source itself supported the direct semantic publish invariant, so this did not invalidate the current build authority, but the validator check was weaker than the claim.

### EXE SHA is not unique build identity

The Unity bootstrap Player EXE SHA repeated across different builds.
Use:
- build directory,
- payload manifest,
- managed assembly SHA,
- scene/build/preflight identity,
not EXE SHA alone.

---

## FILES / SHA256

### Evidence files physically available to this archive-generation chat

Path:
`/mnt/data/KiwiCodexConsolidatedReport_ControlBaselineFailureLocalization_20260907_0106.txt`

Role:
CONTROL boundary-localization report.

SHA256:
`3C1E237A47A548F06A091AA6E7E8C277C89CBE5781B0116D4DCB47D6019C6303`

---

Path:
`/mnt/data/KiwiRuntimeEvidence_ControlBaselineFailureLocalization_20260907_0106.zip`

Role:
CONTROL Runtime evidence bundle.

SHA256:
`06CBF19501FE8301D5A7639E093BB05C939F4CBCBD841E8FA6A967EC098D38DA`

---

Path:
`/mnt/data/KiwiCodexConsolidatedReport_MediaPipeOnlyCausalIsolation_20260907_0754.txt`

Role:
one-factor Inference availability isolation.

SHA256:
`CB1067B5E4D5CCA1D32E0254D19DF8C3A99B8A02730665E77C8751A2588FBF6E`

---

Path:
`/mnt/data/KiwiCodexConsolidatedReport_FacePartCoordinateContract_20260907_1730.txt`

Role:
Static semantic-to-texture coordinate-contract proof.

SHA256:
`59BD4E52233D2869B96DDA57924B4B8F09B3D01D15AC5208205AF117A6A5F950`

---

Path:
`/mnt/data/KiwiAvatarSystem_最新統合情報_統合ロードマップ_R13_4_0909.txt`

Role:
later integrated project state used only for supersession/current-state reconciliation.

SHA256:
`33C7C57C3A44E045A9E1DC6CDFC69F5782FF82BB3A700DC513093B50896F9543`

---

## RUNTIME EVIDENCE

### CONTROL localization run

Authority:
CORRECTNESS / SUPPORTING_ONLY

Not Performance Authority.

Key use:
- internal transaction/crop/mask structural state,
- existing geometry/provider trace,
- build provenance.

Human Visual later overruled any broad visual-normal interpretation.

### MediaPipe-only causal isolation run

Authority:
CORRECTNESS / VISUAL / DIAGNOSTIC_CAUSAL_ISOLATION

Not Performance Authority.

Key use:
- prove Inference frames absent from Runner/Hub/Canonical during isolation,
- compare domain-level Human Visual:
  jump/freeze improved,
  crop/mask unchanged.

### FacePart coordinate audit

Authority:
STATIC_ONLY / PACKAGE_SOURCE / SOURCE_CONTRACT

No Runtime was required for the first boundary because the X-coordinate contradiction was deterministic in source.

### Performance

No clean Production Performance Authority was established in this chat.

---

## CURRENT RESULT

### Historical result of this chat

- current CONTROL Human Visual: FAIL
- LIVE CAMERA in that observed scenario: PASS/normal continuity
- InferenceEngine motion contribution: SUPPORTED / PARTIAL
- Inference whole-failure single cause: REJECTED
- crop/mask Inference-only cause: REJECTED
- crop/mask first proven defect:
  `CANONICAL_TO_CROPPER_COORDINATE_MAPPING`
- scene at Static proof:
  `mirrorX=1`, `swapEyes=1`
- expected minimal mapping:
  `mirrorX=0`, `swapEyes=0`
- ShapeMask owner/latch issues: SECONDARY STATIC CANDIDATES
- F2 exact native identity: OPEN
- F3: FROZEN
- SharedTiltLock: KEEP
- Production code rewrite: NOT AUTHORIZED
- commit/push: NO

### Current project status at archive creation — R13.4 reconciliation

The project has advanced after this chat.

Latest integrated source available here states:
- report-time H1 HEAD: `dff213b8a76677426e7810c8d9e4827185803602`
- scene coordinate contract: `mirrorX=0`, `swapEyes=0`
- H1 candidate tracked changes: fully rolled back
- H1 candidate: NO_GO / concept retained unproven
- high-rate IE frame lacks same-sample FaceGeometry pose
- current unresolved Static boundary:
  `CURRENT_LOCAL_IE_DECODE_TO_INSTALLED_MEDIAPIPE_NORMALIZED_LANDMARK_CONTRACT`
- current Next Action:
  `IE_TO_MEDIAPIPE_GEOMETRY_CONTRACT_DETAILED_AUDIT`
- Runtime: NO by default
- Production change: NO
- commit/push: NO.

This current-state section is intentionally separated from the historical chat result.

---

## OPEN ISSUES

Current project open issues relevant to this archive:

1. IE decode → installed MediaPipe normalized-landmark exact contract.
2. High-rate IE same-sample 468 XYZ → FaceGeometry pose continuity.
3. H1 human-head hybrid geometry contract remains unproven.
4. F1 expression input authority remains Deferred Open.
5. F2 exact native FacePart transaction identity remains open; runtime mismatch unproven.
6. F3 sampling-rotation owner plurality remains open; retirement not authorized.
7. F4 temporal plurality remains open; harmful duplication unproven.
8. Mouth size and surface clip remain separate unproven presentation roots in R13.4.
9. MediaPipe 0.16.3 archive SHA conflict requires path-specific reconciliation.
10. clean Production Performance Authority remains unavailable.

---

## NEXT ACTION

### Current project Next Action — authoritative at archive creation

`IE_TO_MEDIAPIPE_GEOMETRY_CONTRACT_DETAILED_AUDIT`

Mode:
READ_ONLY_FIRST

Immediate goal:
close the exact current-local InferenceEngine decode → installed MediaPipe normalized-landmark contract at method/statement/equation/dataflow level.

Required output:
`STATIC_NORMALIZED_LANDMARK_CONTRACT=PASS / FAIL / INCONCLUSIVE`

If PASS:
move to External Comparative Design Gate before Production code change.

If FAIL/INCONCLUSIVE:
return the exact first failing boundary and stop.

Runtime:
NO by default.

Production:
NO CHANGE.

### Historical chat Next Action — superseded

`mirrorX=0 / swapEyes=0` scene-only fix + one MediaPipe-only Human Visual.

Do not re-run this merely because it is recorded in this archive; R13.4 already records the scene coordinate contract as 0/0 and has advanced the critical path.

---

## DO NOT CHANGE

Without new claim-specific evidence:

- Face Landmarker Primary / Source of Truth
- Native Path B
- latest-frame / no FIFO / no stale accumulation
- bounded / nonblocking
- persistent ROI
- stable Unity-visible presentation texture identity
- Root / Head / Eye / Mouth authority separation
- Head single rigid authority
- Provider normalization owner=1
- Resume != Provider Switch
- same-sample transaction requirement
- 560x315 exact 16:9 / Bilinear presentation baseline
- KiwiFaceMotion as a camera/display workaround
- KiwiInferenceFaceTracker as a camera/display workaround
- strong smoothing
- Kalman workaround
- stale prediction
- unjustified threshold relaxation
- UpdateExternalTexture
- IMFSample cross-callback retention
- D3D12 queue Wait / blocking GPU wait
- speculative Fence/Wait/flush/async-disable
- forced MediaPipe-only Production
- external tracker Primary replacement
- Big-Bang rewrite
- neural face replacement as Primary
- SharedTiltLock retirement without new F3 evidence
- commit/push without explicit instruction.

---

## HANDOFF

To continue from this archive:

1. Treat the FacePart coordinate investigation as historical evidence, not the current critical path.
2. Preserve the key causal split:
   - InferenceEngine affected motion jump/freeze,
   - crop/mask persisted independently under MediaPipe-only.
3. Preserve the proven historical coordinate defect:
   - old scene `mirrorX=1 / swapEyes=1` produced a deterministic X mismatch.
4. Do not re-open that old coordinate task merely from this archive; latest R13.4 records scene 0/0.
5. Start from the latest integrated R13.4 authority and execute:
   `IE_TO_MEDIAPIPE_GEOMETRY_CONTRACT_DETAILED_AUDIT`.
6. First re-freeze current local authority because normal chat does not directly verify live `D:\KiwiAvatarSystem`.
7. Resolve the MediaPipe archive SHA conflict by exact path/size/SHA before using package archive identity.
8. Distinguish:
   - source-appearance FaceGeometry pose reference,
   - visible Kiwi Head rigid-pose authority.
9. Do not mix stale MediaPipe pose with newer IE landmarks.
10. Runtime only for a source-inconclusive residual claim.
11. Do not commit/push unless explicitly instructed.

---

## PROJECT MASTER REPORT — ITEMS TO CARRY FORWARD

Archive:
`KiwiChat_FacePartControlCoordinateAudit_Updated_20260907-JST.zip`

Validated Decision:
- CONTROL Human Visual invalidated broad observer-normal interpretation.
- InferenceEngine availability is a partial motion-domain contributor.
- InferenceEngine is not the single crop/mask cause.
- historical Canonical→Cropper X mapping defect proven.
- F2 open; F3 frozen; SharedTiltLock retirement not authorized.

Rejected:
- permanent MediaPipe-only Production
- Native/Tracking workaround for crop/mask
- broad observer PASS overriding Human Visual
- ShapeMask-first diagnosis before crop mapping
- smoothing/Kalman/threshold workaround
- commit/push.

Superseded:
- historical scene-coordinate Next Action; R13.4 records scene 0/0 and moves to IE geometry contract.

Open:
- current IE normalized-landmark contract
- H1 hybrid geometry continuity
- F1/F2/F3/F4 deferred claims
- MediaPipe archive SHA reconciliation.

Current Next Action:
`IE_TO_MEDIAPIPE_GEOMETRY_CONTRACT_DETAILED_AUDIT`

---

## CHAT ARCHIVE INDEX

Archive: KiwiChat_FacePartControlCoordinateAudit_Updated_20260907-JST.zip  
Topic: FacePartControlCoordinateAudit  
LastWorkUpdate: 2026-09-07  
Status: SUPERSEDED  
Supersedes: broad CONTROL-normal interpretation and presentation-only first-boundary interpretation from earlier same-theme diagnostics  
SupersededBy: KiwiAvatarSystem Integrated Roadmap R13.4 current critical path  
NextArchiveCandidate: IE-to-MediaPipe Geometry Contract Detailed Audit  

---

## ARCHIVE SELF-AUDIT

- Archive timestamp uses last relevant technical work date, not archive request date: PASS
- Exact technical completion time was not safely known: DATE_ONLY used
- Report request date not used in archive name: PASS
- Old conclusions preserved with supersession: PASS
- Current R13.4 Next Action used instead of stale chat Next Action: PASS
- Local live Production not falsely claimed as directly verified by normal chat: PASS
- SHA values are from uploaded files / Codex reports / direct local artifact hashing in archive-generation environment: PASS
- Correctness / Performance / Visual / Static separated: PASS
- Observer defects separated from Product defects: PASS
- No evidence ZIP duplicated into archive: PASS
- Main deliverable count: one ZIP

ReportFileSHA256_PreAppendNoteBasis: FB45C47A997DC00B53DBBAC4EB8D6799768A9DE5446B8B246AC323B3EC1DA741
Note: the value above hashes the report body before these final two metadata lines were appended.
