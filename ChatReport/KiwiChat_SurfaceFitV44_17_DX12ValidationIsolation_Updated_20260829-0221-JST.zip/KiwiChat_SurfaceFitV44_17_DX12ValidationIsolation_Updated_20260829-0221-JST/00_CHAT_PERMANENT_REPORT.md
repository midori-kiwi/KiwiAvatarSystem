# KiwiAvatarSystem Chat Permanent Report

ChatTopic: SurfaceFitV44_17_DX12ValidationIsolation  
ChatTitle: Surface Fit v44.15-v44.17 Optimization and DX12 Validation Isolation  
ArchiveName: KiwiChat_SurfaceFitV44_17_DX12ValidationIsolation_Updated_20260829-0221-JST.zip  
LastWorkUpdate: 2026-08-29 02:21 JST  
LastWorkUpdatePrecision: DATE_TIME  
ArchiveCreated: 2026-09-02 23:55 JST  
ArchiveTimestampBasis: LATEST_RUNTIME_EVIDENCE_BEFORE_ARCHIVE_REQUEST  
ArchiveTimestampEvidence: `Player(20260828-172119).log` = 2026-08-28 17:21 UTC metadata / filename, converted to Asia/Tokyo = 2026-08-29 02:21 JST  
Project: `D:\KiwiAvatarSystem`  
Unity: `6000.0.80f1` / Windows / DX12  
CurrentInvestigationVersion: v44.17 (this chat scope)  
Status: PARTIALLY_DONE  
LocalProductionVerificationAtArchiveCreation: LOCAL_PRODUCTION_NOT_DIRECTLY_VERIFIED  
ArchiveZIPSHA256: SEE_FINAL_RESPONSE_DUE_TO_SELF_REFERENCE  

> Scope warning: this archive preserves this chat's v44.15-v44.17 Surface Fit and DX12 Debug Layer investigation.  
> It is a historical chat archive, not the project-wide latest Production authority. At archive creation, the project has later v44.55.x work.  
> When continuing work, current local Production + latest Runtime evidence must outrank this archive if they conflict.

---

## EXECUTIVE SUMMARY

This chat completed two distinct technical threads.

1. **Surface Fit startup collider cooking**
   - v44.15 disabled PhysX Fast Midphase for the temporary 1,017,188-triangle collider.
   - It removed the huge Fast Midphase warning but caused approximately 2.9-3.1 seconds of synchronous collider cooking and triggered inference soft recovery.
   - v44.16 restored Fast Midphase and partitioned the exact original triangle topology into 3 temporary colliders. Cooking dropped to roughly 0.49-0.53 seconds.
   - v44.17 reduced partitions to 250k triangles each, pre-baked them with `Physics.BakeMesh` through the C# Job System, preserved cleaning/welding/Fast Midphase, and removed only `CookForFasterSimulation`.
   - Runtime, CSV and MP4 validation showed stable Surface Fit accuracy and no visible 200 ms-class startup freeze.
   - **v44.17 Surface Fit was accepted as FINAL PASS / FROZEN for this thread.**

2. **DX12 Debug Layer correctness**
   - The remaining one-time `d3d12: upload buffer was too small... 16,777,216 -> 20,344,040` warning was investigated with DX12 Debug Layer.
   - Debug Layer revealed a much more important repeated state-contract failure:
     - ID 916: `ID3D12CompatibilityDevice::ReflectSharedProperties`
     - ID 538: Copy/Draw resource state invalid
     - ID 527: ResourceBarrier before-state mismatch
   - Initial suspicion focused on the Native Camera D3D12/D3D11 reverse-share path.
   - `DIAG_REVERSE_FENCE` and `DIAG_REVERSE_CREATE` were functionally alive but still produced the same errors.
   - The decisive A/B was `KIWI_NATIVE_CAMERA_MODE=WEBCAM`: Native camera was explicitly disabled from startup and WebCamTexture used instead, yet the same error family continued at high frequency.
   - Therefore **the active Native Camera Path B / ReverseShare is not a necessary condition for these DX12 validation errors.**
   - Root cause remained open. The next isolated candidate is another D3D12/D3D11 shared-resource or presentation path, with Spout/external sharing a hypothesis only, not a confirmed cause.

---

## OBJECTIVE

Primary objectives during this chat:

- eliminate or safely handle the giant temporary Surface Fit MeshCollider warning without changing tracking semantics;
- reduce startup/main-thread stall while preserving exact Surface Fit geometry and hit accuracy;
- validate v44.17 visually and through Runtime evidence;
- investigate the persistent DX12 upload warning using the official Debug Layer;
- isolate whether Native Camera interop caused the discovered D3D12 state errors;
- avoid modifying stable Native Camera, Face Landmarker tracking, or established mesh/inference lifecycle code without direct evidence.

---

## CONFIRMED FACTS

### Surface Fit geometry

The source avatar mesh used by Surface Fit has:

- vertices: 508,601
- triangles: 1,017,188
- source stream 0 stride: 40 bytes
- source stream 0 bytes: 20,344,040

The arithmetic is exact:

`508,601 vertices * 40 bytes = 20,344,040 bytes`

This exactly matches the requested size in the one-time DX12 upload warning.

This is a strong fingerprint of the avatar vertex stream upload, but it does **not** by itself prove which Unity internal upload subsystem emits the warning.

### v44.15

v44.15 used a single huge temporary MeshCollider with Fast Midphase disabled.

Measured collider assignment/cooking:

- 2903.684 ms
- 2939.102 ms
- 3111.888 ms

Observed result:

- huge Fast Midphase warning: removed
- Surface Fit accuracy: remained high
- inference pending age rose to approximately 3.5 seconds
- `SOFT_RETIRE / SOFT_RECOVERED`: occurred
- `HARD_REBUILD`: 0

Conclusion: correct but operationally unacceptable.

### v44.16

v44.16 kept exact baked vertex positions/topology and partitioned only triangle index ranges:

- 500,000
- 500,000
- 17,188 triangles

Total remains exactly 1,017,188 triangles.

Measured `allCookMs` included approximately:

- 509.760 ms
- 485.002 ms
- 533.084 ms

Compared with v44.15 this was about an 82-84% reduction.

Runtime:

- huge Fast Midphase warning: 0
- `SOFT_RETIRE`: 0 in the evaluated run
- `HARD_REBUILD`: 0
- Surface Fit included 639/653 and one later 635/653 result

Conclusion: major improvement, but not final.

### v44.17

v44.17 design:

- exact source/baked geometry preserved
- 250,000-triangle partition limit
- current mesh -> 5 partitions:
  - 250,000
  - 250,000
  - 250,000
  - 250,000
  - 17,188
- `Physics.BakeMesh` pre-bake through `IJobParallelFor`
- Fast Midphase retained
- Mesh Cleaning retained
- Weld Colocated Vertices retained
- `CookForFasterSimulation` disabled only for this short-lived temporary collider workload
- nearest hit across all partitions preserved

Typical v44.17 Runtime measurements in this chat:

- `bakeWallMs`: roughly 175-236 ms depending on run
- `totalBuildMs`: roughly 203-285 ms depending on run
- normal validated Surface Fit: 639/653 = 97.8561%
- later WEBCAM/DX12-debug isolation run: 639/653, 639/653, 642/653
- huge Fast Midphase warning: 0
- `SOFT_RETIRE`: 0
- `SOFT_RECOVERED`: 0
- `HARD_REBUILD`: 0
- old legacy inference restart: 0
- shutdown cleanup remained clean

### v44.17 visual validation

The chat performed two visual validations:

1. normal final CSV + MP4 run:
   - all frames were sequentially inspected
   - no black-frame sequence
   - no mesh collapse, hole, triangle popping or FacePart detachment
   - no long visible freeze attributable to Surface Fit

2. startup-recording run:
   - recording started before the application
   - 581 frames were inspected sequentially
   - no 200 ms-class visible video gap/freeze was observed
   - maximum observed video timestamp gap was approximately 75.5 ms
   - no black frame, mesh collapse or FacePart detachment

Therefore v44.17 Surface Fit was accepted as FINAL PASS for this thread.

### DX12 Debug Layer baseline

Normal v44.17 with DX12 Debug Layer exposed repeated D3D12 validation failures.

`Player(20260828-170600).log` counts:

- ID 916 = 1390
- ID 538 = 2776
- ID 527 = 1388
- upload-buffer warning = 1

Representative semantics:

- ID 916:
  `ID3D12CompatibilityDevice::ReflectSharedProperties: Resource provided was not shared by D3D11, or with a D3D11 desc.`

- ID 538:
  `CopyResource` source resource was in `RENDER_TARGET` rather than `COPY_SOURCE`,
  or Draw attempted render-target use while resource state was `COMMON/PRESENT`.

- ID 527:
  transition barrier's specified before-state did not match the tracked prior/initial state.

No Device Removed / Device Hung result was observed in the evaluated runs.

### DIAG_REVERSE_FENCE

Functional stage result:

- capture = 180
- dropped = 0
- publishedSeq = 180
- producerFenceCompleted = 180
- status = PASS_STAGE_ALIVE

Debug Layer counts in the full log:

- ID 916 = 1347
- ID 538 = 2690
- ID 527 = 1345

Therefore functional liveness did not imply D3D12 correctness.

### DIAG_REVERSE_CREATE

Functional stage result:

- capture = 180
- dropped = 0
- publishedSeq = 180
- producerFenceCompleted = 0
- status = PASS_STAGE_ALIVE

Debug Layer counts in the full log:

- ID 916 = 1764
- ID 538 = 3524
- ID 527 = 1762

The same error family existed before the diagnostic stage and continued after fallback.

Therefore the earlier conclusion "Reverse Create/Open itself is the root cause" was not justified.

### WEBCAM complete Native-camera exclusion

Latest runtime evidence in this chat explicitly logged:

`[WindowsNativeWebCamSource] Native camera explicitly disabled by KIWI_NATIVE_CAMERA_MODE='WEBCAM'. Using WebCamTexture.`

The camera then started as:

- UGREEN Camera 4K
- requested 1920x1080 60 Hz
- actual 1920x1080

Despite active Native Camera being disabled, the same D3D12 error family continued.

Full latest-log counts:

- ID 916 = 1016
- ID 538 = 2028
- ID 527 = 1014
- upload-buffer warning = 1

This is decisive evidence that the active Native Camera Path B / ReverseShare path is **not required** for the validation failure to occur.

It does not identify the final owner of the resource.

---

## PUBLIC DESIGN PRINCIPLES

The following public design principles were used during the chat.

### Unity MeshCollider / cooking

- Fast Midphase is a faster collision midphase path; disabling it can use a different, more expensive cook path.
- Very large concave MeshCollider cooking can be expensive.
- `Physics.BakeMesh` prepares collision data for a mesh.
- `Physics.BakeMesh` is documented as usable from the C# Job System / thread-safe path.
- Reusing the same mesh and cooking options allows the pre-baked collision data to be reused by MeshCollider.
- `CookForFasterSimulation` performs more cooking work to optimize subsequent simulation/query work, so it is not automatically optimal for an extremely short-lived temporary collider.
- Mesh Cleaning and welding are correctness/robustness-oriented options and were retained.

### Unity Jobs

- `JobHandle.Complete()` synchronously waits for scheduled CPU jobs to complete.
- Therefore jobifying the cook reduces where the CPU work executes, but `Complete()` still creates a synchronous join boundary.
- This was accepted only after startup MP4 showed no material visible freeze, avoiding a broader lifecycle redesign.

### Direct3D 12

- A resource used as a Copy source must be in an allowed COPY_SOURCE-compatible state.
- Explicit transition barriers must use a before-state consistent with the tracked prior/initial state.
- A resource used as a render target must be in the render-target state.
- Debug Layer errors concerning state mismatches are correctness evidence and must not be dismissed merely because rendering appears functional.

### Authority principle

Functional output, capture cadence or visual success does not override a reproducible Debug Layer resource-state violation.

Conversely, a Debug Layer error observed in a diagnostic run does not establish which subsystem owns the resource until stage/A-B isolation proves it.

---

## INFERENCES / HYPOTHESES

These are **not confirmed facts**.

1. The repeated ID916/538/527 errors likely originate from another D3D12/D3D11 compatibility/shared-resource path or a presentation/export path that exists even when Native Camera is disabled.

2. Spout or another external/shared render-texture path is a high-priority candidate because:
   - the errors use `ID3D12CompatibilityDevice`;
   - Camera was excluded as a necessary condition;
   - Kiwi has other DX12/D3D11 interoperability infrastructure.

3. The exact resource pointer seen in an individual run appears repeatedly in the same error family, suggesting one long-lived resource is being used under conflicting state assumptions. This does not identify the owner.

4. The one-time 16 MB -> 20,344,040 upload warning is likely separate from the repeating compatibility/state violation. The exact source stream byte fingerprint is strong, but the emitting Unity internal subsystem remains unproven.

Do not convert these hypotheses into fixes before feature/stage isolation.

---

## PRODUCTION AUTHORITY

Authority used in this chat:

1. Runtime logs from the exact v44.15-v44.17 Development Standalone builds
2. Runtime CSV and MP4 from v44.17 final validation
3. Exact generated installer/artifact ZIPs and their internal static-validation manifests
4. Unity 6 runtime behavior and local package/source observations
5. Unity official MeshCollider / Physics.BakeMesh / Job System design principles
6. Microsoft D3D12 resource-state rules
7. Earlier Kiwi project evidence only where not contradicted by newer Runtime evidence

Important archive limitation:

`D:\KiwiAvatarSystem` local Production is not mounted/directly inspected while generating this archive.

Therefore:

`LOCAL_PRODUCTION_NOT_DIRECTLY_VERIFIED`

Later project state, especially v44.55.x Production/Semantic work, outranks this archived v44.17 thread if they conflict.

GitHub:
`https://github.com/midori-kiwi/KiwiAvatarSystem/tree/main`

GitHub main must not be treated as Production authority when local Production is newer.

---

## WORK PERFORMED

### 1. v44.15 Surface Fit Collider / Upload isolation

Purpose:
- remove giant Fast Midphase warning;
- test whether 32 MB async upload setting affects the 16 MB -> 20,344,040 warning.

Implementation:
- Fast Midphase disabled for temporary Surface Fit collider;
- mesh/upload signature telemetry added;
- async upload buffer experiment performed.

Result:
- giant Fast Midphase warning removed;
- Surface Fit stayed accurate;
- collider cooking became ~2.9-3.1 seconds;
- inference soft recovery occurred;
- upload warning remained the same 16 MB -> 20,344,040.

Decision:
- FAIL for Production due severe synchronous cook regression.
- async-upload-buffer setting is not accepted as a fix for this warning.

### 2. v44.16 Partitioned Fast Midphase Surface Fit

Purpose:
- preserve exact Surface Fit geometry;
- keep Fast Midphase;
- remain below giant single-collider scale.

Implementation:
- exact triangle-index range partitioning;
- 3 temporary MeshColliders;
- nearest-hit selection across all partitions.

Result:
- warning removed;
- cooking reduced to ~0.5 seconds;
- no inference recovery in evaluated run;
- one later fit produced 635/653.

Decision:
- PASS as intermediate improvement.
- superseded by v44.17.

### 3. v44.17 Parallel Fast-Cook Surface Fit

Purpose:
- further reduce synchronous cook cost without changing topology or tracking.

Implementation:
- 250k triangle limit -> 5 partitions;
- `Physics.BakeMesh` with `IJobParallelFor`;
- Fast Midphase + cleaning + welding retained;
- `CookForFasterSimulation` disabled;
- synchronous `FitAllNow` contract preserved.

Result:
- Surface Fit returned stable 639/653 in normal validation;
- no Fast Midphase warning;
- no inference lifecycle regression;
- total build generally around low/mid-200 ms;
- final visual run showed no relevant visible startup freeze.

Decision:
- FINAL PASS / FROZEN for Surface Fit.

### 4. v44.17 final CSV + MP4

Purpose:
- ensure reduced cook did not create visual or transaction regression.

Result:
- normal runtime invariants remained intact;
- no visible mesh/FacePart corruption;
- no long video freeze;
- tracking irregularity during extreme head motion was not attributed to mesh optimization or Surface Fit.

Decision:
- visual acceptance.

### 5. Startup-before-app MP4

Purpose:
- capture the actual Surface Fit cook window that the previous recording started too late to contain.

Result:
- 581 frames sequentially checked;
- max video timestamp gap ~75.5 ms;
- no 200 ms-class visible gap/freeze;
- no black frames or geometry collapse.

Decision:
- Surface Fit v44.17 frozen.

### 6. DX12 Debug Layer baseline

Purpose:
- decide whether remaining upload warning is harmless.

Result:
- revealed thousands of ID916/538/527 state/compatibility violations.

Decision:
- previous framing "only a one-time benign upload warning remains" was superseded.
- correctness isolation required.

### 7. DIAG_REVERSE_FENCE

Purpose:
- test Native reverse-share path without Unity external texture consumption.

Result:
- functional PASS_STAGE_ALIVE;
- same validation error family persisted.

Decision:
- not enough to assign root cause.

### 8. DIAG_REVERSE_CREATE

Purpose:
- reduce Native test to reverse shared-resource create/open stage before frame write/fence.

Result:
- functional PASS_STAGE_ALIVE;
- same validation error family persisted;
- errors already occurred before stage and continued afterward.

Decision:
- "Reverse Create/Open is root cause" rejected as premature.

### 9. WEBCAM complete Native Camera exclusion

Purpose:
- remove active Native Camera path from startup and use WebCamTexture.

Result:
- explicit Native camera disabled log confirmed;
- same ID916/538/527 errors continued in large counts.

Decision:
- active Native Camera path excluded as a necessary cause.
- investigate another D3D12/D3D11 compatibility/shared-resource path.

---

## VALIDATED DECISIONS

### Decision: v44.17 Surface Fit is FINAL PASS / FROZEN

Reason:
- exact high-resolution Surface Fit geometry retained;
- stable hit rate;
- no giant Fast Midphase warning;
- no inference recovery regression;
- no visible startup hitch in the required startup MP4.

Evidence:
- Player logs listed below;
- final CSV;
- two MP4 validations;
- artifact static validation.

Regression constraints:
- preserve 250k partition approach unless new evidence requires change;
- preserve exact triangle geometry authority;
- preserve nearest-hit across partitions;
- do not relax fit thresholds to mask failures.

Still current within this archived thread: YES.

### Decision: v44.15 Fast Midphase OFF is REJECTED

Reason:
- ~3 second cook stalls and inference lifecycle pressure.

Still current: YES.

### Decision: v44.16 is SUPERSEDED by v44.17

Reason:
- v44.17 halved remaining cook cost and restored stable observed hit rate.

Still current: YES.

### Decision: active Native Camera Path B is not a necessary condition for the DX12 Debug Layer failure

Reason:
- latest WEBCAM runtime explicitly disabled Native camera and still reproduced the same validation errors.

Important scope:
- this does **not** prove every Native DLL load/init behavior irrelevant;
- it proves the active camera capture/reverse-share pipeline is not required to reproduce the failure.

Still current: YES unless newer authority disproves it.

### Decision: do not modify tracking to hide either issue

Reason:
- both Surface Fit and DX12 state correctness are upstream/resource-management problems.

Still current: YES.

---

## REJECTED APPROACHES

### Rejected: Disable Fast Midphase on the single 1M-triangle temporary collider

Why considered:
- official workaround for huge-collider Fast Midphase concerns.

Why rejected:
- 2.9-3.1 second cook;
- inference soft recovery;
- unacceptable startup stall.

Evidence:
`Player(20260828-163250).log`

Revisit condition:
Only if collider geometry becomes dramatically smaller or cooking is moved to a safe offline/import stage.

### Rejected: Treat v44.16 as final

Why considered:
- warning removed;
- ~82% faster than v44.15.

Why rejected:
- ~0.5 second cook remained;
- one 635/653 fit observed;
- v44.17 provided a better local improvement without broader architecture change.

Revisit condition:
None unless v44.17 regresses.

### Rejected: Increase QualitySettings async upload buffer as the fix for 16 MB -> 20,344,040 warning

Why considered:
- warning text resembles upload-buffer sizing.

Why rejected:
- 32 MB experiment did not change the warning's reported 16 MB size or requested bytes.

Revisit condition:
Only with authoritative Unity source/profiler evidence proving this warning is controlled by that setting.

### Rejected: Attribute DX12 validation errors directly to Reverse Create/Open

Why considered:
- `ReflectSharedProperties` and D3D11/D3D12 compatibility semantics strongly suggested the reverse-share path.

Why rejected:
- same errors occurred before the diagnostic stage and after fallback;
- complete WEBCAM Native-camera exclusion still reproduced them.

Revisit condition:
Only if a minimal Native-DLL-load/no-other-shared-resource test reproduces them uniquely.

### Rejected: Modify Native Camera DLL immediately

Why considered:
- initial error signature pointed at D3D11/D3D12 compatibility.

Why rejected:
- WEBCAM exclusion disproved active Native Camera as necessary cause;
- Native provenance/change risk is high.

Revisit condition:
Only after source/resource-owner isolation points back to Native.

### Rejected: Further async redesign of Surface Fit immediately after v44.17

Why considered:
- `JobHandle.Complete()` still represents a synchronous join.

Why rejected/deferred:
- startup MP4 showed no material visible 200 ms freeze;
- async lifecycle/topology transaction redesign has larger regression scope than measured benefit.

Revisit condition:
A visible startup hitch or measurable UX regression on another avatar/hardware profile.

---

## SUPERSEDED CONCLUSIONS

### OLD
"The remaining DX12 upload-buffer warning is likely the only relevant D3D12 issue."

### NEW
DX12 Debug Layer reveals repeated ID916/538/527 state/compatibility correctness failures.

### WHY
Debug Layer provides stronger correctness evidence than normal non-debug rendering.

### EVIDENCE
`Player(20260828-170600).log`

---

### OLD
"Reverse shared-resource create/open is likely the root cause."

### NEW
Active Native Camera is not a necessary condition; the same failure persists with `KIWI_NATIVE_CAMERA_MODE=WEBCAM`.

### WHY
The camera was explicitly disabled and WebCamTexture used, while the same error family continued.

### EVIDENCE
`Player(20260828-172119).log`

---

### OLD
"v44.16 partitioned collider may be the final Surface Fit solution."

### NEW
v44.17 parallel pre-bake is the accepted Surface Fit version for this thread.

### WHY
Lower cook time, stable hit accuracy, clean lifecycle and visual validation.

---

## OBSERVER / VALIDATOR FINDINGS

1. **DX12 Debug Layer runs are correctness evidence, not performance authority.**
   Thousands of debug messages and validation work invalidate their timing as Production performance measurements.

2. **Functional PASS_STAGE_ALIVE is insufficient.**
   DIAG_REVERSE_FENCE and DIAG_REVERSE_CREATE both progressed capture correctly while violating D3D12 state contracts.

3. **Error counts alone do not identify ownership.**
   The same resource pointer repeats inside each run, but without explicit resource tagging/source-owner logging the subsystem cannot be inferred from the pointer.

4. **The validation hypothesis changed after a stronger A/B.**
   The WEBCAM test invalidated the earlier Reverse Create causal inference. This is an example where the Observer/experiment design itself had to be revised rather than stacking a fix.

5. **The one-time upload warning and repeated state errors must be separated.**
   They may share a mesh/resource timing context, but no direct causal link was proven.

6. **Surface Fit debug timings in DX12 Debug Layer runs are supporting correctness data only.**
   v44.17 performance acceptance should rely on the prior non-debug Runtime/CSV/visual evidence.

---

## FILES / SHA256

### Generated implementation archives

Path:
`/mnt/data/KiwiAvatarSystem_v44_15_SurfaceFitColliderUploadIsolation.zip`

Role:
v44.15 temporary MeshCollider / upload isolation implementation.

SHA256:
`63596c54fc28a808a5b716eff5c2973b0b3f6a7cbdc283d9ccd1309775d9a114`

Current/Obsolete:
OBSOLETE / REJECTED FOR PRODUCTION

---

Path:
`/mnt/data/KiwiAvatarSystem_v44_16_PartitionedSurfaceFitCollider.zip`

Role:
v44.16 3-part Fast Midphase collider implementation.

SHA256:
`8363fef91b753f4c5a0ef6b5fe2db6c2a9fec0a7400f50a2f3da969f93d5c03f`

Current/Obsolete:
SUPERSEDED BY v44.17

---

Path:
`/mnt/data/KiwiAvatarSystem_v44_17_ParallelFastCookSurfaceFit.zip`

Role:
v44.17 accepted Surface Fit implementation.

SHA256:
`44e5e686eddd65b54a2d966b253473e86f18f34e498d43befb45ab0d241268d5`

Current/Obsolete:
CURRENT FOR THIS ARCHIVED THREAD / FINAL PASS

Contained important SHA values from package static validation:

- `KiwiSurfaceFitter.cs` v44.17:
  `96b18b1d3712f7e15ece3f7d32529b4f8a40312b93da63cc1a80385841a575b3`
- `KiwiInferenceLifecycleGuard.cs` v44.14 preserved:
  `1827c11e701482f8b46c310e45df27bef988148e47cb2c3b9c7744869fe481a4`
- `KiwiAvatarRenderMeshOptimizer.cs` v44.11 preserved:
  `b113c5482d88ec4be0de811f248fa5c576ef32ccc11dd9a3fb25351a0b9373e4`

Local Production placement was not directly re-hashed during archive creation.

---

### Key Runtime logs

`Player(20260828-163250).log`
- v44.15
- SHA256:
  `9f9e992287fa4c6ea28602934e55a08ffd64ef810e9b46700f33ae45f166dad6`

`Player(20260828-164155).log`
- v44.16
- SHA256:
  `975c9edeeb6ddfc5d2849f271ba1d22312c72d40fbc1f915989a9b144f54253c`

`Player(20260828-165006).log`
- v44.17 first runtime
- SHA256:
  `0133b45cf5a215ae96b22188e89ccd73e907ea009ec05f6fb1e7bf1a73b8b1b7`

`Player(20260828-165440).log`
- v44.17 normal final-runtime related run
- SHA256:
  `3db75ba444163842a3f142a478977577a41853bf7c5625e12ba32b1371f3688e`

`Player(20260828-170201).log`
- v44.17 startup visual validation related run
- SHA256:
  `110066fbf795080e0694b5be1b0a5b6e752339b2e026078ec738c79207d46d6e`

`Player(20260828-170600).log`
- DX12 Debug Layer baseline
- SHA256:
  `efc5b77ece3c045481bc95a62015c6eea8ffb58dd14ea258a06f88c83e3b8f7c`

`Player(20260828-171158).log`
- DIAG_REVERSE_FENCE
- SHA256:
  `5270f103d676d45e2e1da5ea4cc479491ee8131a58b12044f62a2db4d5f3d518`

`Player(20260828-171523).log`
- DIAG_REVERSE_CREATE
- SHA256:
  `84889d25dbd1fdd4ff1ec258068c122ad71bb59692894ce8e1c5d2a1f3825832`

`Player(20260828-172119).log`
- WEBCAM complete Native-camera exclusion
- SHA256:
  `e08fbd8fa032f3d21c630e3978c87a337554a500384bef0dccd11b4ba16f3fcd`

---

### Final visual/runtime evidence

`KiwiFrameComparison_20260829_015349.csv`
- purpose: v44.17 normal Runtime correctness/cadence support
- SHA256:
  `29315037bd29325fa45036538143e2fa6b0fc9807fe359f91a898b08cf4573b1`

`KiwiAvatarSystem 2026-08-29 01-53-48.mp4`
- purpose: v44.17 final visual evaluation
- SHA256:
  `0bf5c06bfed9b7ff5f244a496e2efd1b523b02142e6c3158da939911ca82a641`

`KiwiAvatarSystem 2026-08-29 02-01-23.mp4`
- purpose: startup-before-app Surface Fit hitch evaluation
- SHA256:
  `4b09d518a288e8da858d6ef4f61d1afc90c4ec8dd71847ea67ec2ad60458a40a`

Evidence files are indexed here rather than duplicated into the archive ZIP to minimize file size and duplication.

---

## RUNTIME EVIDENCE

| Evidence | Authority | Result |
|---|---|---|
| v44.15 Player.log | CORRECTNESS | Fast Midphase warning removed, ~3 s cook regression, soft recovery |
| v44.16 Player.log | CORRECTNESS / SUPPORTING PERFORMANCE | exact 3-part topology, ~0.5 s cook, warning 0 |
| v44.17 normal Player.log | CORRECTNESS | 5-part pre-bake, high fit accuracy, clean lifecycle |
| v44.17 CSV | CORRECTNESS / SUPPORTING PERFORMANCE | cadence/transaction regression check |
| v44.17 final MP4 | VISUAL | no collapse/black/long freeze |
| v44.17 startup MP4 | VISUAL | Surface Fit window captured; no visible ~200 ms freeze |
| DX12 Debug baseline | CORRECTNESS ONLY | repeated ID916/538/527 |
| DIAG_REVERSE_FENCE | CORRECTNESS ONLY | functional alive, validation FAIL |
| DIAG_REVERSE_CREATE | CORRECTNESS ONLY | functional alive, validation FAIL |
| WEBCAM exclusion log | CORRECTNESS ONLY | Native camera disabled, same validation errors |

Do not use Debug Layer runs as Production performance authority.

---

## CURRENT RESULT

### Surface Fit

Status:
**FINAL PASS / FROZEN for this chat thread**

Accepted implementation:
v44.17 Parallel Fast-Cook Surface Fit.

No further Surface Fit redesign is justified without new independent regression evidence.

### DX12 resource-state correctness

Status:
**OPEN / ROOT CAUSE NOT YET IDENTIFIED**

Confirmed:
- repeated state/compatibility Debug Layer errors are real;
- active Native Camera is not required to reproduce them.

Not confirmed:
- resource owner;
- Spout as root cause;
- Presentation as root cause;
- Unity engine bug as root cause;
- relationship to the one-time 20,344,040-byte upload warning.

### One-time upload warning

Status:
**OPEN / SECONDARY**

Confirmed:
- exact requested bytes match source vertex stream 0;
- 32 MB async-upload Quality setting experiment did not change the reported 16 MB warning.

Do not change tracking or Native Camera to hide it.

---

## OPEN ISSUES

1. Identify the owner of the repeating DX12 resource that produces ID916/538/527.

2. A/B disable remaining D3D12/D3D11 compatibility/shared-resource systems one at a time.
   Highest-priority historical candidate:
   - Spout / external shared-resource export path.
   This is a hypothesis, not a conclusion.

3. If available, add observer-only resource identity tagging around:
   - shared-resource creation;
   - D3D11 compatibility reflection/open;
   - copy source/destination transition;
   - render-target transition;
   without adding GPU waits.

4. Verify whether the repeating errors exist in a minimal build with:
   - Native Camera disabled;
   - Spout disabled;
   - preview/export sharing disabled;
   - normal Unity rendering retained.

5. Keep the one-time upload warning separate until the owner is proven.

6. Do not modify Native C++/DLL solely because of the error signature; the latest A/B no longer supports that step.

---

## NEXT ACTION

For continuation of **this archived thread**:

1. Load current local Production and latest project-wide authority first.
2. Confirm whether this DX12 Debug Layer issue is still present in the current Production version.
3. If still present, run a **Spout/external-share disabled A/B under DX12 Debug Layer** while keeping Native Camera disabled or otherwise controlled.
4. Count ID916/538/527 before/after the feature boundary.
5. Only after one subsystem is proven necessary should code modification begin.

Project-wide scheduling note:
At archive creation the project has later v44.55.x semantic/transaction work. If the current master plan says v44.55.24 is higher priority, follow that master authority rather than this historical chat's next action.

---

## DO NOT CHANGE

Until new direct evidence requires it:

- Face Landmarker Primary / Source of Truth
- `KiwiFaceMotion.cs` as camera/resource workaround
- `KiwiInferenceFaceTracker.cs` tracking math as camera/resource workaround
- tracking thresholds
- near-raw tracking policy
- Root/Head/Eye/Mouth authority separation
- latest-frame / no-FIFO policy
- Native Camera stable Path B solely because of these Debug Layer errors
- `g_unityD3D12Queue->Wait(...)` prohibition
- blocking GPU waits
- `UpdateExternalTexture` prohibition
- fixed Unity-visible camera texture identity
- v44.11 MeshOptimizer without independent regression evidence
- v44.14 lifecycle/shutdown cleanup
- v44.17 Surface Fit unless new avatar/hardware evidence demonstrates regression
- Production code based only on Debug Layer error counts without resource-owner isolation

---

## HANDOFF

To resume this chat's work safely:

1. Treat v44.17 Surface Fit as solved/frozen unless a new direct regression appears.
2. Do not return to v44.15 Fast Midphase OFF.
3. Do not return to v44.16 unless v44.17 fails.
4. Do not assume the one-time upload warning is the main DX12 issue.
5. Do not blame Native Camera based on `ReflectSharedProperties`; WEBCAM mode reproduced the same errors.
6. The active unresolved question is:
   **Which non-camera resource path owns the repeated D3D12 compatibility/state violation?**
7. Use staged A/B isolation before fixes.
8. Debug Layer runs are correctness-only.
9. If a new Production version exists, reproduce the issue there before carrying this old diagnosis forward.
10. Preserve current Production authority order:
    local Production + SHA -> same Production Runtime -> local package source -> latest reports -> official source/docs -> GitHub/history -> older diagnostics.

---

## PROJECT MASTER REPORT UPDATE CANDIDATES

If later merged into the project master report, add:

### Archive
`KiwiChat_SurfaceFitV44_17_DX12ValidationIsolation_Updated_20260829-0221-JST.zip`

### Validated Decision
v44.17 Parallel Fast-Cook Surface Fit = FINAL PASS / FROZEN for the v44.17 line.

### Rejected Approach
Single giant Surface Fit MeshCollider with Fast Midphase disabled.

### Superseded Conclusion
Reverse Create/Open or active Native Camera as the direct/necessary cause of ID916/538/527.

### Open Issue
Unidentified non-camera D3D12/D3D11 compatibility/shared-resource owner producing repeated Debug Layer errors.

### Next Action
Reproduce on current Production first; then isolate Spout/external shared-resource paths if still relevant.

---

## CHAT ARCHIVE INDEX

Archive:
`KiwiChat_SurfaceFitV44_17_DX12ValidationIsolation_Updated_20260829-0221-JST.zip`

Topic:
Surface Fit v44.15-v44.17 optimization + DX12 Debug Layer resource-state isolation

LastWorkUpdate:
2026-08-29 02:21 JST

Status:
PARTIALLY_DONE

Supersedes:
- v44.15 Surface Fit single-collider Fast-Midphase-off approach
- v44.16 as final Surface Fit candidate
- early Reverse Create/Open root-cause hypothesis

SupersededBy:
None within this chat archive. Later project-wide v44.55.x state may supersede scheduling/authority.

NextArchiveCandidate:
Current Production reproduction and non-camera shared-resource owner isolation, if this issue remains open after latest project authority is checked.
