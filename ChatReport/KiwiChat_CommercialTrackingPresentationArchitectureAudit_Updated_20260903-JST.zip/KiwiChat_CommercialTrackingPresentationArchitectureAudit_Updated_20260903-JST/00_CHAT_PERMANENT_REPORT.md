# KiwiAvatarSystem Chat Permanent Report

ChatTopic: Commercial Tracking / Presentation Architecture Audit
ChatTitle: Phase16.9–16.17 Tracking / Presentation 全体監査
ArchiveName: KiwiChat_CommercialTrackingPresentationArchitectureAudit_Updated_20260903-JST.zip
LastWorkUpdate: 2026-09-03
LastWorkUpdatePrecision: DATE_ONLY
ArchiveCreated: 2026-09-03T00:48+09:00
ArchiveTimestampBasis: LAST_RELEVANT_WORK_BEFORE_ARCHIVE_REQUEST
Project: D:\KiwiAvatarSystem
Unity: 6000.0.80f1 / Windows / DX12
CurrentInvestigationVersion: KiwiAvatarSystem v5.1.0 Phase16.17 + post-16.17 architecture re-audit
Status: IN_PROGRESS / VALIDATION_PENDING

Archive: KiwiChat_CommercialTrackingPresentationArchitectureAudit_Updated_20260903-JST.zip
Topic: CommercialTrackingPresentationArchitectureAudit
Supersedes: Phase16.9–16.17 chat-only summaries for this chat theme
SupersededBy: NONE
NextArchiveCandidate: Phase16.17 Runtime validation + Provider normalization owner consolidation

## EXECUTIVE SUMMARY

このチャットでは、商用VTuber/ARソフトとOSSの公開設計を比較しながら、KiwiAvatarSystemのTracking / Provider / Root / Eye / Mouth / PresentationをPhase16.9からPhase16.17まで段階的に詰めた。

主な到達点:
- Eye/Mouth Texture/Crop/Maskのsame-sample transactionを強化。
- Landmark isolated rejectの不整合を修正。
- Tracking/Canonical cadenceを5–8Hz級から20–30Hz級へ改善できることを実測。
- Presence rejectとROI authority lossを分離し、短いconfidence dipでROIを失わないPersistent ROI設計を確立。
- 正面静止時のStatic Restが有効。
- onBeforeRenderはfresh canonical sample時のみ処理する設計が有効。
- No-frame Hold / Same-provider Resume / Root Envelope / Provider Bridgeを追加してRoot teleportを抑制。
- その後の全体監査で、`KiwiTrackingQuality10Controller` と `KiwiFaceMotion` が同じRootを時間方向にPresentationしている二重owner構造を発見。
- Phase16.17で `KiwiFaceMotion = sole Root temporal presenter`、`Quality10 = policy/QoS/telemetry only` へ一本化。
- さらにPhase16.17後の再監査で、`KiwiTrackingProviderHub` 自体にProvider handoff normalization / same-provider resume alignmentが存在する一方、Phase16.15/16.16でKiwiFaceMotion側にもResume/Provider Bridgeがあることを確認。**Provider normalization二重化の可能性**が最新Open Issue。

最重要結論:
**新しいfilter/bridgeを追加する前に、Provider normalization ownerを1層へ確定する。**
Phase16.17はSTATIC PASSだがRuntime未検証であり、Production Acceptedではない。

## OBJECTIVE

最重要目標:
「正常sampleを最速・低遅延・高精度でAvatarへ届け、異常sample・authority transition・presentation破綻のみ局所的に抑制する」

固定目標:
- Face Landmarker Primary / Source of Truth
- latest-frame
- FIFO/stale queue禁止
- Persistent ROI
- Tracking cadenceとPresentation cadence分離
- Head single rigid authority
- Root/Eye/Mouth authority分離
- Provider normalization = 1層
- Temporal Presentation owner = 1層
- Prediction = 1層
- Texture/Crop/Mask same-sample transaction
- strong smoothing/Kalmanで問題を隠さない
- thresholdを実測なしに変更しない

## CONFIRMED FACTS

### Authority
- Local Production + SHAが最上位Authority。
- GitHub mainがlocal Productionより古い場合、GitHub mainをProduction Authorityにしない。
- 通常チャットから `D:\KiwiAvatarSystem` を直接確認できていない。
- `LOCAL_PRODUCTION_NOT_DIRECTLY_VERIFIED`
- Local Production SHA: `NOT_AVAILABLE_IN_NORMAL_CHAT`

### Phase16.10
成功runでは概ね:
- Tracking median ≈ 23.79 Hz
- Canonical Adoption ≈ 29.70 Hz
- Effective interval ≈ 42 ms
- Render ≈ 48.5 FPS
- Inference 3 lanes
これにより、旧5–8Hz挙動はFace Landmarker固有限界ではなくPipeline問題を含むことが確認された。

### Phase16.10.1
Play停止時の`SurfaceFittedRawImage` MissingReferenceExceptionは、破棄済みUnityEngine.Objectに対するC# null-conditionalアクセスが原因候補として特定され、Unity-aware `if (obj != null)`へ修正。

### Phase16.11
freshness-first schedulingはTracking/Canonicalが悪化。
schedule delay自体は小さく、Presence/ROI loss→Hard reacquireループが主問題と判断。

### Phase16.12
Sample rejectとROI authority lossを分離。
成功runでは概ね:
- Tracking median ≈ 24.31 Hz
- Canonical Adoption ≈ 32.80 Hz
- Effective interval ≈ 41.14 ms
- Observation Age ≈ 120 ms
- Accepted Source Age ≈ 99 ms
- Hard Anchor ≈ 1
- Stale Anchor discard ≈ 0
- ROI Release = 0
Persistent ROI / Presence Recoveryは採用。

### Inference latency
Phase16.12 telemetry:
- Schedule delay: sub-ms～数ms級
- Schedule CPU: sub-ms級
- Decode CPU: sub-ms級
- Request→completion wait: ≈98 ms
Phase16.13 single-flightでもone-job latencyが≈90–100ms級だったため、
「3-lane depthだけが約100ms latencyの主因」という仮説は棄却。

### Phase16.13
- Adaptive 1→2→3 lane: cadence/latency面で不採用。
- Static Rest: 正面静止時のRoot微動を大きく低減し採用。

### Phase16.14
- Windows Stable 3-laneへ復帰。
- fresh-only onBeforeRenderを導入。
- measured runでは`beforeRenderAcceptedNewSampleCount`が実質0。
- same-sample onBeforeRender再処理はfreshnessを上げず、LateUpdate→Render再advanceを生むため停止方向が正しい。

### Root discontinuity
Phase16.14解析で:
- Canonical frame欠落1frameでRootが数local unit動くevent。
- Same Inference provider / same generationでface center変化が小さいのにRootが2–3 local unit動くevent。
- Same-provider resumeで約4 local unit級event。
Landmark空間誤差だけでは説明できず、Root Presentation側が主要調査対象になった。

### Phase16.15
追加:
- exact No-frame Hold
- Same-provider Resume Bridge
- final Root Correction Envelope
- raw/pre-cap/post-cap/prediction/backlog telemetry

### Phase16.16
追加:
- actual Provider Switch時のRoot-space Provider Bridge
- 最初のrender targetを現在表示Rootに合わせ、accepted new samplesでoffset release
Phase16.16単独Runtimeは未完了。

### Phase16.17 — Single Presentation Authority
Source監査で:
- `KiwiTrackingQuality10Controller`は自分をtemporal presentation layerとして設計。
- `_motionRoot`は`_faceMotion.kiwiRoot`へbind。
- Quality10はPrediction + SmoothDamp/Slerp後、同じRootへPosition/Rotation/Scaleを書き戻す。
- Quality10自身のコメントは「KiwiFaceMotion = near-raw sample、Quality10 = one temporal owner」という設計。

一方Phase16.13–16.16でKiwiFaceMotion側にもStatic Rest / Resume / Root Envelope / Provider Bridgeを追加していたため、二重Temporal Presenter化していた。

Phase16.17:
- KiwiFaceMotion = sole Root temporal presenter
- Quality10 = policy/QoS/telemetry-only
- Legacy Quality10 Root presentationはrollback/A-B用に残すがCommercial既定では抑止
- 重複Predictionを停止
- Static Rest維持

Static Validation recorded:
- C# 81 files
- changed assets 8
- CSV 230/230
- deterministic tests 23/23 PASS
- FaceLandmarkerRunner変更0
- Inference tracker変更0
- ProviderHub変更0
- blocking GPU API追加0
- new Root writer 0
- ZIP integrity PASS

Runtime: **VALIDATION_PENDING**

### Post-Phase16.17 re-audit — 最新Critical Finding
`KiwiTrackingProviderHub` sourceには既に:
- canonical rigid-solve boundary
- provider handoff normalization
- short-gap same-provider resume reference/alignment
- accepted fresh sampleでのhandoff release
が存在する。

同時にKiwiFaceMotionにはPhase16.15/16.16で:
- Same-provider Resume Bridge
- Provider Root-space Bridge
が存在する。

したがって現状は
**ProviderHub canonical normalization + downstream FaceMotion normalization**
の二重化可能性がある。

固定原則「Provider normalization = 1層」に反する可能性があり、次の最優先監査対象。

## PUBLIC DESIGN PRINCIPLES

このチャットで比較対象にした公開情報/Source:
- VTube Studio
- Warudo
- Animaze
- Webcam Motion Capture公開情報
- MediaPipe Face Landmarker
- MediaPipeUnityPlugin
- OpenSeeFace
- Kalidokit
- TikTok Effect House / Face Binding系
- Snapchat/Lens Studio系

採用可能な共通原則:
1. Tracking cadenceとdisplay cadenceは分離。
2. Live inputはlatest-frame優先、FIFOを作らない。
3. short dropoutでpersistent fitting/ROIを即破棄しない。
4. Head/Position/Rotation/Expressionをchannel別に扱う。
5. Rigid Head/Root authorityは1つ。
6. Temporal Presentation ownerは1つ。
7. Provider normalizationは1層。
8. Eye/Mouthはlocal face channelでRootへfeedbackしない。
9. stale/lost時はPredictionを継続しない。
10. Smoothに見せるための古いframe bufferを常設しない。
11. Provider switch/reacquireは明示的stateとして処理。
12. Texture/Crop/Mask/semantic geometryは同一sample transactionへ揃える。

非公開商用内部実装は断定しない。

## INFERENCES / HYPOTHESES

### H1 Provider normalization duplication
Evidence:
ProviderHubにhandoff/resume normalizationがあり、FaceMotionにもPhase16.15/16.16 bridgeがある。
Inference:
同じprovider bias/transitionを二重補正している可能性。
Status: OPEN / HIGHEST PRIORITY.

### H2 Phase16.17 is architecturally cleaner
Reason:
確認された二重Temporal Presenterを解消。
Status:
STATIC_ONLY。Runtime必須。

### H3 Remaining ≈90–110ms is mainly inference/GPU execution path
Reason:
Single-flightでもone-job latencyが≈90–100ms。
Status:
Strong inference。正式Performance authorityはobserver-free benchmark後。

### H4 Apparent Landmarker inaccuracy was partly stale-age/presentation
Reason:
fresh high-cadence時は空間一致が大幅改善。
Status:
Strong inference。Spatial parityは別評価。

### H5 Eye/Mouth残差はtransaction破綻よりcanonical age/presentation clockの可能性が高い
Reason:
後期runでtransaction operational 100%、scene binding valid、texture match ≈1–2ms、miss=0、external writer=0が確認された。
Status:
Strong but regression-test required.

## PRODUCTION AUTHORITY

Priority:
1. local Production + SHA
2. same-Production latest Runtime
3. actual Package Source
4. latest KiwiValidation / Consolidated REPORT
5. official docs/source
6. local git
7. GitHub main
8. older diagnostics

This report:
`LOCAL_PRODUCTION_NOT_DIRECTLY_VERIFIED`

GitHub:
https://github.com/midori-kiwi/KiwiAvatarSystem/tree/main

## WORK PERFORMED

### Phase16.9
Purpose: FaceParts transaction / landmark guard / Writer Audit.
Result: groundwork established; later runs supported transaction/reject improvements.

### Phase16.10
Purpose: tracking throughput recovery.
Result: ~24Hz Tracking / ~30Hz Canonical class successful run.
Decision: low cadence was pipeline-related.

### Phase16.10.1
Purpose: teardown exception fix.
Result: destroyed Unity object access hardened.

### Phase16.11
Purpose: freshness-first schedule/anchor handling.
Result: regression.
Decision: schedule delay not main bottleneck.

### Phase16.12
Purpose: Persistent ROI / Presence recovery.
Result: major success.
Decision: retain.

### Phase16.13
Purpose: Single-flight latency test + Static Rest.
Result: Single-flight rejected; Static Rest retained.

### Phase16.14
Purpose: Stable 3-lane + fresh-only onBeforeRender.
Result: render-boundary rewrite reduced; Update→LateUpdate Root issue remained.

### Phase16.15
Purpose: No-frame Hold / Resume / Root Envelope.
Result: final safety/telemetry added.

### Phase16.16
Purpose: Provider Root-space Handoff.
Result: static implementation only; isolated Runtime not completed.

### Phase16.17
Purpose: eliminate duplicated Root temporal presentation.
Result: STATIC PASS / Runtime pending.

### Post-16.17 re-audit
Purpose: whole-pipeline commercial architecture check.
Result: Provider normalization ownership duplication identified as new top issue.

## VALIDATED DECISIONS

Decision: Face Landmarker Primary maintained.
Still current: YES.

Decision: latest-frame / no FIFO.
Still current: YES.

Decision: Persistent ROI through short confidence dips.
Still current: YES.

Decision: Static Rest final spatial stabilization.
Still current: YES.

Decision: Stable desktop 3-lane is current scheduling baseline.
Still current: YES pending clean backend optimization.

Decision: fresh-only onBeforeRender.
Still current: YES.

Decision: One temporal Root presentation owner.
Current design: KiwiFaceMotion owner, Quality10 policy-only.
Still current: YES, Runtime pending.

Decision: Eye/Mouth independent from Root.
Still current: YES.

## REJECTED APPROACHES

Rejected: strong global Low Pass / Kalman.
Why: normal-path latency/root-cause masking.

Rejected: replace Face Landmarker because it “looks inaccurate”.
Why: pipeline freshness changes materially improved apparent precision.

Rejected: fixed single-flight inference.
Why: one-job latency itself ≈90–100ms; cadence regressed.

Rejected: adaptive 1→2→3 lane oscillation.
Why: Phase16.13 regression/oscillation.

Rejected: same-sample onBeforeRender advance.
Why: no new canonical information; added second presentation advance.

Rejected: Quality10 + FaceMotion both temporally present same Root.
Why: violates single temporal owner.

## SUPERSEDED CONCLUSIONS

OLD: Landmarker model itself is probably the main accuracy problem.
NEW: stale sample age / ROI loss / presentation mismatch explain a large fraction.

OLD: 3-lane depth is the main ≈100ms latency source.
NEW: single-job latency is itself ≈90–100ms class.

OLD: more transition bridge layers are the natural next fix.
NEW: stop adding bridge/filter layers until normalization owner is proven single-layer.

OLD: early Writer Audit counter alone proves rogue post-LateUpdate writer.
NEW: observer timing was imperfect; source audit later confirmed a legitimate second temporal Root presenter existed.

## OBSERVER / VALIDATOR FINDINGS

- Historical Writer Audit had row-local flag/counter timing inconsistency.
- Correctness observer-heavy runs are not formal Performance Authority.
- Static validation proves marker/shape/invariant checks, not Unity Runtime correctness.
- Phase16.17 = STATIC PASS only.
- Future provider-normalization telemetry must expose:
  - raw provider pose
  - canonical normalized pose
  - downstream presentation pose
  - which layer applied handoff/resume offset
  - final Root pose

## FILES / SHA256

Phase16.9 Overlay:
`KiwiAvatarSystem_v5_1_0_Phase16_9_CommercialPresentationTransaction_Overlay.zip`
SHA256: `5867b036f8d46144a46082a614dd07a0fe85cc604bd51f140bdaf46eca3c7c6f`
Status: historical / superseded by later cumulative phases.
Verification: CHAT_RECORDED_SHA_NOT_REHASHED_AT_ARCHIVE_TIME.

Phase16.10 Overlay:
SHA256: `e888b4882e2c6a6ff46b68e9586fd6c78d607c38d0ec1ef9704172d5aff89c64`
Verification: CHAT_RECORDED_SHA_NOT_REHASHED_AT_ARCHIVE_TIME.

Phase16.10.1 Overlay:
SHA256: `9117c950a5d3ec22340e9d1dceffa17d242455e78477c5ce5466915ee08b95c7`
Verification: CHAT_RECORDED_SHA_NOT_REHASHED_AT_ARCHIVE_TIME.

Phase16.11 Overlay:
SHA256: `279d83a6357c4b171af085aaf9f759f399bacccacd0dc416698f54957d29c8eb`
Verification: CHAT_RECORDED_SHA_NOT_REHASHED_AT_ARCHIVE_TIME.

Phase16.12 Overlay:
SHA256: `8e7e642eecb38fad120e061a5dd4c38f1e68529c41c13e5c71c5cb24ddb3b870`
Verification: CHAT_RECORDED_SHA_NOT_REHASHED_AT_ARCHIVE_TIME.

Phase16.13 Overlay:
SHA256: `dd82cd582b5e7ce9a3b5da25f54d5df097e5ca76398839c41b8bc97fb3e9bd7a`
Verification: CHAT_RECORDED_SHA_NOT_REHASHED_AT_ARCHIVE_TIME.

Phase16.14 Overlay:
SHA256: `dbec1ad8669dfcc047ca60e3e3ce8c86cb00658cf12090dc13b6f502e3f9a056`
Verification: CHAT_RECORDED_SHA_NOT_REHASHED_AT_ARCHIVE_TIME.

Phase16.15 Overlay:
SHA256: `7e46d0aae0d500b60204d9d817e9fa729423d8b29ee9a98ad5bccf9daba19528`
Verification: CHAT_RECORDED_SHA_NOT_REHASHED_AT_ARCHIVE_TIME.

Phase16.16 Overlay:
`KiwiAvatarSystem_v5_1_0_Phase16_16_CommercialRootSpaceProviderHandoff_Overlay.zip`
SHA256: `e24cf46bacabbba09e05b0c81c4bd164cb592517accf3fb1046dd16894308963`
Status: static implementation; Runtime isolation incomplete.
Verification: CHAT_RECORDED_SHA_NOT_REHASHED_AT_ARCHIVE_TIME.

Phase16.17 Overlay:
`KiwiAvatarSystem_v5_1_0_Phase16_17_CommercialSinglePresentationAuthority_Overlay.zip`
SHA256: `5f10406e75cc34960ec28e67b41b16876b1dd78d04fcceed9e370482bcd9b6c6`
Status: latest generated cumulative overlay in this chat; Runtime pending.
Verification: CHAT_RECORDED_SHA_NOT_REHASHED_AT_ARCHIVE_TIME.

Phase16.17 Changed Full Files:
`KiwiAvatarSystem_Phase16_17_ChangedFullFiles.zip`
SHA256: `6bb96f1c94da0cfef3c5d856733075ea2613eba1d8be41ade97d16de35cfdf9e`
Verification: CHAT_RECORDED_SHA_NOT_REHASHED_AT_ARCHIVE_TIME.

Local Production SHA:
`NOT_AVAILABLE_IN_NORMAL_CHAT`

## RUNTIME EVIDENCE

Known exact CSV filenames referenced/analyzed in this chat include:
- `KiwiFrameComparison_20260823_011158.csv`
- `KiwiFrameComparison_20260823_072739.csv`
- `KiwiFrameComparison_20260823_104603.csv`
- `KiwiFrameComparison_20260823_111124.csv`

Corresponding same-run MP4 recordings were used for visual correlation.

Evidence classes:
- CORRECTNESS: source identity, frame/timestamp, provider, ROI, accepted/held/missing, Root pre/post cap, transaction state.
- PERFORMANCE: only clean benchmark run may become authority.
- VISUAL: MP4 frame-by-frame for Root jump/static rest/landmark lag/Eye-Mouth.
- STATIC_ONLY: overlay markers, delimiter, CSV parity, GUID, prohibited API, deterministic tests, ZIP integrity.

Large evidence files are not duplicated into this archive.

## CURRENT RESULT

Strong retained architecture:
- Face Landmarker Primary
- latest-frame
- Persistent ROI
- Stable 3-lane baseline
- Static Rest
- fresh-only onBeforeRender
- FaceParts same-sample transaction
- no Eye/Mouth→Root
- no global Kalman/strong LP
- no FIFO

Latest implemented Phase:
**Phase16.17 — Commercial Single Presentation Authority**

Runtime:
**VALIDATION_PENDING**

Latest critical issue:
**ProviderHub vs KiwiFaceMotion provider-normalization duplication may still violate “Provider normalization = 1 layer”.**

## OPEN ISSUES

1. Provider normalization owner duplication — HIGHEST PRIORITY.
2. Phase16.17 Runtime validation.
3. Remaining ≈90–110ms inference service time.
4. Camera input vs Avatar perceived latency clean benchmark.
5. Eye/Mouth and Root presentation-target-time coherence.
6. Provider handoff visual continuity after ownership consolidation.
7. Phase16.16 was not separately Runtime-validated.
8. Separate project track: v44.55.24 Pair-Bound Shadow Output Snapshot remains next step for CPU/preprocessing semantic investigation and is not superseded by this chat.

## NEXT ACTION

**Provider Normalization Ownership Audit before any new transition filter.**

Required:
1. Inspect actual local Production, not just generated overlay.
2. Record SHA256 of:
   - `KiwiTrackingProviderHub.cs`
   - `KiwiFaceMotion.cs`
   - `KiwiTrackingQuality10Controller.cs`
   - applied Phase16.15/16.16 migration outputs.
3. Build authority map:
   raw provider → canonical normalized provider → resume/switch normalization → Root presentation → final envelope.
4. Prove whether ProviderHub already removes the same offset Phase16.16 removes again.
5. Choose exactly one normalization owner.
6. Keep exactly one temporal Root presenter.
7. Unity compile + Full Preflight.
8. Matching CSV+MP4:
   - front static 5–10s
   - slow translation
   - fast/reversal
   - Yaw/Pitch/Roll
   - short no-frame
   - same-provider Resume
   - actual Provider Switch
   - Blink/Eye/Mouth
9. Acceptance:
   - Quality10 legacy Root writes = 0
   - no duplicated provider bridge
   - no >1 local-unit Root discontinuity during normal visible tracking
   - stale Prediction absent during hold
   - Static Rest non-regression
10. Correctness PASS後のみ、≈100ms Inference pathをclean Performance A/B。

Do NOT begin with:
- threshold change
- stronger smoothing
- deeper queue
- another bridge

## DO NOT CHANGE

Without new independent evidence:
- Face Landmarker Primary
- latest-frame/no FIFO
- Persistent ROI
- stable Native camera path
- Static Rest
- fresh-only onBeforeRender
- FaceParts transaction
- Head single rigid authority
- Eye/Mouth→Root prohibition
- no global Kalman
- no strong LP
- no blocking GPU wait
- no UpdateExternalTexture
- no D3D12 queue wait
- no tracking-math camera workaround
- no Production lane.input oracle
- no CPU Production before separate semantic PASS
- no commit/push without explicit request

Additional:
**Do not add another Provider Switch / Resume bridge until normalization ownership is closed.**

## HANDOFF

次チャットはこの順で開始する:

1. Latest generated Phase = **16.17**.
2. Phase16.17 solves duplicated temporal Root presentation:
   - KiwiFaceMotion = sole Root temporal presenter
   - Quality10 = policy/QoS/telemetry-only
3. Phase16.17 = STATIC PASS / RUNTIME PENDING.
4. Post-16.17 re-audit found:
   ProviderHub already has provider handoff/resume normalization, while FaceMotion has Phase16.15/16.16 bridges.
5. Next task is **Provider Normalization Ownership Audit**, not more smoothing.
6. Retain Persistent ROI / Stable 3-lane / Static Rest / fresh-only onBeforeRender / FaceParts transaction.
7. After ownership correctness PASS, profile remaining ≈90–110ms Inference latency.
8. Separate v44.55.x CPU/preprocessing investigation remains independent; project instructions currently point to v44.55.24 Pair-Bound Shadow Output Snapshot.

## PROJECT MASTER REPORT UPDATE CANDIDATES

Archive:
KiwiChat_CommercialTrackingPresentationArchitectureAudit_Updated_20260903-JST.zip

LastWorkUpdate:
2026-09-03 (DATE_ONLY)

Validated Decision:
Single temporal Root presentation owner required.

Rejected Approach:
Dual Quality10 + KiwiFaceMotion temporal Root presentation.

Superseded Conclusion:
3-lane depth alone explains ~100ms inference latency.

Open Issue:
ProviderHub vs KiwiFaceMotion provider-normalization duplication.

Next Action:
Provider Normalization Ownership Audit + Phase16.17 Runtime validation.

Do not claim local MASTER REPORT was modified from normal chat.

## ARCHIVE VALIDATION NOTE

This archive intentionally contains only this permanent report.
Large Runtime MP4/CSV evidence is indexed but not duplicated.
ZIP SHA256 is reported outside this Markdown after archive generation to avoid self-reference.
