# KiwiAvatarSystem Chat Permanent Report

ChatTopic: Native Camera metadata-driven color correction, Production source formalization, and Face Landmarker ImageReadMode audit  
ChatTitle: Native Camera Color / Production Mode 9 / CPUAsync Audit  
ArchiveName: KiwiChat_NativeCameraColorAndLandmarkerReadMode_Updated_20260830-JST.zip  
LastWorkUpdate: 2026-08-30  
LastWorkUpdatePrecision: DATE_ONLY  
ArchiveCreated: 2026-09-03T00:04:00+09:00  
ArchiveTimestampBasis: LAST_RELEVANT_WORK_BEFORE_ARCHIVE_REQUEST  
Project: D:\KiwiAvatarSystem  
Unity: 6000.0.80f1 / Windows / DX12  
CurrentInvestigationVersion: v44.44 observer cleanup after v44.43.1 Production formalization  
Status: PRODUCTION_ACCEPTED  

Archive: KiwiChat_NativeCameraColorAndLandmarkerReadMode_Updated_20260830-JST.zip  
Topic: NativeCameraColorAndLandmarkerReadMode  
Supersedes: frozen BT.709 Limited color assumption / display-side correction attempts / startup-log-only ImageReadMode=CPU interpretation  
SupersededBy: None for this topic as of the supplied 2026-09-02 integrated project authority.  
NextArchiveCandidate: ProductionOutputAuthority_v44_55_24 or later transaction/semantic work

---

## EXECUTIVE SUMMARY

This chat closed two Windows/DX12 camera-input questions without changing Tracking Core.

1. The Native/LIVE CAMERA color defect was traced to the frozen Native DLL converting UGREEN 1920x1080@60 NV12 as BT.709 Limited while Media Foundation reported BT.601 + Full nominal range. Range mismatch was the dominant source of black crush, excessive saturation, and red bias.
2. A metadata-driven Native implementation supporting BT.601/BT.709 × Full/Limited was reconstructed, compiled, ABI-checked, runtime-tested, formalized as project source, and installed as Production mode 9. Final Production runtime retained ~60 Hz Native source cadence with zero relevant blocking waits/failures/transaction regressions and corrected color.
3. The apparent `Image Read Mode = CPU` issue was audited observer-only. It was an early startup state; steady-state transitioned to `CPUAsync`. Windows `Delegate=CPU` was retained, while Unity Inference Engine GPU remained the fast primary path and MediaPipe remained auxiliary.
4. The v44.44 observer was removed successfully with `V44_44_ROLLBACK_PASS`.

No `KiwiFaceMotion.cs`, `KiwiInferenceFaceTracker.cs`, thresholds, smoothing, ROI, Root authority, or FaceTexture transaction rules were changed.

Later project-wide authority supplied on 2026-09-02 shows the broader project has advanced to v44.55.x semantic/transaction work, so this archive must not redirect future work back to Native color or CPUAsync unless new regression evidence appears.

## OBJECTIVE

- Fix degraded Native LIVE CAMERA color at the correct semantic boundary.
- Preserve Path B SystemMemoryNV12, latest-frame, fixed texture identity, timestamps/generation, session epoch, bounded lanes, and non-blocking behavior.
- Reconstruct maintainable Native source because the exact frozen DLL source/PDB was unavailable.
- Prove correctness with Runtime CSV + MP4 before Production adoption.
- Determine whether startup `Image Read Mode = CPU` represented steady-state behavior.
- Avoid speculative Tracking/Native optimization when observer or authority was uncertain.

## CONFIRMED FACTS

### Native media/color semantics

- Camera: UGREEN Camera 4K, 1920x1080@60, Native NV12.
- Media Foundation metadata for the tested mode:
  - nominal range = Full / 0_255
  - YUV matrix = BT.601
  - primaries = BT.709
- Matrix, nominal range, and primaries are separate semantics.
- Exact frozen Native DLL binary audit confirmed embedded BT.709 Limited conversion constants.
- Raw NV12 conversion isolation showed range mismatch dominated the observed visual defect; matrix mismatch was secondary.
- Display-side inverse/gamma/sRGB correction attempts were rejected because they introduced luminance/shadow errors rather than correcting the source semantic mismatch.

### v44.41 A/B/C/D runtime

A = frozen Original Native  
B = hard-coded BT.601 Full shadow  
C = reconstructed metadata-driven Native  
D = WebCamTexture reference

- 1,982 MP4 frames decoded/analyzed total.
- Original black crush reproduced.
- B and C removed the crush.
- C was closer than B to WebCam in saturation and R/G neutrality.
- Two validation gaps remained:
  - telemetry OFF, so no CSV authority
  - reconstructed C returned `sharedTier=1` due hard-coded proxy value

### v44.42 tier parity + telemetry

- Real `D3D12_FEATURE_D3D12_OPTIONS4.SharedResourceCompatibilityTier` query restored.
- C sharedTier = 2, matching A.
- Native Source: 60.19 Hz.
- Source timestamp median: 15.999 ms.
- Arrival median/P95: 16.059 / 17.963 ms.
- Capture GPU Wait delta: 0.
- Processing GPU Wait delta: 0.
- Processing failure delta: 0.
- Cross-system discard delta: 0.
- Epoch violation delta: 0.
- FaceTexture miss/hold delta: 0/0.
- Presentation texture identity remained stable.

Decision: metadata-driven color semantics acceptable for Production mode 9.

### v44.43 / v44.43.1 Production formalization

v44.43 first installer failed before Native compile due PowerShell `Copy-Item` destination layout semantics. This was an installer defect, not a Native source defect.

v44.43.1:
- corrected exact destination creation/copy behavior
- cleaned only SHA-matched known misplaced v44.43 files
- hardened rollback on later failure
- formalized source at `D:\KiwiAvatarSystem\Native\KiwiNativeCamera\Source\KiwiNativeCameraPlugin.cpp`
- source SHA256: `8C28F7A9E22DF9DA66455C37777069E5922037DB62AD7897DBDFEC8931975E03`
- rebuilt Production DLL SHA256: `8091265D91993B0082BFC63D55FFF8A18CC18AACA9B1F907E874E7011D8017E2`
- ABI: 66 exports
- HLSL compile: PASS
- user-run validator: 13 checks / 0 failed
- frozen rollback DLL SHA256: `DB590279E63D50246BBB9F2A25E51D5C6EB36FB2F6F6C423447459628E8C2177`

### v44.43 final Production runtime

- MP4: 697 frames analyzed.
- CSV: 1,252 rows analyzed.
- Native Source: 60.23 Hz.
- Presented: 38.94 Hz.
- Source timestamp median: 15.996 ms.
- Arrival median/P95: 16.086 / 17.758 ms.
- Capture GPU Wait: 0.
- Processing GPU Wait: 0.
- Processing failure: 0.
- Cross-system discard: 0.
- Epoch violation: 0.
- FaceTexture miss/hold delta: 0/0.
- sharedTier: 2.
- cameraGeneration fixed at 2 during run.
- sourceTextureId fixed at -552 during run.
- steady-state LIVE CAMERA: mean luma 125.78, p05 38.83, Y<16 0.029%, saturation 0.146, R/G 1.027.
- no visible corruption/freeze.

Decision: Native Camera metadata color fix Production accepted.

### v44.44 ImageReadMode audit

- Current Kiwi runner logs config early, then hybrid initialization can switch Windows to CPUAsync.
- v44.44 observer made no `config.ImageReadMode` writes.
- MP4: 847 frames analyzed.
- CSV: 1,515 rows analyzed.
- Effective transition: `CPU -> CPUAsync -> FINAL CPUAsync`.
- SentisHybridEnabled=1.
- SentisPrimaryActive=1.
- Native Source: 60.21 Hz.
- Source timestamp median: 16.004 ms.
- Arrival median/P95: 16.114 / 17.391 ms.
- Inference completed: 43.94 Hz.
- Canonical adoption: 43.07 Hz.
- MediaPipe auxiliary: ~10 Hz.
- readback latency median: 63.30 ms async.
- GPU waits: 0/0.
- processing failure: 0.
- Native drop delta: 0.
- cross-system discard: 0.
- epoch violation: 0.
- FaceTexture miss/hold delta: 0/0.

Decision: startup `Image Read Mode = CPU` is not a steady-state defect. CPUAsync already active; no Production mode change required.

Observer cleanup result: `V44_44_ROLLBACK_PASS`.

## PUBLIC DESIGN PRINCIPLES

### Microsoft Media Foundation / D3D

- YUV matrix and nominal range are independent media semantics.
- Active media-type metadata should be queried rather than inferred from camera identity or primaries.
- D3D12 shared-resource compatibility should be queried rather than replaced by a proxy/hard-coded value.

### libyuv/common conversion design

Public libyuv conversion constants distinguish BT.601 limited/full and BT.709 limited/full, supporting Kiwi's four-mode metadata model.

### MediaPipeUnityPlugin

- Face Landmarker configuration defaults to CPUAsync image read mode upstream.
- Windows/macOS sample delegate defaults to CPU.
- CPUAsync uses async texture readback rather than the synchronous CPU read path.
- A startup configuration log does not prove later effective state when application initialization mutates configuration.

### Unity readback principle

Synchronous GPU texture readback can create CPU/GPU synchronization; async readback is preferred when the application can consume asynchronously.

### Kiwi application

- Fix color at the Native YUV→RGB semantic boundary, not with presentation gamma compensation.
- Keep source, inference, and presentation cadences separate.
- Preserve latest-frame coalescing instead of forcing every 60 Hz source frame through a slower consumer.
- Do not optimize a startup-log proxy when Runtime already proves steady-state correctness.

## INFERENCES / HYPOTHESES

- Early in the chat, scaling/filtering/presentation quality was a candidate root cause; later binary/runtime evidence showed the dominant defect was Native range/matrix semantics.
- `ReadyReplacement` near source-minus-presented rate is consistent with intended latest-frame replacement when all-slots-busy/native-drop/failure remain zero and source age is healthy.
- Diagnostic modes 1–8 may have had useful historical meanings, but exact semantics were not recovered sufficiently to reconstruct safely.

These are not reasons to change Tracking Core.

## PRODUCTION AUTHORITY

Authority order used:
1. user-executed local Production SHA/validator output
2. same-Production Runtime CSV + Player.log + MP4
3. exact frozen DLL binary audit / reconstructed source-build evidence
4. actual Kiwi source/config behavior inspected during the chat
5. Microsoft / Unity / MediaPipeUnityPlugin / libyuv public docs/source
6. older diagnostics only when consistent with newer Runtime

At archive creation: `LOCAL_PRODUCTION_NOT_DIRECTLY_VERIFIED`.

Normal chat cannot freshly inspect `D:\KiwiAvatarSystem` at archive time; current state is grounded in user-run validation output and uploaded same-Production Runtime evidence.

The supplied 2026-09-02 integrated project authority shows the broader project later advanced to v44.55.x semantic/transaction work and still treats Native Camera/LIVE CAMERA as stable/closed. No newer supplied authority reverses this chat's accepted color/read-mode decisions.

## WORK PERFORMED

1. LIVE CAMERA path audit — narrowed color problem away from Tracking workarounds. PASS.
2. Media Foundation metadata audit — BT.601 + Full confirmed. PASS.
3. Frozen DLL binary shader audit — BT.709 Limited embedded conversion confirmed. PASS.
4. Raw NV12 conversion isolation — range mismatch dominant. PASS.
5. Display-side correction experiments — luminance/shadow regressions. REJECTED.
6. BT.601 Full binary shadow diagnostic — strong visual correction without cadence/transaction regression. PASS as diagnostic proof.
7. Native source reconstruction — full C++ candidate with 66-export ABI. PASS for Production mode 9 after Runtime.
8. v44.40.x build gate — incremental compile/link/validator issues fixed; v44.40.6 export failure reclassified as parser false negative. PASS after reparse.
9. v44.41 A/B/C/D — color success, but telemetry gap and sharedTier proxy defect discovered. PARTIAL PASS.
10. v44.42 A/C — sharedTier real query + telemetry; correctness PASS.
11. v44.43 source formalization — installer copy-layout failure before Native compile. INSTALLER FAIL, source not rejected.
12. v44.43.1 — installer corrected, formalized source rebuilt, 66 exports/HLSL/Unity validation PASS.
13. v44.43 final Production Runtime — ~60 Hz, zero relevant waits/failures, color stable. PRODUCTION ACCEPTED.
14. v44.44 observer — CPU→CPUAsync steady-state proved. PASS.
15. v44.44 rollback — observer removed. PASS.
16. Next-performance external research — OpenSeeFace discovery began, but no completed optimization decision before archive. INCOMPLETE.

## VALIDATED DECISIONS

### Decision: metadata-driven Native YUV conversion
Reason: active metadata and Runtime contradicted frozen BT.709 Limited hard-coding.  
Evidence: binary audit, raw NV12 isolation, v44.41 visual, v44.42 telemetry, v44.43 Production Runtime.  
Regression constraints: preserve Path B, latest-frame, stable texture identity, session epoch, no blocking waits, FaceTexture transaction safety.  
Still current: YES.

### Decision: Production Native mode 9 source formalized
Reason: v44.42 correctness PASS; v44.43.1 made it reproducible and rollback-safe.  
Evidence: source SHA, 66-export ABI, HLSL compile, Unity build, v44.43 Runtime.  
Still current: YES.

### Decision: diagnostic modes 1–8 remain E_NOTIMPL
Reason: exact historical semantics not recovered.  
Regression constraints: never silently alias them to mode 9.  
Still current: YES unless exact behavior is recovered and validated.

### Decision: keep Windows MediaPipe Delegate=CPU and steady-state ImageReadMode=CPUAsync
Reason: v44.44 directly proved CPUAsync steady-state; upstream config also defaults CPUAsync.  
Still current: YES.

### Decision: no display-side gamma/brightness correction
Reason: source semantic fix solved the root defect; display compensation created new luminance errors.  
Still current: YES.

## REJECTED APPROACHES

- Frozen BT.709 Limited conversion — contradicted media metadata and caused severe visual error.
- Permanent camera-specific BT.601 Full hard-code — correct only for the tested camera/media type; loses metadata authority.
- Display-side gamma/sRGB compensation — hid source error and introduced brightness/shadow regressions.
- Startup-log-only `Image Read Mode=CPU` diagnosis — disproved by v44.44 steady-state observer.
- Speculative Windows MediaPipe GPU delegate switch — unsupported/unnecessary with Inference Engine GPU primary.
- Tracking Core changes for camera/display behavior — authority violation and unnecessary.

## SUPERSEDED CONCLUSIONS

OLD: LIVE CAMERA color problem mainly scaling/filtering/presentation.  
NEW: dominant defect was Native BT.709 Limited conversion on BT.601 Full NV12.  
WHY: Media Foundation metadata + DLL binary audit + raw conversion isolation + Runtime.

OLD: hard-coded BT.601 Full could be final.  
NEW: metadata-driven 601/709 × Full/Limited is Production design.  
WHY: active media type must own color semantics.

OLD: `Image Read Mode = CPU` may be steady-state bottleneck.  
NEW: startup CPU transitions to steady-state CPUAsync.  
WHY: v44.44 observer.

OLD: v44.40.6 export count 0 / build-gate fail.  
NEW: candidate had exact 66/66 exports; validator regex was wrong.  
WHY: dumpbin Debug lines carried `= @ILT+...` suffix.

## OBSERVER / VALIDATOR FINDINGS

### v44.40.6 export parser false negative
Production/C++ defect: NO.  
Validator defect: YES.  
Cause: regex assumed export name was line terminator; Debug dumpbin appended ILT alias.  
Corrected: 66 exports exact ABI/order.

### v44.41 missing telemetry
Production defect: NOT ESTABLISHED.  
Run/observer configuration defect: telemetry OFF.  
Resolution: focused A/C rerun in v44.42.

### v44.43 Copy-Item path bug
Native source defect: NO.  
Installer defect: YES.  
Resolution: v44.43.1 exact target creation, SHA-guarded cleanup, automatic rollback hardening.

### v44.44 observer
Observer-only: YES.  
Writes to ImageReadMode: 0.  
Removed after proof: YES (`V44_44_ROLLBACK_PASS`).

## FILES / SHA256

### Frozen rollback Native DLL
Path: `D:\KiwiAvatarSystem\KiwiBackups\v44_43_20260830_102547\KiwiNativeCamera_FROZEN_ORIGINAL.dll`  
Role: pre-color-fix rollback authority  
SHA256: `DB590279E63D50246BBB9F2A25E51D5C6EB36FB2F6F6C423447459628E8C2177`  
State: obsolete as active Production; current as rollback artifact.

### BT.601 Full shadow diagnostic DLL
Role: diagnostic proof only  
SHA256: `11208718FC986800712AD7571B0FA6EF4E1C0CF79DCDC8D01F49A96AD2796EAC`  
State: obsolete diagnostic control.

### Formalized Native source
Path: `D:\KiwiAvatarSystem\Native\KiwiNativeCamera\Source\KiwiNativeCameraPlugin.cpp`  
SHA256: `8C28F7A9E22DF9DA66455C37777069E5922037DB62AD7897DBDFEC8931975E03`  
Role: Production mode 9 source authority from this chat.  
State: current for this chat; not freshly re-read at archive creation.

### ABI manifest
SHA256: `42F41F24B75E72A936A328FA79A314EEB59C8DB74BFD9EA1C94D4D55791B31B5`  
Role: 66-export ABI authority.

### HLSL validation source
SHA256: `B12D97A9D96C269670A5EA2C4104BB84528A93CF58023FF085B3594EF000DB71`.

### v44.43.1 accepted Production DLL
Path: `D:\KiwiAvatarSystem\Assets\Plugins\x86_64\KiwiNativeCamera.dll`  
SHA256: `8091265D91993B0082BFC63D55FFF8A18CC18AACA9B1F907E874E7011D8017E2`  
Role: rebuilt Production DLL accepted by final Runtime.

### Important generated packages
- `KiwiNativeCandidateBuildGate_v44_40_6.zip` — `380242ADAD560E312FA348AE51EAAE87D23CE5A58B2D8B0BDBC23FA3633EDDFF`
- `KiwiAvatarSystem_v44_41_MetadataNativeRuntimeABCD.zip` — `09EBA129CFC8D9FA85FEFBD5A67C340DCB6140D9A38BB9B82F698B3FD6143D01`
- `KiwiAvatarSystem_v44_42_MetadataTierParityTelemetry.zip` — `EAFCB0EDD1A7A4FDBFD6A938BD1479078D68C68E130A60542B6EEEC156DA31F3`
- `KiwiAvatarSystem_v44_43_ProductionMode9SourceFormalization.zip` — `C9D87CD3DACF5952E65E270CA7875EB2F68B4D0EAD6C0DAA343BBCF0A702719D`
- `KiwiAvatarSystem_v44_43_1_InstallerCopyFix.zip` — `E51A762D0CB286CA401684FD697ED982521E26F0098F406944C40EA867283CCA`
- `KiwiAvatarSystem_v44_44_LandmarkerReadModeRuntimeAudit.zip` — `010A3603B3E4652071C954711CB90A7F9EFFF43DA29C4547C149D61FADC0FBF3`
- v44.44 observer source — `BFB145A452E091CE8EE7E6F1A868D32A224EE323A35ECDF54AE49AE62A6FC0A3`

## RUNTIME EVIDENCE

### v44.41
Files: `KiwiAvatarSystem_v44_41_RUNTIME_RESULTS.zip` plus four 2026-08-30 MP4s (01-05-31 / 01-06-03 / 01-06-34 / 01-07-00).  
Authority: CORRECTNESS + VISUAL, but telemetry incomplete because OFF.  
SHA256: NOT_AVAILABLE_IN_NORMAL_CHAT.

### v44.42
File: `KiwiAvatarSystem_v44_42_TELEMETRY_RESULTS.zip` + A/C MP4s.  
Authority: CORRECTNESS + supporting cadence + VISUAL.  
Key result: 60.19 Hz, sharedTier=2, zero relevant waits/failures/transaction violations.  
SHA256: NOT_AVAILABLE_IN_NORMAL_CHAT.

### v44.43 final Production
Files: `KiwiAvatarSystem_v44_43_RUNTIME_RESULTS.zip`, `KiwiAvatarSystem 2026-08-30 10-45-46.mp4`, `KiwiFrameComparison_20260830_104540.csv`.  
Authority: CORRECTNESS + PRODUCTION ACCEPTANCE + VISUAL.  
MP4 frames: 697. CSV rows: 1,252.  
SHA256: NOT_AVAILABLE_IN_NORMAL_CHAT.

### v44.44 observer
Files: `KiwiAvatarSystem_v44_44_RUNTIME_RESULTS.zip`, `KiwiAvatarSystem 2026-08-30 10-56-20.mp4`, `KiwiFrameComparison_20260830_105619.csv`.  
Authority: CORRECTNESS OBSERVER ONLY; not a clean Performance benchmark.  
MP4 frames: 847. CSV rows: 1,515.  
Key result: CPU→CPUAsync steady-state transition.  
SHA256: NOT_AVAILABLE_IN_NORMAL_CHAT.

## CORRECTNESS / PERFORMANCE / VISUAL / PROVENANCE

Correctness accepted:
- metadata color semantics
- mode 9 Native path
- sharedTier query
- stable source/session identity
- no relevant blocking waits/failures/discards/epoch errors
- CPUAsync steady-state

Performance:
- clean final Production run confirms no gross Native cadence regression (~60 Hz).
- do not use v44.44 observer-heavy readback metrics as formal performance authority.

Visual:
- black crush / excess saturation / red bias removed.
- no final Production corruption/freeze.

Provenance:
- improved from unrecovered frozen source to formalized project source + exact SHA + reproducible build + 66-export ABI + HLSL probe + frozen rollback DLL.
- known limitation: diagnostic modes 1–8 historical behavior unrecovered.

## CURRENT RESULT

Chat-local status: `PRODUCTION_ACCEPTED`.

- Native Camera metadata color correction: CLOSED.
- Production mode 9 source: FORMALIZED and Runtime accepted.
- `Image Read Mode = CPU` concern: CLOSED; steady-state is CPUAsync.
- Windows MediaPipe Delegate: retain CPU.
- v44.44 observer: removed successfully.
- No Tracking Core change required.

Broader project state: the supplied 2026-09-02 integrated instructions show development moved to v44.55.x Production Output Transaction / preprocessing semantic investigation. This archive must not send a future chat back to Native color or CPUAsync optimization without new evidence.

## OPEN ISSUES

Chat-local residual:
1. `StartDiagnostic` modes 1–8 remain E_NOTIMPL. This is not a Production mode 9 failure. Do not invent historical semantics.

A generic next-performance survey (including OpenSeeFace external research) started at the very end of the chat, but no accepted optimization decision resulted before archive.

Later project-wide authority supersedes that generic next step with v44.55.24 Pair-Bound Shadow Output Snapshot.

## NEXT ACTION

For this archived theme: no further Native color or ImageReadMode work unless new independent regression evidence appears.

For the broader project, use the newer 2026-09-02 integrated authority. Current priority:
`v44.55.24 Pair-Bound Shadow Output Snapshot`.

Goal: remove Worker output lifecycle/allocator race as a possible explanation of v44.55.23 `ANOMALOUS_NEITHER_EXACT` before further CPU Production/preprocessing conclusions.

Do not resume the preliminary OpenSeeFace performance survey ahead of that higher-authority semantic/transaction task.

## DO NOT CHANGE

Without new independent evidence:
- Face Landmarker Primary / Source of Truth
- `KiwiFaceMotion.cs` as camera/performance workaround
- `KiwiInferenceFaceTracker.cs` tracking math as camera/performance workaround
- Path B SystemMemoryNV12
- latest-frame priority
- stable Unity-visible presentation texture identity
- cameraGeneration session-epoch semantics
- timestamp/generation transaction rules
- FIFO/stale queues
- `UpdateExternalTexture`
- IMFSample retention across callback/worker
- Unity D3D12 queue Wait
- CPU blocking fence wait
- D3D11On12 1080p Camera Production
- metadata-driven BT.601/BT.709 × Full/Limited
- steady-state CPUAsync
- Windows MediaPipe Delegate=CPU
- display-side gamma/brightness hacks
- strong smoothing/Kalman/threshold relaxation as root-cause masking
- diagnostic modes 1–8 semantics by guesswork

## PROJECT MASTER REPORT UPDATES TO CARRY FORWARD

Validated Decisions:
- metadata-driven Native color conversion Production accepted
- v44.43.1 Production mode 9 source formalized
- rebuilt Production DLL accepted by Runtime
- CPUAsync steady-state confirmed; no ImageReadMode fix needed
- Windows MediaPipe Delegate=CPU retained
- v44.44 observer removed after proof

Rejected Approaches:
- BT.709 Limited fixed conversion
- permanent camera-specific BT.601 Full hard-code
- display-side gamma/sRGB compensation for YUV semantic mismatch
- startup-log-only CPU read-mode diagnosis
- speculative Windows MediaPipe GPU delegate switch

Open Issue:
- diagnostic modes 1–8 historical behavior unrecovered

Archive: `KiwiChat_NativeCameraColorAndLandmarkerReadMode_Updated_20260830-JST.zip`  
LastWorkUpdate: 2026-08-30 DATE_ONLY  
Status: PRODUCTION_ACCEPTED

## HANDOFF

A future chat can treat these as established for this archived topic:

1. Native Camera Production source cadence is ~60 Hz, not the old 13–20 Hz condition.
2. The old LIVE CAMERA color defect was a YUV semantic mismatch, not a Tracking defect.
3. Production color conversion is metadata-driven BT.601/709 × Full/Limited.
4. Formalized source SHA: `8C28F7A9E22DF9DA66455C37777069E5922037DB62AD7897DBDFEC8931975E03`.
5. Accepted rebuilt Production DLL SHA: `8091265D91993B0082BFC63D55FFF8A18CC18AACA9B1F907E874E7011D8017E2`.
6. Frozen rollback DLL SHA: `DB590279E63D50246BBB9F2A25E51D5C6EB36FB2F6F6C423447459628E8C2177`.
7. Runtime accepted with ~60 Hz Native source and no relevant blocking wait/transaction regression.
8. Startup `Image Read Mode = CPU` is not steady-state authority.
9. v44.44 proved steady-state CPUAsync with hybrid active.
10. Observer was removed with `V44_44_ROLLBACK_PASS`.
11. Do not reopen Native color/read-mode work without new regression evidence.
12. Broader project authority has since advanced. As of the supplied 2026-09-02 instructions, next project priority is v44.55.24 Pair-Bound Shadow Output Snapshot.

Before any future local Production change, verify actual placement + SHA + dependencies. Do not assume archived SHA remains current without checking local Production.

## CHAT ARCHIVE INDEX

Archive: `KiwiChat_NativeCameraColorAndLandmarkerReadMode_Updated_20260830-JST.zip`  
Topic: NativeCameraColorAndLandmarkerReadMode  
LastWorkUpdate: 2026-08-30  
LastWorkUpdatePrecision: DATE_ONLY  
Status: PRODUCTION_ACCEPTED  
Supersedes: frozen BT.709 Limited Native color conversion; display-side color workaround attempts; startup-log-only CPU read-mode diagnosis  
SupersededBy: None for this topic as of the supplied 2026-09-02 integrated project authority.  
NextArchiveCandidate: v44.55.24 Production Output Transaction Authority / Pair-Bound Shadow Output Snapshot

## ARCHIVE SELF-AUDIT

- Archive timestamp uses last known technical-work date, not archive-request date: PASS
- Exact final technical-work time unavailable: DATE_ONLY used; no guessed time
- ArchiveCreated separated from LastWorkUpdate: PASS
- Confirmed facts / public principles / inferences separated: PASS
- Current vs obsolete conclusions separated: PASS
- Observer/validator defects separated from Production defects: PASS
- Correctness / Performance / Visual / Provenance separated: PASS
- Unknown evidence SHA values marked NOT_AVAILABLE_IN_NORMAL_CHAT: PASS
- Local Production not falsely claimed as directly inspected at archive creation: PASS
- Later project-wide authority used to avoid stale Next Action: PASS
- One primary report file only: PASS
