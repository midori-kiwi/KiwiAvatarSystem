# KiwiAvatarSystem 次チャット引継ぎ情報
基準: 2026-08-31 JST / v44.55.13 FIX2 STATIC_ALL_PASS

## 現在地
次は v44.55.14。
目的は Production GPU authority を維持したまま、CPU backend の semantic / latency / cadence / safety を1回の統合runtime A/Bで最終確認すること。

## 最重要結論
- v44.54: 同一float入力なら CPU/GPU backend 出力はほぼ完全一致。
- v44.55.10: Production cropTextureのframe-content race確認。外れ値5/5がS+1/S+2で正常化。
- v44.55.11: identity補正は完全成功したが raw STRONG gate未達。landmark p95=0.776px, within1px=98.77%, presence sigmoid p95=0.02973, decision mismatch=0。
- v44.55.12: D3D fixed-point subtexelはNOT_SUPPORTED。FULL_FLOATが全体最良。
- v44.55.13 FIX2: Source guard 29/29 PASS / Unity compile PASS / Editor static audit PASS / critical hash recheck PASS / STATIC_ALL_PASS。

## v44.55.13 FIX2
ZIP SHA256:
1A2C24F4E28ED4EC307DAD5849CADDC9DAA7765F8AAD79A62ADBEB571EA16CCA

Observer:
299C192FE609F59515345D9395B5FE413A551D9CD58E90EBEB4FF7251D46FBDF

Editor:
5C56006675B765B10EFA444DE85C57C405883FAF05C9D16813630D0B02E5540E

Native:
636D76251F9CB3BB785F4497D3D0722033FC0CE36CB4A574B65EDA58B5ABE32A

Interop:
AC473ADBADE5EDC89726211ECAF03D040B5CC00FCA39BEA4A0D16195FA53E8B5

## v44.55.14方針
- static-first / static-max
- Production GPU remains authority
- CPU shadow only
- tracking/ROI/threshold/FaceTexture writes禁止
- 静的に証明できない項目だけruntimeで測る
- 実測時間は短くなくてよい
- 実測回数を最小化する
- 可能なら1回の長めのCSV+MP4で全runtime gateを回収
- pass後のみCPU Production promotion検討

## 必須runtime観測候補
semantic landmark geometry
presence decision parity
accepted/rejected parity
CPU service/E2E
source/canonical/presented Hz
FaceTexture miss/hold/match delta
stale/cross-system/authority/epoch violations
Native drop/failure/GPU wait
Spout final
MP4全フレーム順次解析

## 絶対維持
Face Landmarker primary
latest-frame only
no FIFO
no blocking GPU wait
no UpdateExternalTexture
no IMFSample retention
fixed KiwiNativeCameraPresentation identity
cameraGeneration=session epoch
strict FaceTexture transaction
tracking math/threshold/smoothingをperf workaroundに使わない

Local Production:
LOCAL_PRODUCTION_NOT_DIRECTLY_VERIFIED
