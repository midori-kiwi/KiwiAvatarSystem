# KiwiAvatarSystem 恒久REPORT
Archive: KiwiChat_CPUBackendSemanticAudit_Updated_20260831-JST
ArchiveTimestampMode: DATE_ONLY
LastRelevantTechnicalWorkDate: 2026-08-31 JST
ReportCreatedAt: 2026-09-03 JST
Status: ACTIVE / HANDOFF_READY
LocalProductionVerification: LOCAL_PRODUCTION_NOT_DIRECTLY_VERIFIED

## 1. Executive Summary

本チャットでは、KiwiAvatarSystem の Windows / Unity 6 / DX12 Production inference を、将来的に CPU backend へ切り替えられるかを、安全性・入力同一性・数値同等性・実運用semanticの順で監査した。

主要結論:

1. v44.55.10 で Presentation Texture の frame-content race を実証した。Production lane metadata が sequence S を示していても、cropTexture 実画素が稀に S+1 / S+2 に進んでいた。5件の外れ値すべてで近傍sequenceへ切り替えると約 0.040～0.044 LSB まで一致した。よって残差の主要原因の1つは sampling/color ではなく frame identity / content ownership race。

2. v44.55.11 で identity-corrected Native input と frozen Production crop を使い、CPU Worker / GPUCompute Worker の raw output equivalence を再評価した。identity補正は完全成功したが、設定した STRONG gate は未達。landmark2d p95 0.776 px、1px以内 98.77%、presence sigmoid p95 0.02973。Production CPU切替は保留。

3. v44.55.12 で D3D fixed-point subtexel sampling FULL_FLOAT / 16.8 / 16.9 / 16.10 / 16.12 を比較した。FULL_FLOAT が全体最良で、fixed-point snap は改善せず NOT_SUPPORTED。subtexel座標量子化追跡は終了。

4. v44.55.13 では「静的検証を最大限優先」へ方針変更。FIX1 は同名ファイル探索誤前提を修正したが、observer生成時の literal \n 混入で Unity compile failure。FIX2 で164個の誤埋め込み改行を修復し、source guard 29/29 PASS、Unity実コンパイル PASS、Editor static audit PASS、Production critical hash再照合 PASS。v44.55.13 FIX2 の静的correctness gate は完全PASS。

5. 次は v44.55.14。実測は「時間を最小化する」のではなく「回数を最小化する」。静的検証で可能な限り事前に潰し、必要なruntime項目を1回の十分長い統合A/Bへまとめる。

## 2. Objective

- Production GPU inference authority を壊さず、CPU backend が実運用semantic上 Production GPU と同等に扱えるかを証明する。
- CPU化は性能目的だけでなく、GPU async readback / queue completion floor の回避可能性も評価する。
- Tracking Core / ROI / threshold / smoothing / FaceTexture transaction の既存correctnessを犠牲にしない。

## 3. Confirmed Facts

### Environment
- Project: D:\KiwiAvatarSystem
- Unity: 6000.0.80f1
- Windows / DX12
- Ryzen 9 5950X / RTX 4090
- MediaPipeUnityPlugin v0.16.3
- UGREEN Camera 4K / 1920x1080@60 / Native NV12
- Active Scene: Face Landmark Detection

### Frozen Production architecture
- Face Landmarker remains primary/source of truth.
- Production inference: 3 GPUCompute lanes.
- O25 mesh: 1,017,188 → 254,296 tris / 508,601 verts / 5 blendshapes / 17 bones / resultError 0.000386 / shared mesh identity preserved.
- Native camera Production Path B: MF Source Reader without D3D manager → system-memory NV12 → latest CPU buffer → immediate sample release → GPU upload → fixed KiwiNativeCameraPresentation.

### v44.54 backend equivalence baseline
Exact same host float input:
- CPU median ~11.81 ms
- GPU median ~40.53 ms
- landmark2d p95 ~0.000038 px
- presence sigmoid p95 ~4.35e-7

Conclusion: CPU/GPU backend math itself is effectively equivalent when input floats are identical.

### v44.55.10 frame identity proof
- 5/5 outliers resolved by non-target neighbor.
- target ~3.4 LSB
- best neighbor ~0.040–0.044 LSB
- identityNeighborWins=5 / identityTargetWins=0 / identityNeighborUnder0.5=5
- API failure=0 / snapshotTensorMismatch=0
- winning roles were S+1 or S+2.

### v44.55.11 identity-corrected CPU/GPU raw output
- identity-corrected input mean 0.04593 LSB / p95 0.05104 / max 0.05375 / all <0.5 LSB
- Presentation race 13/13 corrected
- CPU service median 9.37 ms / p95 12.89 ms
- GPU service median 39.38 ms / p95 54.43 ms
- CPU ~1 frame / GPU ~3 frames
- landmark2d p95 0.776 px
- within1px 98.77%
- presence sigmoid p95 0.02973
- presence decision mismatch 0 / far-threshold mismatch 0

Conclusion: Near-pass but STRONG gate failed. Do not switch Production to CPU based on v44.55.11 alone.

### v44.55.12 D3D fixed-point subtexel audit
- status COMPLETE / 55 measured pairs
- errors/nonfinite/API failure=0
- identity outliers 2 / neighbor wins 2/2
- global mean MAE: FULL_FLOAT 0.056946582 / 16.8 0.057583978 / 16.9 0.057425328 / 16.10 0.057168364 / 16.12 0.056995739 LSB
- best counts: FULL_FLOAT 44 / 16.8 0 / 16.9 0 / 16.10 1 / 16.12 10

Conclusion: SUBTEXEL_PARITY_NOT_SUPPORTED. Do not adopt fixed-point subtexel snap.

Concurrent v44.47 steady-state:
- renderHz 83.3294
- CPU Main median 10.6111 ms / p95 16.3093
- CPU Total median 11.2360 ms / p95 16.5218
- GPU median 5.0921 ms / p95 8.2811
- Camera.Render median 7.1946 ms / p95 9.8376
- Graphics.Blit median 0.2705 ms / p95 0.4599
- GfxDeviceD3D12.WaitForGPU=0

### v44.55.13 FIX2 static-first gate
User-executed result:
- Apply PASS
- Production critical files unchanged: 5
- Source guard 29/29 PASS
- Unity batchmode actual compilation PASS
- Editor static audit PASS
- Critical hash recheck PASS
- V44_55_13_FIX2_STATIC_ALL_PASS
- Runtime CSV/MP4 not required at this stage

## 4. Public Design Principles

- Unity Inference Engine / Sentis: Worker backend can be CPU or GPUCompute; Schedule is asynchronous; async readback/lifecycle requires ownership-safe reuse.
- Direct3D: linear filtering has defined texel-center/subtexel behavior; minimum addressing precision does not imply manual CPU 16.8 snapping reproduces hardware bit-for-bit.
- MediaPipeUnityPlugin: GPU texture copy/readback timing requires explicit ownership/synchronization reasoning; frame-delay heuristics are not correctness guarantees.
- Delegate-class systems such as TFLite: CPU/GPU may have small floating differences; final suitability should be judged at task/semantic level.
- Commercial VTuber software does not publicly expose enough internal detail to prove exact backend/sampler implementation. Public facts and inference must remain separate.

## 5. Inferences

Strong inference:
- v44.54 + v44.55.10 indicate backend math is not the root problem and mutable Presentation/crop ownership can produce wrong-frame content.
- Exact input identity must be established before CPU/GPU semantic comparison.

Current inference:
- Remaining ~0.05 LSB input residual is small but can be amplified by the model.
- Fixed-point subtexel search is low-value and closed.

Not yet proven:
- CPU backend can replace Production GPU authority without semantic/latency/cadence regression.
- Presence/landmark differences from v44.55.11 are harmless under real adoption.
- Sustained CPU Production path preserves 60 Hz source cadence and strict FaceTexture behavior.

## 6. Validated / Rejected / Superseded Decisions

Validated:
- v44.54 identical-input backend equivalence.
- v44.55.10 frame-content race confirmed.
- identity-aware matching mandatory for future CPU/GPU comparisons.
- v44.55.13 FIX2 static-first methodology.
- Production critical SHA guards.
- Unity actual compile must be included before final static PASS.
- Static validation should be maximized before runtime testing.

Rejected:
- CPU Production switch based on v44.55.7 or v44.55.11 alone.
- old external lane.input readback mismatch as color/chroma proof.
- D3D fixed-point subtexel snap as parity fix.
- filename uniqueness assumption for Production source resolution.
- source-string checks alone as sufficient static validation.

Superseded:
- v44.55.13 original → FIX1.
- v44.55.13 FIX1 → FIX2 due literal \n generation bug.
- runtime duration minimization → superseded. Current rule: runtime measurement COUNT should be minimal; duration may be long enough for strong evidence.

## 7. Observer / Validator Findings

FIX1 issue:
- resolver incorrectly required exactly one KiwiInferenceFaceTracker.cs; same-name duplicates existed.
- canonical exact path resolution fixed this.
- after 29/29 source guard PASS, Unity compile exposed observer syntax corruption.

FIX2 root cause:
- 164 literal \n sequences inserted instead of real newlines.

FIX2 changes:
- repaired all 164 corruptions
- lexical/delimiter validation
- explicit escaped-newline guard
- compile required before final PASS
- Production critical SHA rechecked after Unity batchmode

User result: complete static PASS.

## 8. Files / SHA256

v44.55.10 ZIP
EB4E275DB26D308666B41C5437A96B9D2FF6E7B66DADA13C76B262B26F849CC4
Native 367D6407803220DD141587F16B2F8A4B76E908B53A1A558C67882BB6BE285959
Interop 3309490628D44BA2FC57718E81B25C6C31E9672252E5127D51DA9D292738E163
Observer 3D57C7392CDCC5FF264CCEC68EC09B2B10A8851498C85AC98095496238E60A99

v44.55.11 ZIP
B976206BEAD21083BF6905A09F80EB78FBAF676636FB79642AA5B6EAA349CFD5

v44.55.12 ZIP
7D1AD278F1F9C53A19E02550AEA1BE0DF202A74832F8EC4AA981F04E6F253B8A
Native 636D76251F9CB3BB785F4497D3D0722033FC0CE36CB4A574B65EDA58B5ABE32A
Interop AC473ADBADE5EDC89726211ECAF03D040B5CC00FCA39BEA4A0D16195FA53E8B5

v44.55.13 original ZIP
0590978B65A71598DB89A82A2C4F042B9712EDF86CAA09DDA1752D4ACE5AECA8

v44.55.13 FIX1 ZIP
F4664C4FAC2AB158DBE29EC9FE47967F59333EBF6042F3383415B25DB57BA58C
Status: SUPERSEDED

v44.55.13 FIX2 ZIP
1A2C24F4E28ED4EC307DAD5849CADDC9DAA7765F8AAD79A62ADBEB571EA16CCA
Observer 299C192FE609F59515345D9395B5FE413A551D9CD58E90EBEB4FF7251D46FBDF
Editor 5C56006675B765B10EFA444DE85C57C405883FAF05C9D16813630D0B02E5540E
Native unchanged 636D76251F9CB3BB785F4497D3D0722033FC0CE36CB4A574B65EDA58B5ABE32A
Interop unchanged AC473ADBADE5EDC89726211ECAF03D040B5CC00FCA39BEA4A0D16195FA53E8B5

Production critical local SHA values are guarded in:
D:\KiwiAvatarSystem\KiwiValidation\v44_55_13_critical_hashes.txt

Normal chat did not directly inspect the user's local Production filesystem.
Local Production status: LOCAL_PRODUCTION_NOT_DIRECTLY_VERIFIED

## 9. Runtime Evidence

- v44.55.10: frame identity race confirmed; 5/5 outlier neighbor wins; prior MP4 sequential analysis showed no black frames/exact duplicates/obvious corruption.
- v44.55.11: identity correction succeeded; CPU faster than GPU readback path; raw semantic STRONG gate failed narrowly on landmarks and more clearly on presence.
- v44.55.12: 55 measured pairs; fixed-point candidates did not improve FULL_FLOAT; concurrent v44.47 healthy; WaitForGPU=0.
- v44.55.13: no runtime evidence required yet; FIX2 static-only gate completed successfully.

Evidence separation:
- Correctness: v44.54 / v44.55.10 / v44.55.11 / v44.55.13 FIX2
- Performance: v44.47 + CPU/GPU service timings
- Visual: prior MP4 sequential analyses
- Provenance: package hashes + local critical hash manifest

Observer-heavy runs must not be treated as pure Production performance authority.

## 10. Open Issues

1. CPU Production semantic equivalence not yet fully proven.
2. v44.55.11 presence sigmoid p95 exceeded STRONG threshold despite no decision mismatch.
3. Remaining ~0.05 LSB residual source unresolved; fixed-point subtexel rejected.
4. Need to test accepted/rejected parity, landmark task geometry, presence decisions, FaceTexture strict transaction, cadence, stale/drop counters, E2E latency.
5. LIVE CAMERA visual-quality issue remains future work; tracking changes are not acceptable workaround.
6. Production mutable Presentation frame-identity race is diagnosed but not yet redesigned in Production.

## 11. Next Action

Create v44.55.14 Static-Max + Single-Run Integrated CPU Semantic A/B.

Required sequence:
1. Reconfirm official guidance relevant to CPU/GPU worker scheduling and task-level equivalence.
2. Compare v44.55.13 static contract with current Production code.
3. Enumerate every remaining condition not provable statically.
4. Add static guards for all provable conditions.
5. Build one integrated runtime A/B that captures all remaining semantic/performance/safety evidence in a SINGLE run.
6. Minimize runtime run COUNT, not runtime duration.
7. GPU remains authority throughout v44.55.14.
8. Only after v44.55.14 PASS consider Production CPU-authority package.

Suggested single-run evidence:
- CPU shadow vs Production GPU semantic landmark geometry
- presence decision parity
- accepted/rejected parity
- CPU service/E2E latency
- source/canonical/presented Hz
- FaceTexture miss/hold/match delta
- stale/cross-system/authority/epoch violations
- Native drop/failure/GPU wait
- Spout final
- one sufficiently long MP4 + CSV

## 12. Do Not Change

- Face Landmarker remains primary/source of truth.
- Do not change KiwiFaceMotion.cs / KiwiInferenceFaceTracker.cs tracking math as camera/performance workaround.
- No threshold relaxation.
- No strong smoothing/global Kalman.
- Root unaffected by yaw/pitch/roll/eyes/mouth.
- Latest-frame only; no FIFO.
- Preserve strict FaceTexture same-sample transaction.
- cameraGeneration remains session/texture identity epoch.
- Unity-visible texture identity remains fixed KiwiNativeCameraPresentation.
- Never g_unityD3D12Queue->Wait(...).
- Never UpdateExternalTexture.
- Never hold IMFSample across callback/worker.
- Never rotate Unity-visible texture identity.
- Never D3D11On12 1080p Production.
- Never CPU-blocking GPU waits.
- Do not promote observer-heavy performance measurements to Production performance authority.
- Do not invent local Production SHA.

## 13. Handoff

Current authoritative development point:
v44.55.13 FIX2 STATIC_ALL_PASS.

Immediate continuation:
Design v44.55.14 Static-Max + Single-Run Integrated CPU Semantic A/B.

User runtime preference:
- static validation should do as much as possible,
- runtime measurement duration does NOT need to be minimal,
- runtime measurement COUNT should be minimal,
- prefer one long integrated run over multiple short repeated runs.

Do not rerun v44.55.10–v44.55.12 unless a new regression requires it.
Do not revisit fixed-point subtexel sampling.
Do not switch Production CPU authority before v44.55.14 integrated evidence passes.
